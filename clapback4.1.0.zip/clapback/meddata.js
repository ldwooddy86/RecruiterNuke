/*
 * Clapback — medical bills & credit dataset  (window.CBM)
 *
 * CHARTER, unchanged: everything here works on YOUR OWN bills, YOUR OWN
 * insurance, YOUR OWN credit file, and lawsuits filed against YOU. It profiles
 * no one. It makes no network requests. Every external check is an ordinary
 * link you choose to open.
 *
 * ACCURACY RULES THIS FILE FOLLOWS — they matter more here than anywhere else
 * in Clapback, because a wrong deadline in a lawsuit is a default judgment:
 *
 *   1. Every legal claim carries a primary source (statute, regulation, or the
 *      agency's own page). Verified live August 22, 2026.
 *   2. Anything that could NOT be verified against a primary source is marked
 *      v:false and the UI says so out loud instead of printing a number.
 *      A confident wrong number is worse than an honest gap.
 *   3. No fabricated URLs. Where a page moves often, we link the stable parent
 *      page rather than a deep link that will rot.
 *   4. Withdrawn guidance and vacated rules are labeled as such. In 2025 the
 *      CFPB withdrew its entire debt-collection guidance library and a court
 *      vacated the medical-debt credit reporting rule — much of the internet
 *      still describes both as live law. Clapback does not.
 *
 * Last researched and URL-verified: August 22, 2026.
 */
window.CBM = (function () {
  "use strict";

  var UPDATED = "August 22, 2026";

  /* ================================================================== */
  /* FEDERAL POVERTY GUIDELINES — 2026                                   */
  /* 91 FR 1797 (Jan. 15, 2026), effective Jan 13, 2026.                 */
  /* Publication of record: govinfo. ASPE blocks automated fetch.        */
  /* Arithmetic self-checked: every step equals the stated increment.    */
  /* ================================================================== */
  var FPL = {
    year: 2026,
    src: "https://www.govinfo.gov/content/pkg/FR-2026-01-15/html/2026-00755.htm",
    srcName: "HHS Poverty Guidelines, 91 FR 1797 (Jan 15, 2026)",
    contiguous: { base: 15960, add: 5680 },
    AK: { base: 19950, add: 7100 },
    HI: { base: 18360, add: 6530 },
    note: "These update every January. Charity care and financial assistance thresholds are almost always written as a percentage of these numbers."
  };

  /* Household size n → annual guideline for the user's state. */
  function fplFor(size, st) {
    var t = st === "AK" ? FPL.AK : st === "HI" ? FPL.HI : FPL.contiguous;
    var n = Math.max(1, Math.min(30, parseInt(size, 10) || 1));
    return t.base + (n - 1) * t.add;
  }

  /* ================================================================== */
  /* NO SURPRISES ACT — consumer protections                             */
  /* ================================================================== */
  var NSA = {
    helpDesk: "1-800-985-3059",
    helpDeskHours: "8am–8pm ET weekdays, 10am–6pm ET weekends. English, Spanish, and 350+ languages.",
    helpDeskSrc: "https://www.cms.gov/medical-bill-rights/help/plan/call-help-desk",
    complaint: "https://www.cms.gov/medical-bill-rights/help/submit-a-complaint",
    hub: "https://www.cms.gov/medical-bill-rights",
    ppdr: "https://www.cms.gov/medical-bill-rights/help/dispute-a-bill",
    keyProtectionsPdf: "https://www.cms.gov/files/document/nsa-keyprotections.pdf",
    ppdrThreshold: 400,
    ppdrDays: 120,
    ppdrFee: 25,
    gfeDaysShort: 1,   // scheduled >= 3 business days out -> GFE within 1 business day
    gfeDaysLong: 3,    // scheduled >= 10 business days out -> GFE within 3 business days
    /* What the ban actually covers. */
    covered: [
      { k: "Emergency services", t: "Out-of-network emergency care — including screening, stabilization, and certain post-stabilization care — cannot be balance billed. No prior authorization can be required, even out of network.", cite: "45 CFR 149.410; 149.110", url: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-149/subpart-E/section-149.410" },
      { k: "Out-of-network providers at an in-network facility", t: "The anesthesiologist, radiologist, pathologist, or assistant surgeon you never chose cannot balance bill you at an in-network hospital, hospital outpatient department, ambulatory surgical center, or critical access hospital.", cite: "45 CFR 149.420", url: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-149/subpart-E/section-149.420" },
      { k: "Air ambulance", t: "Covered out-of-network air ambulance cannot balance bill you — and there is no consent exception at all. This protection cannot be waived.", cite: "45 CFR 149.440", url: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-149/subpart-E/section-149.440" },
      { k: "Your cost sharing counts", t: "What you pay under these protections must be applied to your in-network deductible and in-network out-of-pocket maximum.", cite: "45 CFR 149.110", url: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-149/subpart-B/section-149.110" },
      { k: "Bad provider directory", t: "Plans must verify directory accuracy every 90 days. If wrong directory information sent you out of network, you are refunded anything above in-network cost sharing.", cite: "CMS key protections", url: "https://www.cms.gov/files/document/nsa-keyprotections.pdf" },
      { k: "Continuity of care", t: "Up to 90 days of continued in-network benefits when your provider leaves the network mid-treatment for a serious or complex condition, pregnancy, or scheduled surgery.", cite: "CMS key protections", url: "https://www.cms.gov/files/document/nsa-keyprotections.pdf" }
    ],
    /* The gaps. Being honest about these is the point. */
    gaps: [
      { k: "Ground ambulance is still NOT covered", t: "Confirmed still true in 2026. There is no federal balance-billing protection for ground ambulance. A 2024 federal advisory committee recommended a fix; Congress has not acted. Roughly 22 states have passed their own partial protections — check yours. CMS's own page still lists a 10-state roster dated November 2021, which is five years stale; don't rely on it.", url: "https://www.cms.gov/medical-bill-rights/help/plan/insurance-ground-ambulance-bill" },
      { k: "Medicare, Medicaid, TRICARE, IHS, and VA are outside the NSA", t: "Those programs have their own, generally stronger, balance-billing rules. The NSA governs private and employer coverage.", url: "https://www.cms.gov/newsroom/fact-sheets/no-surprises-understand-your-rights-against-surprise-medical-bills" },
      { k: "Insured patients still get no Good Faith Estimate", t: "As of August 2026 the GFE requirement still reaches only uninsured and self-pay patients. The insured-patient GFE and the Advanced Explanation of Benefits have never been implemented by rulemaking and enforcement stays deferred. A proposed rule was targeted for March 2026 and has not been published.", url: "https://www.cms.gov/nosurprises/policies-and-resources/overview-of-rules-fact-sheets" }
    ],
    /* Services where a provider may NEVER ask you to waive protections. */
    noConsent: [
      "Emergency medicine", "Anesthesiology", "Pathology", "Radiology", "Neonatology",
      "Assistant surgeons", "Hospitalists", "Intensivists",
      "Diagnostic services, including radiology and laboratory services",
      "Any service where no in-network provider at that facility could have done it",
      "Anything arising from an unforeseen, urgent medical need at the time of service",
      "Air ambulance — no consent exception exists at all"
    ],
    noConsentCite: "45 CFR 149.420(b)",
    noConsentUrl: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-149/subpart-E/section-149.420",
    consentTiming: "A valid waiver must reach you at least 72 hours before the service if the appointment was made that far ahead; on the day of scheduling if it was made inside 72 hours; and never less than 3 hours before the service. It must be a physically separate document, and signing it is consent to receiving information — it is not a contract to pay.",
    /* PPDR protections while a dispute is pending — high value. */
    ppdrProtections: [
      "The provider may not move your bill into collections, or threaten to.",
      "The provider must pause any collections already started.",
      "No late fees may be charged on the disputed amount.",
      "The provider may not retaliate against you for disputing."
    ],
    ppdrProtSrc: "https://www.cms.gov/nosurprises/providers-payment-resolution-with-patients",
    /* Enforcement record — useful for confidence. */
    enforcement: "Between January 2022 and December 2025 CMS received 39,999 No Surprises complaints and reported roughly $30.05 million in direct monetary relief to consumers and providers.",
    enforcementSrc: "https://www.cms.gov/files/document/december-2025-complaint-data-enforcement-report.pdf",
    /* Who enforces. */
    directEnforcementStates: ["MO", "TN", "TX", "WY"],
    enforcementNote: "States hold primary enforcement over insurers in most of the country. As of May 1, 2026 CMS directly enforces in Missouri, Tennessee, Texas, and Wyoming. Self-funded employer plans are enforced federally everywhere. This roster changes — check the CMS page rather than assuming it still reads this way.",
    enforcementSrc2: "https://www.cms.gov/marketplace/private-health-insurance/consumer-protections-enforcement"
  };

  /* ================================================================== */
  /* BILLING ERROR TAXONOMY — what to look for, line by line             */
  /* ================================================================== */
  var BILL_ERRORS = [
    { id: "eobgap", name: "The bill is bigger than the EOB says you owe", risk: "high",
      what: "Your insurer's Explanation of Benefits has a 'patient responsibility' line. If the provider's bill is larger than that line for the same claim, the provider is charging you part of its own contractual write-off. That is a prohibited balance bill.",
      spot: "Put the EOB and the bill side by side for the same date of service and claim number. Compare the patient-responsibility total to the amount billed. Any excess is presumptively improper.",
      why: "This is the single highest-value check on this page. It needs no coding knowledge and no clinical judgment, and it produces an unambiguous answer. CMS's own definitions say adjustments coded CO — contractual obligation — are 'considered a write off for the provider and are not billed to the patient.'",
      cite: "Medicare Claims Processing Manual Ch. 22 § 60.1", url: "https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/clm104c22.pdf" },
    { id: "units", name: "Wrong units or quantity — the decimal error", risk: "high",
      what: "A quantity field reading 10 instead of 1, or 100 instead of 10. Most common on drugs, supplies, and time-based units.",
      spot: "Scan the units column of the itemized bill for implausible numbers. This error is visually obvious once you look, and it usually produces the largest single dollar variance on a bill.",
      why: "CMS publishes Medically Unlikely Edits — the maximum units normally billable for a code — free. A billed quantity above the MUE is presumptively wrong.",
      cite: "CMS NCCI (MUE files, quarterly)", url: "https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits" },
    { id: "dup", name: "Duplicate billing", risk: "high",
      what: "The same service billed twice on the same date — or once by the hospital and again by the physician group for the identical act.",
      spot: "Sort the itemized bill by date, then by code, and look for exact repeats. The medical record settles whether a repeat really happened (two blood draws can be legitimate).",
      why: "", cite: "", url: "" },
    { id: "unbundle", name: "Unbundling / fragmentation", risk: "high",
      what: "A procedure with one comprehensive code split into component codes billed separately, for a higher total.",
      spot: "Take two codes billed on the same date and search CMS's free Procedure-to-Procedure edit file for that pair. If they appear as a Column One / Column Two pair and no proper modifier was billed, the Column Two code should not have been separately paid.",
      why: "Watch for modifier 59 ('distinct procedural service') attached to a pair that NCCI says shouldn't be billed together — that combination is the classic unbundling signature.",
      cite: "CMS NCCI PTP edits, updated quarterly", url: "https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits/medicare-ncci-procedure-procedure-ptp-edits" },
    { id: "upcode", name: "Upcoding", risk: "med",
      what: "Billing a higher-intensity code than the service actually delivered — a Level 5 emergency visit for a Level 2 problem.",
      spot: "Compare the code's intensity against what the medical record documents. A short visit for a simple complaint billed at the highest complexity is a flag.",
      why: "", cite: "", url: "" },
    { id: "notrendered", name: "Services not rendered", risk: "high",
      what: "Billed but never performed.",
      spot: "Only the medical record proves this. It is the strongest single reason to request your records.",
      why: "A bill asserts a service occurred. The record is the only contemporaneous evidence of whether it did.", cite: "", url: "" },
    { id: "wrongpt", name: "Wrong patient or wrong date", risk: "high",
      what: "Another patient's charges attached to your account, or charges dated outside your stay.",
      spot: "Check every service date against your actual admission and discharge dates.", why: "", cite: "", url: "" },
    { id: "canceled", name: "Canceled procedure still billed", risk: "med",
      what: "A procedure scheduled and prepped, then aborted — but the charge posted anyway.",
      spot: "Look for charges on a date the record shows a cancellation.", why: "", cite: "", url: "" },
    { id: "roomday", name: "Room charge on your discharge day", risk: "med",
      what: "Hospitals generally bill room-and-board per night, not per calendar day.",
      spot: "Count the room-charge lines and compare against nights actually stayed. A room charge dated the discharge day is frequently improper.", why: "", cite: "", url: "" },
    { id: "ortime", name: "Operating room time discrepancy", risk: "med",
      what: "OR time billed in increments exceeding the documented time.",
      spot: "Compare billed OR units against the anesthesia record's start and stop times, which are contemporaneous and precise.", why: "", cite: "", url: "" },
    { id: "jcode", name: "Drug billed by the wrong unit", risk: "high",
      what: "HCPCS J-codes define a specific quantity per unit — 'per 10 mg', for example. Billing units as if they were milligrams, or vials as if they were units, inflates a charge by orders of magnitude.",
      spot: "Look the J-code up in CMS's free HCPCS file, read its unit definition, and compare to the dose in the medication administration record.",
      cite: "CMS HCPCS quarterly update — free", url: "https://www.cms.gov/medicare/coding-billing/healthcare-common-procedure-system/quarterly-update" },
    { id: "modifier", name: "Wrong modifier", risk: "med",
      what: "Modifiers change a code's meaning and its payment — bilateral, repeat procedure, distinct service. A wrong one can improperly bypass a bundling edit.",
      spot: "See unbundling above. Modifier 59 on a bundled pair is the pattern to check.", why: "", cite: "", url: "" },
    { id: "mutex", name: "Mutually exclusive code pairs", risk: "med",
      what: "Two codes that cannot both be clinically true for the same encounter — two different approaches to the same procedure.",
      spot: "NCCI PTP edits catch these too.", cite: "CMS NCCI", url: "https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits" },
    { id: "obs", name: "Observation status instead of inpatient", risk: "high",
      what: "You can spend days in a hospital bed getting identical care and be classified an outpatient 'under observation.' On Medicare that shifts billing from Part A to Part B — coinsurance on every individual service, self-administered drugs usually not covered, and the days do not count toward the 3-day inpatient stay that unlocks skilled nursing facility coverage.",
      spot: "Look for the MOON (form CMS-10611). A hospital must give it, in writing and orally, within 36 hours of starting observation services. The two-midnight rule turns on the admitting physician's documented expectation, not a stopwatch — and there is a case-by-case exception where the record supports it.",
      why: "New and under-covered: form CMS-10868, the Medicare Change of Status Notice, now conveys appeal rights when a hospital reclassifies you from inpatient to observation. Most consumer guidance still says observation status cannot be appealed. That guidance is out of date.",
      cite: "42 CFR 412.3 (two-midnight); 42 CFR 489.20(y) (MOON)", url: "https://www.cms.gov/medicare/forms-notices/beneficiary-notices-initiative" },
    { id: "timely", name: "Denied for late filing — then billed to you", risk: "high",
      what: "Timely-filing limits are an obligation the provider owes the payer under its network contract. When a claim is denied because the provider filed late, the adjustment carries the CO (contractual obligation) group code.",
      spot: "Find the group code on the EOB. CO means the provider absorbs it. This looks identical to any other denial, and patients routinely pay these bills believing the claim was legitimately rejected.",
      why: "The move is not an appeal to the insurer — you have no standing to cure the provider's lateness. It is a direct written demand to the provider's billing office to write the balance off, escalating to your state insurance department (fully insured) or the US Department of Labor (self-funded) if refused. Medicare's own filing deadline is one calendar year from the date of service.",
      cite: "42 CFR 424.44; Medicare Claims Processing Manual Ch. 22 § 60.1", url: "https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-424/subpart-C/section-424.44" }
  ];

  /* EOB group codes — the decision rule. */
  var GROUP_CODES = [
    { c: "CO", n: "Contractual Obligation", t: "Used when a contract between the payer and the provider, or a regulatory requirement, caused the adjustment. CMS: these adjustments “are considered a write off for the provider and are not billed to the patient.”", who: "provider" },
    { c: "PR", n: "Patient Responsibility", t: "Used when the adjustment is an amount that may be billed to you — typically deductible, copay, and coinsurance.", who: "patient" },
    { c: "OA", n: "Other Adjustments", t: "Used when no other group code applies.", who: "other" },
    { c: "PI", n: "Payer Initiated Reductions", t: "Appears in the full X12 code set maintained outside CMS. Note it is NOT one of the three group codes defined in the Medicare Claims Processing Manual, so don't expect it on a Medicare remittance advice.", who: "other" }
  ];
  var GROUP_CODES_SRC = "https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/clm104c22.pdf";

  /* Free, official lookups a patient can actually use. */
  var CODE_TOOLS = [
    { n: "HCPCS Level II — free from CMS", t: "Drugs (J-codes), supplies, durable equipment, and ambulance. Exactly where unit-based billing errors concentrate. Free public-use files, updated quarterly.", u: "https://www.cms.gov/medicare/coding-billing/healthcare-common-procedure-system/quarterly-update", free: true },
    { n: "NCCI edits — free from CMS", t: "The federal file that proves unbundling. Procedure-to-Procedure pairs, Medically Unlikely Edits (maximum units), and add-on code edits. Updated quarterly.", u: "https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits", free: true },
    { n: "CPT codes — not free", t: "CPT is copyrighted by the American Medical Association. Clapback cannot ship CPT descriptions, and no working free AMA lookup could be verified. You can still price a CPT code you already have using the Medicare fee schedule below — that path needs no license.", u: "https://www.ama-assn.org/practice-management/cpt", free: false },
    { n: "Hospital revenue codes — not free", t: "The official UB-04 data specifications are copyrighted by the American Hospital Association and sold by subscription. This is why hospital bills are harder to audit than physician bills, and why the medical record matters more.", u: "https://www.nubc.org/", free: false }
  ];

  /* Price benchmarking — with the two stale recommendations called out. */
  var PRICE_TOOLS = [
    { n: "CMS Physician Fee Schedule lookup", t: "The anchor benchmark. What Medicare pays for a CPT/HCPCS code in your locality. Express every other price as a multiple of this.", u: "https://www.cms.gov/medicare/physician-fee-schedule/search", tag: "Free · official" },
    { n: "FAIR Health Consumer", t: "The best free consumer price tool. Cost estimates by procedure and ZIP, in-network allowed amounts, and out-of-network costs. A national nonprofit created out of a New York Attorney General settlement with health insurers — which is exactly why it is trustworthy for this.", u: "https://www.fairhealthconsumer.org/", tag: "Free · nonprofit" },
    { n: "The hospital's own published prices", t: "Every hospital must publish a machine-readable file of its actual standard charges, including negotiated rates by payer. The file name is deterministic: <EIN>_<hospitalname>_standardcharges.json or .csv, and a .txt file in the site root points to it. Hospitals must also carry a footer link labeled “Price Transparency.” This is the strongest possible answer to “is this charge reasonable” — it is that hospital's own price.", u: "https://www.cms.gov/priorities/key-initiatives/hospital-price-transparency", tag: "Free · official" },
    { n: "CMS hospital outpatient & ASC rates", t: "Medicare rates for hospital outpatient and ambulatory surgery center services. Raw addenda files, not consumer-friendly, but authoritative.", u: "https://www.cms.gov/medicare/payment/prospective-payment-systems/hospital-outpatient", tag: "Free · official" }
  ];
  var PRICE_STALE = [
    { n: "Healthcare Bluebook", t: "Still recommended as a free consumer tool by nearly every article on the subject. It no longer is — healthcarebluebook.com now redirects to a login-gated employer/health-plan product. No free public lookup could be found." },
    { n: "Turquoise Health", t: "Its consumer and pricing pages return 404. Only an NYC-specific comparison tool and a business-facing out-of-network pricer could be confirmed. Useful company, not a general free consumer search." }
  ];

  /* The price benchmark that IS verified. */
  var PRICE_FACTS = [
    { n: "Private plans paid hospitals 254% of Medicare", t: "For the same services in 2022, across an employer-led transparency initiative covering 2020–2022 data. Published December 10, 2024.", src: "RAND Corporation, Round 5.1", u: "https://www.rand.org/pubs/research_reports/RRA1144-2.html",
      caveat: "This is negotiated commercial prices as a share of Medicare — not chargemaster list prices, which run higher still." },
    { n: "Private PPO clinician rates were 140% of Medicare", t: "In 2023, up from 136% in 2022. Same report: hospitals' Medicare fee-for-service margin was about −13%, while their all-payer operating margin rose to 5.1%.", src: "MedPAC March 2025 Report to Congress", u: "https://www.medpac.gov/wp-content/uploads/2025/03/Mar25_MedPAC_Report_To_Congress_SEC.pdf", caveat: "" }
  ];

  /* Denial and appeal statistics that are actually defensible. */
  var DENIAL_STATS = [
    { big: "19%", t: "of in-network claims were denied in HealthCare.gov plans (2024 plan year). Out-of-network: 37%.", src: "KFF analysis of the CMS Transparency in Coverage public use file", u: "https://www.kff.org/patient-consumer-protections/claims-denials-and-appeals-in-aca-marketplace-plans-in-2024/" },
    { big: "under 1%", t: "of denied claims were appealed — 262,982 internal appeals against roughly 85 million denied in-network claims.", src: "KFF / CMS Transparency in Coverage", u: "https://www.kff.org/patient-consumer-protections/claims-denials-and-appeals-in-aca-marketplace-plans-in-2024/" },
    { big: "~34%", t: "of appealed denials were overturned. Insurers upheld 66% of appeals — which means a third of the people who bothered to appeal won.", src: "KFF / CMS Transparency in Coverage", u: "https://www.kff.org/patient-consumer-protections/claims-denials-and-appeals-in-aca-marketplace-plans-in-2024/" },
    { big: "69%", t: "of insured adults who had a claim denied did not know they had the right to appeal it.", src: "KFF Survey of Consumer Experiences with Health Insurance (fielded Feb–Mar 2023)", u: "https://www.kff.org/affordable-care-act/consumer-survey-highlights-problems-with-denied-health-insurance-claims/" }
  ];
  var STAT_HONESTY = "You will see “80% of medical bills contain errors” quoted everywhere. Clapback will not repeat it. That figure appears only in commercial content and traces back to a trade association for paid billing advocates that has never published a methodology, a sample, or a dataset. No study supports it. The numbers above are government-sourced and say what they actually measure. The honest position: billing errors are common enough that every bill is worth checking, and a third of appealed denials get overturned — not that any specific percentage of bills is wrong.";

  /* ================================================================== */
  /* SECTION 501(r) — the charity care engine                            */
  /* ================================================================== */
  var R501 = {
    scope: "Section 501(r) binds tax-exempt, 501(c)(3) hospital facilities — which is most nonprofit hospitals in the US, applied separately to each facility. It does NOT cover for-profit hospitals, physician practices billing separately, ambulance services, or most standalone labs and imaging centers.",
    reqs: [
      { n: "Financial Assistance Policy (FAP)", t: "Every facility must have one, must say who qualifies and how to apply, and must list which non-hospital providers practicing there are and are not covered by it — the provision that defeats the “the hospital bill is covered but the ER physician's bill isn't” surprise.", cite: "26 CFR 1.501(r)-4", u: "https://www.ecfr.gov/current/title-26/section-1.501(r)-4" },
      { n: "Widely publicized", t: "The FAP, the application form, and a plain-language summary must be free on a website with no registration; paper copies free on request by mail and in the emergency room and admissions areas; conspicuous notice on billing statements including a phone number and the direct URL; and translated for each limited-English group that is the lesser of 1,000 people or 5% of the community.", cite: "26 CFR 1.501(r)-4(b)(5)", u: "https://www.ecfr.gov/current/title-26/section-1.501(r)-4" },
      { n: "Limit on charges (AGB)", t: "This is the negotiating fact. Once you are determined FAP-eligible, the amount you are personally responsible for paying may not exceed the Amounts Generally Billed to insured patients, for emergency or other medically necessary care. For all other care covered by the policy, it must be less than gross charges. One precision point worth knowing so you don't argue the wrong thing: the rule does not forbid the statement from listing gross charges and then applying a discount — what it caps is what you actually owe at the end.", cite: "26 CFR 1.501(r)-5", u: "https://www.ecfr.gov/current/title-26/section-1.501(r)-5" },
      { n: "Billing and collections limits", t: "Before certain collection actions, the hospital must make reasonable efforts to determine whether you qualify for assistance — with hard deadlines. See the timeline calculator.", cite: "26 CFR 1.501(r)-6", u: "https://www.ecfr.gov/current/title-26/section-1.501(r)-6" },
      { n: "Emergency care without discrimination", t: "The facility must provide emergency care regardless of FAP eligibility, and may not do anything that discourages you from seeking it — including demanding payment before treatment.", cite: "26 U.S.C. 501(r)(4)(B)", u: "https://www.irs.gov/charities-non-profits/financial-assistance-policies-faps" }
    ],
    agb: "AGB is calculated one of two ways: a look-back percentage (allowed amounts divided by gross charges over 12 months, based on Medicare fee-for-service alone, Medicare plus all private insurers, or Medicaid in some combination), or prospectively, at what Medicare or Medicaid would have allowed. Ask the hospital which method it uses and what its current AGB percentage is — the FAP is required to state the basis for calculating what patients are charged, so this is a documented, disclosable number.",
    ecas: [
      "Selling your debt to another party",
      "Reporting adverse information about you to a credit bureau",
      "Deferring or denying care, or demanding payment before care, because of unpaid prior bills",
      "Placing a lien on your property",
      "Foreclosing on your real property",
      "Attaching or seizing your bank account or other personal property",
      "Commencing a civil action against you",
      "Causing your arrest",
      "Causing you to be subject to a writ of body attachment",
      "Garnishing your wages"
    ],
    notEcas: "Referring an account to a collection agency is not itself on the list. Neither are routine billing statements or dunning calls, filing a claim in your bankruptcy, or a lien on the proceeds of a personal-injury settlement. The line is crossed at credit reporting, suit, lien, garnishment, seizure, debt sale, or denial of care.",
    d120: "The hospital must refrain from any extraordinary collection action for at least 120 days from the date it provided the FIRST post-discharge billing statement. Not from the date of service, and not from discharge. One carve-out: deferring or denying care over unpaid prior bills is excepted from this 120-day wait, though it carries its own notice rules.",
    d240: "You have at least 240 days from that same first post-discharge billing statement to submit a financial assistance application, and the hospital must accept and process it. This right survives the start of a collection action.",
    d30: "At least 30 days before starting the first extraordinary collection action, the hospital must give you written notice saying financial assistance is available, identifying the specific actions it intends to take, and stating a deadline no earlier than 30 days out — plus a plain-language summary of the FAP and a reasonable effort to tell you about it orally.",
    reversal: "This is the strongest single fact for anyone already being sued or garnished. If you apply during the application period and are found eligible, the hospital must suspend collection actions and “take all reasonably available measures to reverse” any it already took — the regulation names vacating judgments, lifting levies and liens, and removing adverse credit reporting. It must also refund anything you paid above what you owe as a FAP-eligible patient, unless the excess is under $5, including money paid to a collector it referred or sold the debt to. Two carve-outs to know: a completed sale of the debt and the deny-or-defer-care action are excepted from the reversal duty.",
    reversalCite: "26 CFR 1.501(r)-6(c)(6)-(7)",
    reversalUrl: "https://www.ecfr.gov/current/title-26/section-1.501(r)-6",
    weaponize: "Section 501(r) is a tax rule with no private right of action — you cannot sue under it. But the facts it generates are directly usable elsewhere: a charity-care-eligible patient billed at gross charges is being asked for an amount not permitted by law, which is an FDCPA problem (15 U.S.C. 1692f(1)); and a collector representing that a chargemaster balance is owed by a FAP-eligible patient is misrepresenting the character, amount, or legal status of the debt (15 U.S.C. 1692e(2)(A)). The IRS lane is Form 13909. The lane that actually produces money is your state attorney general.",
    enforcementWeak: "The IRS is required to review each hospital's community benefit activities at least every three years. The GAO found it could not provide evidence that it did so, because it had no well-documented process. Do not expect the IRS lane alone to fix your bill.",
    enforcementSrc: "https://www.gao.gov/products/gao-23-106777",
    form13909: "https://www.irs.gov/pub/irs-pdf/f13909.pdf",
    form13909where: "Mail to IRS TEGE Classification, Mail Code 4910DAL, 1100 Commerce Street, Dallas TX 75242-1027, or email eoclass@irs.gov (the IRS notes email is not encrypted). There is no fax number for this form. The IRS keeps your identity confidential and cannot give you status updates."
  };

  /* ================================================================== */
  /* STATE CHARITY CARE / FINANCIAL ASSISTANCE                           */
  /* Only states verified against a primary source appear with numbers.  */
  /* ================================================================== */
  var CHARITY_STATES = {
    WA: { name: "Washington", law: "RCW 70.170.060 (as amended 2025 c 182)", v: true,
      free: "Free care at or below 300% FPL at large hospital systems; 200% FPL elsewhere.",
      disc: "Large systems: 75% off at 301–350% FPL, 50% off at 351–400%. Other hospitals: 75% off at 201–250%, 50% off at 251–300%.",
      extra: ["Screening is mandatory — “an initial determination of sponsorship status shall precede collection efforts.”",
              "Documentation demands are limited to what is “reasonably necessary and readily available.” One current account statement is enough to verify assets. If you have no documentation, a written signed statement from you must be accepted.",
              "Billing statements must say: “You may qualify for free care or a discount on your hospital bill, whether or not you have insurance.”",
              "The Attorney General states charity care applies to past bills too — it does not matter how old they are, or whether they went to collections."],
      url: "https://app.leg.wa.gov/rcw/default.aspx?cite=70.170.060", url2: "https://www.atg.wa.gov/charitycare" },
    NY: { name: "New York", law: "Public Health Law § 2807-k, as amended effective October 20, 2024", v: true,
      free: "Full waiver of charges below 200% FPL.",
      disc: "200–300% FPL: you pay at most 10% of the Medicaid rate (uninsured) or of your cost-sharing (underinsured). 301–400% FPL: at most 20%. Eligibility now runs to 400% FPL, up from 300%.",
      extra: ["Assets may not be considered. Immigration status may not be considered.",
              "Hospitals are prohibited from suing patients at or under 400% FPL, and may not sue anyone within 180 days of the first bill.",
              "Monthly payments are capped at 5% of your gross monthly income.",
              "A uniform financial assistance application is mandatory at every hospital.",
              "“Underinsured” includes anyone whose medical expenses exceeded 10% of annual income."],
      url: "https://www.health.ny.gov/facilities/hospital/financial_assist/docs/25-04_hospital_financial_assistance.pdf",
      warn: "The NY DOH landing page for this program is stale — it still describes the old 300% FPL threshold. Use the 2025 dear-administrator letter linked here." },
    IL: { name: "Illinois", law: "Hospital Uninsured Patient Discount Act, 210 ILCS 89/10", v: true,
      free: "Free care at or below 200% FPL (urban/non-rural hospitals) for services over $150 per encounter; at or below 125% FPL at rural and Critical Access hospitals, for services over $300.",
      disc: "Discount eligibility runs to 600% FPL at non-rural hospitals, 300% FPL at rural and Critical Access hospitals.",
      extra: ["The maximum collectible in any 12-month period is 20% of family income.",
              "Assets above the threshold may be counted, but your primary residence and retirement funds are excluded."],
      url: "https://www.ilga.gov/legislation/ilcs/fulltext.asp?DocName=021000890K10",
      warn: "A widespread error says Illinois gives free care up to 600% FPL. It does not — 600% is the discount ceiling; free care stops at 200% (125% rural). The state's own report-card page is also stale: its dollar examples come from 2009 poverty guidelines and it cites a 25% income cap the statute lowered to 20%." },
    MD: { name: "Maryland", law: "Health-General § 19-214.1; implementing regulations effective December 11, 2025", v: true,
      free: "Free care at or below 200% FPL.",
      disc: "201–250% FPL: 75% reduction. 251–300% FPL: 60% reduction. A separate financial-hardship sliding scale runs to 500% FPL (75% down to 35%), where hardship means medical debt over a 12-month period exceeding 25% of family income.",
      extra: ["Presumptive eligibility is mandatory — hospitals must presume you qualify for free care if you have children in free or reduced-price school meals, get SNAP, get energy assistance, or participate in WIC.",
              "Billing and collections must be suspended while eligibility is determined, within 14 days of application.",
              "A uniform statewide application covers all 42 acute care hospitals.",
              "Separately (HB 268, 2025): hospitals may not sue on debts under $500, may not report to credit agencies, and may not charge interest for eligible low-income consumers; a 240-day financial-assistance notice period applies before collection; and HB 428 bars liens on a debtor's primary residence for medical-debt judgments."],
      url: "https://hscrc.maryland.gov/Pages/consumers_uniform.aspx", url2: "https://mgaleg.maryland.gov/mgawebsite/Laws/StatuteText?article=ghg&section=19-214.1&enactments=false" },
    CA: { name: "California", law: "Hospital Fair Pricing Act, Health & Safety Code § 127400 et seq.", v: true,
      free: "Eligibility runs to 400% FPL (raised from 350% by AB 1020).",
      disc: "Sliding relief within that band under each hospital's policy; the state program sets the floor.",
      extra: ["AB 2297 (effective Jan 1, 2025) eliminated asset tests, barred requiring you to apply for other coverage first, prohibited liens and property sales, and prohibited adverse credit reporting.",
              "AB 1020 extended the wait before adverse credit reporting or a civil action from 150 to 180 days, created a patient complaint process with administrative penalties, restricted debt sales, and requires collectors to certify that patients were screened.",
              "AB 1312 (2025) requires financial assistance screening and presumptive eligibility determinations beginning July 1, 2027.",
              "California also has a hospital bill complaint program with real teeth — see Report it."],
      url: "https://hcai.ca.gov/affordability/hospital-fair-billing-program/laws-and-regulations", url2: "https://hcai.ca.gov/affordability/hospital-fair-billing-program/hospital-bill-complaint-program/" },
    CO: { name: "Colorado", law: "Hospital Discounted Care, HB21-1198", v: true,
      free: "Eligibility at or below 250% FPL.",
      disc: "Discounted care within that band, with payment caps below.",
      extra: ["Screening is mandatory and uninsured patients are screened automatically — you must opt out, not opt in. Insured patients may request screening.",
              "Monthly payments are capped at 4% of monthly household income for hospital bills and 2% for physician bills.",
              "The debt is extinguished after 36 monthly payments, or on payment of the full discounted amount.",
              "Before collections a hospital must complete screening, explain all services and fees in your preferred language, bill your insurance first, and give 30 days' written notice."],
      url: "https://hcpf.colorado.gov/colorado-hospital-discounted-care" },
    NJ: { name: "New Jersey", law: "NJ Hospital Care Payment Assistance (Charity Care)", v: true,
      free: "Free care (0% patient responsibility) at or below 200% FPL.",
      disc: "Sliding: over 200–225% you pay 20%; 225–250% you pay 40%; 250–275% you pay 60%; 275–300% you pay 80%; above 300% there is no assistance.",
      extra: ["The catch is the asset test: individual assets must be at or under $7,500, family assets at or under $15,000. Excess assets may be spent down by paying hospital bills.",
              "If you are on the sliding scale and your qualified medical expenses exceed 30% of gross annual income, you get assistance above that threshold.",
              "Covers inpatient and outpatient care at acute care hospitals. It excludes physician fees, anesthesiology, radiology interpretation, and outpatient prescriptions — those bills come separately.",
              "You have up to one year from the date of service to apply; the hospital must decide within 10 working days.",
              "Separately (P.L. 2024 c.48): interest on medical debt is capped at 3% per year, and wage garnishment is prohibited for patients below 600% FPL."],
      url: "https://www.nj.gov/health/hcf/documents/NJ-Charity-Care-Fact-Sheet-March-2026-English.pdf" },
    MN: { name: "Minnesota", law: "Minn. Stat. § 144.587", v: true,
      free: "No statewide FPL floor is set by statute — Minnesota mandates the process, not the income threshold. Your hospital's own policy controls the numbers.",
      disc: "",
      extra: ["Hospitals must attempt to complete charity care screening in person or by phone within 30 days after services, and must connect you with a certified application counselor or MNsure navigator before discharge where feasible.",
              "Until the hospital determines you are INELIGIBLE for charity care, it may not: enroll you in a payment plan, offer you a loan or credit for the debt, refer the debt for collections (including in-house collections and revenue recapture), or accept credit card payments over $500 for medical debt.",
              "The Attorney General's 2025 Mayo Clinic settlement set free care at 200% FPG and 40–50% discounts from 200–400% FPG, expanded presumptive eligibility, and requires CFO approval before any collection lawsuit. The AG has recommended a statewide 200% FPG floor."],
      url: "https://www.revisor.mn.gov/statutes/cite/144.587", url2: "https://www.ag.state.mn.us/Office/Communications/2025/03/14_MayoClinic.asp" },
    OR: { name: "Oregon", law: "ORS 442.614 and 442.615 (amended by HB 4040, 2026)", v: true,
      free: "Free care (100% discount) at or below 200% FPL.",
      disc: "Over 200–300% FPL: minimum 75% off. Over 300–350%: minimum 50% off. Over 350–400%: minimum 25% off. Applies to all medically necessary services, and you cannot be required to apply for medical assistance before being screened.",
      extra: ["Screening trigger changed in 2026. HB 4040 raised the debt amount that triggers mandatory presumptive-eligibility screening from more than $500 to more than $1,500 for a single hospital encounter. Screening is still required regardless of amount if you are uninsured or enrolled in Medicaid."],
      url: "https://olis.oregonlegislature.gov/liz/2026R1/Downloads/MeasureDocument/HB4040/Enrolled",
      url2: "https://olis.oregonlegislature.gov/liz/2026R1/Measures/Overview/HB4040",
      warn: "Two notes. Third-party statute mirrors still show the old $500 screening trigger — HB 4040 carried an emergency clause and took effect on passage in spring 2026. And HB 4040 is an omnibus health bill: the financial-assistance screening change is one provision among many, so search within it rather than skimming." },
    ME: { name: "Maine", law: "22 M.R.S. § 1716-A (P.L. 2025 c. 488) — effective July 1, 2026", v: true,
      free: "Free/charity care at or below 200% FPL.",
      disc: "Discounted payment plans up to 400% FPL, with monthly payments capped at 4% of monthly family income.",
      extra: ["Hospitals must investigate your insurance coverage on admission, or before discharge for emergency admissions.",
              "Applications may not require notarization. The hospital must tell you about missing information within 15 days, give you at least 30 days to supply it, and decide within 45 days of a complete application.",
              "Translation and interpretation are mandatory for limited-English and deaf or hard-of-hearing patients.",
              "Debt collectors are prohibited from collecting from patients determined to qualify for free or charity care.",
              "Online applications become mandatory July 1, 2028."],
      url: "https://www.mainelegislature.org/legis/Statutes/22/title22sec1716-A.html" },
    CT: { name: "Connecticut", law: "C.G.S. §§ 19a-673, 19a-673b", v: true,
      free: "Hospitals may not collect from an “uninsured patient” more than the COST of providing the care — published charges multiplied by the hospital's most recent cost-to-charge ratio. “Uninsured patient” means income at or below 250% FPL, who applied for and was denied Medicaid and has no other coverage.",
      disc: "",
      extra: ["Referring to collection agents or filing suit is prohibited unless you are an uninsured patient ineligible for the hospital bed fund.",
              "Reporting patients to credit agencies has been prohibited since July 1, 2024.",
              "Foreclosing on liens against a primary residence for health care debt is prohibited.",
              "Garnishing wages of patients eligible for the hospital bed fund is prohibited."],
      url: "https://law.justia.com/codes/connecticut/title-19a/chapter-368z/section-19a-673b/",
      warn: "Connecticut's official statute host blocks automated verification. The text above was confirmed against two independent code reproductions — read cga.ct.gov in a browser before relying on it in a filing." },
    NV: { name: "Nevada", law: "NRS 439B.260", v: true,
      free: "No FPL-based charity care mandate. Nevada requires “major hospitals” to give at least a 30% reduction in billed inpatient charges to a patient who has no insurance, is ineligible for Medicare/Medicaid and other programs, and makes reasonable payment arrangements within 30 days of notice.",
      disc: "",
      extra: ["Do not describe Nevada as an FPL-based charity care state — the income definitions sit in separate indigent-care provisions.",
              "Two versions of this statute are listed by third-party hosts (one “through December 31, 2025” and one “from January 1, 2026”). What changed could not be verified. Read the official NRS page before relying on it."],
      url: "https://www.leg.state.nv.us/NRS/NRS-439B.html" },
    RI: { name: "Rhode Island", law: "216-RICR-20-10-23 § 23.14", v: false,
      free: "Rhode Island requires hospitals to provide essential medical services to qualified charity care patients, with eligibility based on the federal poverty guidelines for family size and income. The specific percentages for free versus discounted care are not stated on the state's public page and could not be verified.",
      disc: "",
      extra: ["Hospitals must give eligible patients the information needed to apply and must not discourage patients who cannot afford to pay from seeking essential medical services.",
              "Ask the hospital directly for its FAP and the exact FPL thresholds — 501(r) requires it to hand them over free."],
      url: "https://health.ri.gov/hospitals/hospital-charity-care" }
  };
  var CHARITY_OTHER = "Roughly 21 states plus DC set minimum hospital financial assistance standards beyond federal law: CA, CO, CT, DE, DC, FL, GA, IL, ME, MD, NV, NJ, NY, NC, OH, OK, RI, SC, TX, VT, WA. Clapback shows verified detail only for the states above. If yours isn't listed, section 501(r) still applies to every nonprofit hospital in the country — use the federal engine on this page, and ask the hospital directly for its Financial Assistance Policy, which it must give you free.";
  var CHARITY_OTHER_SRC = "https://www.commonwealthfund.org/publications/issue-briefs/2026/aug/building-states-medical-debt-protections-closing-gaps";

  var MEDICAID_LOOKBACK = {
    now: "Through December 31, 2026, Medicaid can cover bills incurred up to 3 months before the month you apply, if you would have been eligible then. An old unpaid hospital bill from a period when you were eligible may still be payable.",
    change: "This is reported to narrow sharply on January 1, 2027. Section 71112 of Public Law 119-21 reduces retroactive coverage — CMS confirms the CHIP side may begin no earlier than two months before the month of application. The widely reported Medicaid figures are 1 month for the expansion adult group and 2 months for everyone else, including seniors 65+ and people with disabilities; Clapback could not confirm those two numbers or the exact effective date against the statutory text, so treat them as a strong signal to act now rather than as settled figures. Ask your state Medicaid office what applies to you.",
    url: "https://www.medicaid.gov/medicaid/downloads/wftc-legsltn-overview-slide.pdf"
  };

  /* ================================================================== */
  /* INSURANCE APPEALS                                                   */
  /* ================================================================== */
  var APPEALS = {
    internalDays: 180,
    externalMonths: 4,
    initial: [
      { k: "Urgent care claim", d: "72 hours after the plan receives it" },
      { k: "Pre-service claim (care you haven't had yet)", d: "15 days" },
      { k: "Post-service claim (care already received)", d: "30 days" }
    ],
    initialCite: "29 CFR 2560.503-1(f)(2)",
    decide: [
      { k: "Urgent", one: "72 hours", two: "72 hours" },
      { k: "Pre-service", one: "30 days", two: "15 days per level" },
      { k: "Post-service", one: "60 days", two: "30 days per level" }
    ],
    decideCite: "29 CFR 2560.503-1(i)(2)",
    decideNote: "The number depends on how many internal appeal levels your plan has — the detail most consumer guides get wrong. One level is the norm in the individual market.",
    ext: { standard: "45 days after the independent reviewer receives the request", expedited: "as fast as your condition requires, never more than 72 hours", cost: "Federal external review is free. A state or independent process may charge up to $25." },
    extCite: "45 CFR 147.136(d)",
    ecfr: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-B/part-147/section-147.136",
    /* Rights people don't know they have. */
    rights: [
      { n: "The denial notice must state the denial code AND what it means", t: "Plus a description of the plan's standard. Diagnosis and treatment codes must be handed over on request. This is the legal hook for demanding a real explanation instead of a form letter.", cite: "45 CFR 147.136(b)(2)(ii)(E)" },
      { n: "Your claim file is free", t: "The plan must give you, free of charge, any new or additional evidence it considered, relied on, or generated. Ask for the complete claim file and the clinical criteria used.", cite: "45 CFR 147.136(b)(2)(ii)(C)(1)" },
      { n: "Coverage continues during an internal appeal", t: "For ongoing treatment, the plan must provide continued coverage pending the outcome.", cite: "45 CFR 147.136(b)(2)(iii)" },
      { n: "180 days is a floor, not a ceiling", t: "The regulation says plans must allow “at least” 180 days. Your plan may allow longer — check the denial letter.", cite: "29 CFR 2560.503-1(h)(3)(i)" }
    ],
    /* Denial reasons ranked by whether you actually have leverage. */
    reasons: [
      { n: "Missing prior authorization", lev: "strong", t: "Strong position when the provider was responsible for getting it. A provider's failure to obtain required authorization is typically its contractual failure and adjudicates as CO — the provider absorbs it. Ask: was I told before the service that authorization was needed?" },
      { n: "Not medically necessary", lev: "strong", t: "The flagship external-review issue. Independent reviewers overturn these at meaningful rates because the question is clinical, not contractual. Get the plan's clinical criteria — the notice must describe its standard — and have your treating physician write to those exact criteria, point by point." },
      { n: "Experimental or investigational", lev: "strong", t: "Explicitly within external review's scope, and reviewers must use medical evidence. One of the better categories for consumer wins." },
      { n: "Out of network", lev: "strong", t: "Check the No Surprises Act first. Emergency care, and out-of-network clinicians at in-network facilities, are largely protected — which may mean this is not your bill at all." },
      { n: "Timely filing", lev: "strong", t: "Usually not your problem. This is the provider's contractual obligation to the payer, and it adjudicates as CO. Don't appeal to the insurer — demand in writing that the provider write it off." },
      { n: "Coding error", lev: "fix", t: "Highest-yield and most fixable, and usually not an appeal at all. Call the billing office and ask for a corrected claim. Faster than any appeal." },
      { n: "Coordination of benefits", lev: "fix", t: "Usually an information problem — the plan doesn't know which coverage is primary. Update coordination of benefits by phone, then ask the provider to rebill." },
      { n: "Eligibility", lev: "fix", t: "Same character: a data error — wrong member ID, retroactive termination, an employer feed lag. Fix the record, then rebill." }
    ],
    /* Plan type routing — the value the official sources don't provide. */
    planTypes: [
      { k: "self", n: "Self-funded employer plan", t: "Your employer pays the claims itself; the insurance company only administers them. These are governed by federal ERISA law and are generally exempt from state insurance regulation, because ERISA bars states from treating a self-funded plan as an insurer. Your state insurance department generally cannot compel it.",
        route: "Route complaints to the US Department of Labor's Employee Benefits Security Administration. On external review, self-funded plans normally use a federal process rather than your state's — either the HHS-administered process or a private accredited-reviewer route the plan may use instead. One exception worth checking: where a state has opened its external review process to self-insured plans, a plan may elect to use it. Ask the plan which process applies before you file.",
        who: "EBSA Benefits Advisors — 1-866-444-3272", url: "https://www.askebsa.dol.gov/WebIntake/home.aspx" },
      { k: "full", n: "Fully insured plan", t: "Your employer (or you) bought an insurance policy. The insurance company bears the risk, and your state regulates it. You get both state and federal protections, including state-mandated benefits.",
        route: "Route complaints to your state insurance department. You may also use your state's external review process.",
        who: "Your state Department of Insurance", url: "https://content.naic.org/state-insurance-departments" }
    ],
    planTypeHow: "Your insurance card will look identical either way — a self-funded plan usually carries a familiar carrier's logo because that carrier is only the third-party administrator. The Summary Plan Description is the authoritative document: a self-funded plan says benefits are paid from employer assets, or describes the carrier as providing “administrative services only.” It also names the plan administrator (your employer) separately from the claims administrator (the carrier). If you can't tell, ask HR directly: “Is our health plan self-funded or fully insured?” Roughly two-thirds of covered workers are in self-funded plans.",
    planTypeGap: "This routing is real value. The NAIC's own complaint guidance never mentions that state insurance departments cannot touch self-funded plans. Someone with a self-funded plan who follows the official guidance files with the wrong regulator, loses weeks, and can blow a 180-day clock.",
    /* Federal external review. */
    fed: { states: ["AL", "FL", "GA", "TX", "WI"], contractor: "MAXIMUS Federal Services", portal: "https://externalappeal.cms.gov/ferpportal", phone: "1-888-866-6205", email: "ferp@maximus.com",
      note: "Alabama, Florida, Georgia, Texas and Wisconsin (plus American Samoa, Guam, the Northern Mariana Islands, and the US Virgin Islands) use the HHS-administered federal external review process. Everyone else has a state process — except most self-funded plan members, who normally go federal wherever they live.",
      warn: "Two caveats. The CMS table listing which states use which process is stamped July 9, 2024 — over two years old, and this is exactly the kind of list that moves. Confirm your state at the CMS page rather than treating it as settled. And the federal portal link hands you off from a cms.gov address to a vendor domain (maximusferp.my.site.com) — that is the real contractor CMS uses, not a phishing hop, but it looks alarming if you aren't expecting it.",
      url: "https://www.cms.gov/cciio/resources/files/external_appeals" },
    /* Plans with weak or no appeal rights. */
    exempt: [
      { n: "Grandfathered plans", t: "A plan in existence on or before March 23, 2010 that hasn't made disqualifying changes is NOT required to guarantee you a right to appeal. Your insurer must notify you if your plan is grandfathered — the absence of that disclosure is itself evidence. You still have the plan's own contractual appeal terms, ERISA's “full and fair review” duty, and in many states a state-mandated external review.", url: "https://www.healthcare.gov/health-care-law-protections/grandfathered-plans/" },
      { n: "Short-term limited duration insurance", t: "ACA internal appeal and external review rights do not attach. A 2024 rule capped these at 3 months initial and 4 months total for policies sold on or after September 1, 2024 — but on August 7, 2025 the three federal departments announced they do not intend to prioritize enforcement of that definition, pending new rulemaking, and invited states to do the same. Do not treat the 4-month cap as settled in 2026.", url: "https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/affordable-care-act/for-employers-and-advisers/short-term-limited-duration-insurance/stldi-statement-08-07-2025" },
      { n: "Health care sharing ministries", t: "These are not insurance. The NAIC states plainly that they “can't guarantee the payment of claims” and “are not legally required to do so,” and that state insurance regulators don't supervise them. No ACA appeal rights, no external review, no state insurance department jurisdiction, no guaranty fund. What's left: the ministry's internal grievance process, your state attorney general on deceptive-practices grounds, and a civil suit on contract theories.", url: "https://content.naic.org/article/not-all-products-are-health-insurance-health-care-sharing-ministries-discount-plans-and-risk-sharing" }
    ],
    /* Medicare / Medicaid ladders. */
    medicare: [
      { lvl: "1. Redetermination", who: "Your Medicare Administrative Contractor", file: "120 days from the initial determination", dec: "about 60 days", min: "no minimum", form: "Form CMS-20027" },
      { lvl: "2. Reconsideration", who: "A Qualified Independent Contractor", file: "180 days from the level 1 decision", dec: "about 60 days", min: "no minimum", form: "" },
      { lvl: "3. Administrative Law Judge", who: "Office of Medicare Hearings and Appeals", file: "60 days", dec: "—", min: "$200 in 2026", form: "" },
      { lvl: "4. Medicare Appeals Council", who: "Departmental Appeals Board", file: "60 days", dec: "—", min: "no minimum", form: "" },
      { lvl: "5. Federal district court", who: "US District Court", file: "60 days", dec: "—", min: "$1,960 in 2026", form: "" }
    ],
    medicareUrl: "https://www.medicare.gov/providers-services/claims-appeals-complaints/appeals/original-medicare",
    medicareNote: "Claims may be combined to reach the dollar thresholds at levels 3 and 5.",
    medAdv: "Medicare Advantage is different and better in one respect: you have 65 days from the date on the denial notice (60 days plus a 5-day mailing presumption), standard decisions run 30 days pre-service and 60 days for payment, expedited is 72 hours — and if the plan decides against you, your appeal is AUTOMATICALLY forwarded to an independent review entity. You don't have to ask. As of May 1, 2026 that entity is C2C Innovative Solutions.",
    medAdvUrl: "https://www.medicare.gov/providers-services/claims-appeals-complaints/appeals/medicare-health-plans",
    medicaid: "Medicaid has an exhaustion trap. In managed care you must finish the PLAN's appeal first — and you only get 60 days from the adverse benefit determination notice to file it, shorter than the 90 days for a state fair hearing and far shorter than the 180 days commercial members get. The plan must resolve in 30 days (72 hours expedited). Only then can you request a state fair hearing, within 90 to 120 days of the resolution notice.",
    medicaidCite: "42 CFR 431.221; 42 CFR 438.402, 438.408",
    /* Prior authorization, 2026. */
    priorAuth: "As of January 1, 2026, Medicare Advantage plans, Medicaid and CHIP (fee-for-service and managed care) must decide prior authorization requests within 72 hours for urgent and 7 calendar days for standard requests, and must give a SPECIFIC reason for every denial. They must also publish their prior authorization statistics on their own websites annually — the first set was due March 31, 2026. That's leverage: you can read the plan's own denial rate.",
    priorAuthUrl: "https://www.cms.gov/files/document/fact-sheet-cms-interoperability-and-prior-authorization-final-rule-cms-0057-f.pdf",
    priorAuthVoluntary: "Separately, in June 2025 more than 50 health plans made voluntary commitments — including honoring existing authorizations for 90 days when you change plans, and having all clinical non-approvals reviewed by medical professionals. These are pledges, not rights. You cannot sue over a broken one. Quote them back at the plan anyway.",
    priorAuthVolUrl: "https://www.ahip.org/news/press-releases/health-plans-take-action-to-simplify-prior-authorization",
    /* Code lists. */
    carc: "https://x12.org/codes/claim-adjustment-reason-codes",
    rarc: "https://x12.org/codes/remittance-advice-remark-codes",
    naic: "https://content.naic.org/state-insurance-departments",
    naicHow: "https://content.naic.org/consumer/how-to-file-complaint",
    caps: "https://www.cms.gov/cciio/resources/consumer-assistance-grants"
  };

  /* ================================================================== */
  /* MEDICAL RECORDS — HIPAA right of access                             */
  /* ================================================================== */
  var RECORDS = {
    days: 30,
    ext: 30,
    rule: "A provider must act on your request for records no later than 30 days after receiving it. They may take ONE extension of up to 30 more days, and only with a written statement of the reason for the delay and the date they will finish.",
    cite: "45 CFR 164.524(b)(2)",
    url: "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-C/part-164/subpart-E/section-164.524",
    fees: ["Labor for copying the information", "Supplies for paper copies or electronic media", "Postage, if mailed", "Preparing a summary or explanation — only if you agreed to it in advance"],
    feeNote: "That list is exclusive, and the omission is the point: search and retrieval costs are NOT on it. Providers and records vendors bill for them anyway. That is the most common overcharge on a records request, and it is checkable against four enumerated categories. If your records are stored electronically, the fee may not be a per-page fee.",
    feeCite: "45 CFR 164.524(c)(4)",
    noHold: "Access cannot be denied because you have unpaid medical bills. Patients disputing a bill are sometimes told they must pay first. That is not the law.",
    noHoldUrl: "https://www.hhs.gov/hipaa/for-individuals/right-to-access/index.html",
    ocr: "https://ocrportal.hhs.gov/ocr/smartscreen/main.jsf",
    ocrPhone: "1-800-368-1019",
    ocrDeadline: "A complaint to the HHS Office for Civil Rights must be filed within 180 days of when you knew or should have known about the problem, unless the Secretary waives it for good cause. The OCR portal itself does not display this deadline — it comes from the regulation, 45 CFR 160.306(b)(3).",
    why: "A bill asserts that a service occurred. The medical record is the only contemporaneous evidence of whether it did. For services not rendered, canceled procedures, and operating-room time, the record is dispositive and nothing else is. For unit errors, the medication administration record shows the actual dose against the billed quantity. Requesting records also changes the billing office's posture — it signals you are building a documented case.",
    noPrivate: "HIPAA has no private right of action. You cannot sue under it. The lane is a complaint to HHS OCR — and separately, the same conduct is often an FDCPA violation, which you CAN sue over."
  };

  /* ================================================================== */
  /* CREDIT — bureaus, specialty CRAs, disputes                          */
  /* ================================================================== */
  var BUREAUS = [
    { id: "eq", n: "Equifax", cat: "big3", holds: "One of the three nationwide credit files.", report: "https://www.annualcreditreport.com", freeze: "https://www.equifax.com/personal/credit-report-services/credit-freeze/", phone: "(888) 298-0045" },
    { id: "ex", n: "Experian", cat: "big3", holds: "One of the three nationwide credit files.", report: "https://www.annualcreditreport.com", freeze: "https://www.experian.com/freeze/center.html", phone: "" },
    { id: "tu", n: "TransUnion", cat: "big3", holds: "One of the three nationwide credit files.", report: "https://www.annualcreditreport.com", freeze: "https://www.transunion.com/credit-help", phone: "", note: "The FTC links consumers to transunion.com/credit-help. A shorter freeze URL is widely circulated but could not be verified — use this one." },
    { id: "in", n: "Innovis", cat: "national", holds: "A fourth national credit file most people have never heard of. Lenders do pull it.", report: "https://www.innovis.com/personal/creditReport", freeze: "https://www.innovis.com/personal/securityFreeze", phone: "1-866-712-4546" },
    { id: "ln", n: "LexisNexis Risk Solutions", cat: "national", holds: "Public records, identity, fraud and risk data used across insurance and lending. Also now holds SageStream, an alternative-credit file used by card issuers, retailers, and wireless carriers.", report: "https://consumer.risk.lexisnexis.com/request", freeze: "https://consumer.risk.lexisnexis.com/freeze", phone: "", opt: "https://consumer.risk.lexisnexis.com/opt" },
    { id: "mib", n: "MIB, Inc.", cat: "medical", holds: "Medical and personal information taken from individually underwritten life, health, and disability insurance applications at member carriers — the past 7 years, plus which companies inquired about you. If you have ever applied for individual life or disability coverage, you likely have a file.", report: "https://www.mib.com/request_your_record.html", freeze: "", phone: "", note: "Free once every 12 months, and free after an adverse underwriting decision. No freeze option found." },
    { id: "mil", n: "Milliman IntelliScript", cat: "medical", holds: "Your prescription history, plus medical, claims, and other data, sold to insurance underwriters.", report: "https://www.rxhistories.com/for-consumers/", freeze: "", phone: "", note: "Access is limited to people who recently applied for individual insurance and signed a HIPAA authorization. No freeze option found." },
    { id: "clue", n: "LexisNexis C.L.U.E.", cat: "medical", holds: "Your property and auto insurance claims history — what insurers see when they quote you.", report: "https://consumer.risk.lexisnexis.com/request", freeze: "https://consumer.risk.lexisnexis.com/freeze", phone: "" },
    { id: "cx", n: "ChexSystems", cat: "banking", holds: "Deposit account history — closures and unpaid balances. This is what stops you opening a checking account.", report: "https://www.chexsystems.com", freeze: "https://www.chexsystems.com/security-freeze/place-freeze", phone: "800-887-7652" },
    { id: "ews", n: "Early Warning Services", cat: "banking", holds: "Checking and savings account history and activity reported by member banks, plus a Deposit Score.", report: "https://www.earlywarning.com/your-early-warning-file-disclosure", freeze: "", phone: "1-800-745-1560", note: "Free — Early Warning states it does not charge a fee. No freeze option found; disputes go through a separate form." },
    { id: "nc", n: "NCTUE", cat: "utility", holds: "Telecom, pay-TV, and utility accounts — payment history and unpaid closed accounts.", report: "https://nctueconsumerportal.com", freeze: "https://nctueconsumerportal.com", phone: "1-866-349-5185", note: "Report line 1-866-349-5185; freeze line 1-866-349-5355. Both free." },
    { id: "twn", n: "The Work Number (Equifax)", cat: "employment", holds: "Your employment and income records, plus a log of which credentialed verifiers looked at your data in the last 24 months.", report: "https://employees.theworknumber.com/", freeze: "https://employees.theworknumber.com/employee-data-freeze", phone: "", note: "The data freeze is free and available at any time." },
    { id: "dx", n: "DataX (formerly Teletrack)", cat: "subprime", holds: "Subprime and alternative lending history. Teletrack is now part of DataX, an Equifax company — a merger the CFPB's own published list has not caught up with.", report: "https://consumers.dataxltd.com/", freeze: "", phone: "800-295-4790" }
  ];
  var CRA_CATS = [
    { k: "big3", n: "The three nationwide bureaus", b: "These are the files almost every lender pulls. Free weekly reports at AnnualCreditReport.com — permanently, confirmed by the FTC as of July 2026." },
    { k: "national", n: "Other national files", b: "Lenders pull these too, and almost nobody checks them." },
    { k: "medical", n: "Medical & insurance files", b: "Not credit files — but they hold your prescription history, your insurance application answers, and your claims history, and they shape what insurers will sell you and at what price." },
    { k: "banking", n: "Bank account screening", b: "What stops you opening a checking account." },
    { k: "utility", n: "Telecom & utility", b: "Deposits and denials for phone, cable, and power service." },
    { k: "employment", n: "Employment & income", b: "What verifiers see when they check your income." },
    { k: "subprime", n: "Subprime & alternative lending", b: "Payday, installment, and alternative credit data." }
  ];
  var CRA_LIST_URL = "https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/consumer-reporting-companies/companies-list/";
  var CRA_LIST_NOTE = "The CFPB publishes a full list of consumer reporting companies. The current edition is dated January 2025 — it is stale in at least one place we found (Teletrack's merger into DataX), so treat entries as up to a year and a half old.";

  var FREEZE = {
    rights: [
      { k: "Placing a freeze", t: "Free at every consumer reporting agency, by federal law. Must be done within 1 business day if you ask electronically or by phone, 3 business days by mail.", cite: "15 U.S.C. 1681c-1(i)(2)" },
      { k: "Lifting a freeze", t: "Free. Within 1 HOUR if you ask electronically or by phone; 3 business days by mail.", cite: "15 U.S.C. 1681c-1(i)(3)" },
      { k: "Initial fraud alert", t: "At least 1 year. Tells lenders to verify identity — it does not block access.", cite: "15 U.S.C. 1681c-1(a)" },
      { k: "Extended fraud alert", t: "7 years. Requires an identity theft report.", cite: "15 U.S.C. 1681c-1(b)" },
      { k: "Active duty alert", t: "At least 12 months, for deployed service members.", cite: "15 U.S.C. 1681c-1(c)" }
    ],
    lockWarning: "A security freeze is a federal statutory right — free, at every agency, with statutory deadlines and legal remedies. A “lock” is a private product governed by the bureau's terms of service, which the bureau can change, and which is often bundled into a paid subscription. Experian's own page confirms it: Security Freeze is free; CreditLock is included in a paid membership. Take the freeze.",
    ftc: "https://consumer.ftc.gov/articles/what-know-about-credit-freezes-and-fraud-alerts"
  };

  /* Medical debt on credit reports — the honest picture. */
  var MEDCREDIT = {
    vacated: {
      head: "The federal rule that would have removed medical debt from credit reports was VACATED. It is not law.",
      body: "The CFPB finalized the rule in January 2025. On July 11, 2025 the US District Court for the Eastern District of Texas set it aside and vacated it nationwide in Cornerstone Credit Union League v. CFPB, No. 4:25-cv-00016-SDJ (Judge Sean D. Jordan), holding it exceeded the Bureau's authority under the plain text of the FCRA. It never took effect for a single day. Unusually, this was a consent judgment — the CFPB under new leadership joined the plaintiffs in asking the court to strike down its own rule; consumer intervenors opposed and lost. No appeal has been reported.",
      warn: "A large volume of 2025-vintage advice still tells people medical debt is federally barred from credit reports. It is not. Note also that the published Code of Federal Regulations still shows the amended text — the CFPB never published a correction restoring the old language. The court's vacatur controls; the CFR text does not.",
      url: "https://www.consumerfinance.gov/rules-policy/final-rules/prohibition-on-creditors-and-consumer-reporting-agencies-concerning-medical-information-regulation-v/"
    },
    voluntary: {
      head: "What actually protects you today: the bureaus' own voluntary policies.",
      items: [
        "Paid medical collections are removed from credit reports entirely — effective July 1, 2022.",
        "Unpaid medical collections do not appear until they are one year delinquent — up from six months, also effective July 1, 2022.",
        "Medical collections with an initial reported balance under $500 are not reported at all — effective April 2023."
      ],
      caveat: "These are voluntary industry policies, not law. The bureaus can change them at any time, with no notice and no remedy for you — and Clapback could not verify from a 2026-dated primary source that all three are still being applied, only that the bureaus' own consumer pages still describe them in the present tense. Two details matter: the $500 threshold applies to the INITIAL reported balance, not the current one; and the paid-collection removal applies to collections, not to an account still sitting with the provider.",
      caveat2: "If a medical collection on your report is paid, was under $500 when reported, or is less than a year delinquent, you can dispute it on that basis alone. No legal theory needed — it simply shouldn't be there.",
      url: "https://www.equifax.com/personal/education/credit/score/articles/-/learn/can-medical-debt-impact-credit-scores/"
    },
    scoring: [
      { m: "FICO 8", t: "No medical distinction. Ignores collections with an original balance under $100. Still the most widely used model." },
      { m: "FICO 9", t: "Unpaid medical collections weighted less than other collections; all paid collections ignored. FICO measured the median score for people whose only blemish was a medical collection as about 25 points higher." },
      { m: "VantageScore 3.0 & 4.0", t: "Medical collections excluded entirely, regardless of age or amount — implemented end of January 2023." },
      { m: "Classic FICO (2, 4, 5)", t: "Still permitted for mortgages backed by Fannie Mae and Freddie Mac. No medical discount." }
    ],
    scoringTruth: "Do not let anyone tell you medical debt “doesn't count anymore.” Because Classic FICO is still allowed for GSE mortgages and FICO 8 dominates everywhere else, a large share of real 2026 lending decisions still runs on models that do not discount medical collections. VantageScore 4.0's total exclusion only helps where VantageScore 4.0 is actually used.",
    /* State laws — verified, with the preemption fight flagged honestly. */
    states: [
      { s: "ME", law: "10 M.R.S. § 1310-H(4)(A)", eff: "2019, amended 2025", who: "Credit bureaus, medical creditors, debt collectors, and debt buyers", v: true },
      { s: "NY", law: "Fair Medical Debt Reporting Act (Ch. 727 of 2023)", eff: "December 13, 2023", who: "Providers, hospitals, and ambulance services barred from furnishing; contracts must bar collectors; bureaus barred from reporting", v: true },
      { s: "CO", law: "HB23-1126, C.R.S. § 5-18-109", eff: "August 7, 2023", who: "Bureaus, debt collectors, and collection agencies. Exception for credit above the conforming loan limit and certain life insurance underwriting", v: true },
      { s: "MN", law: "Minn. Stat. § 332C.03 (Debt Fairness Act)", eff: "October 1, 2024", who: "Collecting parties barred from reporting; bureaus barred from including it", v: true },
      { s: "VA", law: "Va. Code § 59.1-444.4", eff: "2024", who: "Medical care facilities, licensed practitioners, EMS agencies, and collection entities", v: true },
      { s: "NJ", law: "Louisa Carman Medical Debt Relief Act, N.J.S.A. 56:11-56", eff: "most provisions ~July 22, 2025", who: "Medical creditors, medical debt collectors, bureaus, and debt buyers. Also caps interest at 3% and bars wage garnishment below 600% FPL", v: true },
      { s: "IL", law: "P.A. 103-0648, 815 ILCS 505/2EEEE", eff: "January 1, 2025", who: "Credit bureaus only", v: true },
      { s: "CA", law: "SB 1061, Civ. Code §§ 1785.20.6, 1785.27", eff: "January 1, 2025", who: "Bureaus, furnishers, providers, collectors, and users of reports. Powerful remedy: medical debt becomes void and unenforceable if someone knowingly furnishes it to a bureau", v: true },
      { s: "CT", law: "Conn. Gen. Stat. § 19a-673b(c)(1)", eff: "July 1, 2024", who: "Hospitals, hospital-affiliated entities, and their collection agents — provider-side, not a bureau ban", v: true },
      { s: "RI", law: "S 2709 (2024), R.I. Gen. Laws ch. 6-60", eff: "January 1, 2025 per the bill text", who: "Providers, facilities, EMS transport, collectors by contract, and bureaus", v: true, note: "Secondary trackers give July 1, 2025. The bill text says January 1, 2025. Unresolved." },
      { s: "VT", law: "9 V.S.A. § 2466d (Act 21 of 2025)", eff: "July 1, 2025", who: "Credit reporting agencies", v: true },
      { s: "WA", law: "ESSB 5480, Ch. 145, Laws of 2025", eff: "July 27, 2025", who: "Amends the collection agency and fair credit reporting acts", v: true },
      { s: "MD", law: "HB 1020 (2025), Com. Law § 14-1213", eff: "October 1, 2025", who: "Providers barred from disclosing; bureaus barred from reporting; users barred from using it for creditworthiness; collector contracts must include prohibiting clauses", v: true },
      { s: "DE", law: "SS 1 for SB 156, 6 Del. C. § 2507J", eff: "October 27, 2025", who: "“No person may report any medical debt to a consumer reporting agency,” plus a bureau-side ban", v: true },
      { s: "OR", law: "SB 605, ORS 646A.677(11)-(12)", eff: "January 1, 2026", who: "Any person barred from reporting medical debt; bureaus barred from including it. Violation is an unlawful trade practice with a private right of action", v: true }
    ],
    statesNarrow: [
      { s: "TX", t: "Very narrow, and now contested. Tex. Bus. & Com. Code § 20.05(a)(5) bars reporting a medical collection only where you were insured and the balance is an out-of-network emergency or facility-based claim. Trade groups reported in August 2026 that a federal court held the FCRA preempts it. The decision itself could not be independently verified — treat Texas as unsettled." },
      { s: "FL", t: "Hospitals only. Reporting to a bureau is treated as an extraordinary collection action barred until financial assistance eligibility is determined, an itemized bill is provided, grievances and insurer adjudication are complete, and 30 days' written notice has been sent by traceable mail." },
      { s: "NC", t: "Not a statute — a condition of the state's enhanced Medicaid payment program. Hospitals must commit not to report medical debt to credit agencies to receive the payments, and all 99 eligible acute-care hospitals participate. Because it is contractual rather than statutory, it is not vulnerable to FCRA preemption. A quiet strategic advantage." },
      { s: "NV", t: "NOT a medical debt credit reporting state, despite appearing on several trackers. AB 204 was vetoed on June 10, 2025. Nevada law requires notice to a medical debtor before collection action — that's all." },
      { s: "NM", t: "Not a credit reporting ban. The Patients' Debt Collection Protection Act bars collection actions against indigent patients (at or below 200% FPL) and requires screening — substantial protection, different mechanism." }
    ],
    preemption: "One live fight you should know about. On October 28, 2025 the CFPB issued an interpretive rule saying the FCRA preempts state medical-debt credit reporting laws — that Congress meant to occupy the field. Read the caveat on its face: the rule states it “does not have the force or effect of law” and “has no legally binding effect.” Courts decide preemption, not the CFPB. And there is binding contrary appellate precedent: in Consumer Data Industry Association v. Frey (1st Cir., Feb. 10, 2022) the First Circuit held the FCRA narrowly preempts and did NOT preempt Maine's medical debt law. These state laws remain on the books and enforceable unless a court says otherwise. Treat industry claims that they are dead as advocacy, not holding — but know the ground is contested.",
    preemptionUrl: "https://www.federalregister.gov/documents/2025/10/28/2025-19671/fair-credit-reporting-act-preemption-of-state-laws"
  };

  /* FCRA dispute mechanics — including the trap that decides whether you can ever sue. */
  var DISPUTE = {
    routes: [
      { k: "cra", n: "Dispute with the credit bureau", cite: "FCRA § 611, 15 U.S.C. 1681i",
        steps: [
          "The bureau must conduct a reasonable reinvestigation within 30 days of receiving your dispute.",
          "That extends to 45 days total — but only if you send additional relevant information DURING the first 30 days. Sending extra documents mid-dispute is what triggers the longer window.",
          "The bureau must notify the furnisher within 5 business days.",
          "If the information is inaccurate, incomplete, or cannot be verified, the bureau must promptly delete or modify it. Non-response by the furnisher means it cannot be verified — so it should come off.",
          "You get written results within 5 business days of completion."
        ] },
      { k: "furn", n: "Dispute directly with the furnisher", cite: "FCRA § 623, 15 U.S.C. 1681s-2; 12 CFR 1022.43",
        steps: [
          "Send it to the right address: the one on your credit report, an address the furnisher designates for disputes, or any business address if none is designated. Wrong address means no duty to investigate.",
          "Identify the account, state the specific information disputed and the basis for the dispute, and include supporting documentation.",
          "The furnisher must investigate, review what you sent, and report results to you within 30 days.",
          "It can refuse as frivolous if you gave insufficient information or the dispute is substantially duplicative — it must tell you within 5 business days."
        ] }
    ],
    trap: {
      head: "The sequencing trap — the most valuable thing on this page.",
      body: "FCRA § 1681s-2 has two halves. Subsection (a) covers the furnisher's duty to report accurately and to handle direct disputes. Subsection (b) covers its duties AFTER a bureau notifies it of a dispute. The statute says the private enforcement provisions “do not apply to any violation of subsection (a)” — that half is enforced only by federal and state agencies. There is NO private right of action.",
      rule: "So if you may ever need to sue: dispute through the CREDIT BUREAU first. That is what triggers § 1681s-2(b), the furnisher duty you can actually enforce in court. A direct-to-furnisher dispute alone preserves no private remedy."
    },
    mov: "After the results come back, if the item was “verified,” you have a separate right most people never use: demand a description of the procedure used to determine accuracy and completeness. The bureau must provide it within 15 days of your request. Weak or boilerplate verification is strong evidence later.",
    movCite: "15 U.S.C. 1681i(a)(6)(B)(iii)",
    statement: "You may add a brief statement to your file about a dispute. The bureau may limit it to 100 words. Use this as a last resort — it does not change your score.",
    theft: {
      head: "If the debt isn't yours at all, skip the dispute and use the identity theft block.",
      body: "A bureau must BLOCK reporting of information you identify as resulting from identity theft within 4 business days of receiving proof of identity, an identity theft report, identification of the specific information, and a statement that it does not relate to any transaction by you. Four business days and a mandatory block, versus 30 days and a discretionary reinvestigation. This is much stronger and much faster.",
      cite: "15 U.S.C. 1681c-2",
      report: "https://www.identitytheft.gov/",
      note: "The FTC report you generate at IdentityTheft.gov serves as the identity theft report the statute requires. If that site won't load — it runs on the same FTC platform that was serving a stale outage notice in August 2026 — a police report also works as an identity theft report. File one, get the report number, and don't let a broken website stall you: freeze all three bureaus first, which you can do directly and immediately."
    },
    hipaaTrack: "For medical identity theft specifically, two HIPAA rights help you reconstruct what happened: an accounting of disclosures made in the prior six years (45 CFR 164.528 — free once every 12 months, 60 days to respond), and the right to request amendment of your record (45 CFR 164.526 — 60 days to respond; on denial you may file a statement of disagreement that must be appended to the record). Set expectations: the accounting EXCLUDES disclosures for treatment, payment, and health care operations — which is exactly where most billing activity sits.",
    vsValidation: "Debt validation and a credit dispute are different tools. Validation is aimed at the collector under the FDCPA and asks whether the debt is owed and the amount is right; it stops collection until the collector responds, and there is a 30-day window. A credit dispute is aimed at the bureau under the FCRA, asks whether the tradeline is accurate, and can be filed any time. Use both, in the right order.",
    arb: "One quiet tip: requesting your free reports by phone (1-877-322-8228) or by mail avoids the mandatory arbitration clause that attaches to online requests.",
    acr: "https://www.annualcreditreport.com",
    ftcFree: "https://consumer.ftc.gov/articles/free-credit-reports"
  };

  /* ================================================================== */
  /* DEBT COLLECTORS — FDCPA / Regulation F                              */
  /* ================================================================== */
  var FDCPA = {
    scope: {
      covered: "Third-party collection agencies. Also, in most courts, debt buyers — though under a different half of the definition. The Supreme Court held in Henson v. Santander (2017) that a company collecting debt it purchased, for its own account, is not covered by the “owed another” prong; it expressly left open the “principal purpose” prong, which is how lower courts still reach the big debt buyers. Don't say “debt buyers are covered, full stop.”",
      notCovered: "A hospital's OWN billing office, collecting in the hospital's name, is excluded from the federal FDCPA. No validation notice, no mini-Miranda, no 7-in-7 call cap, no federal cease-communication right. This surprises almost everyone.",
      trap: "But if the hospital collects using a different name that implies someone else is collecting, courts treat it as a debt collector — the false-name exception.",
      cite: "15 U.S.C. 1692a(6)"
    },
    stateCreditors: [
      { s: "CA", n: "Rosenthal Act", t: "Cal. Civ. Code § 1788.2(c) reaches anyone collecting “on behalf of that person or others” — which includes original creditors, and § 1788.17 makes most of the FDCPA applicable. Important carve-out: it excepts the mini-Miranda and the validation notice as to creditors and their employees. So a California hospital's billing office IS bound by the harassment and false-representation rules, but does NOT owe you a validation notice.", v: true },
      { s: "TX", n: "Texas Debt Collection Act", t: "Tex. Fin. Code § 392.001(6) defines “debt collector” as anyone who directly or indirectly engages in debt collection, with no exclusion for a creditor collecting its own debt. A separate, narrower “third-party debt collector” definition proves the broader term is intentional. Remedies include actual damages, injunction, attorney's fees, and a $100 statutory minimum for certain violations.", v: true },
      { s: "FL", n: "Florida Consumer Collection Practices Act", t: "Fla. Stat. § 559.72 opens “In collecting consumer debts, no PERSON shall” — person, not debt collector — so its 19 prohibitions reach original creditors. Provisions keyed to the defined term “debt collector,” including registration, do not.", v: true },
      { s: "NC", n: "N.C.G.S. Chapter 75, Article 2", t: "Defines debt collector as anyone collecting directly or indirectly, except licensed collection agencies — which makes Article 2 the in-house/original-creditor statute. Civil penalty of not less than $500 and not more than $4,000 per violation, plus actual damages.", v: true },
      { s: "NYC", n: "New York City SHIELD Rule", t: "Takes effect January 1, 2027 — delayed from September 1, 2026, so law-firm alerts from early 2026 have the wrong date. It expressly covers original creditors, caps communications at three per account per seven days across all media (excluding mailed letters), requires direct written consent for electronic contact, requires original account documentation to substantiate a disputed debt, and includes medical-debt provisions. Enforced administratively by the Department of Consumer and Worker Protection; no new private right of action.", v: true }
    ],
    stateCreditorsGap: "Massachusetts, Wisconsin, Michigan, Colorado, and New York State are all commonly described as reaching original creditors too. Clapback could not verify those against primary sources and will not assert them. If you are in one of those states, ask a consumer attorney — it may well help you.",
    validation: {
      head: "The validation notice — and the deadline that actually matters",
      must: ["The collector's name and a mailing address for disputes", "Your name and address", "The original creditor's name", "The account number as of the itemization date", "The current creditor's name", "The itemization date", "The amount owed on the itemization date", "An itemization showing interest, fees, payments, and credits since that date", "The current amount owed", "The date the validation period ends", "A tear-off with the prompts “This is not my debt,” “The amount is wrong,” and “Other”"],
      cite: "12 CFR 1006.34",
      itemization: "The collector picks which of five reference dates to itemize from: your last statement, the charge-off date, your last payment, the transaction that created the debt, or a judgment. A collector choosing the charge-off date hides everything that happened before charge-off. If you are disputing the AMOUNT, ask for itemization from the TRANSACTION date.",
      window: "The validation period runs 30 days from when you receive the notice — and the collector may presume you received it 5 days after sending, excluding Saturdays, Sundays, and federal holidays. So the real window is longer than a flat 30 days from the postmark. Clapback's calculator uses the 5-business-day presumption.",
      effect: "Disputing in writing during that window is the only step that legally STOPS collection. The collector must cease collecting the disputed portion until it mails you verification of the debt or a copy of a judgment. Separately, asking in writing for the original creditor's name and address also stops collection until it answers.",
      honesty: "Be realistic about what verification produces. Neither the FDCPA nor Regulation F defines it, and in most federal circuits a collector satisfies it with a printout showing the creditor's name, your name, an account number, and a balance. A dispute letter is not discovery. It will usually not get you the original signed contract, a full payment history, or the chain of title on a purchased debt. Its power is the pause and the paper trail — which are worth a great deal. The real leverage arrives if they sue, because then they have to actually prove it.",
      noAdmission: "Not disputing is not an admission. The statute says so expressly: failure to dispute “may not be construed by any court as an admission of liability.”"
    },
    calls: {
      head: "Call frequency — what the 7-in-7 rule really says",
      rule: "A collector is PRESUMED to comply if it places no more than seven calls in seven consecutive days about a particular debt, and does not call within seven days after actually speaking with you about that debt.",
      cite: "12 CFR 1006.14(b)",
      nuance: [
        "Both directions are rebuttable. Fewer than seven calls can still be a violation if the pattern shows intent to harass. More than seven can still be lawful if the collector can explain it.",
        "The presumption is measured per particular person AND per particular debt. That second half matters enormously for medical debt, where one hospital stay routinely fragments into many accounts: four accounts at one agency means 28 calls in seven days can sit inside the presumption, and almost nobody knows that.",
        "Calls that never connect don't count.",
        "Calls you consented to, within seven days of consent, don't count.",
        "The statutory backstop still applies regardless: repeated or continuous calls with intent to annoy, abuse, or harass violate 15 U.S.C. 1692d(5)."
      ]
    },
    comms: [
      { k: "Time of day", t: "Before 8:00 a.m. or after 9:00 p.m. local time at YOUR location is presumed inconvenient.", cite: "12 CFR 1006.6(b)(1)" },
      { k: "At work", t: "A collector must not contact you at work if it knows or has reason to know your employer prohibits it. Tell them, in writing, and keep a copy.", cite: "12 CFR 1006.6(b)(3)" },
      { k: "Work email", t: "Separately and flatly prohibited — a collector may not email you at an employer-provided address, with narrow exceptions.", cite: "12 CFR 1006.22(f)" },
      { k: "Social media", t: "Public or semi-public social media messages about your debt are prohibited.", cite: "12 CFR 1006.22(f)" },
      { k: "Opt out of a medium", t: "Every electronic communication must include a clear, simple way to opt out of further electronic contact — and they cannot charge you or demand extra information to honor it. Once you ask them to stop using a medium, they must stop using it.", cite: "12 CFR 1006.6(e); 1006.14(h)" },
      { k: "Postcards and envelope markings", t: "Communicating by postcard is prohibited, as is putting anything on an envelope beyond the collector's address that reveals it's about a debt.", cite: "15 U.S.C. 1692f(7)-(8)" },
      { k: "If you have a lawyer", t: "Once the collector knows you are represented, it must go through your attorney.", cite: "12 CFR 1006.6(b)(2)" }
    ],
    voicemail: "A collector may leave a “limited-content message” that legally isn't a communication at all. It may contain ONLY: a business name that doesn't indicate debt collection, a request that you call back, the name of one or more people to contact, and a callback number — plus optionally a greeting, the date and time, and suggested times to reply. A voicemail that names the debt, states an amount, mentions a creditor, or says “this is an attempt to collect a debt” is NOT a limited-content message. It's a full communication — and if a third party heard it, that's a disclosure problem.",
    voicemailCite: "12 CFR 1006.2(j); 15 U.S.C. 1692c(b)",
    /* Violations the user can log. */
    violations: [
      { id: "calls7", n: "More than 7 calls in 7 days about one debt", cite: "12 CFR 1006.14(b)" },
      { id: "call7after", n: "Called within 7 days after speaking with me about that debt", cite: "12 CFR 1006.14(b)" },
      { id: "hours", n: "Called before 8am or after 9pm my local time", cite: "15 U.S.C. 1692c(a)(1)" },
      { id: "work", n: "Contacted me at work after I told them not to", cite: "15 U.S.C. 1692c(a)(3)" },
      { id: "workemail", n: "Emailed my work address", cite: "12 CFR 1006.22(f)" },
      { id: "thirdparty", n: "Discussed my debt with a third party (family, neighbor, employer)", cite: "15 U.S.C. 1692c(b)" },
      { id: "amount", n: "Misstated the amount, or added fees not authorized by the agreement or by law", cite: "15 U.S.C. 1692e(2)(A); 1692f(1)" },
      { id: "suethreat", n: "Threatened a lawsuit, garnishment, or seizure they can't or won't actually do", cite: "15 U.S.C. 1692e(5)" },
      { id: "timebar", n: "Sued or threatened to sue on a debt past the statute of limitations", cite: "12 CFR 1006.26(b)" },
      { id: "arrest", n: "Threatened arrest, jail, or criminal prosecution", cite: "15 U.S.C. 1692e(4)" },
      { id: "attorney", n: "Implied a lawyer was involved when none was", cite: "15 U.S.C. 1692e(3)" },
      { id: "govt", n: "Implied they were from a government agency", cite: "15 U.S.C. 1692e(1)" },
      { id: "nomini", n: "Never disclosed they were a debt collector", cite: "15 U.S.C. 1692e(11)" },
      { id: "noval", n: "Never sent the validation notice", cite: "15 U.S.C. 1692g(a)" },
      { id: "keptgoing", n: "Kept collecting after I disputed in writing, without sending verification", cite: "15 U.S.C. 1692g(b)" },
      { id: "cease", n: "Kept contacting me after a written cease-communication request", cite: "15 U.S.C. 1692c(c)" },
      { id: "profane", n: "Used obscene, profane, or abusive language", cite: "15 U.S.C. 1692d(2)" },
      { id: "repeat", n: "Repeated or continuous calls to annoy, abuse, or harass", cite: "15 U.S.C. 1692d(5)" },
      { id: "noident", n: "Called without meaningfully identifying themselves", cite: "15 U.S.C. 1692d(6)" },
      { id: "parking", n: "The first I heard of this debt was seeing it on my credit report (debt parking)", cite: "12 CFR 1006.30(a)" },
      { id: "postcard", n: "Sent a postcard, or marked the envelope so anyone could tell it was a debt", cite: "15 U.S.C. 1692f(7)-(8)" },
      { id: "venue", n: "Sued me somewhere other than where I live or where I signed the contract", cite: "15 U.S.C. 1692i" },
      { id: "nodispute", n: "Reported the debt to a credit bureau without noting that I disputed it", cite: "15 U.S.C. 1692e(8)" }
    ],
    suing: {
      head: "You can sue a collector — and the clock is short",
      damages: "Actual damages (emotional distress counts in most circuits), plus statutory damages up to $1,000 per action, plus costs and reasonable attorney's fees if you win.",
      cap: "Read that carefully: $1,000 is the cap on statutory damages for the ACTION, not per violation. Never assume $1,000 times the number of calls. Statutory damages are also discretionary — “as the court may allow.”",
      sol: "ONE YEAR from the date the violation occurred. The Supreme Court held in Rotkiske v. Klemm (2019) that the clock starts when the violation happens, not when you discover it. There is no general discovery rule.",
      cite: "15 U.S.C. 1692k",
      fees: "The fee-shifting provision is the real engine — it is why these cases are economically viable at all. Because the collector pays your attorney's fees if you win, many consumer lawyers take these cases with no money up front. Ask each lawyer directly.",
      naca: "https://www.consumeradvocates.org/findanattorney/"
    },
    timeBarred: {
      head: "Time-barred debt — the most dangerous trap in collections",
      rule: "A collector must not bring or threaten to bring a legal action to collect a debt whose statute of limitations has expired. The only exception is a proof of claim in bankruptcy.",
      cite: "12 CFR 1006.26(b)",
      noDisclosure: "There is NO federal requirement that a collector tell you a debt is time-barred. A 2019 proposal would have required one; it was never finalized. Several states do require it under their own law — New York, California, New Mexico and West Virginia among them — as will New York City's rule from January 1, 2027. Check your state's; a missing disclosure where one is required is itself a violation.",
      withdrawn: "The CFPB used to say this prohibition applied even if the collector neither knew nor should have known the debt was time-barred — strict liability. It WITHDREW that advisory opinion on May 12, 2025. The regulation itself is unchanged and still binding. What's gone is the Bureau's interpretation. Courts will decide.",
      revival: "The trap: in most states, a partial payment or an acknowledgment that you owe an old debt can RESTART the limitations clock. “Can you just send $20 today to show good faith?” is, in many states, the act that resurrects a dead claim and exposes you to a lawsuit you would otherwise have won. In some states even saying “yes, that's mine” is enough.",
      rule2: "If a debt might be past your state's limitations period: do not pay anything, do not promise to pay, do not sign a payment plan, and do not confirm the debt is yours — until you know your state's revival rule. See the Court kit for what Clapback could and could not verify per state."
    },
    cease: {
      head: "The cease-communication letter — a tactical choice, not a magic button",
      what: "Tell a collector in writing that you refuse to pay, or that you want them to stop contacting you, and they must stop — with three exceptions: to say collection efforts are ending, to say they may invoke a specific remedy, or to say they intend to invoke one.",
      cite: "15 U.S.C. 1692c(c)",
      notDo: ["It does NOT erase, cancel, or invalidate the debt.", "It does NOT stop a lawsuit — the exceptions expressly allow notifying you of remedies, and filing suit isn't a prohibited communication.", "It does NOT stop credit reporting.", "It does NOT bind an original creditor or a hospital's own billing office, unless your state's law reaches them."],
      risk: "The real strategic risk: cutting off communication removes the collector's cheapest tool, and in practice that can ACCELERATE a lawsuit, because negotiation is no longer available. A cease letter is right when you're being harassed or the debt isn't yours. It's often wrong when the debt is valid, within the statute of limitations, and you could have settled.",
      how: "Send it by certified mail with return receipt, and keep a copy."
    },
    hipaaMyth: "Two things people get wrong about HIPAA and collections. First: “they violated HIPAA by sending my bill to collections” is almost always false — HIPAA's definition of “payment” expressly includes collection activities, and a collector working for a provider is a business associate. Second: a collector may lawfully know your name, address, date of birth, Social Security number, payment history, and account number, because HIPAA permits disclosing exactly those fields to consumer reporting agencies for collection. What a collector should NOT have or reveal is your diagnosis, treatment, or clinical details. If a collector disclosed WHY you were treated — to you in public, or to anyone else — that is a real problem, and the enforceable claim is under the FDCPA, not HIPAA.",
    hipaaCite: "45 CFR 164.501",
    fake: {
      head: "Real collector or fake?",
      badTest: "Do not use “they knew my Social Security number” as proof a collector is real. HIPAA expressly permits disclosing your SSN, date of birth, address, and payment history to consumer reporting agencies for collection — legitimate medical collectors routinely hold all of it. So do criminals, from data breaches. Knowing your SSN proves nothing in either direction.",
      goodTest: "The one reliable test is the written validation information. A real collector must provide it in the first communication or within five days. A fake one cannot and will not — it has no creditor, no itemization date, no account number, and no address to receive a dispute.",
      flags: ["Wants you to repay a debt you don't recognize", "Refuses to give a mailing address or phone number", "Pressures or frightens you — threatens to report you to law enforcement or have you arrested", "Threatens arrest at your workplace, prison, or driver's license suspension", "Impersonates law enforcement or an attorney", "Demands immediate payment", "A debt you already paid"],
      flagsSrc: "https://consumer.ftc.gov/articles/fake-abusive-debt-collectors",
      steps: ["Get the collector's name, the company name, its address, and its phone number. A refusal is itself a violation and a scam signal.", "Demand written validation information. Do not negotiate before you have it.", "Pay nothing and give no bank or card details until it's validated.", "Verify independently with the original creditor — using a number you look up yourself, never one the caller gives you.", "Dispute in writing within 30 days, certified mail, return receipt, keep a copy.", "Hang up on any threat of arrest, prison, or license suspension.", "Report it to your state attorney general and the CFPB."]
    },
    scams: {
      settlement: "Federal law bans advance fees for debt relief services sold by phone. A debt settlement company may collect a fee only AFTER it has actually settled at least one of your debts under an agreement you signed, AND you have made at least one payment under that settlement. If anyone asks you to pay anything before that — an enrollment fee, an administrative fee, anything — they are breaking the law. Your money must sit in an account you own, at an insured institution, administered by someone not affiliated with the settlement company, and you must be able to withdraw at any time without penalty and get unearned funds back within seven business days.",
      settlementCite: "16 CFR 310.4(a)(5)",
      croa: "Credit repair organizations may not charge you before the service is fully performed, and you have three business days to cancel any contract — the contract must include a Notice of Cancellation form saying so. If you paid a credit repair company, the damages provision lets you recover the GREATER of your actual damages or EVERYTHING YOU PAID THEM, plus attorney's fees. That is a genuinely strong remedy almost nobody knows about.",
      croaCite: "15 U.S.C. 1679b, 1679e, 1679g",
      repairFlags: ["Insists you pay before they help you", "Tells you not to contact the credit bureaus directly", "Pressures you to dispute information that is accurate", "Tells you to falsify a credit application", "Asks you to file a false identity theft report", "Won't put your legal rights in writing", "Promises a “new credit identity” or a way to hide history using a different SSN or EIN"],
      repairSrc: "https://consumer.ftc.gov/articles/credit-repair-scams",
      ftcLine: "The FTC's own summary is worth remembering: “Anything a credit repair company can do legally, you'll be able to do for yourself for little or no cost.”"
    },
    licensing: [
      { s: "TX", n: "Texas", t: "Texas does not license debt collectors. It requires third-party collectors and credit bureaus to file a $10,000 surety bond with the Secretary of State. Collecting without one violates Chapter 392 and, per the Secretary of State, may also be a criminal offense — with a $100 statutory minimum per violation plus attorney's fees. Every Texas third-party collector should be in this portal. Absence is actionable.", u: "https://texas-sos.appianportalsgov.com/tpdc-public-search-portal", v: true },
      { s: "FL", n: "Florida", t: "Consumer collection agencies register with the Office of Financial Regulation.", u: "https://real.flofr.gov/datamart/loginFLOFR.do", v: true },
      { s: "CO", n: "Colorado", t: "Licensed through the Attorney General's Consumer Credit Unit and Collection Agency Board.", u: "https://licensing.coag.gov/s/public-reports", v: true },
      { s: "MA", n: "Massachusetts", t: "Debt collector license through the Division of Banks.", u: "https://services.oca.state.ma.us/LicenseeLookup/licenseelist.asp", v: true },
      { s: "WA", n: "Washington", t: "Licensed through the Department of Licensing.", u: "https://professions.dol.wa.gov/s/license-lookup", v: true },
      { s: "MI", n: "Michigan", t: "Licensed through LARA under the Occupational Code.", u: "https://aca-prod.accela.com/MILARA/GeneralProperty/PropertyLookUp.aspx?isLicensee=Y&TabName=APO", v: true },
      { s: "IL", n: "Illinois", t: "Licensed through IDFPR's Division of Financial Institutions. Note IDFPR runs separate lookups by division — this is the right one.", u: "https://idfpr.illinois.gov/dfi/dfilicenselookup.html", v: true },
      { s: "NC", n: "North Carolina", t: "Licensed, unusually, through the Department of Insurance. There is no public searchable database — call 855-408-1212. Useful tell: since July 1, 2024 collection agencies display their North Carolina permit number on correspondence. A missing permit number is worth flagging.", u: "https://www.ncdoi.gov/licensees/collection-agency-licensing", v: true },
      { s: "NYC", n: "New York City", t: "New York State has no statewide license, but NYC requires one from the Department of Consumer and Worker Protection to collect personal or household debt from NYC residents — including out-of-state agencies, law firms doing regular collection work, and debt buyers. No working consumer-facing license lookup could be found; complaints go to DCWP.", u: "https://a866-dcwpbp.nyc.gov/consumer-complaint/file-complaint", v: true },
      { s: "*", n: "Many other states (via NMLS)", t: "A number of states license debt collectors through the Nationwide Multistate Licensing System. Search the company name here.", u: "https://www.nmlsconsumeraccess.org/", v: true }
    ],
    licensingGap: "Clapback lists only the lookups it verified. If your state isn't here, that does NOT mean it doesn't license collectors — it means we couldn't confirm a working lookup, and telling you “your state doesn't license” when it does would be worse than saying nothing. Search your state's name plus “debt collector license lookup,” or ask your state attorney general.",
    licensingWhy: "Why bother: in some states an unlicensed collector cannot lawfully collect, and judgments it obtained may be void or voidable. Collecting without a required license is also frequently pleaded as an FDCPA violation — threatening action that cannot legally be taken, or collecting an amount not permitted by law.",
    cfpbWithdrawn: "One thing you will not find in Clapback: citations to the CFPB's medical debt advisory opinion, its No Surprises Act bulletin, its time-barred debt advisory opinion, or its pay-to-pay fees opinion. All four were WITHDRAWN on May 12, 2025. Some are still posted on consumerfinance.gov with no withdrawal banner, so tools that scrape the site report them as live. Withdrawing guidance repeals no statute and no regulation — the FDCPA, Regulation F, and the FCRA accuracy rules are unchanged, and your private right to sue is untouched. What's gone is the Bureau's published interpretation and its enforcement posture.",
    cfpbWithdrawnUrl: "https://www.consumerfinance.gov/compliance/guidance/withdrawn-guidance/"
  };

  /* CFPB / FTC / AG complaint lanes — with an honest status note. */
  var COMPLAINT_LANES = [
    { n: "CFPB — Consumer Financial Protection Bureau", t: "For debt collectors, credit bureaus, and credit reporting problems. Verified operating as of August 2026: complaints are being accepted and routed, the public database is live and updating daily, and most companies respond within 15 days. Phone (855) 411-2372, 9am–6pm ET weekdays.", u: "https://www.consumerfinance.gov/complaint/",
      caveat: "File it — but pair it with a state AG complaint rather than treating it as a guaranteed remedy. The Bureau has been operating under litigation-constrained restructuring with substantially reduced staffing, and in June 2026 it announced complaint-system changes including a notice that consumers should exhaust direct disputes with credit bureaus first. Also: file in your OWN name. Complaints submitted by unauthorized third parties can be administratively closed." },
    { n: "Your state attorney general", t: "Often the sharpest tool a consumer has, and frequently more useful than the federal lanes for an individual problem — state AGs intervene on individual matters and hold licensing leverage. Clapback's Report it tab has all 51 offices.", u: "https://www.naag.org/our-work/center-for-consumer-protection/consumer-file-a-complaint/", caveat: "" },
    { n: "FTC — ReportFraud", t: "For scams and fake collectors. Note the FTC does not resolve individual complaints; it feeds a law-enforcement database.", u: "https://consumer.ftc.gov/",
      caveat: "Check this one before you rely on it. Verified twice on August 22, 2026: reportfraud.ftc.gov was still serving a government-shutdown notice with no working reporting form — even though the FTC was plainly operating and issuing press releases that same week. It looks like stale content rather than a real outage, but the form was not usable. The link above goes to the FTC's consumer site instead, which routes you onward if the intake is back. If it isn't, your state attorney general is the better lane anyway. IdentityTheft.gov is on the same platform and could not be confirmed either way — if it won't load, freeze your credit directly with the bureaus and file a police report, which also serves as an identity theft report." },
    { n: "CMS — No Surprises Help Desk", t: "For surprise bills, balance billing, and Good Faith Estimate problems. 1-800-985-3059.", u: "https://www.cms.gov/medical-bill-rights/help/submit-a-complaint", caveat: "" },
    { n: "IRS — Form 13909", t: "To report a nonprofit hospital violating its charity care obligations. Slow, confidential, and no status updates — but it is the federal lane for 501(r).", u: "https://www.irs.gov/pub/irs-pdf/f13909.pdf", caveat: "The GAO found the IRS could not show it was doing its required three-year reviews. Don't rely on this lane alone." },
    { n: "HHS Office for Civil Rights", t: "For being denied your medical records, charged improperly for them, or having your health information mishandled. 180-day deadline. 1-800-368-1019.", u: "https://ocrportal.hhs.gov/ocr/smartscreen/main.jsf", caveat: "" },
    { n: "Your state insurance department", t: "For claim denials and insurer conduct — but ONLY if your plan is fully insured. A state insurance department cannot touch a self-funded employer plan.", u: "https://content.naic.org/state-insurance-departments", caveat: "" },
    { n: "US Department of Labor — EBSA", t: "For self-funded employer health plans, which states cannot regulate. Benefits Advisors: 1-866-444-3272.", u: "https://www.askebsa.dol.gov/WebIntake/home.aspx", caveat: "" }
  ];

  return {
    UPDATED: UPDATED,
    FPL: FPL, fplFor: fplFor,
    NSA: NSA,
    BILL_ERRORS: BILL_ERRORS, GROUP_CODES: GROUP_CODES, GROUP_CODES_SRC: GROUP_CODES_SRC,
    CODE_TOOLS: CODE_TOOLS, PRICE_TOOLS: PRICE_TOOLS, PRICE_STALE: PRICE_STALE, PRICE_FACTS: PRICE_FACTS,
    DENIAL_STATS: DENIAL_STATS, STAT_HONESTY: STAT_HONESTY,
    R501: R501, CHARITY_STATES: CHARITY_STATES, CHARITY_OTHER: CHARITY_OTHER, CHARITY_OTHER_SRC: CHARITY_OTHER_SRC,
    MEDICAID_LOOKBACK: MEDICAID_LOOKBACK,
    APPEALS: APPEALS, RECORDS: RECORDS,
    BUREAUS: BUREAUS, CRA_CATS: CRA_CATS, CRA_LIST_URL: CRA_LIST_URL, CRA_LIST_NOTE: CRA_LIST_NOTE,
    FREEZE: FREEZE, MEDCREDIT: MEDCREDIT, DISPUTE: DISPUTE,
    FDCPA: FDCPA, COMPLAINT_LANES: COMPLAINT_LANES
  };
})();

/* Clapback — "Deadlines" module.
 * The one clock that runs across every other tab. Local only.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM, C = window.CBC;
  var mounted = false;
  var list = [];

  var KIND_LABEL = {
    answer: "Court", ppdr: "Medical bill", records: "Records", appeal: "Insurance",
    validation: "Collector", fdcpa: "Collector", fap240: "Financial assistance",
    eca120: "Financial assistance", other: "Other"
  };

  /* The standard clocks, as a reference card. Each is sourced elsewhere in
     Clapback; this is the one place you can see them side by side. */
  var REFERENCE = [
    { g: "If you're being sued", items: [
      { n: "Answer a debt lawsuit", t: "Typically 14–35 days from service, varying enormously by state and by court level. The summons controls.", go: "court" },
      { n: "Respond to discovery", t: "Commonly 30 days. Miss a request for admission and the fact is deemed admitted against you.", go: "court" },
      { n: "Move to vacate a default judgment", t: "From 30 days to a year depending on ground and state. A judgment entered without proper service is void and usually not time-capped.", go: "court" }
    ]},
    { g: "Medical bills", items: [
      { n: "Apply for hospital financial assistance", t: "At least 240 days from the first billing statement after discharge. Survives even if collection already started.", go: "assist" },
      { n: "Earliest a nonprofit hospital may report or sue you", t: "120 days from that same first post-discharge statement. Anything earlier is a checkable red flag.", go: "assist" },
      { n: "Dispute a bill that beat its Good Faith Estimate", t: "120 calendar days from receiving the initial bill, if the bill ran $400 or more over the estimate.", go: "bills" },
      { n: "Medical records must be produced", t: "30 days, with one 30-day extension that requires written notice of the reason.", go: "bills" }
    ]},
    { g: "Insurance", items: [
      { n: "File an internal appeal", t: "At least 180 days from the denial notice. Your plan may allow longer — check the letter.", go: "appeals" },
      { n: "Request external review", t: "Four months after the final internal denial.", go: "appeals" },
      { n: "Medicare redetermination", t: "120 days from the initial determination. Medicare Advantage: 65 days.", go: "appeals" },
      { n: "Medicaid managed care plan appeal", t: "Only 60 days from the adverse determination — and you must finish the plan's appeal before a state fair hearing.", go: "appeals" }
    ]},
    { g: "Collectors and credit", items: [
      { n: "Dispute a debt in writing", t: "30 days from receipt, and receipt may be presumed 5 business days after they sent it. The only step that legally stops collection.", go: "collect" },
      { n: "Sue a collector under the FDCPA", t: "ONE year from the date of the violation — not from when you discovered it.", go: "collect" },
      { n: "Credit bureau reinvestigation", t: "30 days, extending to 45 only if you send more information during the first 30.", go: "credit" },
      { n: "Method of verification request", t: "The bureau has 15 days to describe how it verified an item.", go: "credit" },
      { n: "Identity theft block", t: "Four business days for the bureau to block, once you supply proof and an identity theft report.", go: "credit" }
    ]},
    { g: "Complaints", items: [
      { n: "HHS Office for Civil Rights", t: "180 days from when you knew or should have known about a records or privacy problem.", go: "bills" }
    ]}
  ];

  function mount() {
    var view = X.$("#view-deadlines");
    if (!view || mounted) { if (mounted) load(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Deadlines</h1>' +
      '<p class="lede">Almost every right in this half of Clapback expires. A default judgment is a missed answer date. A lost appeal is usually a missed 180 days. The strongest collector claim in the world is worthless twelve months and one day after the call. This is the one page that holds all of those clocks in one place.</p>' +

      '<div class="callout callout-info">' +
      '<strong>Everything here is stored on this device only.</strong> Nothing is sent anywhere, and Clapback cannot email or text you. If you want a reminder that actually reaches you, put these dates in your phone’s calendar too — this page is the record, not the alarm.' +
      '</div>' +

      '<div id="dl-summary" class="grid-3"></div>' +

      '<div class="card">' +
      '<h2>Add a deadline</h2>' +
      '<div class="ev-form">' +
      '<div class="ev-field-wide"><label class="field" for="dl-label">What is due</label><input class="input" id="dl-label" placeholder="e.g. File answer — Midland Funding v. me"></div>' +
      '<div class="ev-field"><label class="field" for="dl-due">Date</label><input class="input" id="dl-due" type="date"></div>' +
      '<div class="ev-field"><label class="field" for="dl-kind">Category</label><select class="input" id="dl-kind">' +
      '<option value="answer">Court</option><option value="ppdr">Medical bill</option><option value="fap240">Financial assistance</option>' +
      '<option value="appeal">Insurance</option><option value="validation">Collector</option><option value="records">Records</option>' +
      '<option value="other">Other</option></select></div>' +
      '<div class="ev-field-wide"><label class="field" for="dl-note">Note</label><input class="input" id="dl-note" placeholder="Case number, account number, what happens if you miss it"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="dl-add">Add it</button></div>' +
      '</div>' +
      '</div>' +

      '<h2>What’s running</h2>' +
      '<div id="dl-list"></div>' +

      '<h2>The standard clocks</h2>' +
      '<p class="muted">Every one of these is sourced on the tab it belongs to. This is the side-by-side view.</p>' +
      '<div id="dl-ref"></div>' +

      '<p class="disclaimer">Not legal advice. Deadlines vary by state, by court, and by plan document, and Clapback flags where it could not verify one rather than guessing. The document in front of you — your summons, your denial letter, your validation notice — always controls.</p>';

    renderRef();
    X.$("#dl-add").addEventListener("click", add);
    X.onDeadlines(load);
    load();
  }

  function renderRef() {
    var host = X.$("#dl-ref"); host.innerHTML = "";
    REFERENCE.forEach(function (g) {
      var card = X.el("div", "card");
      card.appendChild(X.el("h3", null, g.g));
      var wrap = X.el("div", "link-list");
      g.items.forEach(function (it) {
        var row = X.el("div", "link-item");
        var l = X.el("div");
        l.appendChild(X.el("div", "li-main", it.n));
        l.appendChild(X.el("div", "li-note", it.t));
        row.appendChild(l);
        var b = X.el("button", "btn btn-ghost btn-sm", "Open →");
        b.setAttribute("data-goto", it.go);
        row.appendChild(b);
        wrap.appendChild(row);
      });
      card.appendChild(wrap);
      host.appendChild(card);
    });
  }

  function add() {
    var label = X.$("#dl-label").value.trim();
    var due = X.$("#dl-due").value;
    if (!label || !due) { X.toast("Add what's due and the date"); return; }
    X.addDeadline({ label: label, due: due, kind: X.$("#dl-kind").value, note: X.$("#dl-note").value.trim() })
      .then(function () {
        X.$("#dl-label").value = ""; X.$("#dl-due").value = ""; X.$("#dl-note").value = "";
        load();
      });
  }

  function load() {
    X.loadDeadlines().then(function (l) {
      list = l.slice().sort(function (a, b) { return String(a.due).localeCompare(String(b.due)); });
      render();
    });
  }

  function render() {
    var host = X.$("#dl-list"); if (!host) return;
    host.innerHTML = "";

    /* summary */
    var sum = X.$("#dl-summary");
    var past = 0, week = 0, month = 0;
    list.forEach(function (d) {
      var n = X.daysUntil(X.parseDate(d.due));
      if (n === null) return;
      if (n < 0) past++; else if (n <= 7) week++; else if (n <= 30) month++;
    });
    sum.innerHTML = "";
    [[String(past), "Already passed"], [String(week), "Due within 7 days"], [String(month), "Due within 30 days"]].forEach(function (p, i) {
      var box = X.el("div", "stat");
      var n = X.el("div", "stat-num", p[0]);
      if (i === 0 && past > 0) n.style.color = "#b91c1c";
      box.appendChild(n);
      box.appendChild(X.el("div", "stat-lbl", p[1]));
      sum.appendChild(box);
    });

    if (!list.length) {
      host.innerHTML = '<div class="card"><p class="muted">Nothing tracked yet. Every calculator in the medical and credit tabs has a “track this” button — or add one above.</p></div>';
      return;
    }

    list.forEach(function (d) {
      var u = X.urgency(d.due);
      var dt = X.parseDate(d.due);
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", d.label));
      var pill = X.el("span", "status-pill " + (u.cls === "sev-high" ? "status-red" : u.cls === "sev-caution" ? "status-amber" : "status-ban"), u.label);
      head.appendChild(pill);
      card.appendChild(head);
      card.appendChild(X.el("div", "law-eff", X.fmt(dt) + "  ·  " + (KIND_LABEL[d.kind] || "Other")));
      if (d.note) card.appendChild(X.el("p", "muted", d.note));
      var row = X.el("div", "btn-row");
      var del = X.el("button", "btn btn-ghost btn-sm", "Done / remove");
      del.addEventListener("click", function () { X.removeDeadline(d.id).then(load); });
      row.appendChild(del);
      var cal = X.el("button", "btn btn-ghost btn-sm", "Add to calendar (.ics)");
      cal.addEventListener("click", function () { ics(d); });
      row.appendChild(cal);
      card.appendChild(row);
      host.appendChild(card);
    });

    var tools = X.el("div", "btn-row");
    var exp = X.el("button", "btn btn-ghost btn-sm", "Export all as CSV");
    exp.addEventListener("click", exportCsv);
    tools.appendChild(exp);
    host.appendChild(tools);
  }

  /* A calendar file is the one way a local-only tool can actually remind you. */
  function ics(d) {
    var dt = X.parseDate(d.due); if (!dt) return;
    var stamp = X.iso(dt).replace(/-/g, "");
    var end = X.iso(X.addDays(dt, 1)).replace(/-/g, "");
    var body = [
      "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Clapback//Deadlines//EN",
      "BEGIN:VEVENT",
      "UID:clapback-" + d.id + "@local",
      "DTSTAMP:" + stamp + "T090000Z",
      "DTSTART;VALUE=DATE:" + stamp,
      "DTEND;VALUE=DATE:" + end,
      "SUMMARY:" + String(d.label).replace(/[\n,;]/g, " "),
      "DESCRIPTION:" + String(d.note || "").replace(/[\n,;]/g, " "),
      "BEGIN:VALARM", "TRIGGER:-P7D", "ACTION:DISPLAY", "DESCRIPTION:Clapback deadline in one week", "END:VALARM",
      "BEGIN:VALARM", "TRIGGER:-P1D", "ACTION:DISPLAY", "DESCRIPTION:Clapback deadline tomorrow", "END:VALARM",
      "END:VEVENT", "END:VCALENDAR"
    ].join("\r\n");
    var blob = new Blob([body], { type: "text/calendar" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = "clapback-deadline.ics";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    X.toast("Calendar file downloaded — open it to add reminders");
  }

  function exportCsv() {
    var rows = [["due_date", "what", "category", "note", "days_remaining"]];
    list.forEach(function (d) {
      rows.push([d.due, d.label, KIND_LABEL[d.kind] || "Other", d.note || "", String(X.daysUntil(X.parseDate(d.due)))]);
    });
    var csv = rows.map(function (r) {
      return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(",");
    }).join("\n");
    var blob = new Blob([csv], { type: "text/csv" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = "clapback-deadlines.csv";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    X.toast("Exported");
  }

  X.bootstrap("deadlines", mount);
})();

/* Clapback — "Credit file" module.
 * Works only on YOUR OWN credit file. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM;
  var MC = M.MEDCREDIT, DS = M.DISPUTE;
  var mounted = false;
  var progress = {};   // { craId: {done:true, at} }
  var prof = {};

  function mount() {
    var view = X.$("#view-credit");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Your credit file</h1>' +
      '<p class="lede">There are more files on you than the three everyone knows about — a fourth national bureau, an insurance-application file, a prescription-history file, a bank-account-screening file, an employment-and-income file. Most people never look at any of them. This tab is for pulling them, freezing them, and fixing what’s wrong on them, with a hard focus on how medical debt actually behaves.</p>' +

      /* ---- the vacated rule ---- */
      '<div class="card danger">' +
      '<h2 id="mc-head"></h2>' +
      '<p id="mc-body"></p>' +
      '<div class="callout callout-warn" id="mc-warn"></div>' +
      '<div class="btn-row">' + X.a("CFPB’s own page on the vacated rule ↗", MC.vacated.url) + '</div>' +
      '</div>' +

      /* ---- voluntary policies ---- */
      '<div class="card">' +
      '<h2 id="vol-head"></h2>' +
      '<ul class="tidy" id="vol-list"></ul>' +
      '<div class="callout callout-info" id="vol-caveat"></div>' +
      '<p id="vol-caveat2"></p>' +
      '<h3 style="margin-top:16px">Quick check: should this medical collection even be there?</h3>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="mv-paid">Is it paid?</label><select class="input" id="mv-paid"><option value="">—</option><option value="y">Yes, paid in full</option><option value="n">No, still unpaid</option></select></div>' +
      '<div class="ev-field"><label class="field" for="mv-amt">Initial reported balance</label><input class="input" id="mv-amt" type="number" min="0" step="1" placeholder="e.g. 340"></div>' +
      '<div class="ev-field"><label class="field" for="mv-delin">Date of first delinquency</label><input class="input" id="mv-delin" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="mv-run">Check it</button></div>' +
      '</div>' +
      '<div id="mv-out"></div>' +
      X.srcLine("Equifax consumer education (the bureaus’ own published policy)", MC.voluntary.url) +
      '</div>' +

      /* ---- state laws ---- */
      '<h2>Does your state restrict medical debt reporting?</h2>' +
      '<div class="card">' +
      '<div class="ev-field" style="max-width:340px"><label class="field" for="mc-state">Your state</label><span id="mc-state-host"></span></div>' +
      '<div id="mc-state-out" style="margin-top:12px"></div>' +
      '</div>' +
      '<div class="card"><h3>Every state Clapback verified</h3><div id="mc-states"></div>' +
      '<h4 style="margin-top:16px">Narrow, conditional, or commonly miscounted</h4><div id="mc-narrow"></div></div>' +
      '<div class="card danger"><h3>One live fight worth knowing about</h3><p id="mc-preempt"></p>' +
      '<div class="btn-row">' + X.a("The CFPB interpretive rule ↗", MC.preemptionUrl) + '</div></div>' +

      /* ---- scoring ---- */
      '<div class="card">' +
      '<h3>How the scoring models actually treat medical collections</h3>' +
      '<div id="mc-scoring" class="link-list"></div>' +
      '<div class="callout callout-warn" id="mc-scoretruth"></div>' +
      '</div>' +

      /* ---- disputes ---- */
      '<h2>Disputing something — in the right order</h2>' +
      '<div class="card danger">' +
      '<h3 id="tr-head"></h3>' +
      '<p id="tr-body"></p>' +
      '<div class="callout callout-warn" id="tr-rule"></div>' +
      '</div>' +
      '<div class="grid-2" id="dispute-routes"></div>' +
      '<div class="card">' +
      '<h3>After the results come back</h3>' +
      '<p id="d-mov"></p>' +
      '<p class="muted" id="d-statement"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3 id="th-head"></h3>' +
      '<p id="th-body"></p>' +
      '<p class="muted" id="th-note"></p>' +
      '<p class="muted" id="th-hipaa"></p>' +
      '<div class="btn-row">' + X.a("IdentityTheft.gov ↗", DS.theft.report, "btn btn-sm") + '</div>' +
      '</div>' +
      '<div class="callout callout-info" id="d-vsval"></div>' +

      /* ---- the files ---- */
      '<h2>Every file on you — pull it, then freeze it</h2>' +
      '<p class="muted">Check each one off as you go. Clapback stamps the date locally so you can see what you’ve done.</p>' +
      '<div class="btn-row">' + X.a("Free weekly reports — AnnualCreditReport.com ↗", DS.acr, "btn") + X.a("FTC on free reports ↗", DS.ftcFree) + '</div>' +
      '<div class="callout callout-info" id="d-arb" style="margin-top:12px"></div>' +
      '<div id="cra-list"></div>' +
      '<p class="fineprint" id="cra-listnote"></p>' +

      /* ---- freezes ---- */
      '<div class="card">' +
      '<h3>Freeze vs lock — take the freeze</h3>' +
      '<div id="fz-rights" class="link-list"></div>' +
      '<div class="callout callout-warn" id="fz-lock"></div>' +
      '<div class="btn-row">' + X.a("FTC on freezes and fraud alerts ↗", M.FREEZE.ftc) + '</div>' +
      '</div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<div class="card"><div id="credit-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal advice. Credit reporting law changes, and the state-law layer described here is being actively contested. Every claim links to its source, verified ' + X.esc(M.UPDATED) + '.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    X.$("#mc-head").textContent = MC.vacated.head;
    X.$("#mc-body").textContent = MC.vacated.body;
    X.$("#mc-warn").innerHTML = "<strong>Why this matters to you right now.</strong> " + X.esc(MC.vacated.warn);

    X.$("#vol-head").textContent = MC.voluntary.head;
    var vl = X.$("#vol-list"); vl.innerHTML = "";
    MC.voluntary.items.forEach(function (s) { vl.appendChild(X.el("li", null, s)); });
    X.$("#vol-caveat").innerHTML = "<strong>Read the fine print.</strong> " + X.esc(MC.voluntary.caveat);
    X.$("#vol-caveat2").textContent = MC.voluntary.caveat2;

    /* states */
    var ms = X.$("#mc-states"); ms.innerHTML = "";
    MC.states.forEach(function (s) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", X.stateName(s.s)));
      head.appendChild(X.el("span", "status-pill pill-ban", "Effective " + s.eff));
      card.appendChild(head);
      card.appendChild(X.el("div", "law-eff", s.law));
      card.appendChild(X.el("p", null, "Who it binds: " + s.who + "."));
      if (s.note) card.appendChild(X.el("p", "muted", s.note));
      ms.appendChild(card);
    });
    var mn = X.$("#mc-narrow"); mn.innerHTML = "";
    MC.statesNarrow.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", X.stateName(s.s)));
      l.appendChild(X.el("div", "li-note", s.t));
      row.appendChild(l);
      mn.appendChild(row);
    });
    X.$("#mc-preempt").textContent = MC.preemption;

    /* scoring */
    var sc = X.$("#mc-scoring"); sc.innerHTML = "";
    MC.scoring.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", s.m));
      l.appendChild(X.el("div", "li-note", s.t));
      row.appendChild(l);
      sc.appendChild(row);
    });
    X.$("#mc-scoretruth").innerHTML = "<strong>Don’t let anyone tell you it doesn’t count anymore.</strong> " + X.esc(MC.scoringTruth);

    /* disputes */
    X.$("#tr-head").textContent = DS.trap.head;
    X.$("#tr-body").textContent = DS.trap.body;
    X.$("#tr-rule").innerHTML = "<strong>So the order is: bureau first.</strong> " + X.esc(DS.trap.rule);

    var dr = X.$("#dispute-routes"); dr.innerHTML = "";
    DS.routes.forEach(function (r) {
      var c = X.el("div", "card mini");
      c.appendChild(X.el("div", "li-main", r.n));
      c.appendChild(X.el("div", "law-eff", r.cite));
      var ul = X.el("ul", "tidy");
      r.steps.forEach(function (s) { ul.appendChild(X.el("li", null, s)); });
      c.appendChild(ul);
      dr.appendChild(c);
    });
    X.$("#d-mov").innerHTML = X.esc(DS.mov) + " <span class='muted'>(" + X.esc(DS.movCite) + ")</span>";
    X.$("#d-statement").textContent = DS.statement;

    X.$("#th-head").textContent = DS.theft.head;
    X.$("#th-body").textContent = DS.theft.body + "  (" + DS.theft.cite + ")";
    X.$("#th-note").textContent = DS.theft.note;
    X.$("#th-hipaa").textContent = DS.hipaaTrack;

    X.$("#d-vsval").innerHTML = "<strong>Validation and dispute are different tools.</strong> " + X.esc(DS.vsValidation) +
      ' <button class="btn btn-ghost btn-sm" data-goto="collect">Validation lives in the Collectors tab →</button>';
    X.$("#d-arb").innerHTML = "<strong>A small tip worth using.</strong> " + X.esc(DS.arb);

    /* freezes */
    var fz = X.$("#fz-rights"); fz.innerHTML = "";
    M.FREEZE.rights.forEach(function (r) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", r.k));
      l.appendChild(X.el("div", "li-note", r.t + "  — " + r.cite));
      row.appendChild(l);
      fz.appendChild(row);
    });
    X.$("#fz-lock").innerHTML = "<strong>A freeze is a right. A lock is a product.</strong> " + X.esc(M.FREEZE.lockWarning);

    X.$("#cra-listnote").innerHTML = X.esc(M.CRA_LIST_NOTE) + ' <a href="' + X.esc(M.CRA_LIST_URL) + '" target="_blank" rel="noopener">The CFPB’s full list ↗</a>';

    X.letterCards(X.$("#credit-letters"), "credit", function () { return {}; });

    /* medical collection checker */
    X.$("#mv-run").addEventListener("click", function () {
      var paid = X.$("#mv-paid").value;
      var amt = parseFloat(X.$("#mv-amt").value);
      var del = X.parseDate(X.$("#mv-delin").value);
      var out = X.$("#mv-out"); out.innerHTML = "";
      var hits = [];
      if (paid === "y") hits.push("It is <strong>paid</strong>. Paid medical collections have been excluded from consumer reports since July 1, 2022.");
      if (isFinite(amt) && amt > 0 && amt < 500) hits.push("The initial reported balance was <strong>under $500</strong>. Medical collections below that threshold have been excluded since April 2023.");
      if (del) {
        var oneYear = X.addDays(del, 365);
        if (X.daysUntil(X.iso(oneYear)) > 0) {
          hits.push("It is <strong>less than one year delinquent</strong> — the one-year reporting delay runs until " + X.esc(X.fmtShort(oneYear)) + ".");
        }
      }
      if (hits.length) {
        out.innerHTML = '<div class="risk-banner risk-high"><div class="risk-ic">✓</div><div>' +
          '<div class="risk-label">This shouldn’t be on your report.</div>' +
          '<div class="risk-sub">' + hits.join(" ") + ' Dispute it with each bureau on that basis alone — no legal theory needed. Use the “Medical collection — voluntary policy removal” letter below and enclose your proof.</div>' +
          '</div></div>';
      } else {
        out.innerHTML = '<div class="risk-banner risk-caution"><div class="risk-ic">–</div><div>' +
          '<div class="risk-label">None of the automatic exclusions apply on what you entered.</div>' +
          '<div class="risk-sub">That doesn’t make it accurate. Check whether your state restricts medical debt reporting (below), whether the amount is right, whether it was ever validated, and — if it came from a nonprofit hospital — whether you were screened for financial assistance before they reported you. If they hadn’t screened you and you later qualify, they must remove the reporting.</div>' +
          '</div></div>';
      }
    });
  }

  function load() {
    X.get(["medCraProgress"]).then(function (d) {
      progress = d.medCraProgress || {};
      return X.profile();
    }).then(function (p) {
      prof = p;
      var host = X.$("#mc-state-host");
      if (host) {
        host.innerHTML = X.stateSelect("mc-state", p.state, "Select a state…");
        X.$("#mc-state").addEventListener("change", renderStateAnswer);
      }
      renderStateAnswer();
      render();
    });
  }

  /* Re-entering the tab re-reads the profile, so a state saved after this
     module first mounted still lands here. An explicit pick on this tab wins. */
  function refresh() {
    X.profile().then(function (p) {
      prof = p;
      var sel = X.$("#mc-state");
      if (sel && !sel.value && p.state) sel.value = p.state;
      renderStateAnswer();
      render();
    });
  }

  function renderStateAnswer() {
    var out = X.$("#mc-state-out"); if (!out) return;
    var st = X.$("#mc-state") ? X.$("#mc-state").value : prof.state;
    if (!st) { out.innerHTML = '<p class="muted">Pick your state and Clapback will tell you what it verified.</p>'; return; }
    var hit = MC.states.filter(function (s) { return s.s === st; })[0];
    var nar = MC.statesNarrow.filter(function (s) { return s.s === st; })[0];
    if (hit) {
      out.innerHTML = '<div class="risk-banner risk-low"><div class="risk-ic">✓</div><div>' +
        '<div class="risk-label">' + X.esc(X.stateName(st)) + ' restricts medical debt on credit reports.</div>' +
        '<div class="risk-sub"><strong>' + X.esc(hit.law) + '</strong>, effective ' + X.esc(hit.eff) + '. Binds: ' + X.esc(hit.who) + '. Cite it in your dispute letter — and see the preemption note below, because industry groups are contesting these laws.</div>' +
        '</div></div>';
    } else if (nar) {
      out.innerHTML = '<div class="risk-banner risk-caution"><div class="risk-ic">◆</div><div>' +
        '<div class="risk-label">' + X.esc(X.stateName(st)) + ' — it’s complicated.</div>' +
        '<div class="risk-sub">' + X.esc(nar.t) + '</div>' +
        '</div></div>';
    } else {
      out.innerHTML = '<div class="risk-banner risk-caution"><div class="risk-ic">–</div><div>' +
        '<div class="risk-label">No verified state restriction in ' + X.esc(X.stateName(st)) + '.</div>' +
        '<div class="risk-sub">The bureaus’ own voluntary policies still apply to you — paid medical collections off, under-$500 off, one-year delay — and so does everything else on this page. Run the quick check above.</div>' +
        '</div></div>';
    }
  }

  function render() {
    var host = X.$("#cra-list"); if (!host) return;
    host.innerHTML = "";
    M.CRA_CATS.forEach(function (cat) {
      var items = M.BUREAUS.filter(function (b) { return b.cat === cat.k; });
      if (!items.length) return;
      var done = items.filter(function (b) { return progress[b.id] && progress[b.id].done; }).length;

      var wrap = X.el("div", "broker-group");
      var head = X.el("div", "cat-head");
      var h = X.el("h3", null, cat.n);
      head.appendChild(h);
      head.appendChild(X.el("span", "cat-count", done + " / " + items.length));
      wrap.appendChild(head);
      wrap.appendChild(X.el("p", "cat-blurb", cat.b));

      items.forEach(function (b) {
        var row = X.el("div", "broker" + (cat.k === "big3" ? " critical" : ""));
        var chk = X.el("input", "broker-check");
        chk.type = "checkbox";
        chk.checked = !!(progress[b.id] && progress[b.id].done);
        chk.id = "cra-" + b.id;
        chk.setAttribute("aria-label", "Mark " + b.n + " as handled");
        chk.addEventListener("change", function () {
          if (chk.checked) progress[b.id] = { done: true, at: Date.now() };
          else delete progress[b.id];
          X.set({ medCraProgress: progress }).then(render);
        });
        row.appendChild(chk);

        var body = X.el("div", "broker-body");
        var nm = X.el("label", "broker-name" + (chk.checked ? " done" : ""), b.n);
        nm.setAttribute("for", "cra-" + b.id);
        body.appendChild(nm);
        body.appendChild(X.el("div", "broker-note", b.holds));
        if (b.note) body.appendChild(X.el("div", "broker-note", b.note));
        if (b.phone) body.appendChild(X.el("div", "broker-note", "Phone: " + b.phone));
        if (progress[b.id] && progress[b.id].at) {
          var when = X.el("div", "done-date", "Marked " + X.fmtShort(new Date(progress[b.id].at)));
          body.appendChild(when);
        }
        row.appendChild(body);

        var act = X.el("div", "broker-act stack");
        var html = "";
        if (b.report) html += X.a("Get your file ↗", b.report, "btn btn-sm");
        if (b.freeze) html += X.a("Freeze ↗", b.freeze);
        if (b.opt) html += X.a("Opt out ↗", b.opt);
        act.innerHTML = html;
        row.appendChild(act);

        wrap.appendChild(row);
      });
      host.appendChild(wrap);
    });
  }

  if (X.hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !mounted) return;
      if (ch.medCraProgress) { progress = ch.medCraProgress.newValue || {}; render(); }
    });
  }

  X.bootstrap("credit", mount);
})();

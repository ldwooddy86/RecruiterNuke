/*
 * Clapback — on-page helper (content script, isolated world).
 *
 * Two defensive nudges, both read-only and local:
 *   1. If you land on a known people-search / data-broker site, it offers a
 *      one-click link to that site's removal page (turn the exposure off).
 *   2. If a page is asking for a password AND its address shows strong phishing
 *      signals (look-alike/typosquat domain, punycode, raw IP, credential trick),
 *      it shows a caution banner explaining why.
 *
 * It never fills, changes, submits, or transmits anything. Data comes from
 * data.js / vet.js, which are injected before this file per manifest.json.
 */
(function () {
  "use strict";
  if (window.top !== window) return;
  if (window.__pdsHelperLoaded) return;
  window.__pdsHelperLoaded = true;

  var PDS = window.PDS || null;
  var PDSVet = window.PDSVet || null;
  var enabled = true;
  var shownBroker = false, shownPhish = false;

  try {
    chrome.storage.local.get(["settings"], function (d) {
      if (chrome.runtime && chrome.runtime.lastError) return;
      enabled = !(d && d.settings && d.settings.detectorEnabled === false);
      if (enabled) run();
      watchToggle();
    });
  } catch (e) { /* extension context unavailable; stay silent */ }

  function watchToggle() {
    try {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area !== "local" || !changes.settings) return;
        var ns = changes.settings.newValue || {};
        enabled = ns.detectorEnabled !== false;
        if (!enabled) removeBanner();
        else run();
      });
    } catch (e) {}
  }

  function run() {
    try { checkBrokerSite(); } catch (e) {}
    try { checkPhishing(); } catch (e) {}
  }

  function hostname() { return (location.hostname || "").toLowerCase().replace(/^www\./, ""); }

  function checkBrokerSite() {
    if (shownBroker || !PDS || !PDS.PEOPLE_SEARCH_SITES) return;
    var h = hostname();
    var hit = PDS.PEOPLE_SEARCH_SITES.find(function (s) {
      return h === s.host || h.slice(-(s.host.length + 1)) === "." + s.host;
    });
    if (!hit) return;
    shownBroker = true;
    showBanner({
      title: "🔎 You're on " + hit.name,
      body: "This is a people-search / data-broker site that may be publishing your name, address, phone, and relatives. You can remove your listing here — then check the rest in your exposure audit.",
      primary: { label: "Open removal page", act: function () { window.open(hit.url, "_blank", "noopener"); } },
      secondary: { label: "My exposure audit", act: function () { openDash("audit"); } }
    });
  }

  function checkPhishing() {
    if (shownPhish || !PDSVet) return;
    if (!document.querySelector('input[type="password"]')) return;   // only when creds are being requested
    var res;
    try { res = PDSVet.url(location.href); } catch (e) { return; }
    if (!res || res.level !== "high") return;
    var reasons = res.signals.filter(function (s) { return s.sev === "high"; }).slice(0, 2).map(function (s) { return s.text; });
    if (!reasons.length) return;
    shownPhish = true;
    showBanner({
      warn: true,
      title: "⛔ This page is asking for a password — its address looks unsafe",
      body: reasons.join(" "),
      note: "If you didn't type this address yourself, don't enter anything. Open the real site from a bookmark or by typing its name into a search engine.",
      primary: null,
      secondary: { label: "Learn more", act: function () { openDash("vet"); } }
    });
  }

  function openDash(view) { try { chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD", view: view }); } catch (e) {} }

  var bannerEl = null;
  function removeBanner() { if (bannerEl && bannerEl.parentNode) bannerEl.parentNode.removeChild(bannerEl); bannerEl = null; }

  function showBanner(o) {
    removeBanner();
    var b = document.createElement("div");
    b.className = "pds-banner" + (o.warn ? " pds-warn" : "");

    var x = document.createElement("button"); x.className = "pds-x"; x.textContent = "×";
    x.addEventListener("click", function (e) { e.stopPropagation(); removeBanner(); });
    b.appendChild(x);

    b.appendChild(mk("div", "pds-h", o.title));
    b.appendChild(mk("div", "pds-p", o.body));
    if (o.note) b.appendChild(mk("div", "pds-note", o.note));

    var row = document.createElement("div"); row.className = "pds-row";
    if (o.primary) row.appendChild(btn(o.primary.label, o.primary.act, false));
    if (o.secondary) row.appendChild(btn(o.secondary.label, o.secondary.act, true));
    row.appendChild(btn("Dismiss", removeBanner, true));
    b.appendChild(row);

    b.appendChild(mk("div", "pds-foot", "Clapback · nothing on this page is read or sent anywhere"));
    document.body.appendChild(b);
    bannerEl = b;
  }

  function mk(tag, cls, text) { var e = document.createElement(tag); e.className = cls; if (text != null) e.textContent = text; return e; }
  function btn(label, act, ghost) {
    var el = document.createElement("button"); el.className = "pds-btn" + (ghost ? " ghost" : ""); el.textContent = label;
    el.addEventListener("click", function (e) { e.stopPropagation(); act(); });
    return el;
  }
})();

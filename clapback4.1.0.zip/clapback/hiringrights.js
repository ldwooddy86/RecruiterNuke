/* Clapback — "Hiring rights" module: Reporting Unethical Hiring Practices,
 * a US resource directory. Content adapted from the user's compiled and
 * verified directory (checked against official sources, August 18, 2026).
 * Structure preserved: triage table → federal profiles → state FEPAs →
 * local agencies → non-governmental resources → sources & methodology.
 * Self-contained, on-device; every button is an ordinary link.
 */
(function () {
  "use strict";
  var D = window.PDS;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function a(u, t) { return '<a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(t || u.replace(/^https?:\/\/(www\.)?/, "")) + " \u2197</a>"; }

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  var profile = {};
  var mounted = false;

  /* ---------------- data (from the compiled directory, Aug 18, 2026) ---------------- */

  var TRIAGE = [
    { p: "Not hired \u2014 or screened out \u2014 because of race, color, religion, sex (incl. pregnancy, sexual orientation, gender identity), national origin, age 40+, disability, or genetic information", w: "EEOC \u2014 dual-files automatically with your state/local FEPA", j: "eeoc" },
    { p: "Employer too small for federal law (under 15 employees), or a state-only protected class (marital status, off-duty conduct\u2026)", w: "Your state or local fair-employment agency \u2014 see the state finder below", j: "states" },
    { p: "\u201cU.S. citizens only\u201d or \u201cvisa workers only\u201d job ads; refusal to accept valid work-authorization documents; E-Verify misuse; citizenship-status discrimination; national-origin discrimination at firms with 4\u201314 employees", w: "DOJ Civil Rights Division \u2014 Immigrant and Employee Rights Section (IER)", j: "ier" },
    { p: "Refused hire, or blacklisted, for union membership, union sympathies, or group advocacy about wages/conditions (non-union workplaces too)", w: "NLRB", j: "nlrb" },
    { p: "Fake job postings, \u201cghost jobs\u201d used to harvest data, recruitment-fee scams, check-cashing \u201conboarding\u201d fraud, bait-and-switch offers", w: "FTC (ReportFraud.ftc.gov) and your state attorney general", j: "ftc", x: "report" },
    { p: "Background check run without written consent; rejection without pre-adverse-action notice and a copy of the report; errors the screening company won\u2019t fix (FCRA)", w: "FTC and CFPB; also dispute directly with the screening company", j: "cfpb" },
    { p: "Criminal-history questions asked earlier than allowed under \u201cban-the-box\u201d / fair-chance laws", w: "State or local fair-employment agency (e.g., NYC Commission on Human Rights)", j: "states" },
    { p: "Disability or protected-veteran discrimination by a company holding federal contracts", w: "OFCCP (U.S. Dept. of Labor) \u2014 see the status note in its profile", j: "ofccp" },
    { p: "Hiring or reemployment discrimination tied to military service or obligations (USERRA)", w: "DOL VETS for private/state/local employers; OSC for federal agencies", j: "vets" },
    { p: "Federal-government hiring abuses: nepotism, tailored job announcements, obstruction of open competition, illegal preferences", w: "U.S. Office of Special Counsel (OSC); appeals to MSPB", j: "osc" },
    { p: "Discrimination applying for a job at a federal agency", w: "That agency\u2019s EEO office \u2014 contact an EEO counselor within 45 days", j: "eeoc" },
    { p: "Pay range omitted from a job posting where disclosure is required; salary-history questions where banned", w: "State labor department or civil-rights agency; NYC CCHR in New York City", j: "states" },
    { p: "Pre-employment polygraph / lie-detector demands (EPPA)", w: "DOL Wage and Hour Division", j: "whd" },
    { p: "Unpaid \u201cworking interviews\u201d or trial shifts; misclassification set up at hire; foreign-labor recruitment abuses (H-2A/H-2B)", w: "DOL Wage and Hour Division and your state labor department", j: "whd" },
    { p: "Discriminatory AI / automated hiring tools (r\u00e9sum\u00e9 screens, video-interview scoring)", w: "EEOC; NYC Dept. of Consumer and Worker Protection (Local Law 144); Illinois Dept. of Human Rights (as of Jan. 1, 2026)", j: "eeoc" }
  ];

  var FEDERAL = [
    { id: "eeoc", name: "EEOC \u2014 Equal Employment Opportunity Commission",
      handles: "Hiring discrimination based on race, color, religion, sex (including pregnancy, sexual orientation, and gender identity), national origin, age (40+), disability, or genetic information \u2014 including discriminatory job ads, recruitment, screening tools, and interview questions. Generally covers private employers with 15+ employees (20+ for age claims), plus state/local governments, employment agencies, and unions.",
      file: 'Begin an inquiry and file a charge through the ' + a("https://publicportal.eeoc.gov", "EEOC Public Portal") + ', by phone, or at any field office. Process guide: ' + a("https://www.eeoc.gov/filing-charge-discrimination", "eeoc.gov/filing-charge-discrimination") + ".",
      deadline: "180 calendar days from the act; extended to 300 days where a state or local law and FEPA cover the same basis. Federal employees: 45 days to contact the agency EEO counselor.",
      contact: "1-800-669-4000 \u00b7 TTY 1-800-669-6820 \u00b7 ASL video 1-844-234-5122 \u00b7 info@eeoc.gov \u00b7 " + a("https://www.eeoc.gov/field-office", "field office locator"),
      note: "Filing is free and a charge is a legal prerequisite to a later Title VII/ADA/ADEA lawsuit. Charges are dual-filed with your state or local FEPA automatically." },
    { id: "ier", name: "DOJ \u2014 Immigrant and Employee Rights Section (IER), Civil Rights Division",
      handles: "Citizenship-status discrimination in hiring/firing/recruitment (employers with 4+ employees); national-origin discrimination by employers with 4\u201314 employees (the gap below EEOC coverage); unfair documentary practices in I-9/E-Verify verification; discriminatory \u201ccitizens-only\u201d or visa-status-restricted job postings; and related retaliation. Protects U.S. citizens and lawfully authorized workers alike.",
      file: "Charge form online at " + a("https://www.justice.gov/crt/filing-an-IER-Charge", "justice.gov/crt/filing-an-IER-Charge") + " (also by mail/fax/email). Overview: " + a("https://www.justice.gov/crt/immigrant-and-employee-rights-section", "IER section home") + ".",
      deadline: "180 days from the discriminatory act.",
      contact: "Worker hotline 1-800-255-7688 (interpreters available; anonymous calls accepted) \u00b7 TTY 1-800-237-2515",
      note: "IER remains active in 2026 and has made citizenship-status discrimination \u2014 including preferences for visa holders over U.S. workers \u2014 an enforcement priority." },
    { id: "whd", name: "DOL \u2014 Wage and Hour Division (WHD)",
      handles: "Hiring-stage wage abuses: unpaid \u201cworking interviews\u201d and trial shifts, minimum-wage/overtime violations, employee misclassification arranged at hire, child-labor violations, pre-employment polygraph demands (Employee Polygraph Protection Act), FMLA interference, and abuses in H-2A/H-2B foreign labor recruitment (illegal recruitment fees, contract misrepresentation).",
      file: "Call or file online: " + a("https://www.dol.gov/agencies/whd/contact/complaints", "dol.gov/agencies/whd/contact/complaints") + " \u00b7 online intake at " + a("https://webapps.dol.gov/contactwhd/", "webapps.dol.gov/contactwhd") + ".",
      deadline: "File promptly \u2014 FLSA back-pay recovery generally reaches back two years (three if willful).",
      contact: "1-866-487-9243 (1-866-4-US-WAGE). Complaints are confidential; immigration status is not a bar to filing.",
      note: "WHD investigates regardless of whether the worker was ultimately hired; retaliation for filing is independently unlawful." },
    { id: "nlrb", name: "NLRB \u2014 National Labor Relations Board",
      handles: "Refusal to hire (or to consider) applicants because of union membership, organizing activity, or protected concerted activity \u2014 including \u201csalting\u201d cases and blacklisting. Applies to most private-sector employers, unionized or not; also covers coercive statements and unlawful conditions imposed during hiring.",
      file: "File an unfair labor practice charge (Form NLRB-501) with any regional office or electronically: " + a("https://www.nlrb.gov/about-nlrb/what-we-do/investigate-charges", "nlrb.gov \u2014 investigate charges") + ".",
      deadline: "Six months from the unfair labor practice (NLRA \u00a710(b)).",
      contact: "1-844-762-6572 \u00b7 regional office locator and e-filing at nlrb.gov",
      note: "The Board regained a decision-issuing quorum in 2026 and regional offices have continued to accept and investigate charges throughout; new intake procedures aim at reducing backlog." },
    { id: "ofccp", name: "DOL \u2014 Office of Federal Contract Compliance Programs (OFCCP)",
      handles: "Hiring discrimination by companies holding federal contracts/subcontracts, on the basis of disability (Rehabilitation Act \u00a7503) or protected-veteran status (VEVRAA).",
      file: "Pre-complaint inquiry or direct complaint form: " + a("https://www.dol.gov/agencies/ofccp/contact/file-complaint", "dol.gov/agencies/ofccp/contact/file-complaint") + " \u00b7 forms to OFCCPComplaintForms@dol.gov.",
      deadline: "300 calendar days from the alleged action.",
      contact: "1-800-397-6251",
      note: "\u26a0\ufe0f Status note (verify before citing): Executive Order 14173 (Jan. 2025) revoked E.O. 11246, ending OFCCP\u2019s race/sex/religion/national-origin jurisdiction over contractors \u2014 those complaints now go to the EEOC. After 2025 proposals to wind the agency down entirely, OFCCP entered 2026 still operating with a complaint-focused docket under its two remaining statutes (\u00a7503 and VEVRAA) and revised its complaint form in early 2026. Its long-term structure remains in flux." },
    { id: "vets", name: "DOL \u2014 Veterans\u2019 Employment and Training Service (VETS)",
      handles: "USERRA violations: refusal to hire, delayed reemployment, or any denial of employment benefits because of past, present, or future military service or obligations \u2014 against private, state, and local employers. Also administers veterans\u2019-preference complaints in federal hiring (VEOA).",
      file: "VETS Form 1010, online or on paper: " + a("https://www.dol.gov/agencies/vets/programs/userra/fileaclaim", "dol.gov \u2014 USERRA: file a claim") + ".",
      deadline: "No fixed statute of limitations, but delay can limit remedies; VEOA veterans\u2019-preference complaints: 60 days.",
      contact: "1-866-487-2365 \u00b7 local VETS staff in every state",
      note: "USERRA complaints against federal executive agencies may instead be filed with the Office of Special Counsel: " + a("https://www.osc.gov/services/userra/filecomplaint/", "osc.gov \u2014 USERRA complaint") + ". Regulatory text: " + a("https://www.law.cornell.edu/cfr/text/20/1002.288", "20 C.F.R. \u00a71002.288") + "." },
    { id: "osc", name: "OSC &amp; MSPB \u2014 federal hiring integrity",
      handles: "The 14 \u201cprohibited personnel practices\u201d in federal-government hiring: nepotism, granting illegal preferences or advantages (e.g., tailoring a vacancy announcement to a preselected candidate), obstructing the right to compete, coercing political activity, discrimination, and whistleblower retaliation. Applicants to federal jobs are covered.",
      file: "OSC complaint (Form OSC-14) e-filed at " + a("https://www.osc.gov/services/prohibited-personnel-practices/filecomplaint/", "osc.gov \u2014 file a PPP complaint") + ". Overview: " + a("https://www.osc.gov/services/prohibited-personnel-practices/overview/", "PPP overview") + ".",
      deadline: "No strict deadline for OSC complaints, but file promptly; MSPB appeals of covered actions are generally due within 30 days.",
      contact: "OSC: 1-800-872-9855 \u00b7 MSPB e-Appeal: " + a("https://www.mspb.gov", "mspb.gov"),
      note: "Discrimination complaints by federal applicants also run through the hiring agency\u2019s EEO office (45-day counselor deadline), per the EEOC federal-sector process." },
    { id: "ftc", name: "FTC \u2014 job scams and deceptive recruiting",
      handles: "Fraudulent and deceptive hiring practices as consumer-protection violations: fake job postings and \u201cghost jobs,\u201d recruitment-fee and training-fee scams, fake-check onboarding fraud, MLM income misrepresentations, and deceptive job ads. Also a primary FCRA enforcer against non-compliant background-screening practices.",
      file: "Report at " + a("https://reportfraud.ftc.gov", "ReportFraud.ftc.gov") + " \u00b7 guidance: " + a("https://consumer.ftc.gov/articles/job-scams", "FTC job-scams guide") + ".",
      deadline: "None \u2014 report any time; reports feed the Consumer Sentinel database used by 2,800+ law-enforcement agencies.",
      contact: "1-877-382-4357",
      note: "The FTC does not resolve individual disputes, but pattern reports drive enforcement actions and refunds. Report identity-theft angles at IdentityTheft.gov; internet-crime angles may also be reported to the FBI\u2019s IC3 (ic3.gov)." },
    { id: "cfpb", name: "CFPB \u2014 background-check reports",
      handles: "Employment background-screening companies are \u201cconsumer reporting agencies\u201d under the FCRA. The CFPB takes complaints about inaccurate criminal/credit records in employment reports, failure to investigate disputes, obsolete information, and mixed files, and forwards them to the company for a required response.",
      file: "Online: " + a("https://www.consumerfinance.gov/complaint/", "consumerfinance.gov/complaint") + ".",
      deadline: "None for complaints; FCRA lawsuits have their own limitations periods (generally 2 years from discovery, up to 5 from violation).",
      contact: "1-855-411-2372",
      note: "The complaint system remained in operation through 2025\u20132026 agency restructuring (Consumer Response annual report published March 2026). Pair a CFPB complaint with a written dispute to the screening company itself, which triggers the FCRA\u2019s 30-day reinvestigation duty." }
  ];

  var FEPA = [
    { st: "AL", agency: "No state FEPA for private employment \u2014 file with EEOC (Birmingham District)", url: "https://eeoc.gov" },
    { st: "AK", agency: "Alaska State Commission for Human Rights", url: "https://humanrights.alaska.gov" },
    { st: "AZ", agency: "Arizona Attorney General \u2014 Civil Rights Division", url: "https://azag.gov" },
    { st: "AR", agency: "No state FEPA \u2014 file with EEOC (Little Rock Area Office)", url: "https://eeoc.gov" },
    { st: "CA", agency: "Civil Rights Department (CRD, formerly DFEH) \u2014 3-year filing window", url: "https://calcivilrights.ca.gov" },
    { st: "CO", agency: "Colorado Civil Rights Division (CCRD); pay-transparency complaints: Colo. Dept. of Labor and Employment", url: "https://ccrd.colorado.gov" },
    { st: "CT", agency: "Commission on Human Rights and Opportunities (CHRO)", url: "https://portal.ct.gov/chro" },
    { st: "DE", agency: "Dept. of Labor \u2014 Division of Industrial Affairs, Office of Anti-Discrimination", url: "https://labor.delaware.gov" },
    { st: "DC", agency: "DC Office of Human Rights", url: "https://ohr.dc.gov" },
    { st: "FL", agency: "Florida Commission on Human Relations", url: "https://fchr.myflorida.com" },
    { st: "GA", agency: "Georgia Commission on Equal Opportunity (public-sector only); private-sector \u2192 EEOC (Atlanta District)", url: "https://gceo.georgia.gov" },
    { st: "HI", agency: "Hawaii Civil Rights Commission", url: "https://labor.hawaii.gov/hcrc" },
    { st: "ID", agency: "Idaho Human Rights Commission", url: "https://humanrights.idaho.gov" },
    { st: "IL", agency: "Illinois Department of Human Rights (AI-in-hiring amendments effective Jan. 1, 2026)", url: "https://dhr.illinois.gov" },
    { st: "IN", agency: "Indiana Civil Rights Commission", url: "https://in.gov/icrc" },
    { st: "IA", agency: "Iowa Office of Civil Rights (formerly Iowa Civil Rights Commission)", url: "https://icrc.iowa.gov" },
    { st: "KS", agency: "Kansas Human Rights Commission", url: "https://khrc.net" },
    { st: "KY", agency: "Kentucky Commission on Human Rights", url: "https://kchr.ky.gov" },
    { st: "LA", agency: "Louisiana Commission on Human Rights (Office of the Governor)", url: "https://gov.louisiana.gov" },
    { st: "ME", agency: "Maine Human Rights Commission", url: "https://maine.gov/mhrc" },
    { st: "MD", agency: "Maryland Commission on Civil Rights", url: "https://mccr.maryland.gov" },
    { st: "MA", agency: "Massachusetts Commission Against Discrimination (MCAD)", url: "https://mass.gov/orgs/massachusetts-commission-against-discrimination" },
    { st: "MI", agency: "Michigan Department of Civil Rights", url: "https://michigan.gov/mdcr" },
    { st: "MN", agency: "Minnesota Department of Human Rights", url: "https://mn.gov/mdhr" },
    { st: "MS", agency: "No state FEPA \u2014 file with EEOC (Jackson Area Office)", url: "https://eeoc.gov" },
    { st: "MO", agency: "Missouri Commission on Human Rights", url: "https://labor.mo.gov" },
    { st: "MT", agency: "Human Rights Bureau, Mont. Dept. of Labor & Industry", url: "https://erd.dli.mt.gov" },
    { st: "NE", agency: "Nebraska Equal Opportunity Commission", url: "https://neoc.nebraska.gov" },
    { st: "NV", agency: "Nevada Equal Rights Commission (DETR)", url: "https://detr.nv.gov" },
    { st: "NH", agency: "New Hampshire Commission for Human Rights", url: "https://nh.gov/hrc" },
    { st: "NJ", agency: "Division on Civil Rights, Office of the Attorney General", url: "https://njcivilrights.gov" },
    { st: "NM", agency: "Human Rights Bureau, N.M. Dept. of Workforce Solutions", url: "https://dws.state.nm.us" },
    { st: "NY", agency: "New York State Division of Human Rights \u2014 3-year filing window for employment", url: "https://dhr.ny.gov" },
    { st: "NC", agency: "No general private-sector FEPA \u2014 EEOC covers; NC DOL Employment Discrimination Bureau enforces retaliation (REDA)", url: "https://labor.nc.gov" },
    { st: "ND", agency: "North Dakota Department of Labor and Human Rights", url: "https://nd.gov/labor" },
    { st: "OH", agency: "Ohio Civil Rights Commission", url: "https://crc.ohio.gov" },
    { st: "OK", agency: "Office of Civil Rights Enforcement, Okla. Attorney General", url: "https://oag.ok.gov" },
    { st: "OR", agency: "Civil Rights Division, Bureau of Labor and Industries (BOLI)", url: "https://oregon.gov/boli" },
    { st: "PA", agency: "Pennsylvania Human Relations Commission", url: "https://phrc.pa.gov" },
    { st: "RI", agency: "Rhode Island Commission for Human Rights", url: "https://richr.ri.gov" },
    { st: "SC", agency: "South Carolina Human Affairs Commission", url: "https://schac.sc.gov" },
    { st: "SD", agency: "Division of Human Rights, S.D. Dept. of Labor & Regulation", url: "https://dlr.sd.gov" },
    { st: "TN", agency: "Civil Rights Enforcement Division, Tenn. Attorney General (replaced the dissolved Human Rights Commission, July 1, 2025)", url: "https://tn.gov/attorneygeneral" },
    { st: "TX", agency: "Civil Rights Division, Texas Workforce Commission \u2014 180-day filing window", url: "https://twc.texas.gov" },
    { st: "UT", agency: "Antidiscrimination and Labor Division (UALD), Utah Labor Commission", url: "https://laborcommission.utah.gov" },
    { st: "VT", agency: "Attorney General\u2019s Civil Rights Unit (private employment); Vt. Human Rights Commission (state employees, housing)", url: "https://ago.vermont.gov" },
    { st: "VA", agency: "Office of Civil Rights, Office of the Attorney General", url: "https://oag.state.va.us" },
    { st: "WA", agency: "Washington State Human Rights Commission", url: "https://hum.wa.gov" },
    { st: "WV", agency: "West Virginia Human Rights Commission", url: "https://hrc.wv.gov" },
    { st: "WI", agency: "Equal Rights Division, Wis. Dept. of Workforce Development", url: "https://dwd.wisconsin.gov/er" },
    { st: "WY", agency: "Labor Standards / Fair Employment Program, Wyo. Dept. of Workforce Services", url: "https://wyomingworkforce.org" }
  ];

  var LOCAL = [
    { j: "New York City, NY", agency: "NYC Commission on Human Rights (NYC CCHR) \u2014 NYC Human Rights Law; Fair Chance Act; salary transparency; credit-history and caregiver protections", url: "https://nyc.gov/cchr" },
    { j: "New York City, NY", agency: "NYC Dept. of Consumer and Worker Protection \u2014 Local Law 144 (bias audits of automated hiring tools)", url: "https://nyc.gov/dcwp" },
    { j: "Chicago, IL", agency: "Chicago Commission on Human Relations", url: "https://chicago.gov/humanrelations" },
    { j: "Cook County, IL", agency: "Cook County Commission on Human Rights", url: "https://cookcountyil.gov" },
    { j: "Los Angeles, CA", agency: "Los Angeles Civil Rights Department (LA Civil Rights) \u2014 private-sector discrimination ordinance", url: "https://lacity.gov" },
    { j: "Seattle, WA", agency: "Seattle Office for Civil Rights", url: "https://seattle.gov/civilrights" },
    { j: "Philadelphia, PA", agency: "Philadelphia Commission on Human Relations \u2014 incl. salary-history ban", url: "https://phila.gov" },
    { j: "Pittsburgh, PA", agency: "Pittsburgh Commission on Human Relations", url: "https://pittsburghpa.gov" },
    { j: "Baltimore, MD", agency: "Baltimore Office of Equity and Civil Rights", url: "https://civilrights.baltimorecity.gov" },
    { j: "Montgomery County, MD", agency: "Montgomery County Office of Human Rights", url: "https://montgomerycountymd.gov" },
    { j: "Prince George\u2019s County, MD", agency: "Prince George\u2019s County Human Relations Commission", url: "https://princegeorgescountymd.gov" },
    { j: "Fairfax County, VA", agency: "Fairfax County Office of Human Rights and Equity Programs", url: "https://fairfaxcounty.gov" },
    { j: "Fort Worth, TX", agency: "City of Fort Worth Civil Rights Office", url: "https://fortworthtexas.gov" },
    { j: "Dallas, TX", agency: "City of Dallas Fair Housing and Human Rights Office", url: "https://dallascityhall.com" },
    { j: "Austin, TX", agency: "City of Austin Office of Civil Rights / Human Rights Commission", url: "https://austintexas.gov" },
    { j: "Minneapolis, MN", agency: "Minneapolis Department of Civil Rights", url: "https://minneapolismn.gov" },
    { j: "St. Paul, MN", agency: "St. Paul Dept. of Human Rights & Equal Economic Opportunity", url: "https://stpaul.gov" },
    { j: "Madison, WI", agency: "City of Madison Department of Civil Rights", url: "https://cityofmadison.com" },
    { j: "Louisville, KY", agency: "Louisville Metro Human Relations Commission", url: "https://louisvilleky.gov" },
    { j: "Kansas City, MO", agency: "Kansas City Human Relations Department", url: "https://kcmo.gov" },
    { j: "St. Louis, MO", agency: "St. Louis Civil Rights Enforcement Agency", url: "https://stlouis-mo.gov" },
    { j: "Miami-Dade County, FL", agency: "Miami-Dade Commission on Human Rights", url: "https://miamidade.gov" },
    { j: "Anchorage, AK", agency: "Anchorage Equal Rights Commission", url: "https://muni.org" }
  ];

  var NGO = [
    { n: "Cornell Law School \u2014 Legal Information Institute (LII)", w: "Authoritative free primary-source texts of every statute and regulation cited here (Title VII at 42 U.S.C. \u00a72000e-2; ADA; ADEA; FCRA; NLRA; USERRA regs at 20 C.F.R. pt. 1002), plus plain-language Wex explainers on employment discrimination.", url: "https://law.cornell.edu" },
    { n: "Workplace Fairness", w: "Comprehensive state-by-state know-your-rights library on hiring discrimination, background checks, drug testing, and retaliation; maintained by employment-law attorneys.", url: "https://workplacefairness.org" },
    { n: "National Employment Lawyers Association (NELA)", w: "Find-a-lawyer directory of plaintiff-side employment attorneys in all 50 states.", url: "https://nela.org" },
    { n: "Legal Aid at Work", w: "Free work-rights helplines and fact sheets (national information; direct services in California).", url: "https://legalaidatwork.org" },
    { n: "A Better Balance", w: "Free confidential legal helpline (1-833-633-3222) on pregnancy, caregiving, and sick-leave rights in hiring and employment.", url: "https://abetterbalance.org" },
    { n: "ABA Free Legal Answers", w: "Pro bono online Q&A with licensed attorneys for income-qualified users.", url: "https://abafreelegalanswers.org" },
    { n: "LawHelp.org / Legal Services Corporation", w: "Directories of free civil legal aid offices by state and county.", url: "https://lawhelp.org" }
  ];

  var MASTER = [
    { n: "EEOC FEPA lists and dual filing (official designation lists, relocated by final rule eff. July 16, 2026)", url: "https://www.eeoc.gov/fair-employment-practices-agencies-fepas-and-dual-filing" },
    { n: "State labor offices \u2014 all 50 states + DC + territories (US DOL)", url: "https://www.dol.gov/agencies/whd/state/contacts" },
    { n: "State attorneys general (NAAG)", url: "https://www.naag.org/find-my-ag/" },
    { n: "NAAG consumer complaint portal directory", url: "https://www.naag.org/our-work/center-for-consumer-protection/consumer-file-a-complaint/" },
    { n: "State consumer protection offices (USA.gov)", url: "https://www.usa.gov/state-consumer" }
  ];

  var SOURCES_PRIMARY = [
    ["EEOC \u2014 Filing a Charge of Discrimination", "https://www.eeoc.gov/filing-charge-discrimination"],
    ["EEOC \u2014 Public Portal", "https://publicportal.eeoc.gov"],
    ["EEOC \u2014 State and Local Programs", "https://www.eeoc.gov/state-and-local-programs"],
    ["EEOC \u2014 FEPAs and Dual Filing (official FEPA lists)", "https://www.eeoc.gov/fair-employment-practices-agencies-fepas-and-dual-filing"],
    ["EEOC \u2014 Federal-Sector EEO Complaint Process", "https://www.eeoc.gov/federal-sector/overview-federal-sector-eeo-complaint-process"],
    ["DOJ Civil Rights Division \u2014 IER home", "https://www.justice.gov/crt/immigrant-and-employee-rights-section"],
    ["DOJ \u2014 Filing an IER Charge", "https://www.justice.gov/crt/filing-an-IER-Charge"],
    ["DOL WHD \u2014 How to File a Complaint", "https://www.dol.gov/agencies/whd/contact/complaints"],
    ["DOL \u2014 State Labor Offices directory", "https://www.dol.gov/agencies/whd/state/contacts"],
    ["NLRB \u2014 Investigate Charges", "https://www.nlrb.gov/about-nlrb/what-we-do/investigate-charges"],
    ["DOL OFCCP \u2014 Complaint Process", "https://www.dol.gov/agencies/ofccp/contact/file-complaint"],
    ["DOL VETS \u2014 USERRA: File a Claim", "https://www.dol.gov/agencies/vets/programs/userra/fileaclaim"],
    ["OSC \u2014 How to File a PPP Complaint", "https://www.osc.gov/services/prohibited-personnel-practices/filecomplaint/"],
    ["OSC \u2014 How to File a USERRA Complaint", "https://www.osc.gov/services/userra/filecomplaint/"],
    ["MSPB \u2014 Prohibited Personnel Practices", "https://www.mspb.gov/ppp/ppp.htm"],
    ["FTC \u2014 ReportFraud", "https://reportfraud.ftc.gov"],
    ["FTC \u2014 Job Scams (consumer guidance)", "https://consumer.ftc.gov/articles/job-scams"],
    ["CFPB \u2014 Submit a Complaint", "https://www.consumerfinance.gov/complaint/"],
    ["USAGov \u2014 State Consumer Protection Offices", "https://www.usa.gov/state-consumer"],
    ["NAAG \u2014 Consumer File a Complaint", "https://www.naag.org/our-work/center-for-consumer-protection/consumer-file-a-complaint/"],
    ["Tennessee AG \u2014 Civil Rights Enforcement Division launch (July 1, 2025)", "https://www.tn.gov/attorneygeneral/news/2025/7/1/pr25-38.html"],
    ["Iowa Office of Civil Rights \u2014 File a Complaint", "https://icrc.iowa.gov/file-complaint"],
    ["City of Fort Worth \u2014 Civil Rights Office", "https://www.fortworthtexas.gov/departments/hr/civil-rights-office"],
    ["Cornell LII \u2014 20 C.F.R. \u00a71002.288 (USERRA complaint filing)", "https://www.law.cornell.edu/cfr/text/20/1002.288"]
  ];
  var SOURCES_SECONDARY = [
    ["EEOC FEP-agency list relocation, final rule eff. July 16, 2026 (Fed. Reg. 2026-14303)", "https://regulations.justia.com/regulations/fedreg/2026/07/16/2026-14303.html"],
    ["Ogletree Deakins \u2014 OFCCP\u2019s Start to 2026: Funding, Complaints, and VEVRAA", "https://ogletree.com/insights-resources/blog-posts/ofccps-start-to-2026-proposed-funding-and-a-focus-on-complaints-and-vevraa/"],
    ["Government Contractor Compliance Update \u2014 OFCCP Is Still Alive (Feb. 2026)", "https://www.governmentcontractorcomplianceupdate.com/2026/02/09/ofccp-is-still-alive-complaint-form-revisions-vevraa-recordkeeping-renewal-and-fy2026-funding/"],
    ["Hunton \u2014 OFCCP funding eliminated; E.O. 11246 revocation context", "https://www.hunton.com/hunton-employment-labor-perspectives/trump-administration-eliminates-ofccp-funding-reshaping-enforcement-landscape-for-federal-contractors"],
    ["Freeman Mathis & Gary \u2014 NLRB Quorum Restored", "https://www.fmglaw.com/employment-law-blog-us/nlrb-quorum-restored-what-employers-need-to-know/"],
    ["Ogletree Deakins \u2014 NLRB Charge-Intake Procedures", "https://ogletree.com/insights-resources/blog-posts/nlrb-clarifies-new-charge-intake-procedures-aimed-at-reducing-backlog/"],
    ["Burr & Forman \u2014 Tennessee Human Rights Commission Dissolved (June 30, 2025)", "https://www.burr.com/newsroom/articles/tennessee-human-rights-commission-dissolved-effective-june-30-2025"],
    ["NFP \u2014 DOJ Targets Citizenship Status Discrimination", "https://www.nfp.com/insights/doj-targets-citizenship-status-discrimination/"],
    ["CFPB \u2014 Consumer Response Annual Report (published Mar. 2026)", "https://files.consumerfinance.gov/f/documents/cfpb_2025-cr-annual-report_2026-03.pdf"]
  ];

  /* ---------------- rendering ---------------- */

  function fedCard(f) {
    return '<details class="hr-agency" id="hr-' + f.id + '">' +
      "<summary><strong>" + f.name + "</strong></summary>" +
      '<div class="hr-agency-body">' +
      "<p><strong>Handles:</strong> " + f.handles + "</p>" +
      "<p><strong>How to file:</strong> " + f.file + "</p>" +
      '<p class="hr-deadline"><strong>\u23f1 Deadline:</strong> ' + f.deadline + "</p>" +
      "<p><strong>Contact:</strong> " + f.contact + "</p>" +
      '<p class="muted">' + f.note + "</p>" +
      "</div></details>";
  }

  function fepaRow(r, mine) {
    return '<div class="hr-fepa-row' + (mine ? " mine" : "") + '">' +
      "<strong>" + esc(STATE_NAME[r.st] || r.st) + (mine ? " \u2605 your state" : "") + "</strong>" +
      '<div class="hr-fepa-agency">' + esc(r.agency) + " \u2014 " + a(r.url) + "</div>" +
      "</div>";
  }

  function mount() {
    var view = $("#view-hiring");
    if (!view || mounted) { if (mounted) renderFepa(); return; }
    mounted = true;

    view.innerHTML =
      '<h1 id="hiring-h1">Reporting unethical hiring practices</h1>' +
      '<p class="lede">\u201cUnethical hiring\u201d isn\u2019t one legal category \u2014 it\u2019s a dozen, each with its own enforcement agency and its own clock. This directory maps every practice to the right door: federal profiles with deadlines and hotlines, your state\u2019s fair-employment agency, the local commissions that cover what state law doesn\u2019t, and the free legal resources for everything else. Compiled and verified against official government sources, <strong>current as of August 18, 2026</strong>.</p>' +
      '<div class="wip-banner" role="note">\u2696\ufe0f This directory is informational and does not constitute legal advice. Filing deadlines are jurisdiction-specific and strictly enforced \u2014 confirm details with the receiving agency before relying on them. Agency structures have been unusually volatile in 2025\u20132026; items flagged \u201cverify before citing\u201d should be re-checked at time of use.</div>' +

      '<div class="card">' +
      '<h2>Three rules that govern where and when to file</h2>' +
      '<ul class="tidy">' +
      '<li><strong>Dual filing (FEPAs).</strong> The EEOC has worksharing agreements with 90+ state and local Fair Employment Practices Agencies \u2014 a charge filed with one is automatically cross-filed with the other, preserving rights under both laws with a single filing. The official FEPA lists live on the EEOC\u2019s site (relocated there by final rule effective July 16, 2026).</li>' +
      '<li><strong>Deadlines are short and vary.</strong> The baseline EEOC deadline is 180 calendar days, extended to 300 where a state or local agency enforces a law on the same basis. State deadlines diverge widely \u2014 Texas allows 180 days; California and New York allow three years. When in doubt, file early with the most protective forum.</li>' +
      '<li><strong>Applicants are covered, not just employees.</strong> Title VII, the ADA, the ADEA, the INA\u2019s anti-discrimination provision, the NLRA, USERRA, and the FCRA all protect job applicants \u2014 every agency below accepts refusal-to-hire complaints, and retaliation for filing is separately illegal under each law.</li>' +
      '</ul>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Triage: which agency handles what</h2>' +
      '<p class="muted">Find the row that matches what happened. Federal filing is free, no attorney is required anywhere below, and most agencies accept anonymous or third-party tips even where a formal charge requires identification.</p>' +
      '<div id="hr-triage">' +
      TRIAGE.map(function (t, i) {
        return '<details class="hr-triage-row"><summary>' + esc(t.p) + "</summary>" +
          '<div class="hr-triage-answer"><strong>\u2192 ' + esc(t.w) + "</strong> " +
          (t.j === "states" ? '<button class="btn btn-ghost btn-sm" data-hr-jump="hr-states">State finder \u2193</button>'
            : '<button class="btn btn-ghost btn-sm" data-hr-jump="hr-' + t.j + '">Agency profile \u2193</button>') +
          (t.x ? ' <button class="btn btn-ghost btn-sm" data-goto="' + t.x + '">Report it tab \u2192</button>' : "") +
          "</div></details>";
      }).join("") +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Federal agencies</h2>' +
      '<p class="muted">Nine doors. Each profile: what it handles, how to file, the deadline, and the phone line \u2014 expand what you need.</p>' +
      FEDERAL.map(fedCard).join("") +
      '</div>' +

      '<div class="card" id="hr-states">' +
      '<h2>Your state\u2019s fair-employment agency</h2>' +
      '<p class="muted">Nearly every state runs a fair-employment / civil-rights agency (FEPA) enforcing state law \u2014 frequently reaching employers with as few as one employee, adding protected classes federal law lacks, and setting its own deadlines. Four states (Alabama, Arkansas, Georgia for private employers, and Mississippi) have no general state enforcement agency for private-sector employment discrimination \u2014 residents there file directly with the EEOC. Wage-and-hour issues in any state: the DOL state labor office directory below. Agency names reflect 2025\u20132026 reorganizations (Tennessee, Iowa noted in rows).</p>' +
      '<input type="search" id="hr-fepa-search" placeholder="Search by state or agency\u2026" aria-label="Search state agencies">' +
      '<div id="hr-fepa"></div>' +
      '<h3 style="margin-top:14px">Master directories (canonical, government-maintained)</h3>' +
      '<ul class="tidy">' + MASTER.map(function (m) { return "<li>" + a(m.url, m.n) + "</li>"; }).join("") + "</ul>" +
      '<p class="muted"><strong>Pay transparency (hiring-stage):</strong> as of mid-2026, statewide pay-range-in-posting laws are enforced in Colorado, Washington, California, New York, Illinois, Hawaii, Maryland, Minnesota, New Jersey, Vermont, and Massachusetts, with local ordinances in NYC (CCHR), Cincinnati, and Toledo, among others. Salary-history bans exist in 20+ states, typically enforced by the same agencies. This area changes quickly \u2014 confirm current coverage via the state labor office directory above.</p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>City &amp; county commissions</h2>' +
      '<p class="muted">Dozens of municipal and county civil-rights commissions are designated FEPAs, taking hiring complaints under local ordinances \u2014 often covering smaller employers, independent contractors, and classes (credit history, caregiver status, height/weight) beyond state or federal law. Major, long-established offices below; the authoritative roster is the EEOC FEPA list above. <strong>Finding yours:</strong> check your EEOC field-office page (each lists its local FEPAs), your city or county site under \u201chuman rights\u201d / \u201chuman relations\u201d / \u201ccivil rights,\u201d or dial 311 (city services) or 211 (community services).</p>' +
      '<div class="hr-local">' +
      LOCAL.map(function (l) {
        return '<div class="hr-fepa-row"><strong>' + esc(l.j) + "</strong>" +
          '<div class="hr-fepa-agency">' + esc(l.agency) + " \u2014 " + a(l.url) + "</div></div>";
      }).join("") +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Reputable non-governmental resources</h2>' +
      '<p class="muted">These organizations don\u2019t enforce the law, but they\u2019re established, widely cited sources for understanding rights, documenting complaints, and finding counsel.</p>' +
      '<ul class="tidy">' +
      NGO.map(function (n) { return "<li><strong>" + esc(n.n) + ".</strong> " + esc(n.w) + " " + a(n.url) + "</li>"; }).join("") +
      '</ul>' +
      '</div>' +

      '<details class="card hr-sources">' +
      '<summary><h2 style="display:inline">Methodology &amp; sources</h2></summary>' +
      '<p class="muted" style="margin-top:10px">Every agency, process, deadline, and contact channel was checked on August 18, 2026 against the official source listed (primary .gov pages wherever available; reputable secondary legal analyses used only to document 2025\u20132026 structural changes). Key statutes: Title VII (42 U.S.C. \u00a72000e et seq.); ADA (42 U.S.C. \u00a712101); ADEA (29 U.S.C. \u00a7621); INA \u00a7274B (8 U.S.C. \u00a71324b); NLRA (29 U.S.C. \u00a7151); FLSA (29 U.S.C. \u00a7201); EPPA (29 U.S.C. \u00a72001); FCRA (15 U.S.C. \u00a71681); USERRA (38 U.S.C. \u00a74301); 5 U.S.C. \u00a72302. This directory reports where to file; it does not evaluate the likelihood of success of any complaint.</p>' +
      '<h3>Primary government sources</h3><ul class="tidy">' +
      SOURCES_PRIMARY.map(function (s) { return "<li>" + a(s[1], s[0]) + "</li>"; }).join("") +
      '</ul><h3>Secondary sources documenting 2025\u20132026 agency changes</h3><ul class="tidy">' +
      SOURCES_SECONDARY.map(function (s) { return "<li>" + a(s[1], s[0]) + "</li>"; }).join("") +
      "</ul></details>";

    $("#hr-fepa-search").addEventListener("input", renderFepa);
    view.addEventListener("click", function (e) {
      var b = e.target.closest("[data-hr-jump]"); if (!b) return;
      var el = document.getElementById(b.dataset.hrJump);
      if (el) {
        if (el.tagName === "DETAILS") el.open = true;
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });

    get(["profile"]).then(function (d) {
      profile = d.profile || {};
      renderFepa();
    });
  }

  function renderFepa() {
    var box = $("#hr-fepa"); if (!box) return;
    var q = (($("#hr-fepa-search") || {}).value || "").toLowerCase().trim();
    var rows = FEPA.filter(function (r) {
      if (!q) return true;
      return (r.st + " " + (STATE_NAME[r.st] || "") + " " + r.agency).toLowerCase().indexOf(q) >= 0;
    });
    var mine = profile.state;
    rows.sort(function (x, y) {
      if (x.st === mine) return -1;
      if (y.st === mine) return 1;
      return (STATE_NAME[x.st] || x.st) < (STATE_NAME[y.st] || y.st) ? -1 : 1;
    });
    box.innerHTML = rows.length
      ? rows.map(function (r) { return fepaRow(r, r.st === mine); }).join("")
      : '<p class="muted">No state matches that search.</p>';
  }

  /* ---------------- init ---------------- */
  if (hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !mounted) return;
      if (ch.profile) { profile = ch.profile.newValue || {}; renderFepa(); }
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="hiring"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

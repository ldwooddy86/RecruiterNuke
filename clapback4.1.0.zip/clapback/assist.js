/* Clapback — "Financial assistance" module (charity care & 501(r)).
 * Works only on YOUR OWN bills. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM;
  var mounted = false;
  var prof = {};

  function mount() {
    var view = X.$("#view-assist");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Financial assistance &amp; charity care</h1>' +
      '<p class="lede">This is the step that most often takes a hospital bill to zero, and the step almost nobody is told about. Most US hospitals are tax-exempt, and keeping that exemption requires them to have a written financial assistance policy, to publicize it, to cap what eligible patients are charged, and to check whether you qualify <strong>before</strong> they report you, sue you, or garnish your wages. Those obligations are enforceable facts with dates attached.</p>' +

      '<div class="callout callout-info">' +
      '<strong>Apply even if you think you earn too much.</strong> Thresholds are higher than people expect — several states now reach 400% of the federal poverty level, and Illinois runs discounts to 600%. Apply even if the bill is old, even if it went to collections, and even if you are already being sued. In Washington the Attorney General states plainly that charity care applies to past bills, no matter how old or whether they went to collections.' +
      '</div>' +

      /* ---- eligibility calculator ---- */
      '<div class="card">' +
      '<h2>Where do you land against the poverty level?</h2>' +
      '<p class="muted">Charity care thresholds are written as a percentage of the federal poverty guidelines. This works out yours. It stays on this device.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="fa-house">People in your household</label><input class="input" id="fa-house" type="number" min="1" max="20" step="1" placeholder="e.g. 3"></div>' +
      '<div class="ev-field"><label class="field" for="fa-income">Annual household income (before tax)</label><input class="input" id="fa-income" type="number" min="0" step="100" placeholder="e.g. 48000"></div>' +
      '<div class="ev-field"><label class="field" for="fa-state">Your state</label><span id="fa-state-host"></span></div>' +
      '<div class="ev-field-wide"><button class="btn" id="fa-run">Work it out</button> <button class="btn btn-ghost" id="fa-save">Save to my profile</button></div>' +
      '</div>' +
      '<div id="fa-out"></div>' +
      '<p class="fineprint" id="fa-src"></p>' +
      '</div>' +

      /* ---- your state ---- */
      '<h2>Your state’s rules</h2>' +
      '<div class="card" id="fa-statecard"></div>' +

      /* ---- 501(r) engine ---- */
      '<h2>What a nonprofit hospital owes you</h2>' +
      '<div class="card">' +
      '<p class="muted" id="r-scope"></p>' +
      '<div id="r-reqs" class="link-list"></div>' +
      '</div>' +

      '<div class="card">' +
      '<h3>Amounts Generally Billed — the negotiating fact</h3>' +
      '<p id="r-agb-lead"></p>' +
      '<p class="muted" id="r-agb"></p>' +
      '<div class="btn-row">' + X.a("26 CFR 1.501(r)-5 ↗", "https://www.ecfr.gov/current/title-26/section-1.501(r)-5") + '</div>' +
      '</div>' +

      /* ---- ECA timeline ---- */
      '<div class="card">' +
      '<h3>The collection clock</h3>' +
      '<p>Three dates govern what a tax-exempt hospital may do to you, and all three run from one event: the <strong>first billing statement after you were discharged</strong>. Not the date of service. Not the date of discharge. Find that statement.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="eca-date">Date of the first bill after discharge</label><input class="input" id="eca-date" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="eca-run">Show my dates</button></div>' +
      '</div>' +
      '<div id="eca-out"></div>' +
      '<h4 style="margin-top:18px">What counts as an “extraordinary collection action”</h4>' +
      '<ul class="tidy" id="eca-list"></ul>' +
      '<p class="muted" id="eca-not"></p>' +
      '<p class="muted" id="eca-30"></p>' +
      X.srcLine("26 CFR 1.501(r)-6 (eCFR)", M.R501.reversalUrl) +
      '</div>' +

      '<div class="card danger">' +
      '<h3>Already reported, sued, or garnished? This is the part to read.</h3>' +
      '<p id="r-reversal"></p>' +
      '<p class="muted">Cite: ' + X.esc(M.R501.reversalCite) + '</p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="court">Open the court kit →</button>' + X.a("Read the rule ↗", M.R501.reversalUrl) + '</div>' +
      '</div>' +

      /* ---- turning it into leverage ---- */
      '<div class="card">' +
      '<h3>Turning a tax rule into actual leverage</h3>' +
      '<p id="r-weapon"></p>' +
      '<p class="muted" id="r-weak"></p>' +
      '<div class="btn-row">' + X.a("IRS Form 13909 ↗", M.R501.form13909) + '<button class="btn btn-ghost btn-sm" data-goto="report">Your state attorney general →</button></div>' +
      '<p class="fineprint" id="r-13909where"></p>' +
      '</div>' +

      /* ---- medicaid ---- */
      '<div class="card">' +
      '<h3>Don’t forget retroactive Medicaid</h3>' +
      '<p id="mcaid-now"></p>' +
      '<div class="callout callout-warn" id="mcaid-change"></div>' +
      '<div class="btn-row">' + X.a("Source ↗", M.MEDICAID_LOOKBACK.url) + '</div>' +
      '</div>' +

      /* ---- other states ---- */
      '<div class="card">' +
      '<h3>If your state isn’t listed above</h3>' +
      '<p class="muted" id="fa-other"></p>' +
      '<div class="btn-row">' + X.a("State-by-state research ↗", M.CHARITY_OTHER_SRC) + '</div>' +
      '</div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<div class="card"><div id="assist-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal advice. Section 501(r) is a condition of a hospital’s tax exemption, not a law you can sue under directly — but the facts it produces are usable everywhere else, and the state programs above are enforceable on their own terms. Every figure here links to its source, verified ' + X.esc(M.UPDATED) + '.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    X.$("#r-scope").textContent = M.R501.scope;

    var rq = X.$("#r-reqs"); rq.innerHTML = "";
    M.R501.reqs.forEach(function (r) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", r.n));
      l.appendChild(X.el("div", "li-note", r.t + "  — " + r.cite));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Rule ↗", r.u);
      row.appendChild(w);
      rq.appendChild(row);
    });

    X.$("#r-agb-lead").innerHTML = "Once you are determined eligible, the amount you are <strong>personally responsible for paying</strong> may not exceed what insured patients are generally billed for emergency or medically necessary care — and for everything else the policy covers, it must be less than gross charges. Most people never learn this exists. Read a statement carefully before you argue: the rule doesn’t stop them printing the gross charge and then discounting it. What it caps is the number at the bottom.";
    X.$("#r-agb").textContent = M.R501.agb;

    var el = X.$("#eca-list"); el.innerHTML = "";
    M.R501.ecas.forEach(function (s) { el.appendChild(X.el("li", null, s)); });
    X.$("#eca-not").textContent = M.R501.notEcas;
    X.$("#eca-30").textContent = M.R501.d30;

    X.$("#r-reversal").textContent = M.R501.reversal;
    X.$("#r-weapon").textContent = M.R501.weaponize;
    X.$("#r-weak").textContent = M.R501.enforcementWeak;
    X.$("#r-13909where").textContent = M.R501.form13909where;

    X.$("#mcaid-now").textContent = M.MEDICAID_LOOKBACK.now;
    X.$("#mcaid-change").innerHTML = "<strong>This narrows on January 1, 2027.</strong> " + X.esc(M.MEDICAID_LOOKBACK.change) + " If you have old bills from a period when you were eligible, applying now is worth more than applying later.";

    X.$("#fa-other").textContent = M.CHARITY_OTHER;
    X.$("#fa-src").innerHTML = "Poverty guidelines: " + X.esc(M.FPL.srcName) + ". " + X.esc(M.FPL.note) + " " +
      '<a href="' + X.esc(M.FPL.src) + '" target="_blank" rel="noopener">Source ↗</a>';

    X.letterCards(X.$("#assist-letters"), "assist", function () { return {}; });

    /* ECA calculator */
    X.$("#eca-run").addEventListener("click", function () {
      var d = X.parseDate(X.$("#eca-date").value);
      var out = X.$("#eca-out"); out.innerHTML = "";
      if (!d) { out.innerHTML = '<div class="callout callout-warn">Enter the date of your first bill after discharge.</div>'; return; }
      var d120 = X.addDays(d, 120), d240 = X.addDays(d, 240);
      var u120 = X.urgency(X.iso(d120)), u240 = X.urgency(X.iso(d240));
      out.innerHTML =
        '<div class="callout callout-info">' +
        '<div style="margin-bottom:10px"><strong>' + X.esc(X.fmt(d120)) + '</strong> — the earliest they may start an extraordinary collection action. ' + X.esc(u120.label) + '.<br>' +
        '<span class="muted">' + X.esc(M.R501.d120) + '</span></div>' +
        '<div><strong>' + X.esc(X.fmt(d240)) + '</strong> — the last day to submit a financial assistance application for this care. ' + X.esc(u240.label) + '.<br>' +
        '<span class="muted">' + X.esc(M.R501.d240) + '</span></div>' +
        '</div>' +
        '<div class="btn-row"><button class="btn btn-sm" id="eca-track">Track both dates</button></div>' +
        '<p class="muted">If a credit report tradeline appeared or a lawsuit was filed before the first date, that is a concrete, checkable red flag. Use the “Stop collection” letter below.</p>';
      X.$("#eca-track").addEventListener("click", function () {
        X.addDeadline({ kind: "fap240", label: "Last day to apply for hospital financial assistance", due: X.iso(d240), note: "240 days from the first post-discharge billing statement. This right survives even if collection already started." });
        X.addDeadline({ kind: "eca120", label: "Earliest date the hospital may start an extraordinary collection action", due: X.iso(d120), note: "Anything before this — credit reporting, a lawsuit, garnishment, a lien — is a problem for them." });
      });
    });

    X.$("#fa-run").addEventListener("click", calc);
    X.$("#fa-save").addEventListener("click", function () {
      X.saveExtra({ household: X.$("#fa-house").value, income: X.$("#fa-income").value }).then(function () {
        X.toast("Saved to this device");
      });
    });
  }

  function load() {
    X.profile().then(function (p) {
      prof = p;
      var host = X.$("#fa-state-host");
      if (host) {
        host.innerHTML = X.stateSelect("fa-state", p.state, "Select a state…");
        X.$("#fa-state").addEventListener("change", renderStateCard);
      }
      if (p.household) X.$("#fa-house").value = p.household;
      if (p.income) X.$("#fa-income").value = p.income;
      renderStateCard();
      if (p.household && p.income) calc();
    });
  }
  /* Re-entering the tab re-reads the profile without clobbering anything the
     user typed or picked here. */
  function refresh() {
    X.profile().then(function (p) {
      prof = p;
      var sel = X.$("#fa-state");
      if (sel && !sel.value && p.state) sel.value = p.state;
      var h = X.$("#fa-house"), i = X.$("#fa-income");
      if (h && !h.value && p.household) h.value = p.household;
      if (i && !i.value && p.income) i.value = p.income;
      renderStateCard();
      if (h && i && h.value && i.value) calc();
    });
  }

  function calc() {
    var n = parseInt(X.$("#fa-house").value, 10);
    var inc = parseFloat(X.$("#fa-income").value);
    var st = X.$("#fa-state") ? X.$("#fa-state").value : prof.state;
    var out = X.$("#fa-out"); out.innerHTML = "";
    if (!n || !isFinite(inc)) { out.innerHTML = '<div class="callout callout-warn">Enter household size and annual income.</div>'; return; }

    var base = M.fplFor(n, st);
    var pct = Math.round((inc / base) * 100);

    var bands = [100, 138, 200, 250, 300, 350, 400, 500, 600];
    var rows = bands.map(function (b) {
      return '<div class="range-item"><strong>' + b + '% FPL</strong><span class="muted"> = ' + X.esc(X.money(Math.round(base * b / 100))) + '</span></div>';
    }).join("");

    /* This is an eligibility result, not a hazard. Landing low against the
       poverty level is GOOD news here — it means assistance is likely — so the
       banner colour tracks how strong your position is, not how alarming it is. */
    var band = pct <= 400 ? "low" : "caution";
    var msg = pct <= 200
      ? "You are at or below 200% of the federal poverty level. In most states with a charity care mandate, that is the free-care band — and under many hospital policies nationwide it means the bill should be written off entirely. Apply."
      : pct <= 400
        ? "You are between 200% and 400% of the poverty level. That is the discounted-care band in most state programs, and several states (New York, California, Maine, Oregon, Washington's large systems) reach 400%. Apply."
        : pct <= 600
          ? "You are between 400% and 600%. Illinois runs discounts to 600% at non-rural hospitals, and Maryland's financial-hardship track reaches 500% when medical debt exceeds 25% of income. Many individual hospital policies go further than their state requires. Apply anyway — the application is free and the answer is a determination you can use."
          : "You are above 600% of the poverty level. Standard charity care may not reach you — but hardship provisions often do, particularly where the bill is large relative to your income. Ask for the hospital's Financial Assistance Policy and read its hardship section, and negotiate against Amounts Generally Billed rather than the chargemaster.";

    out.innerHTML =
      '<div class="risk-banner risk-' + band + '"><div class="risk-ic">' + (pct <= 200 ? "★" : pct <= 400 ? "✓" : "◆") + '</div><div>' +
      '<div class="risk-label">Your income is about ' + pct + '% of the federal poverty level.</div>' +
      '<div class="risk-sub">' + X.esc(msg) + '</div>' +
      '</div></div>' +
      '<div class="range-box" style="margin-top:12px"><div class="li-main" style="margin-bottom:8px">For a household of ' + n + (st === "AK" ? " in Alaska" : st === "HI" ? " in Hawaii" : "") + ', ' + M.FPL.year + ':</div>' + rows + '</div>';
  }

  function renderStateCard() {
    var host = X.$("#fa-statecard"); if (!host) return;
    var st = X.$("#fa-state") ? X.$("#fa-state").value : prof.state;
    if (!st) { host.innerHTML = '<p class="muted">Pick your state above and Clapback will show what it requires of hospitals.</p>'; return; }
    var s = M.CHARITY_STATES[st];
    if (!s) {
      host.innerHTML = '<div class="law-head"><div class="law-name">' + X.esc(X.stateName(st)) + '</div>' +
        '<span class="status-pill pill-none">No verified state mandate</span></div>' +
        '<p class="muted">Clapback has no verified state charity care mandate for ' + X.esc(X.stateName(st)) + '. That does not mean you have no rights — <strong>section 501(r) applies to every tax-exempt hospital in the country</strong>, including yours. Use the federal engine below: request the Financial Assistance Policy, apply within 240 days of your first bill, and hold them to the Amounts Generally Billed cap.</p>';
      return;
    }
    var extra = (s.extra || []).map(function (e) { return "<li>" + X.esc(e) + "</li>"; }).join("");
    host.innerHTML =
      '<div class="law-head"><div class="law-name">' + X.esc(s.name) + '</div>' +
      '<span class="status-pill ' + (s.v ? "status-ban" : "status-amber") + '">' + (s.v ? "Verified" : "Partly unverified") + '</span></div>' +
      '<div class="law-eff">' + X.esc(s.law) + '</div>' +
      (s.free ? '<p><strong>Free care.</strong> ' + X.esc(s.free) + '</p>' : "") +
      (s.disc ? '<p><strong>Discounted care.</strong> ' + X.esc(s.disc) + '</p>' : "") +
      (extra ? '<ul class="tidy">' + extra + '</ul>' : "") +
      (s.warn ? '<div class="callout callout-warn"><strong>Heads up.</strong> ' + X.esc(s.warn) + '</div>' : "") +
      '<div class="btn-row">' + X.a("Official source ↗", s.url) + (s.url2 ? X.a("More ↗", s.url2) : "") + '</div>';
  }

  X.bootstrap("assist", mount);
})();

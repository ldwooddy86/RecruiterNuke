/* Clapback — Staffing & recruiting agencies module
 * Self-contained. Runs entirely on-device. Makes no network requests.
 * Scope, on purpose, matches the rest of this app: this is a COMPANY-level
 * directory — real domains and where your own candidate file lives. It never
 * identifies, looks up, or profiles an individual recruiter or any person.
 */
(function () {
  "use strict";
  var D = window.PDS;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function set(obj) { return hasChrome ? chrome.storage.local.set(obj) : Promise.resolve(); }
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var progress = {};   // { agencyId: { done: true, at: ts } }
  var profile = {};
  var q = "";
  var seg = "all";
  var stFilter = "all";
  var zip = "";
  var onlyMine = false;
  var mounted = false;

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  function mapsUrl(query) { return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(query); }
  function liUrl(name) { return "https://www.linkedin.com/search/results/companies/?keywords=" + encodeURIComponent(name); }
  function xUrl(name) { return "https://x.com/search?q=" + encodeURIComponent(name) + "&f=user"; }
  function fbUrl(name) { return "https://www.facebook.com/search/pages/?q=" + encodeURIComponent(name); }
  function igUrl(name) { return "https://www.google.com/search?q=" + encodeURIComponent("site:instagram.com \"" + name + "\""); }

  var SEG_LABEL = {};
  (D.AGENCY_SEGMENTS || []).forEach(function (s) { SEG_LABEL[s.key] = s.label; });

  /* ---------------- rendering ---------------- */

  function mount() {
    var view = $("#view-agencies");
    if (!view || mounted) { if (mounted) renderList(); return; }
    mounted = true;

    view.innerHTML =
      '<h1 id="agencies-h1">Staffing &amp; recruiting agencies</h1>' +
      '<p class="lede">Every agency you have ever registered with — or been submitted by — still holds a candidate file on you: résumé, contact details, work history, and after a placement, usually your SSN, ID documents, background check, and pay records. Agencies get breached like everyone else. This directory maps the major US firms — now with headquarters state on every entry, a state filter, and a ZIP-code branch finder — so you can <strong>verify who really contacted you</strong> and <strong>take your file back</strong> where you are no longer active.</p>' +

      '<div class="card">' +
      '<h2>Two ways to use this list</h2>' +
      '<ul class="tidy">' +
      '<li><strong>A recruiter contacted you?</strong> Find the agency below and compare the sender\u2019s domain to the real one. The <em>Vet a contact</em> tool now knows all ' + (D.AGENCIES || []).length + ' of these domains and flags look-alikes, typosquats, and free-mail senders automatically. <button class="btn btn-ghost btn-sm" data-goto="vet">Vet a contact \u2192</button></li>' +
      '<li><strong>Used an agency before?</strong> Mark it, open its site, and send the deletion / file-request letter (personalized from your profile). Under most state privacy laws they must respond \u2014 generally within 45 days.</li>' +
      '</ul>' +
      '<p class="muted" style="margin:10px 0 0">Company-level only, by design: this screen never identifies or profiles an individual recruiter \u2014 that\u2019s the behavior this app defends you against.</p>' +
      '</div>' +

      '<div class="card">' +
      '<div class="agency-toolbar">' +
      '<input type="search" id="ag-search" placeholder="Search ' + (D.AGENCIES || []).length + ' agencies by name, domain, or family\u2026" aria-label="Search agencies">' +
      '<select id="ag-state" aria-label="Filter by headquarters state"></select>' +
      '<label class="agency-mine"><input type="checkbox" id="ag-mine"> Show only agencies I\u2019ve marked</label>' +
      '</div>' +
      '<div class="chips" id="ag-chips" role="tablist" aria-label="Filter by segment"></div>' +
      '<div id="ag-state-note" class="agency-state-note hidden"></div>' +
      '<div id="ag-count" class="muted" aria-live="polite"></div>' +
      '<div id="ag-list"></div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Narrow to your ZIP code</h2>' +
      '<p class="muted">The national firms above run branch networks \u2014 hundreds of local offices each. Enter your ZIP and every listed agency gets a <strong>\u201cNear you\u201d</strong> button that opens a map of its offices around you, so you can find where your local file lives \u2014 or check whether an office someone claims to work from actually exists.</p>' +
      '<div class="agency-zip-row">' +
      '<input type="text" id="ag-zip" inputmode="numeric" maxlength="5" placeholder="ZIP code" aria-label="Your ZIP code">' +
      '<button class="btn btn-sm" id="ag-zip-apply">Apply</button>' +
      '<button class="btn btn-ghost btn-sm hidden" id="ag-zip-clear">Clear</button>' +
      '</div>' +
      '<div id="ag-zip-links" class="hidden"></div>' +
      '<p class="muted" style="margin:8px 0 0">Your ZIP is stored only on this device. It appears nowhere except inside map links you choose to click \u2014 this extension itself makes no network requests. Tip: if a \u201crecruiter\u201d gives you a local office address, map it \u2014 a real branch shows up with signage, photos, and history; a mail-drop suite is a caution sign.</p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Verify a recruiter on LinkedIn</h2>' +
      '<p class="muted">LinkedIn is where most recruiter impersonation happens \u2014 fake company pages and fake recruiter profiles wearing a real agency\u2019s name. Every agency above has a <strong>LinkedIn</strong> button that searches the official company page; here\u2019s how to tell the real one:</p>' +
      '<ul class="tidy">' +
      '<li><strong>The Website field is the tell.</strong> Open the company page\u2019s About section \u2014 its website must match the real domain listed in this directory, character for character. \u201cAerotek Careers\u201d pointing at some other domain is an impostor page.</li>' +
      '<li><strong>Sanity-check the numbers.</strong> A national firm\u2019s real page has years of posts, thousands of followers, and hundreds of listed employees. A page created last month with 40 followers is not Robert Half.</li>' +
      '<li><strong>Check the person against the page.</strong> A genuine recruiter\u2019s profile lists the real company page as their employer (the logo links to it), shows history, and has mutual connections. Brand-new profile + stock photo + urgency = walk away.</li>' +
      '<li><strong>Then check the email.</strong> Whatever they say on LinkedIn, the address they mail you from must be the agency\u2019s real domain \u2014 paste it into <button class="btn btn-ghost btn-sm" data-goto="vet">Vet a contact \u2192</button></li>' +
      '<li><strong>Never move to Telegram or WhatsApp</strong> for \u201cinterviews,\u201d and never pay anything. Real agencies are paid by employers, not by you.</li>' +
      '</ul>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Ghosted? Close the loop \u2014 on your terms</h2>' +
      '<p class="muted">Silence after an interview, an assessment, or a submission is a professional failure \u2014 theirs, not yours. These letters are polite and very direct: one clean ask, a real deadline, no groveling, no threats. Send at most two; after that, the final-notice letter ends it your way and pulls your data back.</p>' +
      '<div class="ghost-form">' +
      '<select id="gh-kind" aria-label="Ghosting scenario"></select>' +
      '<p id="gh-hint" class="muted"></p>' +
      '<div class="ghost-fields">' +
      '<input type="text" id="gh-role" placeholder="Role (e.g. Senior Analyst)" aria-label="Role">' +
      '<input type="text" id="gh-org" placeholder="Company or agency" aria-label="Company or agency">' +
      '<input type="text" id="gh-recipient" placeholder="Recipient\u2019s first name (optional)" aria-label="Recipient first name">' +
      '<input type="date" id="gh-lastdate" aria-label="Date of last contact">' +
      '</div>' +
      '<button class="btn" id="gh-generate">Generate letter</button>' +
      '</div>' +
      '<div id="gh-out" class="hidden">' +
      '<div class="ghost-subject"><strong>Subject:</strong> <span id="gh-subject"></span></div>' +
      '<textarea id="gh-text" rows="14" spellcheck="false"></textarea>' +
      '<div class="agency-letter-actions">' +
      '<button class="btn" id="gh-copy">Copy letter</button>' +
      '<button class="btn btn-ghost" id="gh-copy-subject">Copy subject</button>' +
      '</div>' +
      '<p class="muted" style="margin:8px 0 0">Reality check: many will still not reply \u2014 the letter\u2019s job is to get you a fast answer where one exists, and to let <em>you</em> end it cleanly where one doesn\u2019t. Keep it between you and the company; never turn it into a public post naming individuals.</p>' +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Agency not listed?</h2>' +
      '<p class="muted">Roughly <strong>25,000</strong> staffing and recruiting firms operate in the US \u2014 this directory covers the national firms and corporate families behind most candidate files and recruiter outreach. For any local or boutique agency: find the privacy policy in their site footer (or email their office directly), send the same letter, and cite your state\u2019s privacy law. Verify an unfamiliar agency before engaging:</p>' +
      '<ul class="tidy">' +
      '<li><a href="https://americanstaffing.net/" target="_blank" rel="noopener">American Staffing Association</a> \u2014 industry body; members are listed in its directory.</li>' +
      '<li><a href="https://consumer.ftc.gov/articles/job-scams" target="_blank" rel="noopener">FTC \u2014 job scams</a> \u2014 current fake-recruiter and fake-job patterns.</li>' +
      '<li><a href="https://www.ic3.gov/" target="_blank" rel="noopener">FBI IC3</a> \u2014 report employment fraud.</li>' +
      '</ul>' +
      '<p class="muted" style="margin:8px 0 0">Rules of thumb: real agencies never charge you a fee to be placed, never interview only over Telegram/WhatsApp, and never send a check to \u201cbuy equipment.\u201d Paste any suspicious message into <em>Vet a contact</em>.</p>' +
      '</div>' +

      '<div id="ag-letter" class="card hidden">' +
      '<h2>Deletion / file request letter</h2>' +
      '<p class="muted">Personalized from your profile. Send it to the agency\u2019s privacy contact (site footer) or reply to your recruiter and ask them to route it. Log the date \u2014 the checkbox stores it for you.</p>' +
      '<textarea id="ag-letter-text" rows="14" spellcheck="false"></textarea>' +
      '<div class="agency-letter-actions">' +
      '<button class="btn" id="ag-letter-copy">Copy letter</button>' +
      '<button class="btn btn-ghost" id="ag-letter-close">Close</button>' +
      '</div>' +
      '</div>';

    // segment chips
    var chips = $("#ag-chips");
    var allChip = '<button class="chip active" data-seg="all" role="tab" aria-selected="true">All</button>';
    chips.innerHTML = allChip + (D.AGENCY_SEGMENTS || []).map(function (s) {
      return '<button class="chip" data-seg="' + s.key + '" role="tab" aria-selected="false">' + esc(s.label) + "</button>";
    }).join("");

    chips.addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      seg = c.dataset.seg;
      chips.querySelectorAll(".chip").forEach(function (x) {
        x.classList.toggle("active", x === c);
        x.setAttribute("aria-selected", x === c ? "true" : "false");
      });
      renderList();
    });
    $("#ag-search").addEventListener("input", function (e) { q = e.target.value.toLowerCase().trim(); renderList(); });
    $("#ag-state").addEventListener("change", function (e) { stFilter = e.target.value; renderList(); });
    $("#ag-mine").addEventListener("change", function (e) { onlyMine = e.target.checked; renderList(); });

    function applyZip() {
      var v = ($("#ag-zip").value || "").trim();
      if (v && !/^\d{5}$/.test(v)) { $("#ag-zip").setAttribute("aria-invalid", "true"); return; }
      $("#ag-zip").removeAttribute("aria-invalid");
      zip = v;
      set({ agencyZip: zip }).then(function () { renderZip(); renderList(); });
    }
    $("#ag-zip-apply").addEventListener("click", applyZip);
    $("#ag-zip").addEventListener("keydown", function (e) { if (e.key === "Enter") applyZip(); });
    $("#ag-zip-clear").addEventListener("click", function () { $("#ag-zip").value = ""; applyZip(); });
    $("#ag-letter-copy").addEventListener("click", function () {
      var t = $("#ag-letter-text");
      t.select();
      try { navigator.clipboard.writeText(t.value); } catch (err) { document.execCommand && document.execCommand("copy"); }
    });
    $("#ag-letter-close").addEventListener("click", function () { $("#ag-letter").classList.add("hidden"); });

    /* ---- ghosting letter generator ---- */
    var ghSel = $("#gh-kind");
    var GH = D.GHOST_LETTERS || {};
    ghSel.innerHTML = Object.keys(GH).map(function (k) {
      return '<option value="' + k + '">' + esc(GH[k].label) + "</option>";
    }).join("");
    function ghHint() { var g = GH[ghSel.value]; $("#gh-hint").textContent = g ? g.hint : ""; }
    ghSel.addEventListener("change", ghHint);
    ghHint();

    function fmtDate(d) { return d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }); }

    $("#gh-generate").addEventListener("click", function () {
      var g = GH[ghSel.value]; if (!g) return;
      get(["profile"]).then(function (d) {
        profile = d.profile || profile || {};
        var lastRaw = $("#gh-lastdate").value;
        var last = lastRaw ? fmtDate(new Date(lastRaw + "T12:00:00")) : "[date of last contact]";
        var deadline = fmtDate(new Date(Date.now() + 7 * 24 * 3600 * 1000));
        var recipient = ($("#gh-recipient").value || "").trim() || "there";
        var fill = function (s) {
          return s
            .replace(/\{\{recipient\}\}/g, recipient)
            .replace(/\{\{role\}\}/g, ($("#gh-role").value || "").trim() || "[role]")
            .replace(/\{\{org\}\}/g, ($("#gh-org").value || "").trim() || "[company / agency]")
            .replace(/\{\{lastdate\}\}/g, last)
            .replace(/\{\{deadline\}\}/g, deadline)
            .replace(/\{\{name\}\}/g, profile.name || "[Your name]")
            .replace(/\{\{state\}\}/g, profile.state || "[your state]")
            .replace(/\{\{today\}\}/g, fmtDate(new Date()));
        };
        $("#gh-subject").textContent = fill(g.subject);
        $("#gh-text").value = fill(g.body);
        $("#gh-out").classList.remove("hidden");
        $("#gh-out").scrollIntoView({ behavior: "smooth", block: "nearest" });
      });
    });
    $("#gh-copy").addEventListener("click", function () {
      var t = $("#gh-text"); t.select();
      try { navigator.clipboard.writeText(t.value); } catch (err) { document.execCommand && document.execCommand("copy"); }
    });
    $("#gh-copy-subject").addEventListener("click", function () {
      try { navigator.clipboard.writeText($("#gh-subject").textContent); } catch (err) {}
    });

    $("#ag-list").addEventListener("change", function (e) {
      var cb = e.target.closest("input[data-ag]"); if (!cb) return;
      var id = cb.dataset.ag;
      if (cb.checked) progress[id] = { done: true, at: Date.now() };
      else delete progress[id];
      set({ agencyProgress: progress }).then(renderList);
    });
    $("#ag-list").addEventListener("click", function (e) {
      var sb = e.target.closest("button[data-soc]");
      if (sb) {
        var strip = $("#soc-" + sb.dataset.soc);
        if (strip) {
          var open = strip.classList.toggle("hidden");
          sb.setAttribute("aria-expanded", open ? "false" : "true");
        }
        return;
      }
      var b = e.target.closest("button[data-letter-ag]"); if (!b) return;
      openLetter(b.dataset.letterAg);
    });

    get(["agencyProgress", "profile", "agencyZip"]).then(function (d) {
      progress = d.agencyProgress || {};
      profile = d.profile || {};
      zip = (d.agencyZip && /^\d{5}$/.test(d.agencyZip)) ? d.agencyZip : "";
      if (zip) $("#ag-zip").value = zip;
      buildStateSelect();
      renderZip();
      renderList();
    });
  }

  function buildStateSelect() {
    var sel = $("#ag-state"); if (!sel) return;
    var counts = {};
    (D.AGENCIES || []).forEach(function (a) { if (a.st) counts[a.st] = (counts[a.st] || 0) + 1; });
    var codes = Object.keys(counts).sort(function (a, b) { return (STATE_NAME[a] || a) < (STATE_NAME[b] || b) ? -1 : 1; });
    var mine = profile.state && counts[profile.state] ? profile.state : "";
    var html = '<option value="all">HQ state: all</option>';
    if (mine) html += '<option value="' + mine + '">\u2605 My state \u2014 ' + esc(STATE_NAME[mine] || mine) + " (" + counts[mine] + ")</option>";
    codes.forEach(function (c) {
      if (c === mine) return;
      html += '<option value="' + c + '">' + esc(STATE_NAME[c] || c) + " (" + counts[c] + ")</option>";
    });
    sel.innerHTML = html;
    sel.value = stFilter;
  }

  function renderZip() {
    var box = $("#ag-zip-links"), clr = $("#ag-zip-clear");
    if (!box) return;
    clr.classList.toggle("hidden", !zip);
    if (!zip) { box.classList.add("hidden"); box.innerHTML = ""; return; }
    box.classList.remove("hidden");
    box.innerHTML = '<ul class="tidy">' +
      '<li><a href="' + mapsUrl("staffing agency near " + zip) + '" target="_blank" rel="noopener">All staffing agencies near ' + esc(zip) + " \u2197</a> \u2014 see every local firm, including boutiques not in this directory.</li>" +
      '<li><a href="' + mapsUrl("temp agency near " + zip) + '" target="_blank" rel="noopener">Temp / day-labor agencies near ' + esc(zip) + " \u2197</a></li>" +
      '<li><a href="' + mapsUrl("healthcare staffing agency near " + zip) + '" target="_blank" rel="noopener">Healthcare staffing near ' + esc(zip) + " \u2197</a></li>" +
      "</ul>";
  }

  function matches(a) {
    if (seg !== "all" && a.seg !== seg) return false;
    if (stFilter !== "all" && a.st !== stFilter) return false;
    if (onlyMine && !(progress[a.id] && progress[a.id].done)) return false;
    if (!q) return true;
    var hay = (a.name + " " + a.domain + " " + (a.alt || []).join(" ") + " " + (a.fam || "") + " " + (a.hq || "") + " " + (SEG_LABEL[a.seg] || "")).toLowerCase();
    return hay.indexOf(q) >= 0;
  }

  function renderList() {
    var list = $("#ag-list"); if (!list) return;
    var items = (D.AGENCIES || []).filter(matches);
    var markedTotal = Object.keys(progress).filter(function (k) { return progress[k] && progress[k].done; }).length;
    var scope = stFilter !== "all" ? " \u00b7 HQ in " + (STATE_NAME[stFilter] || stFilter) : "";
    $("#ag-count").textContent = items.length + " of " + (D.AGENCIES || []).length + " agencies shown" + scope + " \u00b7 " + markedTotal + " marked as requested";

    renderStateNote();

    if (!items.length) {
      list.innerHTML = '<p class="muted" style="margin-top:10px">Nothing matches \u2014 clear the search or filters. Remember this filter is by <em>headquarters</em>: national firms have branches in every state' + (zip ? "" : ", so set your ZIP below to find offices near you") + '. If the agency isn\u2019t in the directory, use the \u201cAgency not listed?\u201d steps below.</p>';
      return;
    }

    list.innerHTML = items.map(function (a) {
      var p = progress[a.id];
      var when = p && p.at ? new Date(p.at).toLocaleDateString() : "";
      return '<div class="agency-row' + (p && p.done ? " done" : "") + '">' +
        '<label class="agency-check"><input type="checkbox" data-ag="' + esc(a.id) + '"' + (p && p.done ? " checked" : "") + ' aria-label="Mark ' + esc(a.name) + ' as requested"></label>' +
        '<div class="agency-main">' +
        '<div class="agency-top"><strong>' + esc(a.name) + "</strong>" +
        '<span class="seg-badge">' + esc(SEG_LABEL[a.seg] || a.seg) + "</span>" +
        (a.fam ? '<span class="fam-badge" title="Corporate family">' + esc(a.fam) + "</span>" : "") +
        "</div>" +
        '<div class="agency-dom">Real domain: <code>' + esc(a.domain) + "</code>" +
        (a.alt && a.alt.length ? ' <span class="muted">(also ' + a.alt.map(esc).join(", ") + ")</span>" : "") +
        (a.hq ? ' <span class="agency-hq">HQ: ' + esc(a.hq) + "</span>" : "") +
        (when ? ' <span class="agency-when">requested ' + esc(when) + "</span>" : "") +
        "</div>" +
        (a.note ? '<div class="agency-note">' + esc(a.note) + "</div>" : "") +
        "</div>" +
        '<div class="agency-actions">' +
        '<a class="btn btn-ghost btn-sm" href="https://' + esc(a.domain) + '/" target="_blank" rel="noopener">Open site \u2197</a>' +
        '<a class="btn btn-ghost btn-sm" href="' + liUrl(a.name) + '" target="_blank" rel="noopener" title="Find the official company page on LinkedIn">LinkedIn \u2197</a>' +
        '<a class="btn btn-ghost btn-sm" href="https://www.glassdoor.com/Search/results.htm?keyword=' + encodeURIComponent(a.name) + '" target="_blank" rel="noopener" title="Reviews and interview reports \u2014 the Interviews section is where ghosting patterns show up">Glassdoor \u2197</a>' +
        (zip ? '<a class="btn btn-ghost btn-sm" href="' + mapsUrl(a.name + " staffing near " + zip) + '" target="_blank" rel="noopener" title="Map this agency\u2019s offices near you">Near ' + esc(zip) + " \u2197</a>" : "") +
        '<button class="btn btn-ghost btn-sm" data-soc="' + esc(a.id) + '" aria-expanded="false">Socials \u25be</button>' +
        '<button class="btn btn-ghost btn-sm" data-letter-ag="' + esc(a.id) + '">Letter</button>' +
        "</div>" +
        '<div class="agency-soc hidden" id="soc-' + esc(a.id) + '">' +
        '<span class="agency-soc-rule">The real page\u2019s <strong>Website field must show ' + esc(a.domain) + "</strong> \u2014 anything else is an impostor.</span> " +
        '<a href="' + liUrl(a.name) + '" target="_blank" rel="noopener">LinkedIn \u2197</a>' +
        ' \u00b7 <a href="' + xUrl(a.name) + '" target="_blank" rel="noopener">X \u2197</a>' +
        ' \u00b7 <a href="' + fbUrl(a.name) + '" target="_blank" rel="noopener">Facebook \u2197</a>' +
        ' \u00b7 <a href="' + igUrl(a.name) + '" target="_blank" rel="noopener">Instagram \u2197</a>' +
        ' \u00b7 <a href="https://' + esc(a.domain) + '/" target="_blank" rel="noopener">Official links in their site footer \u2197</a>' +
        ' <span class="agency-soc-rule" style="margin-top:6px">Reviews: <a href="https://www.glassdoor.com/Search/results.htm?keyword=' + encodeURIComponent(a.name) + '" target="_blank" rel="noopener">Glassdoor \u2197</a> \u00b7 <a href="https://www.bbb.org/search?find_text=' + encodeURIComponent(a.name) + '" target="_blank" rel="noopener">BBB \u2197</a> \u2014 read the <em>Interviews</em> reviews for ghosting patterns before you invest time.</span>' +
        "</div>" +
        "</div>";
    }).join("");
  }

  function renderStateNote() {
    var box = $("#ag-state-note"); if (!box) return;
    if (stFilter === "all" || !D.STATE_NOTES) { box.classList.add("hidden"); box.innerHTML = ""; return; }
    var name = STATE_NAME[stFilter] || stFilter;
    var body = D.STATE_NOTES[stFilter] || D.STATE_NOTES.DEFAULT || "";
    box.classList.remove("hidden");
    box.innerHTML = "<strong>Verifying agencies in " + esc(name) + ":</strong> " + esc(body) +
      " " + esc(D.STATE_NOTES.HEALTH || "") +
      ' <a href="https://www.dol.gov/agencies/whd/state/contacts" target="_blank" rel="noopener">State labor office directory (US DOL) \u2197</a>' +
      ' \u00b7 <a href="https://americanstaffing.net/" target="_blank" rel="noopener">ASA directory \u2197</a>';
  }

  function openLetter(id) {
    var a = (D.AGENCIES || []).find(function (x) { return x.id === id; });
    if (!a) return;
    get(["profile"]).then(function (d) {
      profile = d.profile || profile || {};
      var text = (D.LETTERS && D.LETTERS.deletion) || "";
      text = "To: " + a.name + " \u2014 Privacy / Data Requests (" + a.domain + ")\n\n" + text;
      text = text
        .replace(/\{\{name\}\}/g, profile.name || "[Your name]")
        .replace(/\{\{state\}\}/g, profile.state || "[Your state]")
        .replace(/\{\{city\}\}/g, profile.city || "[Your city]")
        .replace(/\{\{email\}\}/g, profile.email || "[Your email]")
        .replace(/\{\{today\}\}/g, new Date().toLocaleDateString());
      text += "\n\nP.S. This includes any candidate profile, r\u00e9sum\u00e9, submittal record, assessment, or payroll/onboarding data held by " + a.name + " or its affiliated brands.";
      var box = $("#ag-letter");
      $("#ag-letter-text").value = text;
      box.classList.remove("hidden");
      box.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  /* ---------------- init ---------------- */
  if (hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !mounted) return;
      if (ch.agencyProgress) { progress = ch.agencyProgress.newValue || {}; renderList(); }
      if (ch.agencyZip) { zip = ch.agencyZip.newValue || ""; var zi = $("#ag-zip"); if (zi) zi.value = zip; renderZip(); renderList(); }
      if (ch.profile) { profile = ch.profile.newValue || {}; buildStateSelect(); }
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="agencies"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

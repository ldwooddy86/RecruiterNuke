/* Clapback — "Student loans" module.
 * Your own loans only. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, S = window.CBS;
  var mounted = false;
  var prof = {};

  /* Label + sentence. .law-eff is a small-caps micro-label; putting a whole
     sentence in it renders the sentence in all caps. */
  function fact(label, value, warn) {
    var d = X.el("div", "card-fact" + (warn ? " is-warn" : ""));
    d.appendChild(X.el("b", null, label));
    d.appendChild(document.createTextNode(value));
    return d;
  }

  function mount() {
    var view = X.$("#view-loans");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Student loans</h1>' +
      '<p class="lede">Federal student loan rules changed more between July 2025 and July 2026 than in the previous decade. Almost every explainer online is stale — it will tell you SAVE is a live plan, that Grad PLUS is available, that Fresh Start is open, and that forgiveness is tax-free. All four are now wrong. Everything on this page says when it took effect and links the rule it came from.</p>' +

      '<div class="callout callout-warn" id="ln-volatile"></div>' +

      /* ---- which loans ---- */
      '<h2>First: which kind do you have?</h2>' +
      '<div class="card">' +
      '<p>This determines almost everything else. If you don’t know, log in at StudentAid.gov — every federal loan you have will be listed. Anything not listed there is private.</p>' +
      '<div class="chips" id="ln-kind">' +
      '<button class="chip" data-kind="fed">Federal</button>' +
      '<button class="chip" data-kind="priv">Private</button>' +
      '<button class="chip" data-kind="both">Both</button>' +
      '</div>' +
      '<div id="ln-kind-out" style="margin-top:14px"></div>' +
      '</div>' +

      /* ---- time-sensitive ---- */
      '<div class="card danger">' +
      '<h2 id="ap-head"></h2>' +
      '<p id="ap-body"></p>' +
      '<div class="callout callout-warn" id="ap-deadline"></div>' +
      '<p id="ap-already"></p>' +
      '<p class="muted" id="ap-catch"></p>' +
      '<div class="btn-row"><button class="btn btn-sm" id="ap-track">Track this deadline</button>' +
      X.a("The announcement ↗", S.AUTOPAY.url) + '</div>' +
      '</div>' +

      /* ---- what changed ---- */
      '<h2>What the 2025 law changed</h2>' +
      '<div class="card">' +
      '<p class="muted" id="law-naming"></p>' +
      '<div id="law-list" class="link-list"></div>' +
      '<div class="btn-row">' + X.a("The law ↗", S.LAW.url) + X.a("The implementing rule ↗", S.LAW.ruleUrl) + '</div>' +
      '</div>' +

      /* ---- SAVE ---- */
      '<div class="card danger">' +
      '<h3 id="save-head"></h3>' +
      '<p id="save-body"></p>' +
      '<div class="callout callout-warn" id="save-danger"></div>' +
      '<p class="muted" id="save-honest"></p>' +
      '<p id="save-buyback"></p>' +
      '<div class="btn-row">' + X.a("The Department’s notice ↗", S.SAVE.url) + '</div>' +
      '</div>' +

      /* ---- RAP calculator ---- */
      '<h2>What would the new plan cost you?</h2>' +
      '<div class="card">' +
      '<p>The Repayment Assistance Plan opened July 1, 2026. Unlike the old income-driven plans it takes a percentage of your <strong>total</strong> adjusted gross income rather than your discretionary income — so the arithmetic is different from anything you may have worked out before.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="rap-agi">Your adjusted gross income</label><input class="input" id="rap-agi" type="number" min="0" step="500" placeholder="e.g. 52000"></div>' +
      '<div class="ev-field"><label class="field" for="rap-dep">Dependents</label><input class="input" id="rap-dep" type="number" min="0" max="15" step="1" placeholder="0"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="rap-run">Estimate my payment</button></div>' +
      '</div>' +
      '<div id="rap-out"></div>' +
      '<div class="grid-2" style="margin-top:14px">' +
      '<div class="card mini"><div class="li-main">What’s good about it</div><ul class="tidy" id="rap-good"></ul></div>' +
      '<div class="card mini"><div class="li-main">What isn’t</div><ul class="tidy" id="rap-bad"></ul></div>' +
      '</div>' +
      '<div class="callout callout-warn" id="rap-cliff"></div>' +
      X.srcLine("34 CFR 685.209 (eCFR)", S.RAP.url) +
      '</div>' +

      /* ---- plans ---- */
      '<h2>Every plan, and which are closing</h2>' +
      '<div id="plan-list"></div>' +

      /* ---- discharge ---- */
      '<h2 id="dvol-head"></h2>' +
      '<div class="card">' +
      '<p class="lede" style="font-size:15px" id="vol-lead"></p>' +
      '<div class="grid-2" style="margin-bottom:12px">' +
      '<div class="card mini"><div class="stat-num" style="font-size:26px">$28.7B</div><div class="li-note" id="vol-admin"></div></div>' +
      '<div class="card mini"><div class="stat-num" style="font-size:26px">692</div><div class="li-note" id="vol-bk"></div></div>' +
      '</div>' +
      '<div class="callout callout-info" id="vol-ratio"></div>' +
      '<p class="muted" id="dvol-caveat"></p>' +
      '<p id="vol-take"></p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="bankrupt">Where discharges actually happen →</button>' + X.a("CRS source ↗", S.VOLUMES.adminUrl) + '</div>' +
      '</div>' +

      '<h2>Every way federal debt gets discharged</h2>' +
      '<p class="muted">Check these before you assume you need a lawyer or a court. Several are automatic and several are badly under-claimed.</p>' +
      '<div id="dis-list"></div>' +
      '<div class="card danger"><h3 id="pv-head"></h3><p id="pv-body"></p><div class="callout callout-warn" id="pv-trap"></div><p class="muted" id="pv-honest"></p><div class="btn-row">' + X.a("The rule as published ↗", S.PSLF_VACATUR.ruleUrl, "btn btn-sm") + X.a("Litigation tracker ↗", S.PSLF_VACATUR.url) + '</div></div>' +

      /* ---- tax ---- */
      '<div class="card danger">' +
      '<h2 id="tax-head"></h2>' +
      '<p id="tax-body"></p>' +
      '<div class="grid-2">' +
      '<div class="card mini"><div class="li-main">Still tax-free</div><ul class="tidy" id="tax-free"></ul></div>' +
      '<div class="card mini"><div class="li-main">Now taxable</div><ul class="tidy" id="tax-taxed"></ul></div>' +
      '</div>' +
      '<div class="callout callout-info" id="tax-insolvency"></div>' +
      '<p class="muted" id="tax-states"></p>' +
      '<p id="tax-plan"></p>' +
      X.srcLine("IRS Taxpayer Advocate, March 2026", S.TAX.url) +
      '</div>' +

      /* ---- default ---- */
      '<h2>Behind on payments, or already in default</h2>' +
      '<div class="card"><h3>The timeline</h3><div id="def-timeline" class="link-list"></div></div>' +
      '<div class="card danger"><h3 id="dv-head"></h3><p id="dv-body"></p><div class="callout callout-warn" id="dv-warn"></div>' +
      '<div class="btn-row">' + X.a("Check the Department’s newsroom ↗", S.DEFAULT_.volatile.check, "btn btn-sm") + X.a("The pause announcement ↗", S.DEFAULT_.volatile.url) + '</div></div>' +
      '<div class="grid-2">' +
      '<div class="card"><h3 id="gr-head"></h3><p id="gr-body"></p><div class="callout callout-info" id="gr-compare"></div><p class="muted" id="gr-avoid"></p></div>' +
      '<div class="card"><h3 id="of-head"></h3><p id="of-body"></p><p class="muted" id="of-note"></p><p class="muted" id="of-avoid"></p></div>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Getting out of default: the choice that matters</h3>' +
      '<div id="exit-list"></div>' +
      '<div class="callout callout-info" id="exit-rule"></div>' +
      '<p class="muted" id="exit-caveat"></p>' +
      '</div>' +
      '<div class="card"><p class="muted" id="def-fresh"></p><p class="muted" id="def-stats"></p></div>' +

      /* ---- no SOL ---- */
      '<div class="card danger">' +
      '<h3 id="sol-head"></h3><p id="sol-body"></p><p class="fineprint" id="sol-cite"></p>' +
      '<div class="callout callout-info" id="sol-flip"></div>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="court">Your state’s limitations period →</button></div>' +
      '</div>' +

      /* ---- private ---- */
      '<h2>Private student loans</h2>' +
      '<div class="card"><p id="pr-asym"></p></div>' +
      '<div class="card danger"><h3 id="refi-head"></h3><p id="refi-body"></p><div class="btn-row">' + X.a("CFPB on refinancing ↗", S.PRIVATE.refi.url) + '</div></div>' +
      '<div class="card"><h3>What you do have</h3><div id="pr-have" class="link-list"></div></div>' +
      '<div class="card">' +
      '<h3 id="ls-head"></h3><p id="ls-body"></p><ul class="tidy" id="ls-def"></ul>' +
      '<div class="callout callout-info" id="ls-ncslt"></div>' +
      '<p id="ls-point"></p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="court">Open the court kit →</button></div>' +
      '</div>' +
      '<div class="card danger">' +
      '<h3 id="nq-head"></h3><p id="nq-body"></p><p id="nq-cases"></p>' +
      '<ul class="tidy" id="nq-list"></ul>' +
      '<p class="muted" id="nq-src"></p>' +
      '<div class="callout callout-info" id="nq-irig"></div>' +
      '<p class="fineprint" id="nq-cite"></p>' +
      '</div>' +
      '<div class="card"><p class="muted" id="pr-navient"></p></div>' +

      /* ---- your state ---- */
      '<h2>Your state</h2>' +
      '<div class="card">' +
      '<div class="ev-field" style="max-width:340px"><label class="field" for="ln-state">Where you live</label><span id="ln-state-host"></span></div>' +
      '<div id="ln-state-out" style="margin-top:14px"></div>' +
      '<p class="muted" id="omb-note"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Servicer licensing in your state</h3>' +
      '<p id="lic-note"></p><p class="muted" id="lic-caveat"></p>' +
      '<p id="lic-what"></p><p class="muted" id="lic-pra"></p><p class="muted" id="lic-preempt"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Programs that repay loans for you</h3>' +
      '<div id="lrap-fed" class="link-list"></div>' +
      '<h4 style="margin-top:16px" id="lrap-shead"></h4>' +
      '<p id="lrap-sbody"></p>' +
      '<div id="lrap-states"></div>' +
      '<div class="btn-row">' + X.a("Find your state’s program ↗", S.LRAP.state.find, "btn btn-sm") + '</div>' +
      '<p class="muted" id="lrap-gap"></p>' +
      '</div>' +

      /* ---- servicers/tools ---- */
      '<h2>Who to call, and where to look</h2>' +
      '<div class="card"><h3>Your tools</h3><div id="ln-tools" class="link-list"></div></div>' +
      '<div class="card"><h3>Current servicers</h3><div id="ln-servicers" class="link-list"></div><p class="muted" id="ln-servnote"></p></div>' +
      '<div class="card"><h3>If your servicer won’t fix it</h3><div id="ln-escalate" class="link-list"></div><div class="callout callout-info" id="ln-cfpb"></div></div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<div class="card"><div id="loan-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal, tax, or financial advice. Federal student loan rules are changing fast and two facts on this page — whether involuntary collections are running, and the current means-test figures — are volatile by nature. Every rule here links to the regulation or agency page it came from, verified ' + X.esc(S.UPDATED) + '. Check anything you are about to act on.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    X.$("#ln-volatile").innerHTML = "<strong>Two things on this page move, and Clapback won’t pretend otherwise.</strong> " +
      "Whether the Department is actually garnishing wages and seizing tax refunds today is genuinely uncertain — collections were paused in January 2026 with no end date, and Clapback last confirmed the pause on June 24, 2026. And the tax treatment of forgiveness changed on January 1, 2026. Both are flagged where they appear. Verify before you act on either.";

    /* auto-pay */
    var A = S.AUTOPAY;
    X.$("#ap-head").textContent = A.head;
    X.$("#ap-body").textContent = A.body;
    var u = X.urgency(A.deadline);
    X.$("#ap-deadline").innerHTML = "<strong>" + X.esc(A.deadlineText) + "</strong> — " + X.esc(u.label) + ".";
    X.$("#ap-already").textContent = A.already;
    X.$("#ap-catch").textContent = A.catch;
    X.$("#ap-track").addEventListener("click", function () {
      X.addDeadline({ kind: "loans", label: "Enroll in student loan auto pay for the 1% interest reduction", due: A.deadline, note: "Log into your servicer account. Worth roughly 0.75 percentage points more than the old discount, through June 30, 2028." });
    });

    /* law */
    X.$("#law-naming").textContent = S.LAW.naming;
    var ll = X.$("#law-list"); ll.innerHTML = "";
    S.LAW.changes.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.n));
      l.appendChild(X.el("div", "li-note", c.d));
      row.appendChild(l);
      ll.appendChild(row);
    });

    /* SAVE */
    X.$("#save-head").textContent = S.SAVE.head;
    X.$("#save-body").textContent = S.SAVE.body;
    X.$("#save-danger").innerHTML = "<strong>Two things that cost people real money.</strong> " + X.esc(S.SAVE.danger);
    X.$("#save-honest").textContent = S.SAVE.honest;
    X.$("#save-buyback").textContent = S.SAVE.buyback;

    /* RAP */
    var g = X.$("#rap-good"); g.innerHTML = "";
    S.RAP.good.forEach(function (s) { g.appendChild(X.el("li", null, s)); });
    var b = X.$("#rap-bad"); b.innerHTML = "";
    S.RAP.bad.forEach(function (s) { b.appendChild(X.el("li", null, s)); });
    X.$("#rap-cliff").innerHTML = "<strong>Watch the cliffs.</strong> " + X.esc(S.RAP.cliff);
    X.$("#rap-run").addEventListener("click", rapCalc);

    /* plans */
    var pl = X.$("#plan-list"); pl.innerHTML = "";
    S.PLANS.forEach(function (p) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", p.n));
      var pill = p.open
        ? X.el("span", "status-pill pill-ban", "Open")
        : X.el("span", "status-pill pill-red", p.closes.indexOf("Already") === 0 ? "Ended" : "Closes " + p.closes);
      head.appendChild(pill);
      card.appendChild(head);
      card.appendChild(fact("Who", p.who));
      card.appendChild(fact("Payment", p.pay));
      card.appendChild(fact("Forgiveness", p.forgive));
      card.appendChild(fact("PSLF",
        p.pslf === true ? "Counts toward Public Service Loan Forgiveness."
          : p.pslf === "depends" ? "Counts only in months where the payment is at least the 10-year standard amount. Read the note."
            : "Does NOT count toward PSLF.",
        p.pslf !== true));
      if (p.note) {
        var n = X.el("div", "callout callout-warn"); n.style.margin = "10px 0 0"; n.textContent = p.note;
        card.appendChild(n);
      }
      pl.appendChild(card);
    });

    /* volumes */
    var V = S.VOLUMES;
    X.$("#dvol-head").textContent = V.head;
    X.$("#vol-lead").textContent = V.lead;
    X.$("#vol-admin").textContent = V.admin;
    X.$("#vol-bk").textContent = V.bk;
    X.$("#vol-ratio").innerHTML = "<strong>" + X.esc(V.ratio) + "</strong>";
    X.$("#dvol-caveat").textContent = V.caveat;
    X.$("#vol-take").textContent = V.takeaway;

    /* discharge list */
    var dl = X.$("#dis-list"); dl.innerHTML = "";
    S.DISCHARGE.forEach(function (d) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", d.n));
      if (d.auto) head.appendChild(X.el("span", "status-pill pill-ban", "Can be automatic"));
      card.appendChild(head);
      card.appendChild(X.el("p", null, d.who));
      if (d.note) card.appendChild(X.el("p", "law-tip", d.note));
      card.appendChild(fact("Tax", d.tax, /TAXABLE/.test(d.tax)));
      if (d.cite) card.appendChild(X.el("div", "fineprint", d.cite));
      dl.appendChild(card);
    });

    X.$("#pv-head").textContent = S.PSLF_VACATUR.head;
    X.$("#pv-body").textContent = S.PSLF_VACATUR.body;
    X.$("#pv-trap").innerHTML = "<strong>The trap.</strong> " + X.esc(S.PSLF_VACATUR.trap);
    X.$("#pv-honest").textContent = S.PSLF_VACATUR.honest;

    /* tax */
    var T = S.TAX;
    X.$("#tax-head").textContent = T.head;
    X.$("#tax-body").textContent = T.body;
    var tf = X.$("#tax-free"); tf.innerHTML = "";
    T.free.forEach(function (s) { tf.appendChild(X.el("li", null, s)); });
    var tt = X.$("#tax-taxed"); tt.innerHTML = "";
    T.taxed.forEach(function (s) { tt.appendChild(X.el("li", null, s)); });
    X.$("#tax-insolvency").innerHTML = "<strong>Before you accept a tax bill.</strong> " + X.esc(T.insolvency);
    X.$("#tax-states").textContent = T.states;
    X.$("#tax-plan").textContent = T.plan;

    /* default */
    var D = S.DEFAULT_;
    var dt = X.$("#def-timeline"); dt.innerHTML = "";
    D.timeline.forEach(function (t) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", t.d));
      l.appendChild(X.el("div", "li-note", t.t));
      row.appendChild(l);
      dt.appendChild(row);
    });
    X.$("#dv-head").textContent = D.volatile.head;
    X.$("#dv-body").textContent = D.volatile.body;
    X.$("#dv-warn").innerHTML = "<strong>Don’t assume.</strong> " + X.esc(D.volatile.warn);

    X.$("#gr-head").textContent = D.garnish.head;
    X.$("#gr-body").innerHTML = X.esc(D.garnish.body) + " <span class='muted'>(" + X.esc(D.garnish.cite) + ")</span>";
    X.$("#gr-compare").innerHTML = "<strong>The comparison people get backwards.</strong> " + X.esc(D.garnish.compare) + " <span class='muted'>(" + X.esc(D.garnish.compareCite) + ")</span>";
    X.$("#gr-avoid").textContent = D.garnish.avoid;

    X.$("#of-head").textContent = D.offset.head;
    X.$("#of-body").innerHTML = X.esc(D.offset.body) + " <span class='muted'>(" + X.esc(D.offset.cite) + ")</span>";
    X.$("#of-note").textContent = D.offset.note;
    X.$("#of-avoid").textContent = D.offset.avoid;

    var ex = X.$("#exit-list"); ex.innerHTML = "";
    D.exit.forEach(function (e) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", e.n));
      head.appendChild(X.el("span", "status-pill " + (e.best ? "status-ban" : "status-amber"), e.time));
      card.appendChild(head);
      card.appendChild(X.el("p", null, e.credit));
      card.appendChild(fact("How often", e.times));
      card.appendChild(X.el("p", "muted", e.cost));
      ex.appendChild(card);
    });
    X.$("#exit-rule").innerHTML = "<strong>How to choose.</strong> " + X.esc(D.exitRule);
    X.$("#exit-caveat").textContent = D.rehabCaveat;
    X.$("#def-fresh").textContent = D.freshstart;
    X.$("#def-stats").textContent = D.stats;

    /* no SOL */
    X.$("#sol-head").textContent = S.NOSOL.head;
    X.$("#sol-body").textContent = S.NOSOL.body;
    X.$("#sol-cite").textContent = "Cite: " + S.NOSOL.cite;
    X.$("#sol-flip").innerHTML = "<strong>Private loans are the opposite.</strong> " + X.esc(S.NOSOL.flip);

    /* private */
    var P = S.PRIVATE;
    X.$("#pr-asym").textContent = P.asym;
    X.$("#refi-head").textContent = P.refi.head;
    X.$("#refi-body").textContent = P.refi.body;
    var ph = X.$("#pr-have"); ph.innerHTML = "";
    P.have.forEach(function (h) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", h.n));
      l.appendChild(X.el("div", "li-note", h.t));
      row.appendChild(l);
      ph.appendChild(row);
    });
    X.$("#ls-head").textContent = P.lawsuit.head;
    X.$("#ls-body").textContent = P.lawsuit.body;
    var ld = X.$("#ls-def"); ld.innerHTML = "";
    P.lawsuit.defenses.forEach(function (s) { ld.appendChild(X.el("li", null, s)); });
    X.$("#ls-ncslt").innerHTML = "<strong>About the big trusts.</strong> " + X.esc(P.lawsuit.ncslt);
    X.$("#ls-point").textContent = P.lawsuit.ncsltPoint;

    var N = P.nonqualified;
    X.$("#nq-head").textContent = N.head;
    X.$("#nq-body").textContent = N.body;
    X.$("#nq-cases").textContent = N.cases;
    var nl = X.$("#nq-list"); nl.innerHTML = "";
    N.list.forEach(function (s) { nl.appendChild(X.el("li", null, s)); });
    X.$("#nq-src").textContent = N.listSrc;
    X.$("#nq-irig").innerHTML = "<strong>And you may not need a lawsuit at all.</strong> " + X.esc(N.irigoyen);
    X.$("#nq-cite").textContent = "Cite: " + N.cite;
    X.$("#pr-navient").textContent = P.navient;

    /* licensing */
    X.$("#lic-note").textContent = S.LICENSING.note;
    X.$("#lic-caveat").textContent = S.LICENSING.caveat;
    X.$("#lic-what").textContent = S.LICENSING.what;
    X.$("#lic-pra").textContent = S.LICENSING.pra;
    X.$("#lic-preempt").textContent = S.LICENSING.preempt;

    /* LRAP */
    var lf = X.$("#lrap-fed"); lf.innerHTML = "";
    S.LRAP.fed.forEach(function (f) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", f.n));
      l.appendChild(X.el("div", "li-note", f.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Open ↗", f.u);
      row.appendChild(w);
      lf.appendChild(row);
    });
    X.$("#lrap-shead").textContent = S.LRAP.state.head;
    X.$("#lrap-sbody").textContent = S.LRAP.state.body;
    X.$("#lrap-gap").textContent = S.LRAP.state.gap;

    /* tools, servicers, escalation */
    var tl = X.$("#ln-tools"); tl.innerHTML = "";
    S.TOOLS.forEach(function (t) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", t.n));
      l.appendChild(X.el("div", "li-note", t.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Open ↗", t.u, "btn btn-sm");
      row.appendChild(w);
      tl.appendChild(row);
    });
    var sv = X.$("#ln-servicers"); sv.innerHTML = "";
    S.SERVICERS.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", s.n));
      if (s.p) l.appendChild(X.el("div", "li-note", s.p));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Open ↗", s.u);
      row.appendChild(w);
      sv.appendChild(row);
    });
    X.$("#ln-servnote").textContent = S.SERVICER_NOTE;
    var es = X.$("#ln-escalate"); es.innerHTML = "";
    S.ESCALATE.forEach(function (e) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", e.n));
      l.appendChild(X.el("div", "li-note", e.t));
      row.appendChild(l);
      if (e.u) { var w = X.el("div"); w.innerHTML = X.a("Open ↗", e.u); row.appendChild(w); }
      es.appendChild(row);
    });
    X.$("#ln-cfpb").innerHTML = "<strong>An honest word about the CFPB route.</strong> " + X.esc(S.CFPB_NOTE);
    X.$("#omb-note").textContent = S.OMBUDS_NOTE;

    X.letterCards(X.$("#loan-letters"), "loans", function () { return {}; });

    /* which-kind router */
    X.$("#ln-kind").addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      X.$$("#ln-kind .chip").forEach(function (x) { x.classList.toggle("active", x === c); });
      var k = c.dataset.kind;
      var out = X.$("#ln-kind-out");
      var fed = "<strong>Federal loans.</strong> You have income-driven repayment, Public Service Loan Forgiveness, disability discharge, rehabilitation out of default, and a right to deferment and forbearance. You also have no statute of limitations and a government that can garnish your wages without ever suing you. Everything above the private section applies to you.";
      var priv = "<strong>Private loans.</strong> None of the federal protections apply. What you do have instead is a statute of limitations that actually runs out, full debt collection and credit reporting protections once a collector is involved, and — in some cases — a loan that isn’t protected from bankruptcy discharge at all. Skip to the private section; it is where your leverage is.";
      out.innerHTML = '<div class="callout callout-info">' +
        (k === "fed" ? fed : k === "priv" ? priv :
          fed + "<br><br>" + priv + "<br><br><strong>Handle them separately.</strong> The strategies barely overlap, and the worst mistake is refinancing the federal ones into a private consolidation to simplify — that is a one-way door out of every protection you have.") +
        "</div>";
    });
  }

  function rapCalc() {
    var agi = parseFloat(X.$("#rap-agi").value);
    var dep = parseInt(X.$("#rap-dep").value, 10) || 0;
    var out = X.$("#rap-out"); out.innerHTML = "";
    if (!isFinite(agi) || agi < 0) { out.innerHTML = '<div class="callout callout-warn">Enter your adjusted gross income.</div>'; return; }

    var band = null;
    for (var i = 0; i < S.RAP.brackets.length; i++) {
      if (agi <= S.RAP.brackets[i].max) { band = S.RAP.brackets[i]; break; }
    }
    var annual = band.flat != null ? band.flat : Math.round(agi * band.pct / 100);
    var monthly = annual / 12 - dep * S.RAP.perDependent;
    if (monthly < S.RAP.floor) monthly = S.RAP.floor;
    monthly = Math.round(monthly);
    var rate = band.flat != null ? "a flat $120 a year" : band.pct + "% of your total AGI";

    /* Show the next cliff so the step function is visible. */
    var cliffHtml = "";
    if (band.max !== Infinity) {
      var nextAgi = band.max + 1;
      var nextBand = null;
      for (var j = 0; j < S.RAP.brackets.length; j++) {
        if (nextAgi <= S.RAP.brackets[j].max) { nextBand = S.RAP.brackets[j]; break; }
      }
      if (nextBand) {
        var nAnnual = nextBand.flat != null ? nextBand.flat : Math.round(nextAgi * nextBand.pct / 100);
        var nMonthly = Math.max(S.RAP.floor, Math.round(nAnnual / 12 - dep * S.RAP.perDependent));
        cliffHtml = '<div class="callout callout-warn" style="margin-top:12px">' +
          "<strong>The next step up is at " + X.esc(X.money(band.max)) + ".</strong> " +
          "One dollar of income above that and the same calculation gives roughly " + X.esc(X.money(nMonthly)) +
          " a month instead of " + X.esc(X.money(monthly)) + ". The brackets are steps, not a curve — worth knowing before you take a small raise." +
          "</div>";
      }
    }

    out.innerHTML =
      '<div class="risk-banner risk-low"><div class="risk-ic">≈</div><div>' +
      '<div class="risk-label">About ' + X.esc(X.money(monthly)) + ' a month under RAP.</div>' +
      '<div class="risk-sub">Worked as ' + X.esc(rate) + ' — ' + X.esc(X.money(annual)) + ' a year — divided by 12' +
      (dep ? ', less $50 for each of your ' + dep + ' dependent' + (dep === 1 ? "" : "s") : "") +
      ', with a $10 monthly floor. Forgiveness comes after 360 payments — 30 years. Unpaid interest above your payment is not charged, so the balance will not grow.</div>' +
      '</div></div>' +
      cliffHtml +
      '<p class="muted" style="margin-top:10px">An estimate from the regulation’s own table, not a quote. Your servicer’s figure is the one that counts, and the official Loan Simulator will compare this against every other plan you are eligible for. ' +
      X.a("Loan Simulator ↗", "https://studentaid.gov/loan-simulator") + '</p>';
  }

  function load() {
    X.profile().then(function (p) {
      prof = p;
      var host = X.$("#ln-state-host");
      if (host) {
        host.innerHTML = X.stateSelect("ln-state", p.state, "Select a state…");
        X.$("#ln-state").addEventListener("change", renderState);
      }
      renderState();
    });
  }

  /* Re-entering the tab re-reads the profile, so a state saved after this
     module first mounted still lands here. An explicit pick on this tab wins. */
  function refresh() {
    X.profile().then(function (p) {
      prof = p;
      var sel = X.$("#ln-state");
      if (sel && !sel.value && p.state) sel.value = p.state;
      renderState();
    });
  }

  function renderState() {
    var out = X.$("#ln-state-out"); if (!out) return;
    var st = X.$("#ln-state") ? X.$("#ln-state").value : prof.state;

    /* LRAP state chips render regardless */
    var ls = X.$("#lrap-states");
    if (ls) {
      ls.innerHTML = S.LRAP.state.states.map(function (s) {
        var on = s === st;
        return '<span class="tag' + (on ? " tag-critical" : "") + '">' + X.esc(s) + "</span>";
      }).join(" ");
    }

    if (!st) { out.innerHTML = '<p class="muted">Pick your state and Clapback will show whether it has a student loan ombudsman, and whether it runs a loan repayment program.</p>'; return; }
    var o = S.OMBUDSMEN[st];
    var html = "";
    if (o) {
      html += '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(o.n) + '</div>' +
        '<span class="status-pill pill-ban">' + X.esc(X.stateName(st)) + '</span></div>' +
        '<div class="law-eff">' + X.esc(o.ag) + '</div>' +
        (o.p ? '<p><strong>' + X.esc(o.p) + '</strong>' + (o.e ? '  ·  ' + X.esc(o.e) : "") + '</p>' : "") +
        (o.warn ? '<div class="callout callout-warn">' + X.esc(o.warn) + '</div>' : "") +
        '<div class="btn-row">' + X.a("Their page ↗", o.u, "btn btn-sm") + (o.c ? X.a("File a complaint ↗", o.c) : "") + '</div></div>';
    } else {
      html += '<div class="risk-banner risk-caution"><div class="risk-ic">–</div><div>' +
        '<div class="risk-label">No verified student loan ombudsman in ' + X.esc(X.stateName(st)) + '.</div>' +
        '<div class="risk-sub">That does not mean nobody there can help. Try your state attorney general’s consumer protection line, and use the federal escalation ladder below. Note that a state office generally cannot compel the federal Department of Education anyway — its leverage is over servicers and private lenders.</div>' +
        '</div></div>';
    }
    var hasLrap = S.LRAP.state.states.indexOf(st) >= 0;
    html += '<div class="callout ' + (hasLrap ? "callout-info" : "callout-warn") + '" style="margin-top:12px">' +
      (hasLrap
        ? "<strong>" + X.esc(X.stateName(st)) + " runs a state loan repayment program.</strong> It receives federal grant funding to repay loans for primary care, mental and behavioral health, and dental clinicians serving underserved areas — and it can stack with the federal programs."
        : "<strong>" + X.esc(X.stateName(st)) + " does not appear on the federal grantee list for this program.</strong> It may still run its own state-funded repayment programs, particularly for teachers and health professionals. Search your state’s higher education agency plus “loan repayment.”") +
      '</div>';
    out.innerHTML = html;
  }

  X.bootstrap("loans", mount);
})();

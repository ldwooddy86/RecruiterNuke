/* Clapback — "Debt collectors" module.
 * Works only on collectors who contacted YOU. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM;
  var F = M.FDCPA;
  var mounted = false;
  var log = [];
  var prof = {};

  function mount() {
    var view = X.$("#view-collect");
    if (!view || mounted) { if (mounted) renderLog(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Debt collectors</h1>' +
      '<p class="lede">A collector’s entire business model runs on people not knowing four things: that a written dispute inside the validation window legally stops collection; that there are hard rules about when, where, and how often they may contact you; that you can sue them and make them pay your lawyer; and that the clock to do it is only one year long, running from the violation — not from when you noticed.</p>' +

      '<div class="callout callout-warn" id="cf-withdrawn"></div>' +

      /* ---- who's covered ---- */
      '<h2>First: is this even a “debt collector”?</h2>' +
      '<div class="card">' +
      '<p><strong>Covered.</strong> <span id="sc-cov"></span></p>' +
      '<p><strong>Not covered by the federal law.</strong> <span id="sc-not"></span></p>' +
      '<p class="muted" id="sc-trap"></p>' +
      '<p class="fineprint" id="sc-cite"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Five places where state or local law goes further</h3>' +
      '<p class="muted">In these jurisdictions the rules reach the original creditor too — including a hospital’s own billing office.</p>' +
      '<div id="sc-states"></div>' +
      '<p class="muted" id="sc-gap"></p>' +
      '</div>' +

      /* ---- validation ---- */
      '<h2 id="val-head"></h2>' +
      '<div class="card">' +
      '<p><strong>This is the move.</strong> <span id="val-effect"></span></p>' +
      '<div class="callout callout-info" id="val-honesty"></div>' +
      '<h3 style="margin-top:16px">When does your window actually close?</h3>' +
      '<p class="muted" id="val-window"></p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="v-date">Date the collector sent the notice</label><input class="input" id="v-date" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="v-run">Work out my deadline</button></div>' +
      '</div>' +
      '<div id="v-out"></div>' +
      '<h3 style="margin-top:18px">What the notice must contain</h3>' +
      '<p class="muted">If any of these are missing, say so in your dispute — a defective validation notice is itself a violation.</p>' +
      '<ul class="tidy" id="val-must"></ul>' +
      '<div class="callout callout-info" id="val-item"></div>' +
      '<p class="muted" id="val-noadmit"></p>' +
      X.srcLine("12 CFR 1006.34 and 15 U.S.C. 1692g", "https://www.ecfr.gov/current/title-12/chapter-X/part-1006/subpart-B/section-1006.34") +
      '</div>' +

      /* ---- calls ---- */
      '<h2 id="call-head"></h2>' +
      '<div class="card">' +
      '<p id="call-rule"></p>' +
      '<p class="fineprint" id="call-cite"></p>' +
      '<h3 style="margin-top:14px">The parts nobody tells you</h3>' +
      '<ul class="tidy" id="call-nuance"></ul>' +
      '</div>' +
      '<div class="card">' +
      '<h3>When, where, and how they may contact you</h3>' +
      '<div id="comm-list" class="link-list"></div>' +
      '</div>' +
      '<div class="card">' +
      '<h3>That voicemail may not be legal</h3>' +
      '<p id="vm-body"></p>' +
      '<p class="fineprint" id="vm-cite"></p>' +
      '</div>' +

      /* ---- violation log ---- */
      '<h2>Log what they did</h2>' +
      '<div class="card">' +
      '<p class="muted">Every entry starts a <strong>one-year countdown</strong> from the date of the violation — not from when you noticed it. That is the single most valuable clock this tool runs, because people routinely discover a violation months later and assume they still have time. Stored only on this device; export it from Settings.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="vi-collector">Collector</label><input class="input" id="vi-collector" placeholder="Company name"></div>' +
      '<div class="ev-field"><label class="field" for="vi-date">Date it happened</label><input class="input" id="vi-date" type="date"></div>' +
      '<div class="ev-field-wide"><label class="field" for="vi-kind">What happened</label><select class="input" id="vi-kind"></select></div>' +
      '<div class="ev-field-wide"><label class="field" for="vi-note">What exactly was said or done</label><input class="input" id="vi-note" placeholder="Who called, what was said, who else heard it"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="vi-add">Log it</button></div>' +
      '</div>' +
      '<div id="vi-log"></div>' +
      '</div>' +

      /* ---- suing ---- */
      '<div class="card">' +
      '<h3 id="sue-head"></h3>' +
      '<p id="sue-damages"></p>' +
      '<div class="callout callout-warn" id="sue-cap"></div>' +
      '<p id="sue-sol"></p>' +
      '<p class="muted" id="sue-fees"></p>' +
      '<div class="btn-row">' + X.a("Find a consumer attorney (NACA) ↗", F.suing.naca, "btn btn-sm") + '</div>' +
      '</div>' +

      /* ---- time barred ---- */
      '<h2 id="tb-head"></h2>' +
      '<div class="card danger">' +
      '<p id="tb-rule"></p>' +
      '<p class="muted" id="tb-nodisc"></p>' +
      '<p class="muted" id="tb-withdrawn"></p>' +
      '<div class="callout callout-warn" id="tb-revival"></div>' +
      '<p id="tb-rule2"></p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="court">Check your state’s limitations period →</button></div>' +
      '</div>' +

      /* ---- cease ---- */
      '<div class="card">' +
      '<h3 id="ce-head"></h3>' +
      '<p id="ce-what"></p>' +
      '<h4 style="margin-top:12px">What it does not do</h4>' +
      '<ul class="tidy" id="ce-not"></ul>' +
      '<div class="callout callout-warn" id="ce-risk"></div>' +
      '<p class="muted" id="ce-how"></p>' +
      '</div>' +

      /* ---- fake ---- */
      '<h2 id="fk-head"></h2>' +
      '<div class="card">' +
      '<div class="callout callout-warn" id="fk-bad"></div>' +
      '<div class="callout callout-info" id="fk-good"></div>' +
      '<h4>Red flags</h4><ul class="tidy" id="fk-flags"></ul>' +
      '<h4 style="margin-top:12px">What to do</h4><ol class="tidy" id="fk-steps"></ol>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="vet">Paste the message into Vet a contact →</button>' + X.a("FTC on fake collectors ↗", F.fake.flagsSrc) + '</div>' +
      '</div>' +

      /* ---- medical specifics ---- */
      '<div class="card">' +
      '<h3>Two things people get wrong about HIPAA and collections</h3>' +
      '<p id="hp-body"></p>' +
      '<p class="fineprint" id="hp-cite"></p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="assist">The charity-care angle is the real leverage →</button></div>' +
      '</div>' +

      /* ---- licensing ---- */
      '<h2>Is this collector even licensed?</h2>' +
      '<div class="card">' +
      '<p class="muted" id="lic-why"></p>' +
      '<div id="lic-list" class="link-list"></div>' +
      '<p class="muted" id="lic-gap"></p>' +
      '</div>' +

      /* ---- scams ---- */
      '<h2>Debt relief and credit repair — where the scams live</h2>' +
      '<div class="card danger">' +
      '<h3>The advance-fee rule</h3><p id="sc-settle"></p><p class="fineprint" id="sc-settlecite"></p>' +
      '<h3 style="margin-top:14px">Credit repair — and the remedy nobody uses</h3><p id="sc-croa"></p><p class="fineprint" id="sc-croacite"></p>' +
      '<h4 style="margin-top:12px">Red flags</h4><ul class="tidy" id="sc-flags"></ul>' +
      '<div class="callout callout-info" id="sc-ftcline"></div>' +
      '<div class="btn-row">' + X.a("FTC on credit repair scams ↗", F.scams.repairSrc) + '</div>' +
      '</div>' +

      /* ---- complaints ---- */
      '<h2>Where to complain</h2>' +
      '<div id="lane-list"></div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<div class="card"><div id="collect-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal advice. State law varies substantially and often gives you more than the federal floor. Every rule here links to the statute or regulation it comes from, verified ' + X.esc(M.UPDATED) + '.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    X.$("#cf-withdrawn").innerHTML = "<strong>One thing you won’t find here, and why.</strong> " + X.esc(F.cfpbWithdrawn) +
      ' ' + X.a("The withdrawal list ↗", F.cfpbWithdrawnUrl);

    X.$("#sc-cov").textContent = F.scope.covered;
    X.$("#sc-not").textContent = F.scope.notCovered;
    X.$("#sc-trap").textContent = F.scope.trap;
    X.$("#sc-cite").textContent = "Cite: " + F.scope.cite;

    var ss = X.$("#sc-states"); ss.innerHTML = "";
    F.stateCreditors.forEach(function (s) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", s.n));
      head.appendChild(X.el("span", "status-pill pill-ban", s.s));
      card.appendChild(head);
      card.appendChild(X.el("p", null, s.t));
      ss.appendChild(card);
    });
    X.$("#sc-gap").textContent = F.stateCreditorsGap;

    /* validation */
    X.$("#val-head").textContent = F.validation.head;
    X.$("#val-effect").textContent = F.validation.effect;
    X.$("#val-honesty").innerHTML = "<strong>Be realistic about what comes back.</strong> " + X.esc(F.validation.honesty);
    X.$("#val-window").textContent = F.validation.window;
    var vm = X.$("#val-must"); vm.innerHTML = "";
    F.validation.must.forEach(function (s) { vm.appendChild(X.el("li", null, s)); });
    X.$("#val-item").innerHTML = "<strong>A detail worth using.</strong> " + X.esc(F.validation.itemization);
    X.$("#val-noadmit").textContent = F.validation.noAdmission;

    /* calls */
    X.$("#call-head").textContent = F.calls.head;
    X.$("#call-rule").textContent = F.calls.rule;
    X.$("#call-cite").textContent = "Cite: " + F.calls.cite;
    var cn = X.$("#call-nuance"); cn.innerHTML = "";
    F.calls.nuance.forEach(function (s) { cn.appendChild(X.el("li", null, s)); });

    var cl = X.$("#comm-list"); cl.innerHTML = "";
    F.comms.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.k));
      l.appendChild(X.el("div", "li-note", c.t + "  — " + c.cite));
      row.appendChild(l);
      cl.appendChild(row);
    });
    X.$("#vm-body").textContent = F.voicemail;
    X.$("#vm-cite").textContent = "Cite: " + F.voicemailCite;

    /* suing */
    X.$("#sue-head").textContent = F.suing.head;
    X.$("#sue-damages").textContent = F.suing.damages;
    X.$("#sue-cap").innerHTML = "<strong>Read that carefully.</strong> " + X.esc(F.suing.cap);
    X.$("#sue-sol").innerHTML = "<strong>" + X.esc(F.suing.sol) + "</strong>";
    X.$("#sue-fees").textContent = F.suing.fees;

    /* time barred */
    X.$("#tb-head").textContent = F.timeBarred.head;
    X.$("#tb-rule").innerHTML = "<strong>" + X.esc(F.timeBarred.rule) + "</strong> <span class='muted'>(" + X.esc(F.timeBarred.cite) + ")</span>";
    X.$("#tb-nodisc").textContent = F.timeBarred.noDisclosure;
    X.$("#tb-withdrawn").textContent = F.timeBarred.withdrawn;
    X.$("#tb-revival").innerHTML = "<strong>The trap.</strong> " + X.esc(F.timeBarred.revival);
    X.$("#tb-rule2").innerHTML = "<strong>" + X.esc(F.timeBarred.rule2) + "</strong>";

    /* cease */
    X.$("#ce-head").textContent = F.cease.head;
    X.$("#ce-what").innerHTML = X.esc(F.cease.what) + " <span class='muted'>(" + X.esc(F.cease.cite) + ")</span>";
    var cnn = X.$("#ce-not"); cnn.innerHTML = "";
    F.cease.notDo.forEach(function (s) { cnn.appendChild(X.el("li", null, s)); });
    X.$("#ce-risk").innerHTML = "<strong>Think before you send it.</strong> " + X.esc(F.cease.risk);
    X.$("#ce-how").textContent = F.cease.how;

    /* fake */
    X.$("#fk-head").textContent = F.fake.head;
    X.$("#fk-bad").innerHTML = "<strong>The test everyone uses, and why it’s wrong.</strong> " + X.esc(F.fake.badTest);
    X.$("#fk-good").innerHTML = "<strong>The test that works.</strong> " + X.esc(F.fake.goodTest);
    var ff = X.$("#fk-flags"); ff.innerHTML = "";
    F.fake.flags.forEach(function (s) { ff.appendChild(X.el("li", null, s)); });
    var fs = X.$("#fk-steps"); fs.innerHTML = "";
    F.fake.steps.forEach(function (s) { fs.appendChild(X.el("li", null, s)); });

    /* hipaa */
    X.$("#hp-body").textContent = F.hipaaMyth;
    X.$("#hp-cite").textContent = "Cite: " + F.hipaaCite;

    /* licensing */
    X.$("#lic-why").textContent = F.licensingWhy;
    var ll = X.$("#lic-list"); ll.innerHTML = "";
    F.licensing.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", s.n));
      l.appendChild(X.el("div", "li-note", s.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Look it up ↗", s.u);
      row.appendChild(w);
      ll.appendChild(row);
    });
    X.$("#lic-gap").textContent = F.licensingGap;

    /* scams */
    X.$("#sc-settle").textContent = F.scams.settlement;
    X.$("#sc-settlecite").textContent = "Cite: " + F.scams.settlementCite;
    X.$("#sc-croa").textContent = F.scams.croa;
    X.$("#sc-croacite").textContent = "Cite: " + F.scams.croaCite;
    var sf = X.$("#sc-flags"); sf.innerHTML = "";
    F.scams.repairFlags.forEach(function (s) { sf.appendChild(X.el("li", null, s)); });
    X.$("#sc-ftcline").innerHTML = "<strong>Worth remembering.</strong> " + X.esc(F.scams.ftcLine);

    /* lanes */
    var lanes = X.$("#lane-list"); lanes.innerHTML = "";
    M.COMPLAINT_LANES.forEach(function (l) {
      var card = X.el("div", "law-card");
      card.appendChild(X.el("div", "law-name", l.n));
      card.appendChild(X.el("p", null, l.t));
      if (l.caveat) {
        var c = X.el("div", "callout callout-warn");
        c.style.margin = "10px 0 0";
        c.textContent = l.caveat;
        card.appendChild(c);
      }
      var b = X.el("div", "btn-row"); b.innerHTML = X.a("Open ↗", l.u, "btn btn-sm");
      card.appendChild(b);
      lanes.appendChild(card);
    });

    /* violation select */
    var sel = X.$("#vi-kind"); sel.innerHTML = "";
    F.violations.forEach(function (v) {
      var o = document.createElement("option");
      o.value = v.id; o.textContent = v.n;
      sel.appendChild(o);
    });

    X.letterCards(X.$("#collect-letters"), "collect", function () {
      var last = log.length ? log[log.length - 1] : {};
      return { to: last.collector ? last.collector + "\n[address]" : "" };
    });

    /* validation calculator */
    X.$("#v-run").addEventListener("click", function () {
      var d = X.parseDate(X.$("#v-date").value);
      var out = X.$("#v-out"); out.innerHTML = "";
      if (!d) { out.innerHTML = '<div class="callout callout-warn">Enter the date on the notice.</div>'; return; }
      var receipt = X.addBusinessDays(d, 5);
      var due = X.addDays(receipt, 30);
      var u = X.urgency(X.iso(due));
      out.innerHTML =
        '<div class="callout ' + (u.cls === "sev-high" ? "callout-warn" : "callout-info") + '">' +
        '<strong>Your window closes about ' + X.esc(X.fmt(due)) + '</strong> — ' + X.esc(u.label) + '.<br>' +
        '<span class="muted">Worked out as 5 business days from the send date (the presumed-receipt rule) plus 30 days. Clapback does not model federal holidays, so treat this as the <em>earliest</em> your window closes and send well before it.</span>' +
        '</div>' +
        '<div class="btn-row"><button class="btn btn-sm" id="v-track">Add to my tracker</button></div>' +
        '<p class="muted">Send your written dispute by certified mail with return receipt. The legal effect depends on being able to prove they received it.</p>';
      X.$("#v-track").addEventListener("click", function () {
        X.addDeadline({ kind: "validation", label: "Send a written debt validation dispute (stops collection)", due: X.iso(due), note: "Certified mail, return receipt. This is the only step that legally pauses collection." });
      });
    });

    X.$("#vi-add").addEventListener("click", addViolation);
  }

  function load() {
    X.get(["medViolations"]).then(function (d) {
      log = Array.isArray(d.medViolations) ? d.medViolations : [];
      return X.profile();
    }).then(function (p) { prof = p; renderLog(); });
  }

  function addViolation() {
    var v = {
      collector: X.$("#vi-collector").value.trim(),
      date: X.$("#vi-date").value,
      kind: X.$("#vi-kind").value,
      note: X.$("#vi-note").value.trim(),
      at: Date.now()
    };
    if (!v.date) { X.toast("Add the date it happened"); return; }
    log.push(v);
    X.set({ medViolations: log }).then(function () {
      X.$("#vi-note").value = "";
      X.toast("Logged — one-year clock started");
      renderLog();
    });
  }

  function renderLog() {
    var host = X.$("#vi-log"); if (!host) return;
    host.innerHTML = "";
    if (!log.length) { host.innerHTML = '<p class="muted">Nothing logged yet.</p>'; return; }

    var head = X.el("div", "ev-log-head");
    head.appendChild(X.el("strong", null, log.length + " logged"));
    var exp = X.el("button", "btn btn-ghost btn-sm", "Export as CSV");
    exp.addEventListener("click", exportCsv);
    head.appendChild(exp);
    host.appendChild(head);

    log.slice().reverse().forEach(function (v, ri) {
      var i = log.length - 1 - ri;
      var def = F.violations.filter(function (x) { return x.id === v.kind; })[0] || { n: v.kind, cite: "" };
      var d = X.parseDate(v.date);
      var expiry = d ? X.addDays(d, 365) : null;
      var u = expiry ? X.urgency(X.iso(expiry)) : { cls: "sev-info", label: "" };

      var box = X.el("div", "ev-entry");
      var eh = X.el("div", "ev-entry-head");
      eh.appendChild(X.el("strong", null, def.n));
      var del = X.el("button", "ev-del", "Remove");
      del.addEventListener("click", function () {
        log.splice(i, 1);
        X.set({ medViolations: log }).then(renderLog);
      });
      eh.appendChild(del);
      box.appendChild(eh);

      if (v.collector) box.appendChild(X.el("div", "ev-line", v.collector));
      if (v.note) box.appendChild(X.el("div", "ev-line", v.note));
      if (def.cite) box.appendChild(X.el("div", "ev-when", "Possible violation of " + def.cite));
      if (d) {
        var when = X.el("div", "ev-when", "Happened " + X.fmtShort(d) + "  ·  one-year deadline to sue: " + X.fmtShort(expiry) + " (" + u.label + ")");
        box.appendChild(when);
        var track = X.el("button", "btn btn-ghost btn-sm", "Track that deadline");
        track.addEventListener("click", function () {
          X.addDeadline({ kind: "fdcpa", label: "FDCPA one-year deadline to sue — " + (v.collector || "collector"), due: X.iso(expiry), note: def.n + ". Find a consumer attorney at consumeradvocates.org." });
        });
        box.appendChild(track);
      }
      host.appendChild(box);
    });
  }

  function exportCsv() {
    var rows = [["date", "collector", "violation", "citation", "note", "one_year_deadline"]];
    log.forEach(function (v) {
      var def = F.violations.filter(function (x) { return x.id === v.kind; })[0] || { n: v.kind, cite: "" };
      var d = X.parseDate(v.date);
      rows.push([v.date || "", v.collector || "", def.n, def.cite, v.note || "", d ? X.iso(X.addDays(d, 365)) : ""]);
    });
    var csv = rows.map(function (r) {
      return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(",");
    }).join("\n");
    var blob = new Blob([csv], { type: "text/csv" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = "clapback-collector-violations.csv";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    X.toast("Exported — attach it to a complaint");
  }

  X.bootstrap("collect", mount);
})();

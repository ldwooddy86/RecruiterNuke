/* Clapback — "Sued? Court kit" module.
 * Defensive only: this is for a lawsuit filed against YOU. No network requests.
 * General information, not legal advice.
 */
(function () {
  "use strict";
  var X = window.CBX, C = window.CBC, M = window.CBM;
  var mounted = false;
  var prof = {};
  var picked = "";
  var chosenDefenses = {};

  function mount() {
    var view = X.$("#view-court");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Sued? The court kit</h1>' +

      '<div class="callout callout-warn">' +
      '<strong>Read this before anything else on the page.</strong> ' + X.esc(C.SUMMONS_RULE) +
      '</div>' +

      '<p class="lede">Most consumer debt lawsuits end in a default judgment — the defendant simply never responds. Pew’s study of state courts found more than 70% nationally, and roughly 80% in some jurisdictions. That is the whole game. Responding does not admit the debt; as the federal regulator puts it, responding “simply preserves your right to dispute it.” Almost everything below only works if you file something on time.</p>' +

      '<div class="callout callout-info">' +
      '<strong>What a default judgment turns into.</strong> Wage garnishment, a frozen bank account, liens on your property, post-judgment interest, and a public record that can be renewed for years. Undoing one is far harder than answering in the first place — and every state puts a deadline on trying.' +
      '</div>' +

      /* ---- deadline ---- */
      '<h2>Step one: your deadline</h2>' +
      '<div class="card">' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="ct-state">State where you were sued</label><span id="ct-state-host"></span></div>' +
      '<div class="ev-field"><label class="field" for="ct-served">Date you were served</label><input class="input" id="ct-served" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="ct-run">Show what I know</button></div>' +
      '</div>' +
      '<div id="ct-deadline"></div>' +
      '</div>' +

      /* ---- SOL ---- */
      '<h2>Is it too old to sue on?</h2>' +
      '<div class="card">' +
      '<p class="muted" id="sol-frame"></p>' +
      '<div class="callout callout-warn" id="sol-affirm"></div>' +
      '<div id="sol-out"></div>' +
      '<p class="muted" id="sol-illegal"></p>' +
      '</div>' +
      '<div class="card danger">' +
      '<h3>The most dangerous trap in this entire tool</h3>' +
      '<p id="rev-danger"></p>' +
      '<div class="callout callout-warn" id="rev-rule"></div>' +
      '<div id="rev-verified"></div>' +
      '<p class="muted" id="rev-gap"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Borrowing statutes — when they sue you in the wrong state</h3>' +
      '<div id="borrow-list" class="link-list"></div>' +
      '<p class="fineprint" id="borrow-note"></p>' +
      '</div>' +

      /* ---- defense builder ---- */
      '<h2>Build your defenses</h2>' +
      '<div class="card">' +
      '<p class="muted" id="def-rule"></p>' +
      '<p class="muted">Tick everything that might apply. Clapback lists what evidence each one needs, and drops the ones you pick into the Answer template at the bottom of the page.</p>' +
      '<div class="chips" style="margin-bottom:12px">' +
      '<button class="chip active" data-dfilter="all">All defenses</button>' +
      '<button class="chip" data-dfilter="med">Medical-debt specific</button>' +
      '</div>' +
      '<div id="def-list"></div>' +
      '<div id="def-summary"></div>' +
      '</div>' +

      /* ---- what they must prove ---- */
      '<h2>What they actually have to prove</h2>' +
      '<div class="card">' +
      '<ol class="tidy" id="prove-el"></ol>' +
      '<div class="callout callout-info" id="prove-ftc"></div>' +
      '<p class="muted" id="prove-robo"></p>' +
      '<div class="btn-row">' + X.a("FTC debt buying study ↗", C.PROVE.ftc2013Url) + X.a("CFPB enforcement action ↗", C.PROVE.roboUrl) + '</div>' +
      '</div>' +
      '<div class="card">' +
      '<h3>States that make debt buyers show their work</h3>' +
      '<p class="muted">If you were sued in one of these, check the complaint against the requirement — a missing attachment can end the case.</p>' +
      '<div id="plead-list"></div>' +
      '<p class="muted" id="plead-gap"></p>' +
      '</div>' +

      /* ---- discovery ---- */
      '<h2>Discovery — and the one move that can end it</h2>' +
      '<div class="card">' +
      '<div id="disc-tools" class="link-list"></div>' +
      '<p class="fineprint" id="disc-note"></p>' +
      '<div class="callout callout-info" id="disc-rfa"></div>' +
      '<p class="muted" id="disc-small"></p>' +
      '<p class="muted" id="disc-ca98"></p>' +
      '</div>' +

      /* ---- filing ---- */
      '<h2>Filing it</h2>' +
      '<div class="card"><div id="file-list" class="link-list"></div></div>' +

      /* ---- settle ---- */
      '<h2>If you settle</h2>' +
      '<div class="card"><div id="settle-list" class="link-list"></div></div>' +

      /* ---- vacate ---- */
      '<h2>If a judgment already exists</h2>' +
      '<div class="card danger">' +
      '<p><strong>' + X.esc(C.VACATE.move) + '</strong></p>' +
      '<div class="callout callout-info" id="vac-strategic"></div>' +
      '<div id="vac-rules"></div>' +
      '<p class="muted" id="vac-gap"></p>' +
      '</div>' +

      /* ---- exemptions ---- */
      '<h2>What they can and cannot take</h2>' +
      '<div class="card">' +
      '<h3>Wages</h3>' +
      '<p id="ex-formula"></p>' +
      '<p class="fineprint" id="ex-wagecite"></p>' +
      '<p class="muted" id="ex-wagenote"></p>' +
      '<h4 style="margin-top:14px">States that bar or heavily restrict garnishment for consumer debt</h4>' +
      '<div id="ex-states" class="link-list"></div>' +
      '<p class="muted" id="ex-statesnote"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3 id="ben-head"></h3>' +
      '<p id="ben-body"></p>' +
      '<div class="callout callout-warn" id="ben-trap"></div>' +
      '<p class="muted" id="ex-ny"></p>' +
      '</div>' +
      '<div class="card">' +
      '<h3>“Judgment proof” — what it really means</h3>' +
      '<p id="ex-jp"></p>' +
      '<h4 style="margin-top:12px">Your home</h4>' +
      '<p class="muted" id="ex-home"></p>' +
      '</div>' +

      /* ---- help ---- */
      '<h2>Free help — use it, today</h2>' +
      '<div class="card"><div id="help-nat" class="link-list"></div></div>' +
      '<div class="card"><h3>Your state’s self-help program</h3><div id="help-state"></div><p class="muted" id="help-note"></p></div>' +

      /* ---- letters ---- */
      '<h2>Templates</h2>' +
      '<div class="callout callout-warn">These are structural skeletons to work from, not filings. Many states publish their own fillable answer form — if yours does, use it. What matters most is filing something on time.</div>' +
      '<div class="card"><div id="court-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">This is general legal information, not legal advice, and no attorney-client relationship is created by reading it. Court rules vary by state and often by county. The summons controls. Where Clapback could not verify a state’s rule from a primary source it says so rather than guessing — and in those places, call the clerk of the court named on your summons. Verified ' + X.esc(C.UPDATED) + '.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    X.$("#sol-frame").textContent = C.SOL_FRAME;
    X.$("#sol-affirm").innerHTML = "<strong>Raise it or lose it.</strong> " + X.esc(C.SOL_AFFIRM);
    X.$("#sol-illegal").textContent = C.SOL_ILLEGAL;

    X.$("#rev-danger").textContent = C.REVIVAL.danger;
    X.$("#rev-rule").innerHTML = "<strong>The rule to follow.</strong> " + X.esc(C.REVIVAL.rule);
    var rv = X.$("#rev-verified"); rv.innerHTML = "";
    C.REVIVAL.verified.forEach(function (r) {
      var card = X.el("div", "law-card");
      card.appendChild(X.el("div", "law-name", r.head));
      card.appendChild(X.el("p", null, r.t));
      card.appendChild(X.el("div", "law-eff", r.c));
      rv.appendChild(card);
    });
    X.$("#rev-gap").textContent = C.REVIVAL.gap;

    var bl = X.$("#borrow-list"); bl.innerHTML = "";
    C.BORROWING.forEach(function (b) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", X.stateName(b.s)));
      l.appendChild(X.el("div", "li-note", b.t + "  — " + b.c));
      row.appendChild(l);
      bl.appendChild(row);
    });
    X.$("#borrow-note").textContent = C.BORROWING_NOTE;

    X.$("#def-rule").textContent = C.DEFENSE_RULE;
    renderDefenses("all");
    X.$$(".chip[data-dfilter]").forEach(function (c) {
      c.addEventListener("click", function () {
        X.$$(".chip[data-dfilter]").forEach(function (x) { x.classList.toggle("active", x === c); });
        renderDefenses(c.dataset.dfilter);
      });
    });

    var pe = X.$("#prove-el"); pe.innerHTML = "";
    C.PROVE.elements.forEach(function (s) { pe.appendChild(X.el("li", null, s)); });
    X.$("#prove-ftc").innerHTML = "<strong>Why the standing defense works so often.</strong> " + X.esc(C.PROVE.ftc2013);
    X.$("#prove-robo").textContent = C.PROVE.robo;

    var pl = X.$("#plead-list"); pl.innerHTML = "";
    C.PROVE.pleading.forEach(function (p) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", X.stateName(p.s)));
      head.appendChild(X.el("span", "status-pill pill-ban", p.c));
      card.appendChild(head);
      card.appendChild(X.el("p", null, p.t));
      pl.appendChild(card);
    });
    X.$("#plead-gap").textContent = C.PROVE.pleadingGap;

    var dt = X.$("#disc-tools"); dt.innerHTML = "";
    C.DISCOVERY.tools.forEach(function (t) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", t.n));
      l.appendChild(X.el("div", "li-note", "Limit: " + t.lim + ". Deadline to respond: " + t.dl + ". " + t.c));
      row.appendChild(l);
      dt.appendChild(row);
    });
    X.$("#disc-note").textContent = C.DISCOVERY.note;
    X.$("#disc-rfa").innerHTML = "<strong>" + X.esc(C.DISCOVERY.rfa.head) + "</strong> " + X.esc(C.DISCOVERY.rfa.rule) +
      " " + X.esc(C.DISCOVERY.rfa.why) + " <span class='muted'>(" + X.esc(C.DISCOVERY.rfa.c) + ")</span>";
    X.$("#disc-small").textContent = C.DISCOVERY.smallclaims;
    X.$("#disc-ca98").textContent = C.DISCOVERY.ca98;

    var fl = X.$("#file-list"); fl.innerHTML = "";
    C.FILING.forEach(function (f) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", f.h));
      l.appendChild(X.el("div", "li-note", f.t));
      row.appendChild(l);
      fl.appendChild(row);
    });

    var sl = X.$("#settle-list"); sl.innerHTML = "";
    C.SETTLE.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", s.h));
      l.appendChild(X.el("div", "li-note", s.t));
      row.appendChild(l);
      sl.appendChild(row);
    });

    X.$("#vac-strategic").innerHTML = "<strong>The strongest ground on an old default.</strong> " + X.esc(C.VACATE.strategic);
    var vr = X.$("#vac-rules"); vr.innerHTML = "";
    C.VACATE.rules.forEach(function (r) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", r.j));
      head.appendChild(X.el("span", "status-pill pill-amber", r.c));
      card.appendChild(head);
      card.appendChild(X.el("p", null, "Grounds: " + r.g));
      card.appendChild(X.el("p", null, "Time limit: " + r.t));
      vr.appendChild(card);
    });
    X.$("#vac-gap").textContent = C.VACATE.gap;

    X.$("#ex-formula").innerHTML = "<strong>" + X.esc(C.EXEMPT.wageFormula) + "</strong>";
    X.$("#ex-wagecite").textContent = "Cite: " + C.EXEMPT.wageCite;
    X.$("#ex-wagenote").textContent = C.EXEMPT.wageNote;
    var es = X.$("#ex-states"); es.innerHTML = "";
    C.EXEMPT.states.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", X.stateName(s.s)));
      l.appendChild(X.el("div", "li-note", s.t + "  — " + s.c));
      row.appendChild(l);
      es.appendChild(row);
    });
    X.$("#ex-statesnote").textContent = C.EXEMPT.statesNote;

    X.$("#ben-head").textContent = C.EXEMPT.benefits.head;
    X.$("#ben-body").innerHTML = X.esc(C.EXEMPT.benefits.body) + " <span class='muted'>(" + X.esc(C.EXEMPT.benefits.cite) + ")</span>";
    X.$("#ben-trap").innerHTML = "<strong>The trap.</strong> " + X.esc(C.EXEMPT.benefits.trap) +
      " " + X.a("CFPB on this ↗", C.EXEMPT.benefits.trapUrl);
    X.$("#ex-ny").textContent = C.EXEMPT.nyEipa;
    X.$("#ex-jp").textContent = C.EXEMPT.judgmentProof;
    X.$("#ex-home").textContent = C.EXEMPT.homestead;

    var hn = X.$("#help-nat"); hn.innerHTML = "";
    C.HELP_NATIONAL.forEach(function (h) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", h.n));
      l.appendChild(X.el("div", "li-note", h.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Open ↗", h.u, "btn btn-sm");
      row.appendChild(w);
      hn.appendChild(row);
    });
    X.$("#help-note").textContent = C.HELP_STATE_NOTE;

    X.letterCards(X.$("#court-letters"), "court", function () { return {}; });

    X.$("#ct-run").addEventListener("click", runDeadline);
  }

  function renderDefenses(filter) {
    var host = X.$("#def-list"); host.innerHTML = "";
    var list = C.DEFENSES.filter(function (d) { return filter === "all" || d.med; });
    list.forEach(function (d) {
      var row = X.el("div", "broker");
      var chk = X.el("input", "broker-check");
      chk.type = "checkbox";
      chk.id = "def-" + d.id;
      chk.checked = !!chosenDefenses[d.id];
      chk.addEventListener("change", function () {
        if (chk.checked) chosenDefenses[d.id] = true; else delete chosenDefenses[d.id];
        renderDefSummary();
      });
      row.appendChild(chk);
      var body = X.el("div", "broker-body");
      var nm = X.el("label", "broker-name", d.n + (d.med ? "  ·  medical" : ""));
      nm.setAttribute("for", "def-" + d.id);
      body.appendChild(nm);
      body.appendChild(X.el("div", "broker-note", "When it applies: " + d.when));
      body.appendChild(X.el("div", "broker-note", "What you need: " + d.need));
      if (d.note) body.appendChild(X.el("div", "broker-note", d.note));
      row.appendChild(body);
      host.appendChild(row);
    });
    renderDefSummary();
  }

  function renderDefSummary() {
    var host = X.$("#def-summary"); if (!host) return;
    var picked = Object.keys(chosenDefenses);
    if (!picked.length) { host.innerHTML = ""; return; }
    var names = C.DEFENSES.filter(function (d) { return chosenDefenses[d.id]; });
    var evidence = names.map(function (d) { return "<li><strong>" + X.esc(d.n) + "</strong> — " + X.esc(d.need) + "</li>"; }).join("");
    host.innerHTML =
      '<div class="callout callout-info" style="margin-top:14px">' +
      '<strong>' + picked.length + ' defense' + (picked.length === 1 ? "" : "s") + ' selected. Here is the evidence list to gather:</strong>' +
      '<ul class="tidy">' + evidence + '</ul>' +
      '<div class="btn-row"><button class="btn btn-sm" id="def-copy">Copy this checklist</button></div>' +
      '</div>';
    X.$("#def-copy").addEventListener("click", function () {
      var t = "DEFENSES TO PLEAD AND EVIDENCE TO GATHER\n\n" + names.map(function (d, i) {
        return (i + 1) + ". " + d.n + "\n   When it applies: " + d.when + "\n   Evidence needed: " + d.need + (d.note ? "\n   Note: " + d.note : "") + "\n";
      }).join("\n") + "\nReminder: affirmative defenses generally must be pled in your Answer or they are waived.";
      X.copy(t);
    });
  }

  function load() {
    X.profile().then(function (p) {
      prof = p;
      picked = p.state || "";
      var host = X.$("#ct-state-host");
      if (host) {
        host.innerHTML = X.stateSelect("ct-state", picked, "Select a state…");
        X.$("#ct-state").addEventListener("change", function () { picked = X.$("#ct-state").value; renderSol(); renderHelpState(); });
      }
      renderSol();
      renderHelpState();
    });
  }

  /* Re-entering the tab re-reads the profile, so a state saved after this
     module first mounted still lands here. An explicit pick on this tab wins. */
  function refresh() {
    X.profile().then(function (p) {
      prof = p;
      var sel = X.$("#ct-state");
      if (sel && !sel.value && p.state) { sel.value = p.state; picked = p.state; }
      renderSol();
      renderHelpState();
    });
  }

  function runDeadline() {
    var st = X.$("#ct-state").value;
    var served = X.parseDate(X.$("#ct-served").value);
    var out = X.$("#ct-deadline");
    picked = st;
    renderSol();
    renderHelpState();
    if (!st) { out.innerHTML = '<div class="callout callout-warn">Pick the state where you were sued.</div>'; return; }
    var a = C.ANSWER[st];
    if (!a) { out.innerHTML = ""; return; }

    var html = "";
    if (a.v) {
      html += '<div class="risk-banner risk-caution"><div class="risk-ic">⏱</div><div>' +
        '<div class="risk-label">' + X.esc(X.stateName(st)) + '</div>' +
        '<div class="risk-sub">' + X.esc(a.d) + (a.r ? '<br><span class="muted">' + X.esc(a.r) + '</span>' : "") + '</div>' +
        '</div></div>';
      if (a.u) html += '<div class="btn-row">' + X.a("Primary source ↗", a.u) + '</div>';
    } else {
      html += '<div class="risk-banner risk-high"><div class="risk-ic">?</div><div>' +
        '<div class="risk-label">' + X.esc(X.stateName(st)) + ' — Clapback will not guess this one.</div>' +
        '<div class="risk-sub">' + X.esc(a.d) + '<br><br>' + X.esc(C.ANSWER_UNVERIFIED_NOTE) + '</div>' +
        '</div></div>';
      if (a.u) html += '<div class="btn-row">' + X.a("Where to look ↗", a.u) + '</div>';
    }

    if (served) {
      html += '<div class="callout callout-info" style="margin-top:12px">' +
        '<strong>You were served ' + X.esc(X.fmt(served)) + '.</strong> ';
      if (a.v) {
        html += 'Count forward from that date using the rule above — and then check the number printed on your summons, which controls. ';
      } else {
        html += 'Read the deadline off your summons and count forward from this date. ';
      }
      html += 'Set the deadline in the tracker below so it cannot slip.</div>' +
        '<div class="ev-form"><div class="ev-field"><label class="field" for="ct-due">My answer is due</label><input class="input" id="ct-due" type="date"></div>' +
        '<div class="ev-field-wide"><button class="btn" id="ct-track">Track this deadline</button></div></div>';
    }
    out.innerHTML = html;

    var t = X.$("#ct-track");
    if (t) t.addEventListener("click", function () {
      var due = X.$("#ct-due").value;
      if (!due) { X.toast("Enter the date from your summons"); return; }
      X.addDeadline({ kind: "answer", label: "FILE YOUR ANSWER — debt lawsuit in " + X.stateName(st), due: due, note: "A default judgment follows if you miss this. Filing a bare-bones answer on time beats a perfect one filed late." });
    });
  }

  function renderSol() {
    var out = X.$("#sol-out"); if (!out) return;
    if (!picked) { out.innerHTML = '<p class="muted">Pick your state above.</p>'; return; }
    var s = C.SOL[picked];
    if (!s) { out.innerHTML = ""; return; }
    if (!s.v) {
      out.innerHTML = '<div class="risk-banner risk-high"><div class="risk-ic">?</div><div>' +
        '<div class="risk-label">' + X.esc(X.stateName(picked)) + ' — not verified, so no number.</div>' +
        '<div class="risk-sub">' + X.esc(C.SOL_UNVERIFIED_NOTE) + '</div>' +
        '</div></div>';
      return;
    }
    out.innerHTML =
      '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(X.stateName(picked)) + '</div>' +
      '<span class="status-pill pill-ban">Verified</span></div>' +
      '<div class="law-eff">' + X.esc(s.c) + '</div>' +
      '<p><strong>Written contract:</strong> ' + X.esc(s.w) + '</p>' +
      '<p><strong>Open account / oral:</strong> ' + X.esc(s.o) + '</p>' +
      (s.n ? '<div class="callout callout-info">' + X.esc(s.n) + '</div>' : "") +
      '</div>';
  }

  function renderHelpState() {
    var out = X.$("#help-state"); if (!out) return;
    if (!picked) { out.innerHTML = '<p class="muted">Pick your state above.</p>'; return; }
    var h = C.HELP_STATE[picked];
    if (!h) {
      out.innerHTML = '<p class="muted">Clapback has no verified self-help program for ' + X.esc(X.stateName(picked)) +
        '. Start with the Legal Services Corporation finder and LawHelp.org above — both cover every state — and call the clerk of the court named on your summons to ask whether the courthouse has a self-help desk. Many do.</p>';
      return;
    }
    out.innerHTML =
      '<div class="law-card"><div class="law-name">' + X.esc(h.n) + '</div>' +
      '<p>' + X.esc(h.t) + '</p>' +
      (h.warn ? '<div class="callout callout-warn">' + X.esc(h.warn) + '</div>' : "") +
      '<div class="btn-row">' + X.a("Open it ↗", h.u, "btn btn-sm") + '</div></div>';
  }

  X.bootstrap("court", mount);
})();

/*
 * Clapback — being sued: court defense dataset  (window.CBC)
 *
 * THE RULE THAT GOVERNS THIS FILE:
 *   A wrong deadline here is a default judgment. So every jurisdiction carries
 *   a verified flag. Where a primary source could not be reached, the entry
 *   says so and the UI prints the honest gap instead of a number. There is no
 *   guessing anywhere in this file.
 *
 *   And above all of it: THE SUMMONS CONTROLS. Every summons states the
 *   deadline to respond, and that printed period is the authoritative answer
 *   for that case — not this chart, not any chart. If they disagree, follow
 *   the summons and call the clerk of the court named on it.
 *
 * Not legal advice. General information only. Verified August 22, 2026.
 */
window.CBC = (function () {
  "use strict";

  var UPDATED = "August 22, 2026";

  var SUMMONS_RULE = "Your summons states your deadline. That printed date is the authoritative answer for your case — not this chart. If they disagree, follow the summons and call the clerk of the court named on it. And never let a deadline pass while you research: a bare-bones Answer filed on time beats a perfect Answer filed late.";

  /* ================================================================== */
  /* ANSWER DEADLINES — all 51 jurisdictions                             */
  /* d: the deadline text. v: verified against a primary source.        */
  /* ================================================================== */
  var ANSWER = {
    AL: { v: true, d: "30 days in Circuit Court — but 14 days in District Court, where most smaller consumer debt cases are heard.", r: "Ala. R. Civ. P. 12(a)", u: "https://judicial.alabama.gov/docs/library/rules/cv12.pdf" },
    AK: { v: true, d: "20 days after the day you receive the summons — 40 days if the defendant is the State or if you were served outside the United States.", r: "Summons form CIV-100 (Civil Rules 4, 5, 12, 42(c), 55)", u: "https://public.courts.alaska.gov/web/forms/docs/civ-100.pdf" },
    AZ: { v: true, d: "20 days if you were served in Arizona, 30 days if served outside it — Superior Court. Justice court, where most debt cases are actually filed, could not be verified.", r: "Ariz. R. Civ. P. 4 (per the summons form)", u: "https://superiorcourt.maricopa.gov/media/2knoyb42/cvc2z.pdf" },
    AR: { v: true, d: "30 days, not counting the day you received it. 60 days if you are incarcerated in an Arkansas facility.", r: "Ark. R. Civ. P. 12", u: "https://www.arcourts.gov/circuit/sites/default/files/Summons_Proof_of_Service.pdf" },
    CA: { v: true, d: "30 days after the summons is served.", r: "Cal. Code Civ. Proc. § 412.20(a)(3)", u: "https://selfhelp.courts.ca.gov/debt-lawsuits/respond" },
    CO: { v: true, d: "21 days if served in Colorado, 35 days if served outside it — District Court. County Court could not be verified.", r: "C.R.C.P. 4 (per form JDF 600)", u: "https://www.coloradojudicial.gov/sites/default/files/2023-07/JDF600.pdf" },
    CT: { v: false, d: "Connecticut runs on a “return day” system rather than a days-after-service clock, which makes it genuinely different from most states. The specific day counts could not be verified from a primary source.", r: "Conn. Practice Book § 10-8 and §§ 10-46 to 10-58 govern", u: "https://www.jud.ct.gov/lawlib/Law/answer.htm" },
    DE: { v: true, d: "15 days in Justice of the Peace Court, counted from the date you received it, not counting that day. Superior Court could not be verified.", r: "10 Del. C. §§ 9522, 9523", u: "https://delcode.delaware.gov/title10/c095/sc02/" },
    DC: { v: true, d: "21 days after being served with the summons and complaint.", r: "D.C. Super. Ct. Civ. R. 12(a)(1)", u: "https://www.dccourts.gov/sites/default/files/rules-superior-court/Civil-Rule-12-Defenses-and-Objections.pdf" },
    FL: { v: true, d: "20 days after service of original process and the initial pleading.", r: "Fla. R. Civ. P. 1.140(a)(1) — verified against the rules as published April 1, 2026 by The Florida Bar, which hosts the current consolidated text", u: "https://www-media.floridabar.org/uploads/2026/04/Civil-Procedure-Rules-04-01-26.pdf" },
    GA: { v: true, d: "30 days after service of the summons and complaint.", r: "O.C.G.A. § 9-11-12(a)", u: "https://law.justia.com/codes/georgia/title-9/chapter-11/article-3/section-9-11-12/" },
    HI: { v: true, d: "20 days in Circuit Court. District Court is unusual: you appear or answer on the SECOND MONDAY following service (extended if that's a holiday).", r: "HRCP 12(a); DCRCP 12(a)", u: "https://www.courts.state.hi.us/wp-content/uploads/2024/09/dcrcp_ada.htm" },
    ID: { v: true, d: "21 days after being served with the summons and complaint.", r: "I.R.C.P. 12(a)(1)", u: "https://isc.idaho.gov/ircp12-new" },
    IL: { v: true, d: "30 days after service. Small claims are governed separately by Rule 286.", r: "Ill. S. Ct. R. 181(a)", u: "https://ilcourtsaudio.blob.core.windows.net/antilles-resources/resources/f3e14c02-f103-410a-b192-a7b74607e49d/Rule%20181.pdf" },
    IN: { v: true, d: "20 days after service of the pleading.", r: "Ind. Trial R. 6(D)(1)", u: "https://rules.incourts.gov/Content/trial/rule6/current.htm" },
    IA: { v: true, d: "20 days after service of the original notice and petition.", r: "Iowa R. Civ. P. 1.303(1)", u: "https://www.legis.iowa.gov/docs/ACO/CourtRulesChapter/1.pdf" },
    KS: { v: true, d: "21 days after being served with the summons and petition. At least 41 days if served by publication.", r: "K.S.A. 60-212(a)(1)", u: "https://www.ksrevisor.gov/statutes/chapters/ch60/060_002_0012.html" },
    KY: { v: true, d: "20 days following the day the paper is delivered to you.", r: "Ky. CR 4.02 (Official Form 1, AOC-105)", u: "https://www.kycourts.gov/Legal-Forms/Legal%20Forms/105.pdf" },
    LA: { v: true, d: "21 days after service of citation — 30 days if discovery requests were served with the petition.", r: "La. C.C.P. art. 1001", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-1001/" },
    ME: { v: true, d: "20 days. 50 days if served outside the continental US or Canada.", r: "M.R. Civ. P. 12(a)", u: "https://www.courts.maine.gov/rules/text/MRCivPPlus/RULE%2012.pdf" },
    MD: { v: true, d: "District Court: 15 days to file a Notice of Intention to Defend — which is NOT a full answer, so read the form carefully. Circuit Court: 30 days to answer.", r: "Md. Rule 3-307; Md. Rule 2-321", u: "https://www.peoples-law.org/default-orders-judgments-maryland" },
    MA: { v: false, d: "Could not be verified from a primary source. The Massachusetts rule pages blocked automated retrieval.", r: "", u: "" },
    MI: { v: true, d: "21 or 28 days, depending on how and where you were served. Clapback will not tell you which applies to you: the official benchbook table and common secondary sources describe the split differently, and getting it wrong is a default judgment. Read your summons — it states your date.", r: "MCR 2.108(A)", u: "https://michiganlegalhelp.org/resources/debt-collection-and-foreclosure" },
    MN: { v: true, d: "21 days after service of the summons. Minnesota uses “pocket service” — you can be sued and served before anything is filed with a court, which surprises people.", r: "Minn. R. Civ. P. 12.01", u: "https://www.revisor.mn.gov/court_rules/cp/id/12/" },
    MS: { v: false, d: "Could not be verified from a primary source. The Mississippi courts site blocked automated retrieval.", r: "", u: "" },
    MO: { v: true, d: "30 days after service. 30 days after acknowledgment if served by mail; 45 days after first publication.", r: "Mo. R. Civ. P. 55.25(a)", u: "https://www.courts.mo.gov/page.jsp?id=199656" },
    MT: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    NE: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    NV: { v: true, d: "21 days after being served with the summons and complaint.", r: "NRCP 12(a)(1)(A)", u: "https://www.leg.state.nv.us/CourtRules/NRCP.html" },
    NH: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    NJ: { v: false, d: "Could not be verified from a primary source. The New Jersey courts site blocked automated retrieval.", r: "", u: "" },
    NM: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    NY: { v: true, d: "20 days if a person handed it to you directly. 30 days for every other method of service. 10 days in City Courts outside New York City if you were served within the county. Weekends and holidays count.", r: "CPLR 320(a); CPLR 3012", u: "https://www.nycourts.gov/help/problems-money/answering-consumer-debt-case" },
    NC: { v: true, d: "30 days after service of the summons and complaint.", r: "N.C. Gen. Stat. § 1A-1, Rule 12(a)(1)", u: "https://www.ncleg.gov/EnactedLegislation/Statutes/PDF/BySection/Chapter_1A/GS_1A-1,_Rule_12.pdf" },
    ND: { v: true, d: "21 days after being served with the summons and complaint.", r: "N.D.R.Civ.P. 12(a)(1)", u: "https://www.ndcourts.gov/legal-resources/rules/ndrcivp/12" },
    OH: { v: true, d: "28 days after service of the summons and complaint.", r: "Ohio Civ. R. 12(A)(1) — as stated by Ohio Legal Help, the state's endorsed self-help portal, which also publishes a free fillable answer form. Clapback could not machine-read the rule text itself. Confirm against your summons.", u: "https://www.ohiolegalhelp.org/topic/debt_lawsuit" },
    OK: { v: true, d: "20 days after service of the summons and petition.", r: "12 O.S. § 2012(A)(1)", u: "https://law.justia.com/codes/oklahoma/title-12/section-12-2012/" },
    OR: { v: true, d: "30 days from the date of service, or the date stated in the summons if served by publication.", r: "ORCP 7 C(2)", u: "https://oregon.public.law/rules-of-civil-procedure/orcp-7-summons/" },
    PA: { v: false, d: "Could not be verified from a primary source — the official Pennsylvania Code host blocks automated retrieval. Note that Magisterial District Court practice generally involves appearing at a hearing rather than filing a written answer, but that could not be confirmed either.", r: "Pa.R.C.P. 1026 governs Court of Common Pleas responsive pleadings", u: "https://www.pacourts.us/learn/representing-yourself" },
    RI: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    SC: { v: false, d: "Could not be verified from a primary source. The South Carolina courts site blocked automated retrieval.", r: "", u: "" },
    SD: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    TN: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    TX: { v: true, d: "Justice Court, where most consumer debt suits are filed: by the end of the 14th day after service — moving to the next business day if that lands on a weekend, holiday, or court closure. Filing the answer is FREE. District and County Court: by 10:00 a.m. on the Monday next after 20 days from service.", r: "Tex. R. Civ. P. 502.5 (justice); 99(b) (district/county) — as stated by TexasLawHelp and the Texas State Law Library, the state's own self-help programs. Clapback could not machine-read the rule text itself, which lives inside a single very large PDF. Confirm against your summons.", u: "https://texaslawhelp.org/guide/how-to-answer-a-debt-collection-case-in-justice-court" },
    UT: { v: true, d: "21 days if served in Utah, 30 days if served outside it. The day you received it is day zero.", r: "Utah R. Civ. P. 12(a)(1)", u: "https://www.utcourts.gov/en/self-help/case-categories/consumer/debt-collection.html" },
    VT: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    VA: { v: true, d: "Circuit Court: 21 days. General District Court — where most consumer debt cases are heard on a “warrant in debt” — requires NO written answer beforehand. You appear in court on the return date. Missing that date is a default.", r: "Va. Sup. Ct. R. 3:8(a); Va. Code §§ 16.1-88 et seq.", u: "https://www.vacourts.gov/static/courts/gd/resources/manuals/gdman/gd_manual.pdf" },
    WA: { v: true, d: "20 days if served in state, not counting the day of service. 60 days if served personally out of state, by publication, or while in a jail, detention, or prison facility.", r: "Wash. Super. Ct. CR 12(a)", u: "https://www.courts.wa.gov/court_rules/pdf/CR/SUP_CR_12_00_00.pdf" },
    WV: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" },
    WI: { v: true, d: "20 days after service of the complaint. 45 days if the defendant is an insurance company, if any claim sounds in tort, or if the state or a state officer is a defendant.", r: "Wis. Stat. § 802.06(1)", u: "https://docs.legis.wisconsin.gov/statutes/statutes/802/06" },
    WY: { v: false, d: "Could not be verified from a primary source.", r: "", u: "" }
  };
  var ANSWER_UNVERIFIED_NOTE = "Clapback could not verify this state's deadline from a primary source, and will not guess. Nationally the range runs about 14 to 35 days. Your summons states YOUR deadline — read it, and call the clerk of the court printed on it to confirm. Do that today, not after you finish reading.";

  /* ================================================================== */
  /* STATUTES OF LIMITATIONS                                             */
  /* w: written contract. o: open account / oral. v: verified.           */
  /* ================================================================== */
  var SOL_FRAME = "Which limitations period applies to a medical bill is fact-specific and genuinely contested. The same bill can be pled as breach of a WRITTEN contract (the financial-responsibility form you signed at intake), as an OPEN ACCOUNT or account stated, as an ORAL or implied contract, or as quantum meruit — and each often carries a different period. Plaintiffs plead the longest theory available. Your job as a defendant is to argue the claim is really the shorter one. This is exactly the question worth a free legal-aid consult.";
  var SOL_AFFIRM = "The statute of limitations is an AFFIRMATIVE DEFENSE almost everywhere. If you do not raise it in your Answer, you can lose it — even on a debt that is plainly too old. The CFPB puts it plainly: a court may still enter judgment against you if you don't show up and raise it.";
  var SOL_ILLEGAL = "Separately: suing or threatening to sue on a time-barred debt is itself illegal under 12 CFR 1006.26(b). If a collector did that, you may have a counterclaim, not just a defense.";

  var SOL = {
    AL: { v: true, w: "6 years", o: "3 years (open or unliquidated account, from the last item or when due)", c: "Ala. Code §§ 6-2-34, 6-2-37" },
    AK: { v: false, w: "", o: "", c: "" },
    AZ: { v: true, w: "6 years — expressly includes credit card debt", o: "3 years (oral debt; stated or open account)", c: "A.R.S. §§ 12-548, 12-543" },
    AR: { v: false, w: "", o: "", c: "" },
    CA: { v: true, w: "4 years — also book accounts and accounts stated on written accounts", o: "2 years (contract not founded on a writing)", c: "Cal. Code Civ. Proc. §§ 337, 339", n: "§ 337 goes further than most: once the 4 years expire, “a person shall not bring suit or initiate an arbitration or other legal proceeding to collect the debt.”" },
    CO: { v: true, w: "6 years (liquidated debt, or an unliquidated amount that is determinable)", o: "6 years (same provision)", c: "C.R.S. § 13-80-103.5" },
    CT: { v: true, w: "6 years", o: "6 years — the statute expressly covers “an action for an account, or on any simple or implied contract, or on any contract in writing”", c: "Conn. Gen. Stat. § 52-576" },
    DE: { v: true, w: "3 years", o: "3 years", c: "10 Del. C. § 8106" },
    DC: { v: true, w: "3 years (simple contract, express or implied)", o: "3 years", c: "D.C. Code § 12-301(a)(7)" },
    FL: { v: true, w: "5 years", o: "4 years — “not founded on a written instrument… and on store accounts”", c: "Fla. Stat. §§ 95.11(2)(b), 95.11(4)(j)" },
    GA: { v: true, w: "6 years (simple contracts in writing)", o: "Open account: O.C.G.A. § 9-3-25 governs but could not be verified — don't rely on a number", c: "O.C.G.A. § 9-3-24" },
    HI: { v: false, w: "", o: "", c: "" },
    ID: { v: false, w: "", o: "", c: "" },
    IL: { v: true, w: "10 years", o: "5 years (unwritten contracts, express or implied)", c: "735 ILCS 5/13-206; 5/13-205" },
    IN: { v: true, w: "6 years (promissory notes and written payment contracts executed after Aug 31, 1982)", o: "Could not be verified", c: "Ind. Code § 34-11-2-9" },
    IA: { v: true, w: "10 years", o: "5 years (unwritten contracts)", c: "Iowa Code § 614.1(5a), (4)" },
    KS: { v: true, w: "5 years", o: "Could not be verified (K.S.A. 60-512 governs)", c: "K.S.A. 60-511" },
    KY: { v: true, w: "10 years for written contracts executed after July 15, 2014", o: "Could not be verified (KRS 413.120 governs)", c: "KRS 413.160" },
    LA: { v: true, w: "Could not be verified (art. 3499, personal actions)", o: "3 years — and this one matters: art. 3494 expressly covers “an action on an open account” and “recovery of compensation for services rendered,” which is squarely how medical billing works", c: "La. Civ. Code art. 3494" },
    ME: { v: false, w: "", o: "", c: "" },
    MD: { v: true, w: "3 years", o: "3 years", c: "Md. Cts. & Jud. Proc. § 5-101" },
    MA: { v: true, w: "6 years (actions of contract)", o: "6 years", c: "M.G.L. c. 260, § 2" },
    MI: { v: false, w: "", o: "", c: "" },
    MN: { v: true, w: "6 years (“contract or other obligation, express or implied”)", o: "6 years", c: "Minn. Stat. § 541.05 subd. 1(1)" },
    MS: { v: false, w: "", o: "", c: "" },
    MO: { v: true, w: "Could not be verified (§ 516.110 governs writings for payment of money)", o: "5 years (contracts or obligations, express or implied)", c: "Mo. Rev. Stat. § 516.120" },
    MT: { v: false, w: "", o: "", c: "" },
    NE: { v: false, w: "", o: "", c: "" },
    NV: { v: true, w: "6 years", o: "4 years (contract not founded on a writing; open account for goods)", c: "NRS 11.190(1)(b), (2)(a), (2)(c)" },
    NH: { v: false, w: "", o: "", c: "" },
    NJ: { v: true, w: "6 years (“contractual claim or liability, express or implied, not under seal”)", o: "6 years", c: "N.J.S.A. 2A:14-1" },
    NM: { v: true, w: "6 years", o: "Could not be verified (NMSA § 37-1-4 governs)", c: "NMSA § 37-1-3(A)" },
    NY: { v: true, w: "6 years generally — BUT only 3 YEARS for any action arising out of a consumer credit transaction", o: "3 years for consumer credit transactions", c: "CPLR 213(2); CPLR 214-i", n: "The Consumer Credit Fairness Act cut this from six years to three, effective May 7, 2022. It is one of the strongest consumer-debt statutes in the country." },
    NC: { v: true, w: "3 years (“upon a contract, obligation or liability arising out of a contract, express or implied”)", o: "3 years", c: "N.C.G.S. § 1-52(1)" },
    ND: { v: false, w: "", o: "", c: "" },
    OH: { v: true, w: "6 years", o: "4 years (contract not in writing)", c: "R.C. 2305.06; R.C. 2305.07", n: "Ohio also has a specific 6-year period for “consumer transactions” for personal, family, or household purposes — and the cause of action accrues 30 calendar days after the last charge or payment, whichever is later. Note: a new version of R.C. 2305.06 takes effect September 23, 2026. Re-check before relying on this." },
    OK: { v: true, w: "5 years", o: "3 years (express or implied contract not in writing)", c: "12 O.S. § 95(A)(1), (A)(2)" },
    OR: { v: false, w: "", o: "", c: "" },
    PA: { v: true, w: "4 years (including contracts founded in writing and contracts implied in law)", o: "4 years", c: "42 Pa.C.S. § 5525" },
    RI: { v: false, w: "", o: "", c: "" },
    SC: { v: true, w: "3 years (“contract, obligation, or liability, express or implied”)", o: "3 years", c: "S.C. Code § 15-3-530(1)" },
    SD: { v: false, w: "", o: "", c: "" },
    TN: { v: true, w: "6 years (“actions on contracts not otherwise expressly provided for”)", o: "6 years", c: "Tenn. Code Ann. § 28-3-109(a)(3)" },
    TX: { v: true, w: "4 years (“debt”)", o: "4 years — on an open or stated account the claim accrues “on the day that the dealings in which the parties were interested together cease”", c: "Tex. Civ. Prac. & Rem. Code § 16.004(a)(3), (c)" },
    UT: { v: false, w: "", o: "", c: "" },
    VT: { v: false, w: "", o: "", c: "" },
    VA: { v: true, w: "5 years — but only if the contract is in writing AND SIGNED by the party charged", o: "3 years — unwritten contracts, and also written contracts NOT signed by the party charged", c: "Va. Code § 8.01-246(2), (4)", n: "This is a big deal for medical debt. Hospital intake paperwork is often unsigned or signed by someone else. Unsigned means 3 years, not 5." },
    WA: { v: true, w: "6 years — written contracts and “an action upon an account receivable”", o: "3 years (contract not in writing and not arising out of a written instrument)", c: "RCW 4.16.040; RCW 4.16.080(3)" },
    WV: { v: false, w: "", o: "", c: "" },
    WI: { v: true, w: "6 years (“any contract, obligation, or liability, express or implied”)", o: "6 years", c: "Wis. Stat. § 893.43(1)" },
    WY: { v: false, w: "", o: "", c: "" }
  };
  var SOL_UNVERIFIED_NOTE = "Clapback could not verify this state's limitations periods from a primary source, and will not guess — a wrong number here could cost you a winning defense or waste a filing. Ask legal aid (free — see below), or search your state's statutes for “limitation of actions” plus “contract.” Raise the defense in your Answer anyway if the debt looks old: you can usually drop a defense later, and you often cannot add one.";

  var BORROWING = [
    { s: "NY", t: "A claim that accrued outside New York is barred if it's barred under either New York law or the law of the place it accrued — except where the claim accrued in favor of a New York resident. Relevant because debt buyers forum-shop.", c: "CPLR 202" },
    { s: "CA", t: "A claim arising in another state that is time-barred THERE cannot be maintained in California, except in favor of a continuous California citizen holder.", c: "CCP § 361" },
    { s: "AZ", t: "The reverse: Arizona's statute expressly says Arizona's period applies on a conflict, for written-contract and credit-card debt actions.", c: "A.R.S. § 12-548(B)" }
  ];
  var BORROWING_NOTE = "Most states have a borrowing statute in some form. Clapback verified only these three and will not publish the others.";

  /* ================================================================== */
  /* REVIVAL — restarting the clock                                      */
  /* ================================================================== */
  var REVIVAL = {
    danger: "In most states, a partial payment or an acknowledgment that you owe an old debt can RESTART the limitations clock — even after it expired. The dangerous moment is a phone call: “can you just send $20 today to show good faith” is, in many states, the exact act that resurrects a dead claim and exposes you to a lawsuit you would otherwise have won.",
    rule: "If a debt might be past your state's limitations period: do not pay anything, do not promise to pay, do not sign a payment plan or settlement, and do not confirm the debt is yours — until you know your state's rule.",
    verified: [
      { s: "NY", head: "New York — nothing revives it, for consumer credit", t: "CPLR 214-i: “when the applicable limitations period expires, any subsequent payment toward, written or oral affirmation of or other activity on the debt does not revive or extend the limitations period.” This is the strongest consumer protection of its kind that Clapback could verify anywhere.", c: "CPLR 214-i (Consumer Credit Fairness Act)" },
      { s: "NY", head: "New York — general (non-consumer-credit) debts", t: "A signed writing is the only competent evidence of a new or continuing contract that takes an action out of the limitations bar. But the statute expressly does not affect the effect of actual payments of principal or interest.", c: "N.Y. Gen. Oblig. Law § 17-101" },
      { s: "TX", head: "Texas — a signed writing is required", t: "An acknowledgment of a claim that appears barred “is not admissible in evidence to defeat the law of limitations… unless the acknowledgment is in writing and is signed by the party to be charged.” An oral acknowledgment cannot revive a Texas claim.", c: "Tex. Civ. Prac. & Rem. Code § 16.065" }
    ],
    gap: "Clapback could verify a statutory non-revival or writing-only rule for New York and Texas only. Wisconsin and Mississippi are frequently described in secondary sources as non-revival states; that could not be confirmed. For every other state, assume a payment CAN restart the clock until a lawyer in your state tells you otherwise. A national “no-revival states” list published without verification is exactly the kind of error that costs someone a case."
  };

  /* ================================================================== */
  /* AFFIRMATIVE DEFENSES                                                */
  /* ================================================================== */
  var DEFENSES = [
    { id: "sol", n: "Statute of limitations", med: false,
      when: "The suit was filed after your state's limitations period ran out.",
      need: "The date of your last payment or last charge, the charge-off date, account statements, and your credit report showing the date of first delinquency.",
      note: "You must plead it or you can lose it." },
    { id: "standing", n: "Lack of standing / broken chain of assignment", med: false,
      when: "A debt buyer is suing but can't prove it actually owns YOUR specific account.",
      need: "Demand the full chain: original creditor to each intermediate buyer to the plaintiff, with bills of sale AND the account-level schedule naming you and your account number. A generic bill of sale referencing “a pool of accounts” proves nothing about you.",
      note: "The FTC studied 76 million purchased accounts and found that “for most portfolios, buyers did not receive any documents at the time of purchase.” They typically got data files and seller surveys — not contracts or statements. This defense works because it is usually true." },
    { id: "statement", n: "Failure to state a claim", med: false,
      when: "The complaint omits required elements or required attachments.",
      need: "The complaint itself. In states with debt-buyer pleading statutes, missing attachments can mean dismissal — North Carolina's statute says a non-compliant complaint “shall be dismissed by the court upon motion of the debtor or sua sponte.”",
      note: "" },
    { id: "service", n: "Insufficient or improper service of process", med: false,
      when: "You were never properly served, were served at a stale address, or someone signed for you who shouldn't have.",
      need: "Get the affidavit of service from the court file, then contradict it: a lease, a work schedule, travel records, proof of who actually lives at that address.",
      note: "“Sewer service” is real and documented. The FTC found process servers not performing service and filling out false affidavits, including a New York prosecution covering more than 100,000 instances. A judgment entered without proper service is VOID, not merely voidable — which matters enormously if you're trying to undo an old default." },
    { id: "nocontract", n: "No contract / no account stated", med: false,
      when: "You never signed anything, or you disputed the statement so it never became an “account stated.”",
      need: "Make them produce the alleged contract. Your own dispute letters.",
      note: "" },
    { id: "paid", n: "Payment, accord and satisfaction, or release", med: false,
      when: "You already paid it, settled it, or the insurer paid it.",
      need: "Cancelled checks, bank records, EOBs, settlement letters, zero-balance statements.",
      note: "" },
    { id: "reasonable", n: "Unreasonable charges — the chargemaster challenge", med: true,
      when: "Attack the AMOUNT, not just the obligation. Where there is no enforceable written price term, the recoverable amount is the reasonable value of the services — not whatever the chargemaster says.",
      need: "Force itemization by code. Then compare against: Medicare's rate for the same codes, the hospital's own negotiated commercial rates from its published price transparency file, and the hospital's own Amounts Generally Billed figure, which its Financial Assistance Policy is required to explain.",
      note: "Doctrine is widely applied but Clapback verified no case citations — do not quote case names you haven't read. The AGB requirement itself is real and verifiable: 26 CFR 1.501(r)-4." },
    { id: "r501", n: "Charity care screening failure (501(r))", med: true,
      when: "A tax-exempt hospital sued you without making reasonable efforts to determine whether you qualify for financial assistance. A LAWSUIT IS an extraordinary collection action.",
      need: "The hospital's 501(c)(3) status and Form 990 Schedule H; its Financial Assistance Policy and plain-language summary; billing statements with dates; proof you received no notice; your income against the FAP thresholds.",
      note: "Three bright-line dates to check: was suit filed within 120 days of the first post-discharge billing statement? Did you get written notice at least 30 days before, identifying the intended action? Are you still inside the 240-day application window? If you apply and qualify, the hospital must reverse what it did — including vacating the judgment." },
    { id: "nsa", n: "No Surprises Act violation", med: true,
      when: "The bill is for emergency services, for an out-of-network provider at an in-network facility, or for air ambulance — and you were balance billed anyway. Or you're uninsured/self-pay and never got a Good Faith Estimate.",
      need: "The Good Faith Estimate, the bill, the insurer's EOB, and the facility's network status.",
      note: "Also file the CMS complaint in parallel. 1-800-985-3059." },
    { id: "notrendered", n: "Services not rendered / duplicate / wrong patient", med: true,
      when: "Coding errors, upcoding, unbundling, or charges on dates you weren't there.",
      need: "The itemized bill by date and code, the medical records, and the discharge summary.",
      note: "" },
    { id: "insurance", n: "Insurance not properly billed", med: true,
      when: "The provider failed to bill your insurer, billed the wrong plan, or missed the plan's timely-filing deadline, then billed you.",
      need: "Your insurance card and dates of coverage, EOBs, the plan's timely-filing rule, and the provider's claim submission history.",
      note: "A timely-filing denial adjudicates as a contractual obligation the provider absorbs — not a patient balance." },
    { id: "fdcpa", n: "FDCPA counterclaim", med: false,
      when: "The collector misrepresented the amount or status, sued in the wrong venue, sued on time-barred debt, or ignored a validation request.",
      need: "Collection letters, call logs, court filings, envelope postmarks.",
      note: "Venue matters and people miss it: 15 U.S.C. 1692i says a collector may sue only where you signed the contract or where you live. And the FDCPA has a ONE-YEAR clock from the violation." },
    { id: "fcra", n: "FCRA counterclaim", med: false,
      when: "A furnisher kept reporting the debt after you disputed it through a credit bureau.",
      need: "Your bureau dispute, the bureau's result letter, and subsequent credit reports.",
      note: "Only a bureau-routed dispute creates the privately enforceable duty. See the Credit file tab." },
    { id: "unconsc", n: "Unconscionability", med: false, when: "Grossly one-sided terms or price.", need: "The contract; comparative pricing evidence.", note: "General doctrine; not verified for any specific state." },
    { id: "mitigate", n: "Failure to mitigate", med: false, when: "The plaintiff let charges or interest balloon.", need: "The billing timeline.", note: "General doctrine; not verified for any specific state." }
  ];
  var DEFENSE_RULE = "Affirmative defenses generally must be pled in your Answer or they are WAIVED. Plead them even if you're unsure — you can usually drop one later, and you often cannot add one later.";

  /* ================================================================== */
  /* WHAT THE PLAINTIFF MUST PROVE                                       */
  /* ================================================================== */
  var PROVE = {
    elements: [
      "That you agreed to pay — or are liable under a state statute — for these specific services.",
      "The amount, with an itemization, not a lump sum.",
      "That the charges are reasonable, where there's no enforceable price term.",
      "If a debt buyer: an unbroken chain of assignment to your specific account."
    ],
    ftc2013: "The FTC studied 76 million accounts purchased between 2006 and 2009. Its finding: “For most portfolios, buyers did not receive any documents at the time of purchase.” Buyers typically got data files and seller surveys. Consumers disputed 3.2% of debts, and buyers verified only 51.3% of those — roughly 500,000 disputed accounts left unverified annually. What buyers paid tells you what they knew they were getting: about 7.9 cents on the dollar for debt under 3 years old, 2.2 cents for 6-to-15-year-old debt, essentially nothing over 15 years.",
    ftc2013Url: "https://www.ftc.gov/sites/default/files/documents/reports/structure-and-practices-debt-buying-industry/debtbuyingreport.pdf",
    robo: "In September 2015 the CFPB took action against the two largest debt buyers for filing affidavits containing misleading statements, using documents falsely claimed to verify debts without actually reviewing account records, and suing past the statute of limitations. Encore Capital: $42M in refunds, $10M penalty, and an order to stop collecting on $125M of debt. Portfolio Recovery Associates: $19M in refunds, $8M penalty. Both were barred from reselling purchased debts.",
    roboUrl: "https://www.consumerfinance.gov/about-us/newsroom/cfpb-takes-action-against-the-two-largest-debt-buyers-for-using-deceptive-tactics-to-collect-bad-debts/",
    defaults: "Most consumer debt collection lawsuits end in a default judgment — the defendant never responds. Pew's 2020 study of state courts found more than 70% nationally, with 71% in Colorado and roughly 80% in New York City and in Washington State. An earlier FTC staff report put the range at 60% to 90%. Whatever the exact figure, the shape is the same: the case is usually decided by whether you show up. Responding does not admit the debt — the CFPB says responding “simply preserves your right to dispute it.”",
    defaultsUrl: "https://www.pew.org/en/research-and-analysis/reports/2020/05/how-debt-collectors-are-transforming-the-business-of-state-courts",
    pleading: [
      { s: "NC", t: "A debt buyer must ATTACH a copy of the contract or writing evidencing the original debt containing your signature (or, for credit cards with no signed document, documents generated when the card was actually used), plus a copy of each assignment establishing ownership, showing the original account number and identifying you by name. A complaint that doesn't comply “shall be dismissed by the court upon motion of the debtor or sua sponte.”", c: "N.C.G.S. § 58-70-150" },
      { s: "MD", t: "For assigned consumer debt where the plaintiff isn't the original creditor, the affidavit must include an Assigned Consumer Debt Checklist plus certified proof you incurred the debt, a certified copy of the original agreement, a chronological list of all prior owners with certified bills of sale for each transfer, charge-off details, and a list of all Maryland collection licenses held.", c: "Md. Rule 3-306(c),(d)" },
      { s: "CA", t: "Three strong statutes. Pre-suit (§ 1788.52): on written request a debt buyer must supply ownership proof, charge-off balance, default and last-payment dates, original creditor and account number, all subsequent purchasers, and its California license number — FREE, within 15 calendar days — or CEASE COLLECTION until it does. Its first written communication must carry a 12-point-type notice of this right. Pleading (§ 1788.58): the complaint must allege the full chain and ATTACH the contract, with special added requirements for general acute care HOSPITAL debt, including financial assistance information. Default judgments (§ 1788.60): no default or other judgment may be entered without authenticated business records — non-compliance means the court “shall not enter a default judgment” and may dismiss.", c: "Cal. Civ. Code §§ 1788.52, 1788.58, 1788.60" },
      { s: "NY", t: "A consumer credit complaint must ATTACH the contract and state the original creditor, the last four digits of the account, the date and amount of the last payment, the balance per the most recent statement, the chain of ownership if the plaintiff isn't the original creditor, and a full itemization. Separately, before any default judgment the clerk mails an Additional Notice of Lawsuit and no default may be entered until at least 20 days after that mailing — in English and Spanish. Debt buyers must file a stack of affirmations, and every application requires an Affirmation of Non-Expiration of the Statute of Limitations.", c: "CPLR 3016(j); 22 NYCRR §§ 202.27-a et seq." },
      { s: "TX", t: "Justice court debt claim petitions must include account details, loan information, interest terms, and assignment history. On a no-answer default the judge renders judgment only on the plaintiff's proof of damages — establishing your obligation, the breach, the amount due, and the plaintiff's ownership of the account.", c: "Tex. R. Civ. P. 508.2, 508.3" }
    ],
    pleadingGap: "Several more states are commonly reported to have debt-buyer pleading requirements — Connecticut, Massachusetts, Delaware, Oregon, Washington, Minnesota, Colorado, Illinois among them. Clapback could not verify those and will not publish them. Ask legal aid whether your state has one; it can end a case outright."
  };

  /* ================================================================== */
  /* DISCOVERY                                                           */
  /* ================================================================== */
  var DISCOVERY = {
    tools: [
      { n: "Interrogatories", lim: "25, including all discrete subparts, absent agreement or a court order", dl: "30 days to answer", c: "FRCP 33" },
      { n: "Requests for production", lim: "No numeric cap", dl: "30 days", c: "FRCP 34" },
      { n: "Requests for admission", lim: "No numeric cap", dl: "30 days", c: "FRCP 36" },
      { n: "Depositions", lim: "Available", dl: "—", c: "FRCP 30" }
    ],
    note: "These are the federal baselines. Your state's numbers differ, sometimes a lot — check your state rules or ask the clerk.",
    rfa: {
      head: "Requests for admission are the highest-leverage move available to a self-represented defendant.",
      rule: "Under the federal rule and most state analogues, a matter is ADMITTED unless the party answers or objects within 30 days. An admission is then conclusively established for that case, and undoing it requires a court order.",
      why: "So if you serve requests like “Admit that Plaintiff possesses no document bearing Defendant's signature relating to the account at issue” and “Admit that Plaintiff cannot produce a bill of sale identifying Defendant's account by account number” — and the plaintiff blows the deadline — those facts are established. That can support dismissal or summary judgment.",
      c: "FRCP 36(a)(3), (b)"
    },
    smallclaims: "Small claims, justice, and conciliation courts commonly restrict or prohibit discovery, and some limit lawyer appearances. Clapback did not verify any individual state's small-claims discovery rule. Ask the clerk what's allowed in your court before you rely on it.",
    ca98: "One verified state-specific gem. In California limited civil cases, written testimony can substitute for live testimony only if it was served at least 30 days before trial, the declarant's address is within 150 miles of the courthouse, and the declarant is available for service of process there during the 20 days before trial. Debt buyers routinely try to prove up cases with a declaration from an out-of-state records custodian — which fails all three."
  };

  /* ================================================================== */
  /* DEFAULT JUDGMENTS — undoing one                                     */
  /* ================================================================== */
  var VACATE = {
    move: "Move fast. Every regime Clapback verified has a deadline, and the shortest are measured in months.",
    strategic: "A judgment entered without proper service is VOID, not merely voidable — and in every regime verified below, void-judgment grounds are NOT subject to the one-year or six-month caps. Given the FTC's documented findings on false affidavits of service, improper service is the most common winning ground on an old default. Get the affidavit of service from the court file first.",
    rules: [
      { j: "Federal", g: "Mistake, inadvertence, surprise, or excusable neglect; newly discovered evidence; fraud or misconduct by an opposing party; the judgment is void; it's been satisfied or reversed; or any other reason justifying relief.", t: "“A reasonable time” — and for the first three grounds, no more than ONE YEAR after entry.", c: "FRCP 60(b), 60(c)(1)" },
      { j: "California", g: "Mistake, inadvertence, surprise, or excusable neglect. § 473(d) separately allows setting aside a VOID judgment.", t: "Within a reasonable time, in no case exceeding SIX MONTHS after entry — or 90 days where written notice was personally served in California on the party and attorney. Your application must include a copy of the proposed answer.", c: "Cal. Code Civ. Proc. § 473(b),(d)" },
      { j: "New York", g: "Excusable default; newly discovered evidence; fraud, misrepresentation, or other misconduct of an adverse party; lack of jurisdiction; or reversal of a prior judgment.", t: "For excusable default: within ONE YEAR after service of a copy of the judgment with written notice of entry. The other grounds are not subject to that cap.", c: "CPLR 5015(a)" }
    ],
    gap: "Vacatur grounds and deadlines vary enormously between states — from 30 days to no limit. Clapback verified the three above and will not publish numbers for the rest. Ask your court's self-help center or legal aid immediately; this is one of the most time-sensitive questions in law."
  };

  /* ================================================================== */
  /* AFTER JUDGMENT — what they can and cannot take                      */
  /* ================================================================== */
  var EXEMPT = {
    wageFormula: "Federal law caps what can be garnished from your wages in any workweek at the LESSER of: 25% of disposable earnings for that week, OR the amount by which disposable earnings exceed 30 times the federal minimum hourly wage.",
    wageCite: "15 U.S.C. § 1673(a)",
    wageNote: "Clapback shows the formula, not a dollar figure, because the 30× floor depends on the federal minimum wage in effect. These limits do NOT apply to child support and alimony orders (which run 50–65%), Chapter 13 bankruptcy orders, or state and federal tax debts — and federal student loans are garnished administratively under a separate, different cap.",
    states: [
      { s: "TX", t: "Current wages for personal services are exempt from garnishment, except for court-ordered child support.", c: "Tex. Prop. Code § 42.001(b)(1)" },
      { s: "PA", t: "Wages, salaries, and commissions are exempt from attachment or execution while in the employer's hands — with enumerated exceptions for divorce and support, board for four weeks or less, residential lease judgments (capped), PHEAA student loans, and criminal restitution, fines, costs, and bail.", c: "42 Pa.C.S. § 8127" },
      { s: "SC", t: "For consumer credit sales, leases, loans, and rental-purchase agreements, “the creditor may not attach unpaid earnings of the debtor by garnishment or like proceedings” — regardless of where the transaction happened.", c: "S.C. Code § 37-5-104" },
      { s: "NC", t: "Earnings for personal services within the 60 days preceding the order cannot be applied to a judgment where those earnings are necessary for the use of a family supported wholly or partly by that labor. Note this is a family-necessity protection with a 60-day lookback, not an outright ban — don't describe it as one.", c: "N.C.G.S. § 1-362" }
    ],
    statesNote: "Clapback verified these four. Roughly 19 states are reported to exceed the federal wage-garnishment protections in some way; the rest could not be verified. Never assume your state “bans garnishment entirely” — every one of these has exceptions.",
    benefits: {
      head: "Federal benefits in a bank account protect themselves — automatically",
      body: "When a bank receives a garnishment order, it must review the account and protect direct-deposited federal benefits without freezing them. Covered: Social Security, VA, Railroad Retirement Board, and Office of Personnel Management payments. The bank looks back two months from the date of the account review and protects the lesser of all benefit payments posted in that window or the account balance. It must examine the order within two business days, give you full access to the protected amount, and notify you within three business days if there's more in the account than that.",
      cite: "31 CFR Part 212",
      trap: "The trap: this protects DIRECT DEPOSIT only. If you receive Social Security or VA benefits by check and deposit the check yourself, the bank does not have to protect two months' worth. Switch to direct deposit. Two further limits: the automatic protection does not apply to garnishment orders from a state child support agency, or from the United States or a state agency — and it only reaches funds actually in the account, so money already spent or moved is not covered.",
      trapUrl: "https://www.consumerfinance.gov/ask-cfpb/can-a-debt-collector-take-my-social-security-or-va-benefits-en-1157/"
    },
    nyEipa: "New York goes further than most: the Exempt Income Protection Act (CPLR 5222-a) protects 16 categories including Social Security, SSI and SSD, public assistance, veterans and unemployment benefits, pensions and retirement payments, workers' comp, child and spousal support, Railroad Retirement, Black Lung, COVID-19 relief, and 90% of income earned in the last 60 days — with a defined procedure and short deadlines on both sides.",
    judgmentProof: "You are functionally “judgment proof” when all your income and property fall within exemptions — for instance, your income is entirely exempt federal benefits, your wages are below the federal floor or in a state that bars consumer wage garnishment, and your home, vehicle, and personal property fit within your state's exemptions. Be clear-eyed about what that does and doesn't mean: a judgment can still be entered, still accrues interest, still appears on public record, and can still be enforced later if your circumstances change. It is a practical situation, not a legal status.",
    homestead: "Homestead exemptions protect some or all of your home's value from creditors' claims. They range from a few thousand dollars to unlimited, and change frequently. Clapback verified only Texas (acreage-based, exempt from seizure with enumerated permitted encumbrances; sale proceeds stay exempt for six months) and will not publish unverified dollar amounts for other states — that would be actively harmful. Look up your state's exemption statute, or ask legal aid."
  };

  /* ================================================================== */
  /* SETTLING                                                            */
  /* ================================================================== */
  var SETTLE = [
    { h: "Your leverage is highest right after you file an Answer", t: "Before the plaintiff has spent money on discovery — and highest of all if it cannot produce the chain of assignment." },
    { h: "A consent judgment is still a judgment", t: "It appears on the public record, accrues post-judgment interest, can be enforced by garnishment, levy, or lien the moment you miss a payment, and often includes a permanent waiver of your defenses — including the statute of limitations. If you settle, strongly prefer DISMISSAL WITH PREJUDICE upon payment over a stipulated judgment held in reserve." },
    { h: "Get it in writing before you pay a cent", t: "The writing should state the total amount, the payment schedule, that payment is full satisfaction, that the case will be dismissed with prejudice, who pays court costs, that the plaintiff will not sell or re-report the balance, and how the credit reporting will be handled." },
    { h: "If it might be time-barred, settling can revive it", t: "In most states, signing a payment plan on a time-barred debt restarts the clock. New York is the verified exception for consumer credit. Check before you sign anything." },
    { h: "For nonprofit hospital debt, charity care beats any settlement", t: "If you qualify for the hospital's Financial Assistance Policy, the right outcome isn't a discount — it's free or discounted care, plus a duty to reverse what they already did, including vacating the judgment and removing the credit reporting. Apply before you settle." }
  ];

  /* ================================================================== */
  /* FILING MECHANICS                                                    */
  /* ================================================================== */
  var FILING = [
    { h: "How to file", t: "In person at the clerk's office (bring the original plus copies, and ask the clerk to file-stamp your copy), by mail where permitted (certified, return receipt — and note some states count filing on receipt, not mailing), or by e-filing where available." },
    { h: "Filing an Answer is usually free", t: "Filing a COUNTERCLAIM often is not. Texas confirms an answer in justice court is free. If a fee applies, ask the clerk for a fee waiver — the federal forms are AO 239 (long) and AO 240 (short); state form numbers vary and Clapback did not verify them." },
    { h: "You must serve a copy on the other side", t: "Send a copy of your Answer to the plaintiff's attorney at the address on the complaint, and attach a certificate of service saying what you sent, to whom, at what address, by what method, on what date, signed by you." },
    { h: "Watch who does the mailing", t: "New York, for example, does not let you personally mail your own papers — a non-party aged 18 or over must do it, with an affidavit of service." },
    { h: "A general denial may be enough to answer — but not to preserve defenses", t: "In Texas justice court, an answer that denies all the plaintiff's allegations without specifying reasons is sufficient to constitute an answer. But a general denial does NOT preserve affirmative defenses like the statute of limitations. Plead those separately, by name." }
  ];

  /* ================================================================== */
  /* FREE LEGAL HELP                                                     */
  /* ================================================================== */
  var HELP_NATIONAL = [
    { n: "Legal Services Corporation — legal aid finder", t: "Enter your address and get the LSC-funded legal aid organization serving your area, with phone and website. Start here.", u: "https://www.lsc.gov/about-lsc/what-legal-aid/i-need-legal-help" },
    { n: "LawHelp.org", t: "Free legal rights resources, court forms, self-advocacy tools, and referrals to nonprofit legal aid in every state and territory. Run by Pro Bono Net.", u: "https://www.lawhelp.org/" },
    { n: "ABA Free Legal Answers", t: "A virtual legal advice clinic — qualifying users post civil legal questions free and get answers from pro bono attorneys. Operating in 40+ jurisdictions. Consumer Rights and Financial are explicitly covered topics.", u: "https://abafreelegalanswers.org/" },
    { n: "NACA — find a consumer attorney", t: "The National Association of Consumer Advocates directory. Debt Collection and Credit Reporting are listed practice areas. These are the lawyers who take FDCPA and FCRA cases — often with no money up front, because the statutes make the defendant pay your fees if you win.", u: "https://www.consumeradvocates.org/findanattorney/" },
    { n: "CFPB — what to do if you're sued", t: "Plain-language guidance from the federal regulator, including how to respond and how to negotiate.", u: "https://www.consumerfinance.gov/ask-cfpb/what-should-i-do-if-a-creditor-or-debt-collector-sues-me-en-334/" }
  ];

  var HELP_STATE = {
    CA: { n: "California Courts Self-Help", t: "A dedicated debt lawsuits guide with a Medical Debt section, and the answer form named: PLD-C-010, “Answer — Contract.” Small claims limits are $12,500 for individuals and $6,250 for businesses.", u: "https://selfhelp.courts.ca.gov/debt-lawsuits/respond" },
    NY: { n: "New York CourtHelp", t: "A fillable Written Answer for consumer credit cases (form CIV-GP-58B) used by all five NYC Civil Court districts, letting you admit or deny allegations and state defenses and counterclaims. You can amend within 10 days of filing.", u: "https://www.nycourts.gov/forms/written-answer-consumer-credit" },
    OH: { n: "Ohio Legal Help", t: "One of the strongest debt-specific self-help programs verified anywhere. A statewide fillable debt collection answer, a Franklin County Municipal Court-specific interview form, a small claims answer, and a wage garnishment topic.", u: "https://www.ohiolegalhelp.org/topic/debt_lawsuit" },
    TX: { n: "TexasLawHelp", t: "A step-by-step guide to answering a debt collection case in justice court, with Form CV-ANS-103. Also guides on exempt property and appealing a justice court case.", u: "https://texaslawhelp.org/guide/how-to-answer-a-debt-collection-case-in-justice-court" },
    MI: { n: "Michigan Legal Help", t: "Run jointly by the Michigan State Bar Foundation and the Michigan Supreme Court. A Do-It-Yourself Civil Answer tool that prepares the forms, courthouse self-help centers statewide, and a Setting Aside a Default topic.", u: "https://michiganlegalhelp.org/resources/debt-collection-and-foreclosure" },
    UT: { n: "Utah Courts Self-Help", t: "Form 1013GE, “Answering a Debt Collection Complaint,” plus a Motion to Set Aside Judgment form, garnishment and judgment guides.", u: "https://www.utcourts.gov/en/self-help/case-categories/consumer/debt-collection.html",
      warn: "Utah's old OCAP system is retired and its replacement, MyPaperwork, does not cover debt collection. Use Form 1013GE." },
    MN: { n: "Minnesota Judicial Branch Self-Help", t: "A statewide Self-Help Center at (651) 435-6535, walk-in locations, and a Conciliation Court Virtual Assistant.", u: "https://www.mncourts.gov/selfhelp" },
    AZ: { n: "AZCourtHelp", t: "Run by the Arizona Bar Foundation and endorsed by the Chief Justice. Form Finder, court locator, legal aid referrals, and live chat. Note the landing page leans toward family law and eviction — use the Form Finder and search for a civil answer rather than browsing.", u: "https://azcourthelp.org/" },
    MD: { n: "Maryland People's Law Library", t: "From the Maryland Judiciary's Thurgood Marshall State Law Library — including default orders and judgments.", u: "https://www.peoples-law.org/default-orders-judgments-maryland" },
    VA: { n: "Virginia General District Court Manual", t: "The official manual for the court where most Virginia consumer debt cases are heard.", u: "https://www.vacourts.gov/static/courts/gd/resources/manuals/gdman/gd_manual.pdf" },
    PA: { n: "Pennsylvania Courts — representing yourself", t: "The official self-representation page, including In Forma Pauperis fee assistance. Note it contains no response deadlines and directs you to your county court administrator.", u: "https://www.pacourts.us/learn/representing-yourself" }
  };
  var HELP_STATE_NOTE = "Clapback lists only the state self-help programs it verified. If yours isn't here, start with the LSC finder and LawHelp.org above, and call the clerk of the court on your summons — many courthouses have a self-help desk.";

  return {
    UPDATED: UPDATED, SUMMONS_RULE: SUMMONS_RULE,
    ANSWER: ANSWER, ANSWER_UNVERIFIED_NOTE: ANSWER_UNVERIFIED_NOTE,
    SOL: SOL, SOL_FRAME: SOL_FRAME, SOL_AFFIRM: SOL_AFFIRM, SOL_ILLEGAL: SOL_ILLEGAL, SOL_UNVERIFIED_NOTE: SOL_UNVERIFIED_NOTE,
    BORROWING: BORROWING, BORROWING_NOTE: BORROWING_NOTE,
    REVIVAL: REVIVAL, DEFENSES: DEFENSES, DEFENSE_RULE: DEFENSE_RULE,
    PROVE: PROVE, DISCOVERY: DISCOVERY, VACATE: VACATE, EXEMPT: EXEMPT,
    SETTLE: SETTLE, FILING: FILING,
    HELP_NATIONAL: HELP_NATIONAL, HELP_STATE: HELP_STATE, HELP_STATE_NOTE: HELP_STATE_NOTE
  };
})();

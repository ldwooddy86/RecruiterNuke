/* Clapback — "Insurance appeals" module.
 * Works only on YOUR OWN claims and denials. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM;
  var A = M.APPEALS;
  var mounted = false;

  function mount() {
    var view = X.$("#view-appeals");
    if (!view || mounted) return;
    mounted = true;

    view.innerHTML =
      '<h1>Insurance appeals</h1>' +
      '<p class="lede">About one in five in-network claims gets denied. Fewer than one percent of those denials are ever appealed — and roughly a third of the ones that <em>are</em> appealed get overturned. That gap is the whole opportunity. Insurers are not staffed on the assumption that people will push back, because almost nobody does.</p>' +

      '<div class="callout callout-warn">' +
      '<strong>Your clock is already running.</strong> You generally have at least 180 days from the denial notice to file an internal appeal, and four months after the final internal denial to request external review. Both are floors, not ceilings — your plan may allow longer — but do not find out the hard way. Work out your dates below and put them in the tracker.' +
      '</div>' +

      /* ---- plan type router ---- */
      '<h2>First question: who actually regulates your plan?</h2>' +
      '<div class="card">' +
      '<p>This determines who you complain to, which external review process you use, and whether your state insurance department can help you at all. Getting it wrong costs weeks against a hard deadline — and the official guidance won’t tell you, because the federal and state sources each describe only their own half.</p>' +
      '<div class="chips" id="plan-chips">' +
      '<button class="chip" data-plan="self">Self-funded employer plan</button>' +
      '<button class="chip" data-plan="full">Fully insured plan</button>' +
      '<button class="chip" data-plan="unknown">I don’t know</button>' +
      '</div>' +
      '<div id="plan-out" style="margin-top:14px"></div>' +
      '<div class="callout callout-info" style="margin-top:12px" id="plan-gap"></div>' +
      '</div>' +

      /* ---- deadline calculator ---- */
      '<h2>Your deadlines</h2>' +
      '<div class="card">' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="ap-date">Date on the denial notice</label><input class="input" id="ap-date" type="date"></div>' +
      '<div class="ev-field"><label class="field" for="ap-kind">Kind of claim</label><select class="input" id="ap-kind">' +
      '<option value="post">Post-service — I already got the care</option>' +
      '<option value="pre">Pre-service — care I haven’t had yet</option>' +
      '<option value="urgent">Urgent</option>' +
      '</select></div>' +
      '<div class="ev-field"><label class="field" for="ap-levels">Internal appeal levels in your plan</label><select class="input" id="ap-levels">' +
      '<option value="1">One (most common)</option><option value="2">Two</option>' +
      '</select></div>' +
      '<div class="ev-field-wide"><button class="btn" id="ap-run">Work out my dates</button></div>' +
      '</div>' +
      '<div id="ap-out"></div>' +
      X.srcLine("29 CFR 2560.503-1 and 45 CFR 147.136 (eCFR)", A.ecfr) +
      '</div>' +

      /* ---- rights ---- */
      '<h2>Four rights people don’t know they have</h2>' +
      '<div class="card"><div id="ap-rights" class="link-list"></div></div>' +

      /* ---- reasons ---- */
      '<h2>What they said, and whether you can beat it</h2>' +
      '<p class="muted">Some denials are worth a full appeal. Some are a five-minute phone call to the billing office and shouldn’t be appealed at all. Knowing which is which saves months.</p>' +
      '<div id="ap-reasons"></div>' +

      /* ---- EOB decoder ---- */
      '<div class="card">' +
      '<h3>Reading the EOB</h3>' +
      '<p>Three numbers, in order: the <strong>billed amount</strong> (what the provider asked for — largely fictional for in-network care), the <strong>allowed amount</strong> (the negotiated rate), and <strong>patient responsibility</strong> (deductible plus coinsurance plus copay). The difference between billed and allowed is the network discount, and it is the provider’s contractual write-off — not yours.</p>' +
      '<p>Every adjustment carries a group code, and that code is the decision rule: <strong>CO means the provider absorbs it. PR means you may owe it.</strong> A charge on your bill that maps to a CO adjustment on the EOB is presumptively improper billing.</p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="bills">Run the EOB-vs-bill check →</button>' +
      X.a("Official CARC list ↗", A.carc) + X.a("RARC list ↗", A.rarc) + '</div>' +
      '</div>' +

      /* ---- external review ---- */
      '<h2>External review — a reviewer who doesn’t work for your insurer</h2>' +
      '<div class="card">' +
      '<p>After the final internal denial you can send it to an independent reviewer whose decision <strong>binds the plan</strong>. Medical necessity and experimental-or-investigational denials do best here, because the question is clinical rather than contractual. Standard decisions come within 45 days, expedited within 72 hours. Federal external review is free; a state process may charge up to $25.</p>' +
      '<div class="callout callout-info" id="ext-fed"></div>' +
      '<div class="callout callout-warn" id="ext-warn"></div>' +
      '<div class="btn-row" id="ext-btns"></div>' +
      '</div>' +

      /* ---- prior auth ---- */
      '<div class="card">' +
      '<h3>Prior authorization in 2026</h3>' +
      '<p id="pa-rule"></p>' +
      '<p class="muted" id="pa-vol"></p>' +
      '<div class="btn-row">' + X.a("CMS rule fact sheet ↗", A.priorAuthUrl) + X.a("The voluntary pledges ↗", A.priorAuthVolUrl) + '</div>' +
      '</div>' +

      /* ---- medicare/medicaid ---- */
      '<h2>Medicare and Medicaid work differently</h2>' +
      '<div class="card">' +
      '<h3>Original Medicare — five levels</h3>' +
      '<div id="mc-ladder"></div>' +
      '<p class="muted" id="mc-note"></p>' +
      '<div class="btn-row">' + X.a("Medicare appeals ↗", A.medicareUrl) + '</div>' +
      '</div>' +
      '<div class="card">' +
      '<h3>Medicare Advantage — better in one important way</h3>' +
      '<p id="ma-note"></p>' +
      '<div class="btn-row">' + X.a("Medicare Advantage appeals ↗", A.medAdvUrl) + '</div>' +
      '</div>' +
      '<div class="card danger">' +
      '<h3>Medicaid — the exhaustion trap</h3>' +
      '<p id="mcaid-note"></p>' +
      '<p class="fineprint" id="mcaid-cite"></p>' +
      '</div>' +

      /* ---- weak plans ---- */
      '<h2>Plans with weak or no appeal rights</h2>' +
      '<div id="ap-exempt"></div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<div class="card"><div id="ap-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal or medical advice. Your plan documents control, and many plans give you more than the federal minimum described here. Every deadline on this page links to the regulation it comes from, verified ' + X.esc(M.UPDATED) + '.</p>';

    renderStatic();
    wire();
  }

  function renderStatic() {
    /* rights */
    var r = X.$("#ap-rights"); r.innerHTML = "";
    A.rights.forEach(function (it) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", it.n));
      l.appendChild(X.el("div", "li-note", it.t + "  — " + it.cite));
      row.appendChild(l);
      r.appendChild(row);
    });

    /* reasons */
    var rs = X.$("#ap-reasons"); rs.innerHTML = "";
    A.reasons.forEach(function (it) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", it.n));
      var pill = it.lev === "strong" ? ["status-ban", "Worth appealing"] : ["status-amber", "Fix it, don’t appeal it"];
      head.appendChild(X.el("span", "status-pill " + pill[0], pill[1]));
      card.appendChild(head);
      card.appendChild(X.el("p", null, it.t));
      rs.appendChild(card);
    });

    /* external */
    X.$("#ext-fed").innerHTML = "<strong>Which process do you use?</strong> " + X.esc(A.fed.note);
    X.$("#ext-warn").innerHTML = "<strong>One honest caveat.</strong> " + X.esc(A.fed.warn);
    X.$("#ext-btns").innerHTML =
      X.a("Federal external review portal ↗", A.fed.portal, "btn btn-sm") +
      X.a("Check your state’s status ↗", A.fed.url) +
      X.a("Find your state insurance department ↗", A.naic);

    /* prior auth */
    X.$("#pa-rule").textContent = A.priorAuth;
    X.$("#pa-vol").textContent = A.priorAuthVoluntary;

    /* medicare ladder */
    var ml = X.$("#mc-ladder"); ml.innerHTML = "";
    A.medicare.forEach(function (l) {
      var row = X.el("div", "link-item");
      var left = X.el("div");
      left.appendChild(X.el("div", "li-main", l.lvl + " — " + l.who));
      left.appendChild(X.el("div", "li-note", "File within " + l.file + ". Decision: " + l.dec + ". Minimum amount: " + l.min + (l.form ? ". " + l.form : "")));
      row.appendChild(left);
      ml.appendChild(row);
    });
    X.$("#mc-note").textContent = A.medicareNote;
    X.$("#ma-note").textContent = A.medAdv;
    X.$("#mcaid-note").textContent = A.medicaid;
    X.$("#mcaid-cite").textContent = "Cite: " + A.medicaidCite;

    /* exempt plans */
    var ex = X.$("#ap-exempt"); ex.innerHTML = "";
    A.exempt.forEach(function (e) {
      var card = X.el("div", "law-card");
      card.appendChild(X.el("div", "law-name", e.n));
      card.appendChild(X.el("p", null, e.t));
      var b = X.el("div", "btn-row"); b.innerHTML = X.a("Source ↗", e.url);
      card.appendChild(b);
      ex.appendChild(card);
    });

    X.$("#plan-gap").innerHTML = "<strong>Why this matters more than it should.</strong> " + X.esc(A.planTypeGap);

    X.letterCards(X.$("#ap-letters"), "appeals", function () { return {}; });
  }

  function wire() {
    X.$("#plan-chips").addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      X.$$("#plan-chips .chip").forEach(function (x) { x.classList.toggle("active", x === c); });
      showPlan(c.dataset.plan);
    });

    X.$("#ap-run").addEventListener("click", function () {
      var d = X.parseDate(X.$("#ap-date").value);
      var kind = X.$("#ap-kind").value;
      var levels = X.$("#ap-levels").value;
      var out = X.$("#ap-out"); out.innerHTML = "";
      if (!d) { out.innerHTML = '<div class="callout callout-warn">Enter the date on the denial notice.</div>'; return; }

      var internal = X.addDays(d, A.internalDays);
      var ui = X.urgency(X.iso(internal));
      var dec = A.decide.filter(function (x) { return x.k.toLowerCase().indexOf(kind === "post" ? "post" : kind === "pre" ? "pre" : "urgent") === 0; })[0] || A.decide[2];
      var decText = levels === "2" ? dec.two : dec.one;

      out.innerHTML =
        '<div class="callout ' + (ui.cls === "sev-high" ? "callout-warn" : "callout-info") + '">' +
        '<div style="margin-bottom:8px"><strong>File your internal appeal by ' + X.esc(X.fmt(internal)) + '</strong> — ' + X.esc(ui.label) + '.<br>' +
        '<span class="muted">The regulation says plans must allow <em>at least</em> 180 days, so yours may allow longer. Check the denial letter. Never treat 180 days as the maximum.</span></div>' +
        '<div><strong>Once filed, they must decide within ' + X.esc(decText) + '.</strong><br>' +
        '<span class="muted">' + X.esc(A.decideNote) + '</span></div>' +
        '</div>' +
        '<div class="callout callout-info" style="margin-top:10px">' +
        '<strong>After the final internal denial you get four months to request external review.</strong> That clock starts from the final denial, not from today — come back and add it when you have that letter.' +
        '</div>' +
        '<div class="btn-row"><button class="btn btn-sm" id="ap-track">Track the internal appeal deadline</button>' +
        '<button class="btn btn-ghost btn-sm" id="ap-draft">Draft the claim-file request first</button></div>' +
        '<p class="muted">Send the claim-file request the same day you get a denial. You cannot write a good appeal without knowing the exact criteria you are being measured against — and the plan must give you that evidence free of charge.</p>';

      X.$("#ap-track").addEventListener("click", function () {
        X.addDeadline({ kind: "appeal", label: "Internal appeal of an insurance denial must be filed", due: X.iso(internal), note: "180 days from the denial notice. Your plan may allow longer — check the letter." });
      });
      X.$("#ap-draft").addEventListener("click", function () {
        var host = X.$("#ap-letters");
        if (host) { host.scrollIntoView({ behavior: "smooth", block: "start" }); }
      });
    });
  }

  function showPlan(k) {
    var out = X.$("#plan-out");
    if (k === "unknown") {
      out.innerHTML = '<div class="card mini"><div class="li-main">How to find out</div><p class="muted">' + X.esc(A.planTypeHow) + '</p></div>';
      return;
    }
    var p = A.planTypes.filter(function (x) { return x.k === k; })[0];
    if (!p) { out.innerHTML = ""; return; }
    out.innerHTML =
      '<div class="card mini">' +
      '<div class="li-main">' + X.esc(p.n) + '</div>' +
      '<p>' + X.esc(p.t) + '</p>' +
      '<p><strong>Where your complaint goes.</strong> ' + X.esc(p.route) + '</p>' +
      '<div class="btn-row">' + X.a(p.who + " ↗", p.url, "btn btn-sm") + '</div>' +
      '</div>';
  }

  X.bootstrap("appeals", mount);
})();

/* Clapback — "Legal campaigns" module.
 * Tracks the legal campaigns being waged against the recruitment industry —
 * courts, regulators, prosecutors, and legislatures going after AI screening,
 * ghost jobs, wage-fixing, temp-labor abuses, missing pay ranges, and hiring
 * bias. Same rules as the ghost tracker: the feed is a researched snapshot
 * shipped with the extension (Clapback makes no network requests), every item
 * is dated, statused precisely, and sourced — primary sources where they
 * exist — and the follow links keep you current between releases.
 * Read-only: this tab stores nothing and profiles no one. Company names
 * appear only as they appear in public court and agency records.
 */
(function () {
  "use strict";
  var D = window.PDS;

  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  var KIND_LABEL = {
    courts: "Private litigation",
    criminal: "Criminal prosecution",
    enforcement: "Regulator action",
    legislation: "Legislation"
  };

  var FRONT_LABEL = {};
  (D.LEGAL_FRONTS || []).forEach(function (f) { FRONT_LABEL[f.id] = f.label; });

  var frontFilter = "all";
  var mounted = false;

  function counts() {
    var by = {};
    (D.LEGAL_FEED || []).forEach(function (i) { by[i.front] = (by[i.front] || 0) + 1; });
    return by;
  }

  function mount() {
    var view = $("#view-legal");
    if (!view || mounted) { if (mounted) renderFeed(); return; }
    mounted = true;

    view.innerHTML =
      '<h1 id="legal-h1">Legal campaigns</h1>' +
      '<p class="lede">The recruitment industry is being taken to court — on more fronts than ghost jobs. AI résumé screens face a collective action covering a billion applications, a staffing executive went to prison for fixing nurses’ wages, applicants are winning statutory damages over missing pay ranges, and temp-agency laws survived the industry’s own challenge. This tab tracks each campaign: what it targets, where it stands, and which of your tools it powers.</p>' +

      '<div class="callout callout-info">' +
      '<strong>How to read this tab.</strong> A “campaign” here means sustained, documented legal pressure on a recruiting practice — not one news cycle. Statuses are precise on purpose: an investigation is not a lawsuit, a passed bill is not a signed law, and one conviction is not an industry-wide rule. Every item is dated and sourced; nothing here is legal advice, and no individual is profiled — names appear only as they do in public court and agency records.' +
      '</div>' +

      '<div class="card">' +
      '<h2>The fronts</h2>' +
      '<p class="muted">Six distinct pressure campaigns, each aimed at a distinct practice. Pick one to filter the tracker below.</p>' +
      '<div class="chips" id="lc-chips" role="tablist" aria-label="Filter by front"></div>' +
      '<p class="muted" id="lc-front-blurb" aria-live="polite"></p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>The tracker</h2>' +
      '<p class="muted">Snapshot researched <strong>' + esc(D.LEGAL_UPDATED || "") + '</strong> — shipped with this version because Clapback makes no network requests of its own. Newest first. Ghost-job items appear here as headlines only; the full state-by-state ghost feed lives on the <button class="btn btn-ghost btn-sm" data-goto="ghostmap">Ghost map</button> tab.</p>' +
      '<div id="lc-feed"></div>' +
      '<div class="gm-follow"><strong>Follow it live:</strong> ' +
      (D.LEGAL_FOLLOW || []).map(function (f) { return '<a href="' + esc(f.u) + '" target="_blank" rel="noopener">' + esc(f.n) + " ↗</a>"; }).join(" · ") +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Turn a campaign into your next move</h2>' +
      '<p class="muted">These cases set the rules; your tools are how you use them. Each row below is the concrete step this tab’s campaigns make possible.</p>' +
      '<ul class="tidy">' +
      '<li><strong>An algorithm screened you out?</strong> Illinois, NYC, California, Colorado, and Texas now regulate AI hiring tools, and the EEOC takes these charges — the <button class="btn btn-ghost btn-sm" data-goto="hiring">Hiring rights</button> tab routes you to the right door with the deadline attached.</li>' +
      '<li><strong>Hit a ghost posting or a fake recruiter?</strong> Deceptive postings are reportable consumer fraud — file through <button class="btn btn-ghost btn-sm" data-goto="report">Report it</button>, and log it on the <button class="btn btn-ghost btn-sm" data-goto="ghostmap">Ghost map</button> so your evidence pack builds itself.</li>' +
      '<li><strong>Posting missing a pay range in a disclosure state?</strong> In Washington that omission alone carries statutory damages — elsewhere it’s reportable to the state labor or civil-rights agency in the <button class="btn btn-ghost btn-sm" data-goto="hiring">Hiring rights</button> state finder.</li>' +
      '<li><strong>Temp agency shorting your pay or safety?</strong> NJ and IL temp-worker laws survived the industry’s court challenge — wage complaints go to your state labor department via <button class="btn btn-ghost btn-sm" data-goto="report">Report it</button>, and an unregistered agency is itself reportable.</li>' +
      '<li><strong>Want your candidate file out of their systems?</strong> The <button class="btn btn-ghost btn-sm" data-goto="agencies">Staffing agencies</button> tab generates the deletion letter — the same data-harvesting concern several of these campaigns cite.</li>' +
      '</ul>' +
      '</div>' +

      '<p class="fineprint">A tracker, not legal advice — deadlines are short and statutes vary by state, so for anything high-stakes talk to an employment lawyer (the Hiring rights tab lists free legal-help lanes). Snapshot verified ' + esc(D.LEGAL_UPDATED || "") + '; if it happened after that, it’s in the follow links, not in this feed yet.</p>';

    // front filter chips (with counts)
    var by = counts();
    var chips = $("#lc-chips");
    var defs = [{ id: "all", label: "All fronts" }].concat(D.LEGAL_FRONTS || []);
    chips.innerHTML = defs.map(function (f, i) {
      var n = f.id === "all" ? (D.LEGAL_FEED || []).length : (by[f.id] || 0);
      return '<button class="chip' + (i === 0 ? " active" : "") + '" data-front="' + esc(f.id) + '" role="tab" aria-selected="' + (i === 0) + '">' + esc(f.label) + " (" + n + ")</button>";
    }).join("");
    chips.addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      frontFilter = c.dataset.front;
      chips.querySelectorAll(".chip").forEach(function (x) {
        x.classList.toggle("active", x === c);
        x.setAttribute("aria-selected", x === c ? "true" : "false");
      });
      renderBlurb();
      renderFeed();
    });

    renderBlurb();
    renderFeed();
  }

  function renderBlurb() {
    var el = $("#lc-front-blurb"); if (!el) return;
    if (frontFilter === "all") { el.textContent = ""; el.classList.add("hidden"); return; }
    var f = (D.LEGAL_FRONTS || []).filter(function (x) { return x.id === frontFilter; })[0];
    if (!f) { el.textContent = ""; el.classList.add("hidden"); return; }
    el.classList.remove("hidden");
    el.innerHTML = "<strong>" + esc(f.label) + ":</strong> " + esc(f.blurb);
  }

  function renderFeed() {
    var box = $("#lc-feed"); if (!box) return;
    var items = (D.LEGAL_FEED || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; })
      .filter(function (i) { return frontFilter === "all" || i.front === frontFilter; });

    if (!items.length) {
      box.innerHTML = '<p class="muted" style="margin-top:8px">No tracked items on this front — clear the filter, or check the follow links for anything newer than ' + esc(D.LEGAL_UPDATED || "this snapshot") + ".</p>";
      return;
    }
    box.innerHTML = items.map(function (i) {
      return '<div class="gm-feed-item">' +
        '<div class="gm-feed-head">' +
        '<span class="gm-feed-date">' + esc(i.date) + "</span>" +
        '<span class="seg-badge">' + esc(FRONT_LABEL[i.front] || i.front) + "</span>" +
        '<span class="seg-badge">' + esc(KIND_LABEL[i.kind] || i.kind) + "</span>" +
        (i.st ? '<span class="seg-badge">' + esc(STATE_NAME[i.st] || i.st) + "</span>" : "") +
        '<span class="gm-feed-status">' + esc(i.status) + "</span>" +
        "</div>" +
        "<strong>" + esc(i.title) + "</strong>" +
        '<p class="gm-feed-sum">' + esc(i.sum) + "</p>" +
        '<div class="gm-feed-src">Sources: ' + (i.src || []).map(function (s) {
          return '<a href="' + esc(s.u) + '" target="_blank" rel="noopener">' + esc(s.n) + " ↗</a>";
        }).join(" · ") + "</div>" +
        "</div>";
    }).join("");
  }

  /* ---------------- init ---------------- */
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="legal"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

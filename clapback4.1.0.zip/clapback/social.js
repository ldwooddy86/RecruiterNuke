/*
 * Clapback — social cleanup engine (content script, isolated world)
 *
 * SCOPE & SAFETY, up front:
 *   • This ONLY acts on the account you are already logged into, in your own
 *     browser. It has no credentials, no server, and cannot reach any other
 *     account. It makes NO network requests of its own — it clicks the site's
 *     own buttons, the same ones you would click by hand, just in sequence.
 *   • It never runs on its own. It stays completely dormant until YOU launch a
 *     cleanup from the Clapback dashboard or popup.
 *   • Destructive actions always offer a no-click Preview first, are paced with
 *     human-like pauses, are capped by a limit you set, and can be stopped
 *     instantly. Deletions on these platforms are permanent — the panel nudges
 *     you to download your data first.
 *
 * The UI lives in a Shadow DOM so the host page's CSS can't touch it and it
 * can't touch the host page's styles.
 */
(function () {
  "use strict";
  if (window.top !== window) return;               // top frame only
  if (window.__pdsSocialLoaded) return;
  window.__pdsSocialLoaded = true;

  var PDS = window.PDS || null;
  var HOST = (location.hostname || "").toLowerCase().replace(/^www\./, "");

  /* Which platform are we on? */
  function platformForHost() {
    if (!PDS || !PDS.SOCIAL_PLATFORMS) return null;
    for (var i = 0; i < PDS.SOCIAL_PLATFORMS.length; i++) {
      var p = PDS.SOCIAL_PLATFORMS[i];
      for (var h = 0; h < p.hosts.length; h++) {
        var host = p.hosts[h];
        if (HOST === host || HOST.slice(-(host.length + 1)) === "." + host) return p;
      }
    }
    return null;
  }
  var PLATFORM = platformForHost();
  if (!PLATFORM) return;                             // not a supported social host

  /* ------------------------------------------------------------------ *
   * Low-level helpers                                                    *
   * ------------------------------------------------------------------ */
  var STOP = false;         // cooperative stop flag for the running job
  var RUNNING = null;       // id of the running action, or null

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function rand(a, b) { return Math.floor(a + Math.random() * (b - a)); }
  function human() { return sleep(rand(1100, 2400)); }   // pacing between actions
  function text(el) { return (el && (el.innerText || el.textContent) || "").trim(); }
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && el.offsetParent !== null;
  }
  function all(sel, root) { try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); } catch (e) { return []; } }
  function one(sel, root) { try { return (root || document).querySelector(sel); } catch (e) { return null; } }

  // A "real" click: some SPA buttons need pointer events, not just .click().
  function click(el) {
    if (!el) return false;
    try {
      el.scrollIntoView({ block: "center" });
      var opts = { bubbles: true, cancelable: true, view: window };
      ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (t) {
        try { el.dispatchEvent(new MouseEvent(t, opts)); } catch (e) {}
      });
      if (typeof el.click === "function") el.click();
      return true;
    } catch (e) { return false; }
  }

  // Poll until fn() returns a truthy value or we time out.
  async function waitFor(fn, timeout, interval) {
    timeout = timeout || 6000; interval = interval || 180;
    var t = 0, v;
    while (t < timeout) {
      try { v = fn(); } catch (e) { v = null; }
      if (v) return v;
      await sleep(interval); t += interval;
    }
    return null;
  }

  // Find a clickable menu/dialog item by matching visible text (case-insensitive).
  function itemByText(root, re) {
    var nodes = all('[role="menuitem"], [role="button"], button, a, div[tabindex], span', root);
    for (var i = 0; i < nodes.length; i++) {
      if (!vis(nodes[i])) continue;
      var t = text(nodes[i]);
      if (t && re.test(t) && t.length < 40) return nodes[i];
    }
    return null;
  }

  async function pressEscape() {
    try { document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", keyCode: 27, bubbles: true })); } catch (e) {}
    await sleep(250);
  }

  // Progressive scrolling to force the timeline to load more items.
  var _lastH = 0, _dry = 0;
  async function loadMore() {
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(rand(700, 1200));
    var h = document.body.scrollHeight;
    if (h <= _lastH) _dry++; else _dry = 0;
    _lastH = h;
    return _dry < 4;   // false → nothing new after several tries
  }

  /* ------------------------------------------------------------------ *
   * Per-platform recipes.                                                *
   * Each recipe: { preview() -> Number, step() -> 'deleted'|'none'|'skip' }
   * `step` performs exactly ONE removal so the engine stays in control.  *
   * Selectors favour stable data-testids + text matching, with fallbacks.*
   * ------------------------------------------------------------------ */
  var RECIPES = {
    /* ---- X / Twitter ---- */
    "x-delete-posts": {
      preview: function () {
        return all('article[role="article"]').filter(function (a) {
          return !/promoted|ad$/i.test(text(a).slice(0, 40)) && !a.getAttribute("data-pds");
        }).length;
      },
      step: async function () {
        var art = all('article[role="article"]').filter(function (a) { return !a.getAttribute("data-pds") && vis(a); })[0];
        if (!art) return "none";
        art.setAttribute("data-pds", "seen");
        var caret = one('[data-testid="caret"]', art);
        if (!caret) return "skip";
        click(caret);
        var menu = await waitFor(function () { return one('[role="menu"]'); }, 4000);
        if (!menu) { await pressEscape(); return "skip"; }
        var del = itemByText(menu, /^delete$/i) || one('[data-testid="Dropdown"] [role="menuitem"]', menu);
        if (!del || !/delete/i.test(text(del))) { await pressEscape(); return "skip"; }   // not your post
        click(del);
        var confirm = await waitFor(function () { return one('[data-testid="confirmationSheetConfirm"]'); }, 4000);
        if (!confirm) { await pressEscape(); return "skip"; }
        click(confirm);
        await sleep(rand(600, 1000));
        return "deleted";
      }
    },
    "x-unretweet": {
      preview: function () { return all('[data-testid="unretweet"]').filter(vis).length; },
      step: async function () {
        var btn = all('[data-testid="unretweet"]').filter(vis)[0];
        if (!btn) return "none";
        click(btn);
        var confirm = await waitFor(function () { return one('[data-testid="unretweetConfirm"]'); }, 4000);
        if (!confirm) { await pressEscape(); return "skip"; }
        click(confirm);
        await sleep(rand(400, 800));
        return "deleted";
      }
    },
    "x-unlike": {
      preview: function () { return all('[data-testid="unlike"]').filter(vis).length; },
      step: async function () {
        var btn = all('[data-testid="unlike"]').filter(vis)[0];
        if (!btn) return "none";
        click(btn);
        await sleep(rand(300, 700));
        return "deleted";
      }
    },

    /* ---- Reddit (best-effort; Power Delete Suite / Redact are more reliable) ---- */
    "rd-delete-comments": {
      preview: function () {
        var c = all('shreddit-comment, [data-testid="comment"], .Comment').filter(vis).length;
        return c;
      },
      step: async function () {
        var comment = all('shreddit-comment, [data-testid="comment"], .Comment')
          .filter(function (n) { return vis(n) && !n.getAttribute("data-pds"); })[0];
        if (!comment) return "none";
        comment.setAttribute("data-pds", "seen");
        // open the overflow / more menu
        var more = one('[aria-label="more options" i], [aria-label*="more" i], button[aria-haspopup="menu"]', comment) ||
                   itemByText(comment, /^more$|^\.\.\.$|options/i);
        if (!more) return "skip";
        click(more);
        var menu = await waitFor(function () { return one('[role="menu"], [aria-label*="menu" i]'); }, 3500);
        if (!menu) { await pressEscape(); return "skip"; }
        var del = itemByText(menu, /^delete$/i);
        if (!del) { await pressEscape(); return "skip"; }
        click(del);
        var confirm = await waitFor(function () {
          return itemByText(document.body, /^delete$|^yes,? delete$|confirm/i);
        }, 3500);
        if (confirm) click(confirm);
        await sleep(rand(500, 900));
        return "deleted";
      }
    }
  };

  /* ------------------------------------------------------------------ *
   * The engine — drives a recipe with caps, pacing, and a hard stop.     *
   * ------------------------------------------------------------------ */
  async function runJob(actionId, limit, onProgress) {
    STOP = false; RUNNING = actionId; _lastH = 0; _dry = 0;
    var recipe = RECIPES[actionId];
    var done = 0, skipped = 0, emptyScrolls = 0;
    if (!recipe) { RUNNING = null; return { done: 0, stopped: false, error: "No recipe" }; }
    onProgress({ msg: "Starting… (only touching the account you're signed into)", done: 0, limit: limit });
    while (!STOP && done < limit) {
      var res = "none";
      try { res = await recipe.step(); } catch (e) { res = "skip"; }
      if (res === "deleted") {
        done++; emptyScrolls = 0;
        onProgress({ msg: "Removed " + done + " of up to " + limit + "…", done: done, limit: limit });
        await human();
      } else if (res === "skip") {
        skipped++;
        await sleep(rand(300, 600));
      } else { // 'none' — try to load more
        onProgress({ msg: "Loading more…", done: done, limit: limit });
        var more = await loadMore();
        emptyScrolls++;
        if (!more || emptyScrolls > 6) break;   // nothing left
      }
    }
    RUNNING = null;
    var stopped = STOP; STOP = false;
    return { done: done, skipped: skipped, stopped: stopped };
  }

  /* ------------------------------------------------------------------ *
   * Panel UI (Shadow DOM, fully isolated)                                *
   * ------------------------------------------------------------------ */
  var rootHost = null, shadow = null, panelBuilt = false;

  var PANEL_CSS = "\
:host { all: initial; }\
* { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; }\
.wrap { position: fixed; right: 18px; bottom: 18px; width: 372px; max-width: calc(100vw - 24px); max-height: calc(100vh - 36px); overflow: auto; background: #ffffff; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 14px; box-shadow: 0 18px 50px rgba(15,23,42,.32); z-index: 2147483000; font-size: 13.5px; line-height: 1.5; }\
.hd { display: flex; align-items: center; gap: 10px; padding: 13px 15px; background: #1F4936; color: #fff; border-radius: 14px 14px 0 0; position: sticky; top: 0; }\
.hd .ic { font-size: 18px; }\
.hd .t { font-weight: 700; font-size: 14px; flex: 1; }\
.hd button { background: rgba(255,255,255,.14); color: #fff; border: 0; border-radius: 7px; width: 26px; height: 26px; cursor: pointer; font-size: 15px; line-height: 1; }\
.hd button:hover { background: rgba(255,255,255,.26); }\
.bd { padding: 14px 15px 16px; }\
.note { background: #f0f9ff; border: 1px solid #bae6fd; color: #0c4a6e; border-radius: 10px; padding: 10px 12px; font-size: 12.5px; margin-bottom: 12px; }\
.note.warn { background: #fffbeb; border-color: #fde68a; color: #92400e; }\
.note b { color: inherit; }\
.dl { display: block; text-align: center; background: #1E6B45; color: #fff; text-decoration: none; border-radius: 9px; padding: 9px 12px; font-weight: 600; font-size: 13px; margin-bottom: 14px; }\
.dl:hover { background: #2F8A5C; }\
.card { border: 1px solid #e2e8f0; border-radius: 11px; padding: 12px 13px; margin-bottom: 11px; background: #fff; }\
.card h4 { margin: 0 0 3px; font-size: 13.5px; }\
.card p { margin: 0 0 9px; font-size: 12.5px; color: #475569; }\
.row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }\
.row label { font-size: 12px; color: #475569; }\
input[type=number] { width: 72px; border: 1px solid #CFC7B0; border-radius: 7px; padding: 6px 8px; font: inherit; font-size: 12.5px; }\
.btn { border: 0; border-radius: 8px; padding: 8px 12px; font-size: 12.5px; font-weight: 600; cursor: pointer; }\
.btn.p { background: #1E6B45; color: #fff; }\
.btn.p:hover { background: #2F8A5C; }\
.btn.g { background: #fff; color: #1F4936; border: 1px solid #CFC7B0; }\
.btn.g:hover { background: #f1f5f9; }\
.btn.d { background: #b91c1c; color: #fff; }\
.btn.d:hover { background: #dc2626; }\
.btn:disabled { opacity: .5; cursor: default; }\
.prog { margin-top: 10px; display: none; }\
.prog.on { display: block; }\
.bar { height: 8px; background: #e2e8f0; border-radius: 999px; overflow: hidden; margin-bottom: 6px; }\
.fill { height: 100%; width: 0; background: #1E6B45; transition: width .25s; }\
.log { font-size: 12px; color: #334155; max-height: 92px; overflow: auto; background: #f8fafc; border: 1px solid #eef2f7; border-radius: 8px; padding: 7px 9px; white-space: pre-wrap; }\
.gate { display: flex; align-items: flex-start; gap: 8px; font-size: 12px; color: #334155; margin: 9px 0; }\
.gate input { margin-top: 2px; }\
.assist ol { margin: 4px 0 10px; padding-left: 18px; font-size: 12.5px; color: #334155; }\
.assist ol li { margin-bottom: 5px; }\
.foot { font-size: 11px; color: #94a3b8; text-align: center; margin-top: 6px; }\
.min { position: fixed; right: 18px; bottom: 18px; z-index: 2147483000; background: #1F4936; color: #fff; border: 0; border-radius: 999px; padding: 11px 16px; font-weight: 700; font-size: 13px; cursor: pointer; box-shadow: 0 10px 30px rgba(15,23,42,.32); }\
";

  function elm(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  function downloadLink() {
    var d = (PLATFORM.links || []).find(function (l) { return l.kind === "download"; });
    return d ? d.url : null;
  }

  function buildPanel() {
    if (panelBuilt) { showPanel(); return; }
    rootHost = document.createElement("div");
    rootHost.id = "pds-social-root";
    rootHost.style.all = "initial";
    shadow = rootHost.attachShadow({ mode: "open" });
    var style = document.createElement("style"); style.textContent = PANEL_CSS; shadow.appendChild(style);

    var wrap = elm("div", "wrap");

    var hd = elm("div", "hd");
    hd.appendChild(elm("span", "ic", PLATFORM.icon));
    hd.appendChild(elm("span", "t", "Data Shield — clean up " + PLATFORM.name));
    var minBtn = elm("button", null, "–"); minBtn.title = "Minimize"; minBtn.addEventListener("click", minimize);
    var closeBtn = elm("button", null, "×"); closeBtn.title = "Close"; closeBtn.addEventListener("click", closePanel);
    hd.appendChild(minBtn); hd.appendChild(closeBtn);
    wrap.appendChild(hd);

    var bd = elm("div", "bd");

    var S = (PDS && PDS.SOCIAL_SAFETY) || {};
    var safe = elm("div", "note");
    safe.innerHTML = "<b>🔒 Your account only.</b> " + esc(S.ownOnly || "Acts only on the account you're signed into.");
    bd.appendChild(safe);

    var dl = downloadLink();
    if (dl) {
      var a = elm("a", "dl", "⬇ Download your " + PLATFORM.name + " data first");
      a.href = dl; a.target = "_blank"; a.rel = "noopener";
      bd.appendChild(a);
    }

    (PLATFORM.actions || []).forEach(function (act) {
      bd.appendChild(act.assist ? assistCard(act) : engineCard(act));
    });

    if (!(PLATFORM.actions || []).length) {
      bd.appendChild(elm("div", "note", "Use the platform links in the Clapback dashboard for " + PLATFORM.name + " — its safest cleanup is through the site's own settings."));
    }

    var brittle = elm("div", "note warn");
    brittle.innerHTML = "<b>Heads up.</b> " + esc(S.brittle || "") + " " + esc(S.tos || "");
    bd.appendChild(brittle);

    bd.appendChild(elm("div", "foot", "Clapback · local · no network requests of its own"));
    wrap.appendChild(bd);
    shadow.appendChild(wrap);
    document.documentElement.appendChild(rootHost);
    panelBuilt = true;
  }

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]; }); }

  function assistCard(act) {
    var card = elm("div", "card assist");
    card.appendChild(elm("h4", null, act.label));
    card.appendChild(elm("p", null, act.desc));
    var ol = document.createElement("ol");
    [
      "Click Open below to jump to " + PLATFORM.name + "'s own bulk tool.",
      "Use its multi-select to pick old items (it lets you select many at once).",
      "Delete or archive the selection — this is safer and faster than scripted clicking here."
    ].forEach(function (t) { var li = document.createElement("li"); li.textContent = t; ol.appendChild(li); });
    card.appendChild(ol);
    var open = elm("button", "btn p", "Open the native tool ↗");
    open.addEventListener("click", function () { window.open(act.where, "_blank", "noopener"); });
    card.appendChild(open);
    return card;
  }

  function engineCard(act) {
    var card = elm("div", "card");
    card.appendChild(elm("h4", null, act.label));
    card.appendChild(elm("p", null, act.desc + (act.whereHint ? " — " + act.whereHint : "")));

    var row = elm("div", "row");
    var lab = elm("label", null, "Max to remove:");
    var limit = document.createElement("input"); limit.type = "number"; limit.min = "1"; limit.max = "5000"; limit.value = "50";
    var preview = elm("button", "btn g", "Preview count");
    var start = elm("button", "btn d", "Start");
    var stop = elm("button", "btn g", "Stop"); stop.style.display = "none";
    row.appendChild(lab); row.appendChild(limit); row.appendChild(preview); row.appendChild(start); row.appendChild(stop);
    card.appendChild(row);

    var gate = elm("div", "gate");
    var gcb = document.createElement("input"); gcb.type = "checkbox";
    var gid = "g-" + act.id; gcb.id = gid;
    var gl = document.createElement("label"); gl.setAttribute("for", gid);
    gl.textContent = "I understand this permanently deletes from my own account and can't be undone.";
    gate.appendChild(gcb); gate.appendChild(gl);
    if (act.gate) card.appendChild(gate);

    var prog = elm("div", "prog");
    var bar = elm("div", "bar"); var fill = elm("div", "fill"); bar.appendChild(fill);
    var log = elm("div", "log", "");
    prog.appendChild(bar); prog.appendChild(log);
    card.appendChild(prog);

    function setLog(m) { log.textContent = m; }
    function setFill(done, lim) { fill.style.width = (lim ? Math.min(100, (done / lim) * 100) : 0) + "%"; }

    preview.addEventListener("click", function () {
      try {
        var n = RECIPES[act.id] ? RECIPES[act.id].preview() : 0;
        prog.classList.add("on");
        setLog(n > 0
          ? "Found about " + n + " item(s) currently loaded on this page. Scroll down to load more, or just Start — it keeps loading as it goes."
          : "Found 0 right now. Make sure you're on the right page (" + (act.whereHint || "your profile") + "). If it's still 0, the site may have changed and this recipe needs updating — use the platform's own tools meanwhile.");
      } catch (e) { setLog("Couldn't read the page."); }
    });

    start.addEventListener("click", async function () {
      if (RUNNING) { setLog("Another cleanup is already running — let it finish or Stop it."); return; }
      if (act.gate && !gcb.checked) { prog.classList.add("on"); setLog("Tick the confirmation box first."); return; }
      var lim = Math.max(1, Math.min(5000, parseInt(limit.value, 10) || 50));
      prog.classList.add("on");
      preview.disabled = true; start.disabled = true; limit.disabled = true; stop.style.display = "";
      var out = await runJob(act.id, lim, function (p) { setLog(p.msg); setFill(p.done, p.limit); });
      preview.disabled = false; start.disabled = false; limit.disabled = false; stop.style.display = "none";
      setFill(out.done, lim);
      setLog((out.stopped ? "Stopped. " : "Done. ") + "Removed " + out.done + " item(s)"
        + (out.skipped ? " (skipped " + out.skipped + " that weren't removable here)" : "")
        + ". Re-run to continue if more remain.");
    });

    stop.addEventListener("click", function () { STOP = true; setLog("Stopping…"); });
    return card;
  }

  var minimized = null;
  function minimize() {
    if (rootHost) rootHost.style.display = "none";
    if (minimized) return;
    minimized = document.createElement("div");
    var sh = minimized.attachShadow({ mode: "open" });
    var st = document.createElement("style"); st.textContent = PANEL_CSS; sh.appendChild(st);
    var b = document.createElement("button"); b.className = "min"; b.textContent = "🛡 Data Shield";
    b.addEventListener("click", function () { restore(); });
    sh.appendChild(b);
    minimized.id = "pds-social-min";
    document.documentElement.appendChild(minimized);
  }
  function restore() {
    if (minimized && minimized.parentNode) minimized.parentNode.removeChild(minimized);
    minimized = null;
    if (rootHost) rootHost.style.display = "";
  }
  function showPanel() { if (rootHost) rootHost.style.display = ""; restore(); }
  function closePanel() {
    STOP = true;
    if (rootHost && rootHost.parentNode) rootHost.parentNode.removeChild(rootHost);
    if (minimized && minimized.parentNode) minimized.parentNode.removeChild(minimized);
    rootHost = shadow = minimized = null; panelBuilt = false;
  }

  /* ------------------------------------------------------------------ *
   * Activation — dormant until the user launches from the dashboard.     *
   * ------------------------------------------------------------------ */
  function activate() { buildPanel(); }

  // 1) storage flag set by the dashboard/popup right before opening this tab
  try {
    chrome.storage && chrome.storage.local.get(["socialActivate"], function (d) {
      if (chrome.runtime && chrome.runtime.lastError) return;
      var f = d && d.socialActivate;
      if (f && f.platform === PLATFORM.id && (Date.now() - (f.ts || 0) < 120000)) {
        chrome.storage.local.remove("socialActivate");
        // let the SPA settle before we inject
        setTimeout(activate, 800);
      }
    });
    // 2) if the flag is set while we're already here
    chrome.storage && chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !ch.socialActivate) return;
      var f = ch.socialActivate.newValue;
      if (f && f.platform === PLATFORM.id) { chrome.storage.local.remove("socialActivate"); activate(); }
    });
    // 3) direct message (popup "clean this site")
    chrome.runtime && chrome.runtime.onMessage.addListener(function (msg, _s, resp) {
      if (msg && msg.type === "PDS_SOCIAL_ACTIVATE") { activate(); resp && resp({ ok: true }); }
      return false;
    });
  } catch (e) { /* extension context missing; stay dormant */ }
})();

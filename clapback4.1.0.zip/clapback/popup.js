/* Clapback — popup logic (MV3-safe, no inline scripts) */
(function () {
  "use strict";
  var D = window.PDS;
  var V = window.PDSVet;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  var STALE_MS = D.RECHECK_DAYS * 24 * 60 * 60 * 1000;
  var ownPhone = "";

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function set(obj) { return hasChrome ? chrome.storage.local.set(obj) : Promise.resolve(); }
  function openUrl(url) { if (hasChrome && chrome.tabs) chrome.tabs.create({ url: url }); else window.open(url, "_blank"); window.close(); }
  function openExt(rel) { openUrl(hasChrome && chrome.runtime ? chrome.runtime.getURL(rel) : rel); }

  function countProgress(raw, items) {
    var done = 0, stale = 0, now = Date.now();
    (items || []).forEach(function (it) {
      var v = raw && raw[it.id];
      if (v === true) { done++; return; }
      if (v && typeof v === "object" && v.done) { done++; if (typeof v.at === "number" && now - v.at > STALE_MS) stale++; }
    });
    return { done: done, stale: stale };
  }

  function renderProgress(d) {
    var b = countProgress(d.brokerProgress, D.BROKERS);
    var total = D.BROKERS.length;
    document.getElementById("pop-optouts").textContent = b.done + " / " + total;
    document.getElementById("pop-fill").style.width = (total ? (b.done / total * 100) : 0) + "%";
    var bits = [];
    if (b.stale) bits.push(b.stale + " due for recheck");
    bits.push(total + "+ brokers & people-search sites");
    document.getElementById("pop-note").textContent = bits.join(" · ");
  }

  function applyTheme(settings) {
    try {
      var s = settings || {};
      var theme = s.theme || "system";
      if (theme === "system") theme = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
      document.documentElement.setAttribute("data-theme", theme);
      var reduce = s.motion || (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
      document.documentElement.setAttribute("data-motion", reduce ? "reduce" : "no");
    } catch (e) {}
  }

  var LEVEL = {
    high: { cls: "pv-high", label: "High risk" },
    caution: { cls: "pv-caution", label: "Caution" },
    low: { cls: "pv-low", label: "No strong signals" }
  };

  function runVet() {
    var raw = (document.getElementById("pv-input").value || "").trim();
    var box = document.getElementById("pv-result");
    if (!raw) { box.classList.add("hidden"); return; }
    var res;
    try { res = V.run(raw, { ownNumber: ownPhone }); } catch (e) { return; }
    var ui = LEVEL[res.level] || LEVEL.low;
    box.innerHTML = "";
    var pill = document.createElement("div");
    pill.className = "pv-pill " + ui.cls;
    pill.textContent = ui.label + " · checked as " + res.type;
    box.appendChild(pill);
    var top = res.signals.filter(function (s) { return s.sev === "high"; })[0] ||
              res.signals.filter(function (s) { return s.sev === "caution"; })[0] ||
              res.signals[0];
    if (top) { var p = document.createElement("div"); p.className = "pv-sig"; p.textContent = top.text; box.appendChild(p); }
    var more = document.createElement("button"); more.className = "pv-more"; more.textContent = "Full check & what to do ↗";
    more.addEventListener("click", function () { openExt("dashboard.html#vet"); });
    box.appendChild(more);
    box.classList.remove("hidden");
  }

  document.addEventListener("DOMContentLoaded", function () {
    get(["settings", "profile", "brokerProgress"]).then(function (d) {
      ownPhone = (d.profile && d.profile.phone) || "";
      var settings = d.settings || { detectorEnabled: true };
      applyTheme(settings);
      var toggle = document.getElementById("detector-toggle");
      toggle.checked = settings.detectorEnabled !== false;
      toggle.addEventListener("change", function () { settings.detectorEnabled = toggle.checked; set({ settings: settings }); });
      renderProgress(d);
    });

    document.getElementById("pv-go").addEventListener("click", runVet);
    document.getElementById("pv-input").addEventListener("keydown", function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") runVet();
    });

    document.querySelectorAll("[data-open]").forEach(function (b) {
      b.addEventListener("click", function () { openExt(b.getAttribute("data-open")); });
    });
    document.querySelectorAll("[data-url]").forEach(function (b) {
      b.addEventListener("click", function () { openUrl(b.getAttribute("data-url")); });
    });
  });
})();

/*
 * Clapback — shared helpers for the medical bills & credit modules  (window.CBX)
 *
 * Small, boring, and shared so the seven new tabs don't each reimplement
 * storage, escaping, letters, and date math. Runs entirely on-device.
 * Makes no network requests.
 */
window.CBX = (function () {
  "use strict";

  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  /* ---------------- storage ---------------- */
  function get(keys) {
    if (hasChrome) return chrome.storage.local.get(keys);
    return Promise.resolve((Array.isArray(keys) ? keys : [keys]).reduce(function (o, k) {
      try { var v = localStorage.getItem("pds_" + k); if (v != null) o[k] = JSON.parse(v); } catch (e) {}
      return o;
    }, {}));
  }
  function set(obj) {
    if (hasChrome) return chrome.storage.local.set(obj);
    try { Object.keys(obj).forEach(function (k) { localStorage.setItem("pds_" + k, JSON.stringify(obj[k])); }); } catch (e) {}
    return Promise.resolve();
  }

  /* ---------------- DOM ---------------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function toast(msg) {
    if (window.__pdsToast) window.__pdsToast(msg);
  }
  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { toast("Copied to clipboard"); },
        function () { toast("Copy failed — select and copy manually"); }
      );
    } else { toast("Copy not available — select the text manually"); }
  }
  /* Safe external link markup for innerHTML-built views. */
  function a(label, url, cls) {
    return '<a class="' + (cls || "btn btn-ghost btn-sm") + '" href="' + esc(url) +
      '" target="_blank" rel="noopener" style="display:inline-block;text-decoration:none">' + esc(label) + '</a>';
  }
  function srcLine(name, url) {
    if (!url) return name ? '<div class="fineprint">Source: ' + esc(name) + '</div>' : "";
    return '<div class="fineprint">Source: <a href="' + esc(url) + '" target="_blank" rel="noopener">' + esc(name || url) + '</a></div>';
  }

  /* ---------------- dates ---------------- */
  var DAY = 86400000;
  function parseDate(v) {
    if (!v) return null;
    var parts = String(v).split("-");
    if (parts.length === 3) {
      var d = new Date(+parts[0], +parts[1] - 1, +parts[2]);
      return isNaN(d.getTime()) ? null : d;
    }
    var g = new Date(v);
    return isNaN(g.getTime()) ? null : g;
  }
  function addDays(date, n) { return new Date(date.getTime() + n * DAY); }
  /* Business days: skips Saturdays and Sundays. Federal holidays vary year to
     year, so we deliberately do NOT model them — we say so in the UI and
     advise treating the result as the earliest possible date. */
  function addBusinessDays(date, n) {
    var d = new Date(date.getTime()), added = 0;
    while (added < n) {
      d = addDays(d, 1);
      var w = d.getDay();
      if (w !== 0 && w !== 6) added++;
    }
    return d;
  }
  function fmt(date) {
    if (!date) return "";
    try { return date.toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" }); }
    catch (e) { return date.toDateString(); }
  }
  function fmtShort(date) {
    if (!date) return "";
    try { return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
    catch (e) { return date.toDateString(); }
  }
  function iso(date) {
    if (!date) return "";
    var m = String(date.getMonth() + 1); if (m.length < 2) m = "0" + m;
    var d = String(date.getDate()); if (d.length < 2) d = "0" + d;
    return date.getFullYear() + "-" + m + "-" + d;
  }
  function daysUntil(date) {
    if (!date) return null;
    var t = new Date(); t.setHours(0, 0, 0, 0);
    var x = new Date(date.getTime()); x.setHours(0, 0, 0, 0);
    return Math.round((x.getTime() - t.getTime()) / DAY);
  }
  function todayStr() {
    try { return new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }); }
    catch (e) { return new Date().toDateString(); }
  }

  /* ---------------- deadlines ---------------- */
  /* One shared store, written by every module, surfaced in the Deadlines tab
     and on the Overview. { id, kind, label, due (ISO), note, created } */
  function loadDeadlines() {
    return get(["medDeadlines"]).then(function (d) {
      return Array.isArray(d.medDeadlines) ? d.medDeadlines : [];
    });
  }
  function addDeadline(item) {
    return loadDeadlines().then(function (list) {
      var id = "d" + (list.length ? (Math.max.apply(null, list.map(function (x) { return parseInt(String(x.id).slice(1), 10) || 0; })) + 1) : 1);
      var row = {
        id: id,
        kind: item.kind || "other",
        label: item.label || "Deadline",
        due: item.due || "",
        note: item.note || "",
        created: iso(new Date())
      };
      list.push(row);
      return set({ medDeadlines: list }).then(function () {
        toast("Added to your deadline tracker");
        broadcast();
        return row;
      });
    });
  }
  function removeDeadline(id) {
    return loadDeadlines().then(function (list) {
      var next = list.filter(function (x) { return x.id !== id; });
      return set({ medDeadlines: next }).then(function () { broadcast(); return next; });
    });
  }
  var listeners = [];
  function onDeadlines(fn) { listeners.push(fn); }
  function broadcast() { listeners.forEach(function (fn) { try { fn(); } catch (e) {} }); }

  /* Urgency banding for the UI. */
  function urgency(due) {
    var n = daysUntil(parseDate(due));
    if (n === null) return { cls: "sev-info", label: "" };
    if (n < 0) return { cls: "sev-high", label: "Passed " + Math.abs(n) + " day" + (Math.abs(n) === 1 ? "" : "s") + " ago" };
    if (n === 0) return { cls: "sev-high", label: "TODAY" };
    if (n <= 7) return { cls: "sev-high", label: n + " day" + (n === 1 ? "" : "s") + " left" };
    if (n <= 30) return { cls: "sev-caution", label: n + " days left" };
    return { cls: "sev-ok", label: n + " days left" };
  }

  /* ---------------- profile ---------------- */
  /* Clapback's core profile has name/email/phone/city/state/notes. The medical
     modules also want a street address, ZIP, and household size for the
     poverty-level calculator. Those live in a separate key so importing an
     older backup never breaks. */
  var EXTRA_DEFAULT = { addr: "", zip: "", household: "", income: "" };
  function profile() {
    return get(["profile", "medProfile"]).then(function (d) {
      var p = d.profile || {};
      var x = Object.assign({}, EXTRA_DEFAULT, d.medProfile || {});
      return {
        name: p.name || "", email: p.email || "", phone: p.phone || "",
        city: p.city || "", state: p.state || "", notes: p.notes || "",
        addr: x.addr, zip: x.zip, household: x.household, income: x.income
      };
    });
  }
  function saveExtra(obj) {
    return get(["medProfile"]).then(function (d) {
      var next = Object.assign({}, EXTRA_DEFAULT, d.medProfile || {}, obj);
      return set({ medProfile: next });
    });
  }

  /* ---------------- letters ---------------- */
  function fillLetter(body, p, vars) {
    var v = vars || {};
    return String(body)
      .replace(/\{\{name\}\}/g, p.name || "[Your full name]")
      .replace(/\{\{addr\}\}/g, p.addr || "[Your street address]")
      .replace(/\{\{city\}\}/g, p.city || "[City]")
      .replace(/\{\{state\}\}/g, p.state || "[State]")
      .replace(/\{\{zip\}\}/g, p.zip || "[ZIP]")
      .replace(/\{\{email\}\}/g, p.email || "[Your email]")
      .replace(/\{\{phone\}\}/g, p.phone || "[Your phone]")
      .replace(/\{\{today\}\}/g, todayStr())
      .replace(/\{\{to\}\}/g, v.to || "[Recipient name]\n[Recipient address]")
      .replace(/\{\{acct\}\}/g, v.acct || "[Account number]")
      .replace(/\{\{amount\}\}/g, v.amount || "[Amount]")
      .replace(/\{\{dos\}\}/g, v.dos || "[Date(s) of service]")
      .replace(/\{\{provider\}\}/g, v.provider || "[Provider name]")
      .replace(/\{\{deadline\}\}/g, v.deadline || "[Deadline]");
  }

  /* A reusable letter output panel appended to any container. */
  function letterPanel(container, letter, text) {
    var box = $(".cbx-letter", container);
    if (!box) {
      box = el("div", "letter-output cbx-letter");
      container.appendChild(box);
    }
    box.classList.remove("hidden");
    box.innerHTML = "";

    var head = el("div", "letter-tools");
    var h = el("strong", null, letter.n);
    head.appendChild(h);
    var tools = el("div", "btn-row");
    tools.style.margin = "0";

    var cSub = el("button", "btn btn-ghost btn-sm", "Copy subject line");
    cSub.addEventListener("click", function () { copy(fillLetterSubject(letter, text)); });
    var cBody = el("button", "btn btn-sm", "Copy letter");
    cBody.addEventListener("click", function () { copy(text); });
    var cPrint = el("button", "btn btn-ghost btn-sm", "Print / save as PDF");
    cPrint.addEventListener("click", function () { printText(letter.n, text); });
    var cClose = el("button", "btn btn-ghost btn-sm", "Close");
    cClose.addEventListener("click", function () { box.classList.add("hidden"); });
    tools.appendChild(cBody); tools.appendChild(cSub); tools.appendChild(cPrint); tools.appendChild(cClose);
    head.appendChild(tools);
    box.appendChild(head);

    if (letter.when) {
      var w = el("div", "callout callout-info");
      w.style.margin = "10px 0";
      w.innerHTML = "<strong>When to use it.</strong> " + esc(letter.when) +
        (letter.send ? '<div style="margin-top:8px"><strong>How to send it.</strong> ' + esc(letter.send) + "</div>" : "");
      box.appendChild(w);
    }
    if (letter.sub) {
      var sub = el("div", "ghost-subject");
      sub.textContent = "Subject: " + fillLetterSubject(letter, text);
      box.appendChild(sub);
    }
    var ta = el("textarea", "letter-text");
    ta.value = text;
    ta.setAttribute("aria-label", letter.n + " — editable letter text");
    ta.rows = 22;
    box.appendChild(ta);

    var fine = el("p", "fineprint", "Edit anything in the box before you send it — anything in [square brackets] needs your details. Nothing here is legal advice, and nothing leaves this device.");
    box.appendChild(fine);

    box.scrollIntoView({ behavior: "smooth", block: "nearest" });
    return box;
  }
  var _lastSubject = "";
  function fillLetterSubject(letter, text) { return _lastSubject || letter.sub || letter.n; }
  function setSubject(s) { _lastSubject = s; }

  function printText(title, text) {
    var w = window.open("", "_blank");
    if (!w) { toast("Your browser blocked the print window"); return; }
    var html = '<!doctype html><html><head><meta charset="utf-8"><title>' + esc(title) +
      '</title><style>body{font:13px/1.55 Georgia,serif;margin:48px;white-space:pre-wrap;max-width:6.5in}</style></head><body>' +
      esc(text) + "</body></html>";
    w.document.write(html);
    w.document.close();
    setTimeout(function () { try { w.print(); } catch (e) {} }, 250);
  }

  /* Render the letter library for one category into a container.
     ctxFn() supplies the case details (recipient, account, amount, dates). */
  function letterCards(container, cat, ctxFn) {
    var lib = window.CBL;
    if (!lib) return;
    container.innerHTML = "";
    var list = lib.LETTERS.filter(function (x) { return x.cat === cat; });
    var out = el("div", "cbx-letter-host");
    list.forEach(function (L) {
      var card = el("div", "link-item");
      card.style.alignItems = "flex-start";
      var left = el("div");
      var title = el("div", "li-main", L.n + (L.first ? "  ·  start here" : ""));
      if (L.first) title.style.color = "var(--accent, #1E6B45)";
      left.appendChild(title);
      left.appendChild(el("div", "li-note", L.when));
      card.appendChild(left);
      var b = el("button", "btn btn-sm", "Draft it");
      b.addEventListener("click", function () {
        profile().then(function (p) {
          var vars = ctxFn ? ctxFn() : {};
          var text = fillLetter(L.body, p, vars);
          setSubject(fillLetter(L.sub || L.n, p, vars));
          letterPanel(out, L, text);
        });
      });
      card.appendChild(b);
      container.appendChild(card);
    });
    container.appendChild(out);
  }

  /* ---------------- misc ---------------- */
  function stateName(abbr) {
    var D = window.PDS;
    if (!D || !D.STATES) return abbr;
    var s = D.STATES.find(function (x) { return x[0] === abbr; });
    return s ? s[1] : abbr;
  }
  function money(n) {
    var v = Number(n);
    if (!isFinite(v)) return "";
    return "$" + v.toLocaleString("en-US", { maximumFractionDigits: 0 });
  }
  function stateSelect(id, sel, includeAll) {
    var D = window.PDS;
    var out = '<select class="input" id="' + id + '">';
    if (includeAll) out += '<option value="">' + esc(includeAll) + "</option>";
    (D && D.STATES ? D.STATES : []).forEach(function (p) {
      out += '<option value="' + p[0] + '"' + (p[0] === sel ? " selected" : "") + ">" + esc(p[1]) + "</option>";
    });
    return out + "</select>";
  }
  /* Mount helper matching the rest of Clapback: mount on load and on nav click. */
  function bootstrap(view, mount) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
    else mount();
    var btn = document.querySelector('[data-view="' + view + '"]');
    if (btn) btn.addEventListener("click", mount);
  }

  return {
    hasChrome: hasChrome,
    get: get, set: set,
    $: $, $$: $$, esc: esc, el: el, a: a, srcLine: srcLine, toast: toast, copy: copy,
    parseDate: parseDate, addDays: addDays, addBusinessDays: addBusinessDays,
    fmt: fmt, fmtShort: fmtShort, iso: iso, daysUntil: daysUntil, todayStr: todayStr, urgency: urgency,
    loadDeadlines: loadDeadlines, addDeadline: addDeadline, removeDeadline: removeDeadline, onDeadlines: onDeadlines,
    profile: profile, saveExtra: saveExtra,
    fillLetter: fillLetter, letterPanel: letterPanel, letterCards: letterCards, setSubject: setSubject, printText: printText,
    stateName: stateName, money: money, stateSelect: stateSelect, bootstrap: bootstrap
  };
})();

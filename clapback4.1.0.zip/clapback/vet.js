/*
 * Clapback — local vetting engine (window.PDSVet)
 *
 * Judges whether an inbound EMAIL, PHONE, URL, or MESSAGE that contacted YOU
 * shows signs of being a scam or spoof. Everything runs locally in your browser:
 * it inspects the text you paste and returns risk signals plus what to do. It
 * does NOT look up who owns anything, and it makes no network requests.
 *
 * Limits worth knowing: heuristics flag *patterns*, not verdicts. A clean result
 * is not proof something is safe, and a flag is not proof of fraud — it's a
 * prompt to slow down and verify through official channels.
 */
window.PDSVet = (function () {
  "use strict";
  var D = window.PDS || {};

  /* ---------------- shared helpers ---------------- */

  // Multi-part public suffixes we care about (small, common set).
  var MULTI_TLD = ["co.uk", "org.uk", "gov.uk", "ac.uk", "com.au", "net.au", "org.au",
    "co.nz", "co.jp", "com.br", "co.in", "com.mx", "com.sg", "co.za"];

  function labelsOf(host) { return (host || "").toLowerCase().split("."); }

  function registrable(host) {
    host = (host || "").toLowerCase().replace(/^\.+|\.+$/g, "");
    var parts = host.split(".");
    if (parts.length <= 2) return host;
    var lastTwo = parts.slice(-2).join(".");
    var lastThree = parts.slice(-3).join(".");
    if (MULTI_TLD.indexOf(lastTwo) >= 0) return lastThree;
    return lastTwo;
  }
  function tldOf(host) {
    var parts = (host || "").toLowerCase().split(".");
    return parts.length ? parts[parts.length - 1] : "";
  }

  // Normalize common look-alike substitutions so "paypa1" -> "paypal", "arnazon" -> "amazon".
  function deHomoglyph(s) {
    s = (s || "").toLowerCase();
    try { s = s.normalize("NFKD").replace(/[̀-ͯ]/g, ""); } catch (e) {}
    s = s.replace(/rn/g, "m").replace(/vv/g, "w").replace(/cl/g, "d");
    s = s.replace(/0/g, "o").replace(/1/g, "l").replace(/3/g, "e").replace(/4/g, "a")
         .replace(/5/g, "s").replace(/6/g, "g").replace(/7/g, "t").replace(/8/g, "b")
         .replace(/9/g, "g").replace(/\$/g, "s").replace(/@/g, "a").replace(/!/g, "i").replace(/\|/g, "l");
    return s;
  }

  function levenshtein(a, b) {
    a = a || ""; b = b || "";
    var m = a.length, n = b.length;
    if (!m) return n; if (!n) return m;
    var prev = new Array(n + 1), cur = new Array(n + 1), i, j;
    for (j = 0; j <= n; j++) prev[j] = j;
    for (i = 1; i <= m; i++) {
      cur[0] = i;
      for (j = 1; j <= n; j++) {
        var cost = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      }
      for (j = 0; j <= n; j++) prev[j] = cur[j];
    }
    return prev[n];
  }

  // Does `host` try to look like a known brand it doesn't actually belong to?
  // Returns null, or { brand, kind, real } where kind is 'token'|'typo'|'homoglyph'.
  function brandImpersonation(host) {
    var brands = D.IMPERSONATED_BRANDS || [];
    var reg = registrable(host);
    var hostWords = host.replace(/[^a-z0-9]+/gi, " ").toLowerCase();
    // De-homoglyphed views catch digit/character swaps like "paypa1", "g00gle".
    var deReg = deHomoglyph(reg);
    var deHost = deHomoglyph(host);
    var deHostWords = deHost.replace(/[^a-z0-9]+/gi, " ").toLowerCase();
    // If the registrable domain is genuinely ANY known brand's, it's not
    // impersonation — checked up front so two real brands that happen to sit
    // near each other (e.g. shiftkey.com / shiftmed.com) never cross-flag.
    for (var i0 = 0; i0 < brands.length; i0++) {
      if (brands[i0].domains.indexOf(reg) >= 0) return null;
    }
    for (var i = 0; i < brands.length; i++) {
      var br = brands[i];
      // Homoglyph attack: normalized domain resolves to a real brand domain.
      for (var d = 0; d < br.domains.length; d++) {
        if (deReg === br.domains[d] && reg !== br.domains[d]) return { brand: br.name, kind: "homoglyph", real: br.domains[0] };
      }
      // Typosquat: registrable domain within edit-distance 2 of a brand domain.
      for (var t = 0; t < br.domains.length; t++) {
        var bd = br.domains[t];
        if (reg !== bd && Math.abs(reg.length - bd.length) <= 3) {
          var dist = levenshtein(reg, bd);
          // Distance budget scales with length: dist-2 on a 7-char domain
          // matches far too much of the legitimate namespace.
          var maxd = bd.length >= 10 ? 2 : 1;
          if (dist > 0 && dist <= maxd && bd.length >= 8) return { brand: br.name, kind: "typo", real: bd };
        }
      }
      // Token abuse: brand name sits in the domain but the registrable domain isn't
      // the brand's. Checked against both the raw domain and a de-homoglyphed copy,
      // so "paypa1-secure.com" or "amaz0n-login.net" still trip it.
      for (var k = 0; k < br.tokens.length; k++) {
        var tok = br.tokens[k];
        var hit;
        if (/[^a-z0-9]/.test(tok)) {
          hit = host.toLowerCase().indexOf(tok) >= 0 || deHost.indexOf(tok) >= 0;
        } else {
          var re = new RegExp("\\b" + tok + "\\b");
          hit = re.test(hostWords) || re.test(deHostWords);
        }
        if (hit) {
          // Whole-word match on the de-homoglyphed brand token indicates a swap
          // when the raw host didn't already contain it literally.
          var swapped = !new RegExp("\\b" + tok.replace(/[^a-z0-9]/g, "") + "\\b").test(hostWords) && !/[^a-z0-9]/.test(tok);
          return { brand: br.name, kind: swapped ? "homoglyph" : "token", real: br.domains[0] };
        }
      }
    }
    return null;
  }

  function levelFromScore(score) { return score >= 5 ? "high" : score >= 2 ? "caution" : "low"; }
  function sig(sev, text) { return { sev: sev, text: text }; }

  /* ---------------- EMAIL ---------------- */
  function email(addr) {
    addr = (addr || "").trim();
    var m = /^([^\s@]+)@([^\s@]+\.[^\s@]+)$/.exec(addr);
    var out = { type: "email", input: addr, level: "low", score: 0, signals: [], recommend: [], verify: (D.VERIFY_LINKS || {}).email || [] };
    if (!m) { out.signals.push(sig("info", "That doesn't parse as a normal email address (name@domain). Double-check it before trusting it.")); out.level = "caution"; return out; }
    var local = m[1].toLowerCase(), host = m[2].toLowerCase();
    var reg = registrable(host), tld = tldOf(host);
    var score = 0;

    var imp = brandImpersonation(host);
    if (imp) {
      score += 6;
      if (imp.kind === "homoglyph") out.signals.push(sig("high", "The domain “" + host + "” is a look-alike of " + imp.brand + " using swapped characters. The real address would end in @" + imp.real + "."));
      else if (imp.kind === "typo") out.signals.push(sig("high", "The domain “" + host + "” is one or two characters off from " + imp.brand + " (" + imp.real + ") — a classic typosquat."));
      else out.signals.push(sig("high", "This uses the " + imp.brand + " name in the domain, but the real domain is " + imp.real + ", not " + reg + ". Brands send from their own domain."));
    }

    if ((D.FREEMAIL || []).indexOf(reg) >= 0) {
      // Freemail is normal for individuals, but not for a claimed institution.
      var brandInLocal = (D.IMPERSONATED_BRANDS || []).some(function (br) {
        return br.tokens.some(function (tk) { return local.indexOf(tk.replace(/[^a-z0-9]/g, "")) >= 0; });
      });
      if (brandInLocal) { score += 5; out.signals.push(sig("high", "This claims a brand in the name part but sends from a free mailbox (" + reg + "). Real companies don't email you from Gmail/Outlook/etc.")); }
      else out.signals.push(sig("info", "Sent from a free personal mailbox (" + reg + "). Normal for an individual — but no company or agency will contact you from one."));
    }

    if ((D.RISKY_TLDS || []).indexOf(tld) >= 0) { score += 2; out.signals.push(sig("caution", "The domain ends in .​" + tld + ", a top-level domain heavily used in spam and phishing.")); }
    if (host.split(".").some(function (l) { return l.indexOf("xn--") === 0; })) { score += 4; out.signals.push(sig("high", "The domain uses punycode (xn--…), which can hide look-alike foreign characters. Treat with suspicion.")); }
    if ((reg.match(/-/g) || []).length >= 2) { score += 1; out.signals.push(sig("caution", "The domain has several hyphens — common in throwaway phishing domains (e.g. “secure-account-verify”).")); }
    if (/\d{3,}/.test(reg)) { score += 1; out.signals.push(sig("caution", "The domain contains a long run of digits, which is unusual for a real organization.")); }

    if (!out.signals.length) out.signals.push(sig("ok", "No obvious look-alike or spoofing patterns in the address itself."));

    out.recommend = [
      "Never click a link or open an attachment just because the address looks right — display names and even domains can be faked or look-alikes.",
      "To verify, ignore this message and reach the company through a number or website you already trust (the back of your card, the official app).",
      "Check whether this address shows up in known breaches (link below) — if so, expect more targeted phishing."
    ];
    out.score = score; out.level = levelFromScore(score);
    return out;
  }

  /* ---------------- PHONE ---------------- */
  function phone(num, opts) {
    opts = opts || {};
    var raw = (num || "").trim();
    var digits = raw.replace(/[^\d]/g, "");
    var out = { type: "phone", input: raw, level: "low", score: 0, signals: [], recommend: [], verify: (D.VERIFY_LINKS || {}).phone || [] };
    var own = ((opts.ownNumber || "").replace(/[^\d]/g, "") || "");
    var score = 0;

    var national = digits;
    if (national.length === 11 && national.charAt(0) === "1") national = national.slice(1);
    var area = national.length >= 10 ? national.slice(0, 3) : "";
    var prefix = national.length >= 10 ? national.slice(3, 6) : "";

    var ownNat = own;
    if (ownNat.length === 11 && ownNat.charAt(0) === "1") ownNat = ownNat.slice(1);
    var ownArea = ownNat.slice(0, 3), ownPrefix = ownNat.slice(3, 6);

    if (national.length && national.length < 10 && digits.length < 10) {
      out.signals.push(sig("info", "That's shorter than a standard 10-digit US number — could be a short code (many are legitimate) or an international number."));
    }

    if (own && national.length >= 10 && national === ownNat) {
      score += 5; out.signals.push(sig("high", "This is your OWN number showing as the caller — a dead giveaway of caller-ID spoofing. You are not calling yourself."));
    } else if (own && area && area === ownArea && prefix && prefix === ownPrefix) {
      score += 4; out.signals.push(sig("high", "The area code and first three digits match your own number. “Neighbor spoofing” fakes a nearby number so you'll pick up — a very common scam pattern."));
    } else if (own && area && area === ownArea) {
      out.signals.push(sig("info", "Shares your area code. Scammers often spoof a local-looking number; a familiar area code proves nothing."));
    }

    var tollfree = ["800", "888", "877", "866", "855", "844", "833", "822"];
    if (tollfree.indexOf(area) >= 0) out.signals.push(sig("info", "Toll-free number. Legitimate businesses use these — but so do robocallers, and toll-free numbers can be spoofed too."));
    if (area === "900") { score += 3; out.signals.push(sig("high", "900 numbers are premium-rate — calling back can cost you money.")); }
    if (national.length >= 10 && /^(\d)\1{9}$/.test(national)) { score += 2; out.signals.push(sig("caution", "The number is all the same digit — almost certainly fake/spoofed.")); }
    if (area && (area.charAt(0) === "0" || area.charAt(0) === "1")) { score += 2; out.signals.push(sig("caution", "US area codes never start with 0 or 1 — this number looks invalid or spoofed.")); }

    out.signals.push(sig("info", "Caller ID is trivially faked. The name and number you see prove nothing about who is actually calling or texting."));

    out.recommend = [
      "Don't call back the number shown or in the voicemail. If it claims to be your bank/utility/agency, hang up and dial the official number from their website or your card.",
      "Never share passwords, one-time codes, SSN, or card details with an inbound caller — no real institution asks for those this way.",
      "If it's a robocall or scam, don't press buttons or speak much — that confirms a live line. Block the number and report it (links below)."
    ];
    out.score = score; out.level = levelFromScore(score);
    if (out.level === "low") out.signals.unshift(sig("ok", "No strong spoofing signals from the number itself — but caller ID alone can't tell you it's genuine."));
    return out;
  }

  /* ---------------- URL / DOMAIN ---------------- */
  function url(u) {
    var raw = (u || "").trim();
    var out = { type: "url", input: raw, level: "low", score: 0, signals: [], recommend: [], verify: (D.VERIFY_LINKS || {}).domain || [] };
    var work = raw;
    var hadProto = /^[a-z][a-z0-9+.\-]*:\/\//i.test(work);
    if (!hadProto) work = "http://" + work;
    var host = "", parsed = null, protocol = "";
    try { parsed = new URL(work); host = parsed.hostname.toLowerCase(); protocol = parsed.protocol; }
    catch (e) { out.signals.push(sig("info", "That doesn't parse as a normal web address. If it came in a message, treat unexpected links as suspicious.")); out.level = "caution"; return out; }
    var reg = registrable(host), tld = tldOf(host), score = 0;

    if (/@/.test(raw.replace(/^[a-z]+:\/\//i, ""))) { score += 5; out.signals.push(sig("high", "The link contains an “@” before the domain. Everything before @ is ignored by browsers — the real destination is what comes after it. Classic disguise trick.")); }
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) { score += 4; out.signals.push(sig("high", "The link points at a raw IP address instead of a domain name — legitimate companies don't send you to bare IPs.")); }
    if (host.split(".").some(function (l) { return l.indexOf("xn--") === 0; })) { score += 4; out.signals.push(sig("high", "The domain uses punycode (xn--…), which can disguise look-alike foreign characters.")); }

    var imp = brandImpersonation(host);
    if (imp) {
      score += 6;
      if (imp.kind === "homoglyph") out.signals.push(sig("high", "“" + host + "” is a character-swapped look-alike of " + imp.brand + " (real: " + imp.real + ")."));
      else if (imp.kind === "typo") out.signals.push(sig("high", "“" + host + "” is a near-miss typosquat of " + imp.brand + " (real: " + imp.real + ")."));
      else out.signals.push(sig("high", "This puts the " + imp.brand + " name in the address, but the real domain is " + reg + ", not " + imp.real + ". The brand's real site would be on " + imp.real + "."));
    }

    var labels = host.split(".");
    if (labels.length >= 5) { score += 2; out.signals.push(sig("caution", "The address has many subdomain parts (e.g. login.secure.verify…). Scammers stack these to bury the real domain, which is always the last two labels: " + reg + ".")); }
    if ((D.URL_SHORTENERS || []).indexOf(reg) >= 0) { score += 2; out.signals.push(sig("caution", "This is a link shortener — the real destination is hidden. Don't tap it blind; expand it first or skip it.")); }
    if ((D.RISKY_TLDS || []).indexOf(tld) >= 0) { score += 2; out.signals.push(sig("caution", "The domain ends in .​" + tld + ", a top-level domain heavily abused for phishing.")); }
    if (protocol === "http:" && hadProto) { score += 1; out.signals.push(sig("caution", "The link is plain http (not https). Never enter credentials or personal info on a non-secure page.")); }
    if ((reg.match(/-/g) || []).length >= 2) { score += 1; out.signals.push(sig("caution", "The domain has several hyphens — common in disposable phishing domains.")); }

    if (!out.signals.length) out.signals.push(sig("ok", "No obvious disguise patterns. The real domain is “" + reg + "” — make sure that's who you expected."));

    out.recommend = [
      "The only part that matters is the registrable domain (the last two labels before the first slash): here that's “" + reg + "”. Everything else can be dressed up.",
      "Don't log in via a link someone sent you. Open a new tab and type the site's address yourself, or use your saved bookmark/app.",
      "When in doubt, run the domain through Google Safe Browsing or VirusTotal (links below) before visiting."
    ];
    out.score = score; out.level = levelFromScore(score);
    return out;
  }

  /* ---------------- MESSAGE TEXT ---------------- */
  function message(text) {
    var raw = (text || "").trim();
    var low = raw.toLowerCase();
    var out = { type: "message", input: raw.length > 400 ? raw.slice(0, 400) + "…" : raw, level: "low", score: 0, signals: [], recommend: [], verify: (D.VERIFY_LINKS || {}).report || [] };
    var groups = D.SCAM_PHRASES || {};
    var hitCats = [];
    Object.keys(groups).forEach(function (cat) {
      var matches = groups[cat].filter(function (p) { return low.indexOf(p) >= 0; });
      if (matches.length) hitCats.push({ cat: cat, matches: matches.slice(0, 4) });
    });
    var score = hitCats.length * 2;
    hitCats.forEach(function (h) {
      out.signals.push(sig(hitCats.length >= 3 ? "high" : "caution", h.cat + ": “" + h.matches.join("”, “") + "”"));
    });

    // Links in the body → offer to check them.
    var links = raw.match(/\b((?:https?:\/\/|www\.)[^\s]+)|([a-z0-9-]+\.[a-z]{2,}\/[^\s]*)/gi);
    if (links && links.length) { out.signals.push(sig("caution", "Contains " + links.length + " link" + (links.length > 1 ? "s" : "") + ". Paste each one into the URL check above before tapping.")); score += 1; out.foundLinks = links.slice(0, 5); }

    if (!hitCats.length) out.signals.push(sig("ok", "No classic scam-language patterns matched. That alone doesn't make it safe — keep your guard up if it's unexpected or asks for money, codes, or logins."));
    else out.signals.unshift(sig("info", "Detected " + hitCats.length + " manipulation tactic" + (hitCats.length > 1 ? "s" : "") + " commonly used in scams. The more tactics stacked together, the higher the risk."));

    out.recommend = [
      "Slow down. Manufactured urgency (“act now,” “account suspended”) is the scammer's main tool — real institutions give you time.",
      "Never pay with gift cards, wire transfers, or crypto at someone's instruction, and never share a login or one-time code. Those requests are scams, full stop.",
      "Verify independently: contact the person/company through a channel you already trust, not the number or link in this message."
    ];
    out.score = score; out.level = levelFromScore(score);
    return out;
  }

  /* ---------------- classify + run ---------------- */
  function classify(str) {
    var s = (str || "").trim();
    if (!s) return "message";
    // Whitespace present: a spaced phone number, otherwise free-text message.
    if (/\s/.test(s)) {
      var pd = s.replace(/[^\d]/g, "");
      if (!/[a-zA-Z@\/:]/.test(s.replace(/[\s()+\-.]/g, "")) && pd.length >= 7 && pd.length <= 15) return "phone";
      return "message";
    }
    // URL first — a scheme, www., or an "@" used as a disguise inside a link.
    if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(s)) return "url";
    if (/^www\./i.test(s)) return "url";
    if (s.indexOf("@") >= 0 && s.indexOf("/") >= 0) return "url";
    if (/^([^\s@]+)@([^\s@]+\.[^\s@]+)$/.test(s)) return "email";
    if (/^[a-z0-9-]+(\.[a-z0-9-]+)+(\/|$)/i.test(s)) return "url";
    var digits = s.replace(/[^\d]/g, "");
    if (!/[a-zA-Z]/.test(s.replace(/[\s()+\-.]/g, "")) && digits.length >= 7 && digits.length <= 15) return "phone";
    return "message";
  }

  function run(str, opts) {
    var kind = classify(str);
    if (kind === "email") return email(str);
    if (kind === "url") return url(str);
    if (kind === "phone") return phone(str, opts);
    return message(str);
  }

  return { run: run, classify: classify, email: email, phone: phone, url: url, message: message,
           _registrable: registrable, _brandImpersonation: brandImpersonation };
})();

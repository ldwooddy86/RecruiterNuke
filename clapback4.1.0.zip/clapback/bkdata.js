/*
 * Clapback — bankruptcy & student loan discharge dataset  (window.CBB)
 *
 * Every number in the 51-state table was checksummed against the published
 * national totals before it went in here. The 51 filing rows sum to 575,614,
 * which is the Administrative Office's 581,570 consumer total less the 5,956
 * filed in Puerto Rico, the Virgin Islands, Guam and the Northern Marianas —
 * the table covers the 50 states and DC only. Chapter 13 shares recompute
 * from the same table, the Chapter 13 completion column sums to the BAPCPA
 * Report's own national figure, and the population column sums to the Census
 * national total exactly. One widely-circulated population source failed that
 * check and was discarded — which is the whole reason for doing it.
 *
 * On the geography of student loan discharge: no government agency publishes
 * student-loan-specific discharge data by district or state. The judiciary
 * publishes adversary proceeding counts per district but does not code them
 * by nature of suit. The only district-level map that exists was built by
 * hand from PACER dockets by three law professors, and it counts FILINGS,
 * not outcomes. Clapback publishes that map, labels it precisely, and states
 * the gap rather than inventing the rest.
 *
 * Verified August 22–23, 2026. Not legal advice.
 */
window.CBB = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  /* ================================================================== */
  /* NATIONAL TOTALS                                                     */
  /* ================================================================== */
  var NATIONAL = {
    period: "the 12 months ending June 30, 2026",
    total: 608511,
    consumer: 581570,
    business: 26941,
    ch7: 366863,      // consumer only
    ch13: 214153,     // consumer only
    yoy: "+12.0% consumer, +12.2% overall",
    rate: 168.4,      // consumer filings per 100k population
    ch13share: 36.9,
    src: "Administrative Office of the U.S. Courts, Table F-2",
    url: "https://www.uscourts.gov/data-news/data-tables/2026/06/30/bankruptcy-filings/f-2",
    prUrl: "https://www.uscourts.gov/data-news/judiciary-news/2026/07/28/bankruptcies-rise-122-percent",
    context: "Filings have risen every quarter since mid-2022, but they remain far below the historic peaks — 2005 and 2010 each exceeded 1.5 million. The rise is real and sustained. It is not a spike."
  };

  /* ================================================================== */
  /* STATE TABLE — consumer filings, 12 months ending June 30, 2026      */
  /* [ consumer filings, population, per 100k, Ch13 share %, Ch13        */
  /*   completion % ] — completion is from BAPCPA Report Table 6, cases  */
  /*   TERMINATED in the 12 months to Dec 31 2024: plans completed over  */
  /*   total terminated, districts summed to states. Different table,    */
  /*   different period from the filing columns. Flagged in the UI.      */
  /* ================================================================== */
  var STATES = {
    AL: [21412, 5193088, 412.3, 70.3, 52.9], MS: [10137, 2954160, 343.1, 54.4, 53.5],
    TN: [22354, 7315076, 305.6, 56.7, 45.4], NV: [9515, 3282188, 289.9, 16.8, 46.9],
    GA: [32494, 11302748, 287.5, 54.2, 42.7], KY: [12534, 4606864, 272.1, 44.9, 54.6],
    IN: [18442, 6973333, 264.5, 43.9, 58.6], AR: [7338, 3114791, 235.6, 58.1, 51.3],
    MI: [23306, 10127884, 230.1, 31.6, 48.0], UT: [7980, 3538904, 225.5, 33.7, 42.1],
    OH: [26796, 11900510, 225.2, 23.0, 57.3], LA: [10186, 4618189, 220.6, 75.1, 48.4],
    IL: [26941, 12719141, 211.8, 40.9, 49.1], MD: [13103, 6265347, 209.1, 36.1, 43.1],
    FL: [46701, 23462518, 199.0, 29.0, 44.6], OR: [7994, 4273586, 187.1, 20.5, 60.6],
    VA: [16471, 8880107, 185.5, 39.7, 55.8], OK: [7548, 4123288, 183.1, 17.2, 57.2],
    MO: [11154, 6270541, 177.9, 43.1, 54.7], MN: [10155, 5830405, 174.2, 22.6, 64.9],
    AZ: [12939, 7623818, 169.7, 16.9, 51.9], WI: [9911, 5972787, 165.9, 35.2, 53.3],
    DE: [1557, 1059952, 146.9, 36.7, 54.5], CO: [8778, 6012561, 146.0, 18.6, 52.4],
    NJ: [13832, 9548215, 144.9, 36.6, 47.0], KS: [4254, 2977220, 142.9, 47.1, 71.0],
    NE: [2850, 2018006, 141.2, 33.0, 69.9], CA: [54719, 39355309, 139.0, 17.6, 46.9],
    ID: [2484, 2029733, 122.4, 8.1, 57.8], WA: [9767, 8001020, 122.1, 21.2, 65.2],
    TX: [37406, 31709821, 118.0, 37.3, 37.1], IA: [3534, 3238387, 109.1, 18.0, 52.8],
    NY: [21607, 20002427, 108.0, 32.3, 27.0], WV: [1844, 1766147, 104.4, 20.2, 64.5],
    PA: [13613, 13059432, 104.2, 44.6, 50.7], ND: [808, 799358, 101.1, 12.7, 59.3],
    RI: [1105, 1114521, 99.1, 24.3, 59.0], SC: [5471, 5570274, 98.2, 66.5, 50.0],
    WY: [562, 588753, 95.5, 14.8, 30.8], CT: [3484, 3688496, 94.5, 15.5, 35.5],
    NC: [10423, 11197968, 93.1, 64.7, 59.8], DC: [565, 693645, 81.5, 24.6, 32.9],
    HI: [1139, 1432820, 79.5, 37.3, 61.5], NM: [1646, 2125498, 77.4, 12.9, 57.8],
    MT: [883, 1144694, 77.1, 17.1, 69.7], SD: [718, 935094, 76.8, 20.3, 60.8],
    MA: [5056, 7154084, 70.7, 32.2, 44.4], NH: [972, 1415342, 68.7, 25.8, 61.9],
    VT: [283, 644663, 43.9, 24.4, 70.7], ME: [572, 1414874, 40.4, 22.2, 69.6],
    AK: [271, 737270, 36.8, 26.9, 40.7]
  };
  var STATE_NOTE = "Consumer (non-business) filings for the 12 months ending June 30, 2026, from Table F-2 of the Administrative Office of the U.S. Courts, with districts summed to states and per-capita computed against Census Vintage 2025 population. The Chapter 13 completion column comes from a different table and a different period: BAPCPA Report Table 6, Chapter 13 cases TERMINATED in the 12 months ending December 31, 2024 — cases mostly filed three to five years earlier — showing the share that ended with the plan completed. The rest were dismissed or converted to another chapter. Don't read the two columns as the same cohort.";
  var STATE_NOTE_URL = "https://www.uscourts.gov/data-news/data-tables/2024/12/31/bankruptcy-abuse-prevention-and-consumer-protection-act-bapcpa/bapcpa-6";
  var STATE_HEADLINE = "Alabama files consumer bankruptcy at 11 times the rate of Alaska. Same federal statute, same forms, same court system, an eleven-fold spread.";

  var CH13_HIGH = [
    { d: "Alabama Middle", v: 82.1 }, { d: "Georgia Southern", v: 81.9 }, { d: "Louisiana Western", v: 80.2 },
    { d: "Alabama Southern", v: 77.9 }, { d: "North Carolina Eastern", v: 75.0 }, { d: "Louisiana Eastern", v: 74.5 },
    { d: "Tennessee Western (Memphis)", v: 73.0 }, { d: "Georgia Middle", v: 68.9 }, { d: "South Carolina", v: 66.5 }
  ];
  var CH13_LOW = [
    { d: "Idaho", v: 8.1 }, { d: "Oklahoma Eastern", v: 11.3 }, { d: "Oklahoma Northern", v: 11.6 },
    { d: "North Dakota", v: 12.7 }, { d: "New Mexico", v: 12.9 }, { d: "California Southern", v: 13.6 },
    { d: "West Virginia Southern", v: 14.5 }, { d: "Wyoming", v: 14.8 }, { d: "California Central (LA)", v: 14.9 }
  ];
  var CH13_STORY = {
    head: "The chapter you file matters enormously, and where you live largely decides it",
    body: "Chapter 7 wipes out qualifying debt in about four months. Chapter 13 puts you on a three-to-five-year payment plan, and you only get the discharge if you finish. Of the Chapter 13 cases that ended in the 12 months to December 2024, 49.4% ended with the plan completed. The rest were dismissed or converted to another chapter.",
    bodySrc: "Administrative Office of the U.S. Courts, BAPCPA Report Table 6 (12 months ending December 31, 2024)",
    bodyUrl: "https://www.uscourts.gov/data-news/data-tables/2024/12/31/bankruptcy-abuse-prevention-and-consumer-protection-act-bapcpa/bapcpa-6",
    spread: "The share of consumer filings that are Chapter 13 runs from 82% in the Middle District of Alabama to 8% in Idaho. A ten-fold spread under one federal statute.",
    compound: "Chapter 13 share and Chapter 13 completion are two different measures on two different maps, and a state can be bad on both. Tennessee is one: 57% of its consumer filings are Chapter 13 — well above the 37% national share — and only 45% of its Chapter 13 plans finish, below the 49% national rate. Georgia is worse on completion at 43%. Compare the two map modes for your own state before you accept advice about which chapter to file. (Share is by district; completion is by state — the completion table is not published by district.)",
    race: "There is peer-reviewed evidence that this is not neutral. A 2025 study found Black filers use Chapter 13 at 46% versus 23% for white filers, and that minority filers face a Chapter 13 dismissal rate 12.7 points higher — with the researchers attributing at least 15% of that gap, after controls, to taste-based or inaccurate statistical bias. An earlier audit study found attorneys recommended Chapter 13 more often to couples cued as Black, on identical financial facts.",
    raceSrc: "Argyle, Indarte, Iverson & Palmer, NBER Working Paper 33575 (2025); Braucher, Cohen & Lawless, Journal of Empirical Legal Studies (2012)",
    raceUrl: "https://www.nber.org/system/files/working_papers/w33575/w33575.pdf",
    fees: "A commonly offered structural explanation is fees: Chapter 13 attorney fees can be paid out of the plan over time, while Chapter 7 counsel generally must be paid up front — a decisive constraint if you have no cash. That explanation is widely repeated but Clapback could not find it quantified, so treat it as a plausible account rather than a measured finding.",
    use: "What to do with this: if you are in a high-Chapter-13 district and someone steers you toward Chapter 13, ask directly why Chapter 7 is not right for you, and ask what the completion rate is in that district. Both are fair questions and a good lawyer will answer them."
  };

  /* ================================================================== */
  /* WHERE STUDENT LOAN DISCHARGE ACTUALLY HAPPENS                       */
  /* ================================================================== */
  var SLAP = {
    head: "Where student loan discharge cases are filed",
    lead: "This is the map, and it comes with a caveat that matters: it shows where cases are FILED, not where they succeed. No dataset anywhere breaks down student loan discharge OUTCOMES by geography.",
    src: "Belisa Pang, Dalié Jiménez & Matthew A. Bruckner, “Full Discharge Ahead? An Empirical First Look at the New Student Loan Discharge Process in Bankruptcy,” 41 Emory Bankruptcy Developments Journal 259 (2025), Table 1",
    url: "https://scholarlycommons.law.emory.edu/ebdj/vol41/iss2/3/",
    method: "Built by hand from PACER and Bloomberg Law dockets across all 94 bankruptcy districts, covering November 18, 2022 through October 15, 2024 — the 23 months after the Justice Department's new guidance. Total: 2,514 cases, a 330% increase over the comparable period before it.",
    /* Top 10 are consistent across extractions. Ranks 11–15 share the same
       values but the extracted ordering was internally inconsistent, so they
       are presented as an unordered group. */
    top: [
      { d: "District of Minnesota", st: "MN", cir: "8th", post: 244, pre: 8 },
      { d: "Western District of Washington", st: "WA", cir: "9th", post: 114, pre: 4 },
      { d: "Middle District of Florida", st: "FL", cir: "11th", post: 107, pre: 13 },
      { d: "Northern District of Ohio", st: "OH", cir: "6th", post: 100, pre: 14 },
      { d: "Northern District of Illinois", st: "IL", cir: "7th", post: 84, pre: 12 },
      { d: "District of Oregon", st: "OR", cir: "9th", post: 72, pre: 12 },
      { d: "Central District of California", st: "CA", cir: "9th", post: 67, pre: 34 },
      { d: "Southern District of Indiana", st: "IN", cir: "7th", post: 63, pre: 7 },
      { d: "Eastern District of Michigan", st: "MI", cir: "6th", post: 56, pre: 22 },
      { d: "Eastern District of Tennessee", st: "TN", cir: "6th", post: 56, pre: 0 }
    ],
    also: { d: "Also in the top 15, values confirmed but their exact order not", st: ["GA", "VA", "AL", "AZ", "NV"],
      t: "Northern District of Georgia (54), Western District of Virginia (54), Middle District of Alabama (52), District of Arizona (50), and District of Nevada (43). Clapback shows these as a group rather than a ranked list because three separate readings of the published table returned an ordering that contradicts a descending sort. The values are almost certainly right; the ranks among them are not worth asserting." },
    derived: "Clapback's arithmetic on the article's figures: those top 15 districts account for about 48% of every student loan discharge case filed in the country, from 16% of the districts. Minnesota alone is about 10% of the national total.",
    zero: "Four districts had none at all in either period: South Dakota, the Virgin Islands, Guam, and the Northern Mariana Islands.",
    /* The counterintuitive part — and the reason to publish this honestly. */
    why: {
      head: "Why Minnesota? Not the legal test — and this is the most useful thing on this page",
      body: "The obvious explanation is the circuit split. The Eighth Circuit, which includes Minnesota, uses a “totality of the circumstances” test rather than the stricter Brunner test every other deciding circuit applies. It looks like the answer. It isn't.",
      evidence: "The leading empirical study found no statistically significant difference in outcomes between Brunner circuits and the Eighth Circuit. Its author put it plainly: identical debtors filing in a Brunner circuit and a totality circuit should expect similar outcomes.",
      evidenceSrc: "Jason Iuliano, 86 American Bankruptcy Law Journal 495 (2012)",
      kicker: "And the geography argues against the doctrinal explanation too: Minnesota is first by a wide margin, but no other Eighth Circuit district appears in the top 15 at all. If the test were driving it, the whole circuit would light up.",
      real: "The researchers attribute the concentration to early adopters — courts and local consumer bankruptcy bars that took up the new process, “potentially due to greater awareness, resources, or a more proactive legal community.” Note the correlation: four courts published their own guidance on their websites, and one of them, the Western District of Washington, ranks second nationally.",
      pardo: "A separate study of every undue hardship case in one district found that case characteristics the law deems irrelevant — attorney experience and which judge you drew — significantly affected outcomes. Geography matters here, but the operative unit may be the courtroom, not the circuit.",
      soWhat: "What this means for you: your circuit's legal test is not your destiny, and being outside Minnesota is not a reason to give up. What predicts whether these cases get filed is whether local lawyers know the process exists. That is a question you can answer with a phone call — ask a consumer bankruptcy attorney in your area whether they have filed one under the 2022 Justice Department guidance."
    },
    gap: "The honest gap: the federal judiciary publishes adversary proceeding counts for every bankruptcy district, but does not code them by nature of suit — so no government dataset shows where student loan discharge cases are filed. The Justice Department surveyed all 94 U.S. Attorney's Offices and published no geographic breakdown at all. And nothing anywhere — government or academic — breaks down student loan discharge OUTCOMES by district or state. Clapback will not build a map out of numbers that don't exist."
  };

  var THE_GAP = {
    head: "The number that should change how you think about this",
    rows: [
      { big: "139,000", t: "student loan borrowers filed for bankruptcy in 2024." },
      { big: "692", t: "of them filed the separate lawsuit required to try to discharge the loans — about 1 in 201." },
      { big: "~87%", t: "of the resolved cases one researcher counted ended in a full or partial discharge." }
    ],
    rowNote: "That 87% is Jason Iuliano's own count of 652 resolved cases. The Justice Department reports 98%. Iuliano questions the Department's methodology, so Clapback shows the lower, independently derived number and tells you the other exists.",
    quote: "Over the longer run the ratio is worse still. The researcher who compiled the filing data put it this way, about the whole 2011–2024 period: for every five hundred student loan borrowers in bankruptcy, 499 give up without even attempting to discharge their student loans.",
    span: "Across 2011–2024, more than three million student loan borrowers filed for bankruptcy. 7,293 — two-tenths of one percent — even attempted a student loan discharge. The 2024 rate, 1 in 201, is several times better than that long-run average and still leaves 99.5% not trying.",
    src: "Jason Iuliano, “Bridging the Student Loan Bankruptcy Gap,” 99 Am. Bankr. L.J. Iss. 3 (2025)",
    url: "https://www.ablj.org/bridging-the-student-loan-bankruptcy-gap-vol-99-issue-3-html/",
    point: "The barrier is not that these cases lose — most of the few that are brought succeed. The barrier is that almost nobody files one. One caution on the causal story: success rates were climbing before 2022 too (39% in 2007, 61% in 2017, 87% after the reforms), and the researcher behind those numbers reads the rise as a longer-term pattern rather than something the 2022 guidance alone produced."
  };

  /* ================================================================== */
  /* THE LAW                                                             */
  /* ================================================================== */
  var CIRCUITS = {
    "1st": { t: "Unsettled", c: "In re Nash (1st Cir. 2006) declined to choose a test. The circuit's Bankruptcy Appellate Panel applies totality of the circumstances.", states: ["ME", "MA", "NH", "RI"] },
    "2nd": { t: "Brunner", c: "Brunner v. New York State Higher Education Services Corp. (2d Cir. 1987) — where the test comes from.", states: ["CT", "NY", "VT"] },
    "3rd": { t: "Brunner", c: "In re Faish (3d Cir. 1995)", states: ["DE", "NJ", "PA"] },
    "4th": { t: "Brunner", c: "In re Frushour (4th Cir. 2005)", states: ["MD", "NC", "SC", "VA", "WV"] },
    "5th": { t: "Brunner — strictest", c: "In re Gerhardt (5th Cir. 2003). Described as requiring a showing that repayment would impose intolerable difficulties — a hardening of Brunner, not a softening.", states: ["LA", "MS", "TX"] },
    "6th": { t: "Brunner", c: "Oyler v. ECMC (6th Cir. 2005)", states: ["KY", "MI", "OH", "TN"] },
    "7th": { t: "Brunner", c: "In re Roberson (7th Cir. 1993); applied flexibly in Krieger v. ECMC (7th Cir. 2013)", states: ["IL", "IN", "WI"] },
    "8th": { t: "Totality of the circumstances", c: "Long v. ECMC (8th Cir. 2003). Looks at past, present and reasonably reliable future resources; reasonable and necessary living expenses; and any other relevant circumstances.", states: ["AR", "IA", "MN", "MO", "NE", "ND", "SD"] },
    "9th": { t: "Brunner", c: "In re Pena (9th Cir. 1998)", states: ["AK", "AZ", "CA", "HI", "ID", "MT", "NV", "OR", "WA"] },
    "10th": { t: "Brunner — expressly softened", c: "ECMC v. Polleys (10th Cir. 2004): the terms must be applied so that debtors who truly cannot afford to repay may have their loans discharged, and an overly restrictive reading fails the Code's fresh-start purpose.", states: ["CO", "KS", "NM", "OK", "UT", "WY"] },
    "11th": { t: "Brunner", c: "In re Cox (11th Cir. 2003)", states: ["AL", "FL", "GA"] },
    "DC": { t: "No circuit-level precedent", c: "The bankruptcy court applies Brunner.", states: ["DC"] }
  };
  var CIRCUIT_NOTE = "Two corrections to things you may have read. The Second Circuit never softened Brunner — a 2020 bankruptcy court decision that read it leniently was reversed by the district court. And the Tenth Circuit's softening is real and quotable, which makes it the most useful case to cite outside the Eighth Circuit. But remember the outcome evidence: the doctrinal map is uneven, and the evidence that it drives results is weak.";
  var BRUNNER = [
    "You cannot maintain a minimal standard of living for yourself and your dependents, based on current income and expenses, if forced to repay.",
    "Additional circumstances indicate that this inability is likely to persist for a significant portion of the repayment period.",
    "You have made good faith efforts to repay."
  ];

  var GUIDANCE = {
    head: "What changed in November 2022",
    date: "November 17, 2022",
    body: "The Justice Department, working with the Department of Education, issued guidance creating a standardized process. You complete an Attestation form and give it to the Assistant U.S. Attorney handling your case. If it shows present inability to pay (measured against IRS collection standards), future inability to pay, and good faith efforts to repay, the government may stipulate to the facts establishing undue hardship and recommend discharge to the court.",
    presumptions: [
      "You are 65 or older",
      "You have a disability or chronic injury affecting your income",
      "You were unemployed for at least 5 of the last 10 years",
      "You are currently unemployed",
      "You did not get the degree the loan was for",
      "The school closed",
      "You cannot get work in the field you trained for",
      "Your current income is not enough and is unlikely to rise",
      "The loan has been in repayment status, other than in-school, for at least 10 years"
    ],
    presumptionNote: "Any one of these creates a presumption that your inability to pay will persist — the prong that historically sank the most cases. The form also takes “other circumstances,” so not matching this list is not the end of the inquiry. Read Section III of the form itself rather than screening yourself out on a summary.",
    results: "The Justice Department reported 632 cases in the first ten months, with 99% of decided cases producing a full or partial discharge. By March 2024 it reported 1,220 cases and 98% providing relief. An independent academic count of 652 resolved cases found 87% successful, 502 of them — 77% — resolved by settlement, with exactly one decided on the merits.",
    resultsNote: "Clapback could not independently source the frequently repeated “mean discharge of $85,000” or the claim that 97% of borrowers entered the process voluntarily, so neither is stated here as fact.",
    form: "https://www.justice.gov/civil/media/1316521/dl?inline",
    formNote: "The Attestation form was last revised May 2025. Important filing instruction, verbatim from the form: it should be submitted to the Assistant U.S. Attorney handling the case, and should NOT be filed with the court unless the court or an attorney directs it.",
    hub: "https://www.justice.gov/ust/student-loan-guidance",
    volatile: {
      head: "Is the guidance still in force? Clapback's honest answer",
      body: "It appears to be, and Clapback found no evidence of rescission. The Justice Department's U.S. Trustee page still hosts the guidance, the fact sheet and the form, and was updated March 17, 2026. The Civil Division's forms page still lists all of it and was updated July 10, 2026. The form itself was revised in May 2025, under the current administration.",
      caveat: "But that is continued maintenance and non-rescission, not an affirmative re-endorsement — Clapback found no 2025 or 2026 statement reaffirming it. And there is a live open question: in March 2026 the Departments of Education and Treasury signed an agreement moving management of roughly $180 billion in defaulted federal loans to Treasury. Nothing Clapback could find addresses how that affects who you name as defendant, who receives the Attestation, or whether the guidance governs Treasury-held loans. Ask the U.S. Attorney's office or a bankruptcy attorney before relying on the workflow for a defaulted loan.",
      note: "You may notice the Justice Department press releases about this now sit under an /archives/ path. That is routine archiving of prior-administration press content, not a policy change — the substantive guidance and the form sit on live pages updated in 2026."
    }
  };

  var PROCESS = {
    head: "What actually happens",
    steps: [
      { n: "Filing bankruptcy does NOT discharge student loans", t: "This surprises almost everyone. A covered student loan survives your discharge automatically unless you file a separate lawsuit inside the bankruptcy case — an adversary proceeding — and win it. Chapter 7 or Chapter 13 makes no difference to this." },
      { n: "There is no filing fee", t: "The court's fee schedule charges $350 for filing an adversary complaint, and then says in terms: this fee must not be charged if the debtor is the plaintiff. Filing costs you nothing." },
      { n: "Service is the trap", t: "You must serve the United States at THREE separate addresses: the Civil Process Clerk at your district's U.S. Attorney's office, the Attorney General in Washington, and the Department of Education's Office of General Counsel. Getting this wrong defeats a large share of self-represented filers. Get it right the first time." },
      { n: "The Attestation comes next", t: "After service, the government attorney should provide you with the Attestation form and your loan account history. You complete it and return it to them — not to the court." },
      { n: "Then it is a negotiation, not a trial", t: "The United States and its agencies get 35 days from issuance of the summons to answer, rather than the 30 days an ordinary defendant gets — Bankruptcy Rule 7012(a). In practice the government routinely asks for extensions and courts routinely grant them, so expect this to run months rather than weeks; check your own court's local rules and scheduling order for the real dates. Of 652 resolved cases studied, 502 ended in settlement and exactly one was decided on the merits. This is a paperwork process, not a trial practice." }
    ],
    prose: {
      head: "Can you do it yourself?",
      yes: "Mechanically, yes. There is no filing fee, the process is a negotiation rather than a trial, and the Attestation is a form. One pre-2022 study found attorney representation did not significantly improve outcomes, though that was a different regime.",
      no: "But the three-address service requirement defeats many self-represented litigants, and the Attestation requires an IRS collection-standards analysis with supporting income documentation.",
      honest: "Clapback could find no study reporting self-represented versus represented success rates under the 2022 guidance, and will not publish a number. One data point that is worth more than a guess: the filings cluster in districts where the local consumer bankruptcy bar adopted the process. That is an argument that finding a lawyer who has done one is the binding constraint — so start by asking."
    }
  };

  var PARTIAL = "Courts can discharge part of a student loan, and the Justice Department describes outcomes as full or partial discharge. The Sixth and Ninth Circuits permit it, requiring undue hardship as to the portion discharged; the Eighth Circuit's appellate panel requires a loan-by-loan analysis where there are several loans. Clapback found no circuit that flatly forbids it. Under the 2022 guidance partial discharges have become the minority outcome — the median discharge is now 100% of the debt.";

  var CH13_LOANS = "If you are in Chapter 13 with student loans, know three things. Your plan payment on an unsecured student loan is usually far below the contractual amount, so the loan defaults during the bankruptcy and interest keeps running. Many courts now permit separate classification so the loan can be treated better, but it is contested and court-by-court. And at plan completion you still owe the balance, with accrued interest capitalized — many Chapter 13 debtors exit owing more than they entered owing. A 2023 rule would have given forgiveness credit for plan months, but it was enjoined in 2024 and its status after the 2025 statutory changes is unverified. Don't count on it.";

  /* ================================================================== */
  /* GENERAL BANKRUPTCY                                                  */
  /* ================================================================== */
  var DISCHARGEABLE = [
    "Credit card balances", "Medical bills", "Personal loans, payday loans, signature loans",
    "Most money judgments from ordinary civil suits", "Deficiency balances after repossession or foreclosure",
    "Old utility bills, old rent, broken leases", "Collection accounts and most debts sold to debt buyers"
  ];
  var NOT_DISCHARGEABLE = [
    { n: "Most taxes", c: "§ 523(a)(1)" },
    { n: "Debts from fraud or a materially false written financial statement", c: "§ 523(a)(2)" },
    { n: "Debts you failed to list, unless the creditor had actual timely notice", c: "§ 523(a)(3)" },
    { n: "Fraud or defalcation as a fiduciary, embezzlement, larceny", c: "§ 523(a)(4)" },
    { n: "Child support and alimony", c: "§ 523(a)(5)" },
    { n: "Willful and malicious injury to person or property", c: "§ 523(a)(6)", ch13: "In Chapter 13 only injury to a PERSON survives — willful and malicious injury to property is discharged. § 1328(a)(4)" },
    { n: "Fines, penalties and forfeitures payable to a government unit and not compensating an actual loss — civil as well as criminal", c: "§ 523(a)(7)" },
    { n: "Student loans — unless you win an undue hardship proceeding", c: "§ 523(a)(8)" },
    { n: "Debts from death or injury caused by drunk driving", c: "§ 523(a)(9)" },
    { n: "Criminal restitution and criminal fines", c: "§ 523(a)(13)" },
    { n: "Divorce property-settlement obligations, as distinct from support", c: "§ 523(a)(15)", ch13: "Discharged in Chapter 13 — § 1328(a) does not carry this exception over. Support under § 523(a)(5) survives either way." }
  ];
  var ND_NOTE = "This list is the Chapter 7 exceptions. Chapter 13's discharge under § 1328(a) is broader on two of them, flagged above — which is one real reason to compare the chapters rather than assume Chapter 7 is always the stronger discharge.";
  var LIENS = "The most misunderstood point in bankruptcy: discharge kills your personal liability, not a valid lien. A mortgage holder or car lender can still foreclose or repossess. If you want to keep the house or the car, the loan has to be dealt with separately.";
  var MEDICAL_BK = {
    head: "Medical debt is fully dischargeable",
    body: "It is ordinary unsecured debt. The statute lists every exception to discharge and medical debt appears in none of them. One caveat: a medical bill charged to a credit card is still dischargeable, but a very recent large charge could draw a fraud objection — medical necessity makes that hard to sustain, but the mechanism exists.",
    dispute: "On how much of bankruptcy is “medical,” researchers genuinely disagree and Clapback will not pick a side. A 2019 survey found 66.5% of debtors cited at least one medical contributor — a prevalence-among-filers question, answered by a survey of a sample of filers, not a count of all of them. A 2018 study in the New England Journal of Medicine found hospitalization causes about 4% of personal bankruptcies among non-elderly adults — a causal question requiring a comparison group of people who didn't go bankrupt. Both are right about their own question. A high share of filers can have medical debt while hospitalization causes only a small share of filings, because filers usually arrive with many overlapping stressors. Note too that the 4% study looked at hospitalizations only, excluding chronic illness, outpatient care, prescriptions, and long-run income loss.",
    safe: "The defensible statement: medical debt is dischargeable, and medical bills are among the most commonly reported contributors to consumer bankruptcy — though how often they are the cause rather than one factor among many is contested."
  };

  var STAY = {
    head: "The automatic stay",
    body: "Filing triggers it instantly — no hearing, no judge's signature. It stops lawsuits mid-case, wage garnishment, repossession, foreclosure, bank levies and setoffs, and all collection calls and letters.",
    cite: "11 U.S.C. § 362",
    notStop: [
      "Criminal proceedings",
      "Establishing paternity, or establishing or modifying child support; custody and visitation; domestic violence proceedings",
      "Collecting child support from property that isn't part of the bankruptcy estate — including wage withholding for support",
      "Tax audits, deficiency notices, demands for returns, and tax assessments",
      "An eviction where the landlord already had a judgment for possession before you filed — but see the cure right below, this one is not absolute"
    ],
    evictCure: "That last exception has a way out that almost nothing tells you about. Under § 362(l), if your state's law would let you cure the entire money default even after the judgment, you can file a certification saying so along with your petition and deposit with the court clerk the rent that comes due in the next 30 days. Do that and the stay applies to the eviction after all. It is a narrow, fast-moving right — the certification goes in with the petition — so if you are facing a possession judgment, raise § 362(l) with a lawyer or your local legal aid before you file, not after.",
    utilities: "One correction worth making, because a lot of guidance gets it wrong: utility protection is NOT the automatic stay. It is a separate section, and it gives you 20 days to provide adequate assurance of payment — usually a deposit. Miss that and service can be cut off.",
    utilCite: "11 U.S.C. § 366",
    repeat: "If you had one case dismissed in the past year, the stay ends automatically after 30 days unless you move to extend it. If you had two or more dismissed, no stay arises at all unless you ask the court for one. This matters most for exactly the people most likely to need it."
  };

  var CREDIT = {
    head: "What it does to your credit — the honest version",
    law: "The statute permits reporting a bankruptcy for up to 10 years, and it makes no distinction between Chapter 7 and Chapter 13. The familiar 7-year figure for Chapter 13 is voluntary credit bureau policy, not law — the bureaus remove Chapter 13 early to encourage repayment chapters.",
    cite: "15 U.S.C. § 1681c(a)(1)",
    honest: "And the framing that actually matters: if you are considering bankruptcy, you usually do not have good credit to protect. By the time someone weighs it, the report typically already carries charge-offs, collections and 120-plus-day delinquencies — each independently reportable for seven years and each already suppressing the score. Bankruptcy discharges those accounts and stops the bleeding. Scores often rise within a year or two of discharge because balances go to zero and the delinquency stream ends.",
    caveat: "Clapback did not verify specific score-recovery timelines or mortgage waiting periods, so it won't quote you numbers on those. The direction of the effect and the reporting periods are solid."
  };

  var MEANS = {
    head: "The means test, in one paragraph",
    body: "It decides whether you can use Chapter 7. Start with your average monthly income over the six full calendar months before you file — including a non-filing spouse's contributions, excluding Social Security. Annualize it and compare to the median family income for your state and household size. At or below median, you pass. Above it, you deduct allowed expenses using IRS standards plus secured and priority debt payments; abuse is presumed if what's left over 60 months exceeds $17,150, or exceeds $10,275 and is at least 25% of your unsecured debt.",
    trap: "The most practically useful thing about it: the lookback is backward-looking. Someone who just lost a job may still show high income and fail — and simply waiting a few months can flip the result.",
    volatile: "The U.S. Trustee reissues these numbers on a schedule. The census median family income tables changed on November 1, 2025 and again on April 1, 2026; the administrative expense multipliers and IRS standards changed on July 15, 2026. Clapback deliberately does not ship any of them, because a hardcoded table would be wrong within months. Pull the current ones from the U.S. Trustee, and check which date stamp applies to the table you are reading.",
    url: "https://www.justice.gov/ust/means-testing",
    fees: [
      { n: "Chapter 7", v: "$338" }, { n: "Chapter 13", v: "$313" },
      { n: "Chapter 11", v: "$1,738" }, { n: "Chapter 12", v: "$278" }
    ],
    feeNote: "A trap in the official fee schedule: it lists only the administrative and surcharge components, so reading it alone gives you $93 for Chapter 7. The real total is $338.",
    waiver: "There is a fee waiver for Chapter 7 — Official Form 103B — if your household income is below 150% of the federal poverty line and you cannot pay in installments. There is no fee waiver for Chapter 13, though installments are available in any chapter. Having paid an attorney does not by itself disqualify you."
  };

  var COUNSELING = {
    head: "Two required courses, commonly confused",
    pre: { n: "Pre-filing credit counseling", t: "Within 180 days BEFORE you file. Skip it and you cannot file.", u: "https://www.justice.gov/ust/list-credit-counseling-agencies-approved-pursuant-11-usc-111" },
    post: { n: "Pre-discharge debtor education", t: "AFTER you file, before discharge. Skip it and your discharge is denied.", u: "https://www.justice.gov/ust/list-approved-providers-personal-financial-management-instructional-courses-debtor-education" },
    note: "Both lists are searchable by state and judicial district. Alabama and North Carolina are Bankruptcy Administrator districts rather than U.S. Trustee districts, so approval there runs through the Bankruptcy Administrator — worth knowing, since those are two of the highest-filing states in the country."
  };

  var HELP = [
    { n: "Filing without an attorney", t: "The federal judiciary's own guidance. Note that court staff and judges are barred from giving you legal advice.", u: "https://www.uscourts.gov/court-programs/bankruptcy/filing-without-attorney" },
    { n: "Legal Services Corporation", t: "Find the legal aid organization serving your area.", u: "https://www.lsc.gov/about-lsc/what-legal-aid/i-need-legal-help" },
    { n: "ABA Free Legal Answers", t: "Free answers from pro bono attorneys in 40+ jurisdictions.", u: "https://abafreelegalanswers.org/" },
    { n: "Approved credit counseling agencies", t: "The required pre-filing course, by state.", u: "https://www.justice.gov/ust/credit-counseling-and-debtor-education-providers" }
  ];
  var PREPARER_WARN = "Bankruptcy petition preparers may only type your information into the forms. They cannot give legal advice, cannot sign for you, and cannot accept court fees. The official forms are free from the courts — nobody should charge you for the forms themselves.";

  return {
    UPDATED: UPDATED, NATIONAL: NATIONAL, STATES: STATES, STATE_NOTE: STATE_NOTE, STATE_NOTE_URL: STATE_NOTE_URL, STATE_HEADLINE: STATE_HEADLINE,
    CH13_HIGH: CH13_HIGH, CH13_LOW: CH13_LOW, CH13_STORY: CH13_STORY,
    SLAP: SLAP, THE_GAP: THE_GAP, CIRCUITS: CIRCUITS, CIRCUIT_NOTE: CIRCUIT_NOTE, BRUNNER: BRUNNER,
    GUIDANCE: GUIDANCE, PROCESS: PROCESS, PARTIAL: PARTIAL, CH13_LOANS: CH13_LOANS,
    DISCHARGEABLE: DISCHARGEABLE, NOT_DISCHARGEABLE: NOT_DISCHARGEABLE, ND_NOTE: ND_NOTE, LIENS: LIENS,
    MEDICAL_BK: MEDICAL_BK, STAY: STAY, CREDIT: CREDIT, MEANS: MEANS,
    COUNSELING: COUNSELING, HELP: HELP, PREPARER_WARN: PREPARER_WARN
  };
})();

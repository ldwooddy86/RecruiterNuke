/* Clapback — "Represent" module: your representatives + policymaker channels.
 * Self-contained, on-device, zero network requests: every button is an
 * ordinary link to an official lookup, and you enter your ZIP/address on the
 * government's own site — never here.
 */
(function () {
  "use strict";
  var D = window.PDS;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var profile = {};
  var mounted = false;

  function linkList(items) {
    return '<ul class="tidy">' + items.map(function (f) {
      return "<li><strong><a href=\"" + esc(f.url) + '" target="_blank" rel="noopener">' + esc(f.name) + " \u2197</a></strong> \u2014 " + esc(f.why) + "</li>";
    }).join("") + "</ul>";
  }

  function mount() {
    var view = $("#view-represent");
    if (!view || mounted) return;
    mounted = true;

    var R = D.REP_LINKS || { fed: [], state: [], exec: [] };

    view.innerHTML =
      '<h1 id="represent-h1">Represent</h1>' +
      '<p class="lede">Reporting handles the scam in front of you; <strong>this tab handles the rules</strong>. Ghost jobs are legal because job ads escaped truth-in-advertising. Staffing agencies hold SSNs in most states without so much as registering. Data brokers resell your life because no federal one-stop deletion exists. The people who can change all three have offices, staff, and constituent-mail counts \u2014 and you\u2019re the constituent.</p>' +

      '<div class="card">' +
      '<h2>Your members of Congress</h2>' +
      linkList(R.fed) +
      '</div>' +

      '<div class="card">' +
      '<h2>Your state legislators</h2>' +
      linkList(R.state) +
      '<p class="muted" style="margin:8px 0 0">State capitols move faster than Congress on this: staffing-agency registration is already law in Massachusetts, New Jersey, and Illinois \u2014 the letter below asks your state for the same.</p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>The executive branch</h2>' +
      linkList(R.exec) +
      '</div>' +

      '<div class="card">' +
      '<h2>Write the letter</h2>' +
      '<p class="muted">Three ready-to-send letters, filled from your profile \u2014 one clean ask each, no form-letter mush. Paste into the contact form your lookup lands on. A single paragraph of your own experience is worth ten statistics, so there\u2019s a slot for it.</p>' +
      '<div class="ghost-form">' +
      '<select id="adv-kind" aria-label="Letter topic"></select>' +
      '<p id="adv-hint" class="muted"></p>' +
      '<textarea id="adv-story" rows="3" placeholder="Optional: one short paragraph of your own experience (a posting that sat for months, an agency that vanished with your documents\u2026)"></textarea>' +
      '<button class="btn" id="adv-generate">Generate letter</button>' +
      '</div>' +
      '<div id="adv-out" class="hidden">' +
      '<div class="ghost-subject"><strong>Subject:</strong> <span id="adv-subject"></span></div>' +
      '<textarea id="adv-text" rows="14" spellcheck="false"></textarea>' +
      '<div class="agency-letter-actions">' +
      '<button class="btn" id="adv-copy">Copy letter</button>' +
      '<button class="btn btn-ghost" id="adv-copy-subject">Copy subject</button>' +
      '</div>' +
      '<p class="muted" style="margin:8px 0 0">Constituent mail is tallied by topic. Short, specific, and polite beats long and furious \u2014 and a reply from a staffer means it was counted.</p>' +
      '</div>' +
      '</div>';

    var GH = D.ADVOCACY_LETTERS || {};
    var sel = $("#adv-kind");
    sel.innerHTML = Object.keys(GH).map(function (k) {
      return '<option value="' + k + '">' + esc(GH[k].label) + "</option>";
    }).join("");
    function hint() { var g = GH[sel.value]; $("#adv-hint").textContent = g ? g.hint : ""; }
    sel.addEventListener("change", hint);
    hint();

    function fmtDate(d) { return d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }); }

    $("#adv-generate").addEventListener("click", function () {
      var g = GH[sel.value]; if (!g) return;
      get(["profile"]).then(function (d) {
        profile = d.profile || profile || {};
        var story = ($("#adv-story").value || "").trim();
        var storypara = story ? "\n\nMy own experience: " + story : "";
        var fill = function (s) {
          return s
            .replace(/\{\{storypara\}\}/g, storypara)
            .replace(/\{\{name\}\}/g, profile.name || "[Your name]")
            .replace(/\{\{city\}\}/g, profile.city || "[Your city]")
            .replace(/\{\{state\}\}/g, profile.state || "[Your state]")
            .replace(/\{\{today\}\}/g, fmtDate(new Date()));
        };
        $("#adv-subject").textContent = fill(g.subject);
        $("#adv-text").value = fill(g.body);
        $("#adv-out").classList.remove("hidden");
        $("#adv-out").scrollIntoView({ behavior: "smooth", block: "nearest" });
      });
    });
    $("#adv-copy").addEventListener("click", function () {
      var t = $("#adv-text"); t.select();
      try { navigator.clipboard.writeText(t.value); } catch (err) { document.execCommand && document.execCommand("copy"); }
    });
    $("#adv-copy-subject").addEventListener("click", function () {
      try { navigator.clipboard.writeText($("#adv-subject").textContent); } catch (err) {}
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="represent"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

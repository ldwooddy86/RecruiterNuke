/* Clapback — "Report it" module: state AG offices + federal reporting lanes.
 * Self-contained. Runs entirely on-device. Makes no network requests — every
 * button is an ordinary link to an official government intake.
 * Data provenance: AG sites pulled from the USA.gov state-attorney-general
 * directory; direct complaint-form links individually verified (Aug 2026).
 */
(function () {
  "use strict";
  var D = window.PDS;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  var profile = {};
  var picked = "";
  var mounted = false;

  function host(u) { try { return new URL(u).host; } catch (e) { return u; } }
  function formSearch(site) {
    return "https://www.google.com/search?q=" + encodeURIComponent("site:" + host(site) + " consumer complaint form");
  }

  function mount() {
    var view = $("#view-report");
    if (!view || mounted) { if (mounted) renderState(); return; }
    mounted = true;

    view.innerHTML =
      '<h1 id="report-h1">Report it</h1>' +
      '<p class="lede">Fee-charging \u201crecruiters,\u201d fake job postings that harvest applications, bait-and-switch offers, impersonation \u2014 these aren\u2019t just annoying, they\u2019re <strong>deceptive trade practices</strong>, and the people who enforce that law work for you. This tab routes each harm to the office that actually acts on it: your state attorney general, the right federal intake, or your state labor department. Complaints are how patterns get noticed; yours counts even when no one calls you back.</p>' +

      '<div class="card">' +
      '<h2>Your state attorney general</h2>' +
      '<div class="report-pick">' +
      '<select id="rp-state" aria-label="Choose your state"></select>' +
      '</div>' +
      '<div id="rp-out"></div>' +
      '<p class="muted" style="margin:10px 0 0">Sources: official sites from the <a href="https://www.usa.gov/state-attorney-general" target="_blank" rel="noopener">USA.gov attorney-general directory</a>; direct form links verified August 2026. If a state has redesigned its site since, the \u201cfind the current form\u201d button will still land you there.</p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Which harm goes where</h2>' +
      '<ul class="tidy">' +
      '<li><strong>Fake job postings, fee-charging agencies, bait-and-switch pay, impersonating a real firm</strong> \u2192 your state AG (above) <em>and</em> the FTC. Deceptive-practices law squarely covers all of it.</li>' +
      '<li><strong>\u201cGhost jobs\u201d \u2014 postings for roles that don\u2019t exist</strong> \u2192 honest framing first: being ghosted by a real employer is rude, not illegal, and AGs don\u2019t police rudeness. But <em>advertising jobs that don\u2019t exist</em> \u2014 to farm applications, harvest personal data, or pad a pipeline \u2014 is deceptive advertising. Report the posting to the AG + FTC, and report the listing to the job platform it ran on; platforms remove them and sanction repeat posters.</li>' +
      '<li><strong>You sent a scammer your SSN, ID, or bank details</strong> \u2192 IdentityTheft.gov immediately (recovery plan), then IC3. Then run this app\u2019s account-hardening checklist.</li>' +
      '<li><strong>Fake checks, \u201cbuy equipment,\u201d crypto or wire demands</strong> \u2192 FBI IC3, plus your bank the same day.</li>' +
      '<li><strong>A staffing agency stiffed you on pay or working conditions</strong> \u2192 your state labor department (<a href="https://www.dol.gov/agencies/whd/state/contacts" target="_blank" rel="noopener">US DOL directory of state labor offices \u2197</a>) \u2014 wage claims are their lane, not the AG\u2019s.</li>' +
      '<li><strong>Discrimination in hiring</strong> \u2014 by an employer <em>or</em> a staffing agency \u2192 the EEOC; agencies are covered employers under federal law.</li>' +
      '</ul>' +
      '<p class="muted" style="margin:8px 0 0">Hiring-specific violations \u2014 discrimination, background-check abuse, union retaliation, federal-hiring integrity \u2014 have their own full directory with deadlines and hotlines: <button class="btn btn-ghost btn-sm" data-goto="hiring">Hiring rights \u2192</button></p><p class="muted" style="margin:8px 0 0">One report, several boxes: it\u2019s normal (and effective) to file the same incident with your AG, the FTC, and the platform. Enforcement runs on repetition.</p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Federal reporting lanes</h2>' +
      '<ul class="tidy">' +
      (D.REPORT_FED || []).map(function (f) {
        return "<li><strong><a href=\"" + esc(f.url) + '" target="_blank" rel="noopener">' + esc(f.name) + " \u2197</a></strong> \u2014 " + esc(f.why) + "</li>";
      }).join("") +
      '</ul>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Build the complaint in five minutes</h2>' +
      '<ul class="tidy">' +
      '<li><strong>Who:</strong> the name they used, the company they claimed, the real company if impersonated (this directory gives you the real domain), email addresses, phone numbers, profile links.</li>' +
      '<li><strong>What:</strong> two or three sentences, in order: what they posted or promised, what they asked for, what happened.</li>' +
      '<li><strong>Evidence:</strong> screenshots of the posting and messages, the full email headers if you have them, dates. Don\u2019t edit the screenshots.</li>' +
      '<li><strong>Money or data:</strong> what you paid or shared, when, and how.</li>' +
      '<li><strong>Never include</strong> your SSN or account numbers in the complaint text itself \u2014 intakes will say so too.</li>' +
      '</ul>' +
      '<p class="muted" style="margin:8px 0 0">Work the incident with the rest of Clapback: <button class="btn btn-ghost btn-sm" data-goto="vet">Vet the contact</button> <button class="btn btn-ghost btn-sm" data-goto="agencies">Check the real agency</button> <button class="btn btn-ghost btn-sm" data-goto="harass">Log evidence</button></p>' +
      '</div>';

    var sel = $("#rp-state");
    var codes = Object.keys(D.AG_OFFICES || {}).sort(function (a, b) {
      return (STATE_NAME[a] || a) < (STATE_NAME[b] || b) ? -1 : 1;
    });
    sel.innerHTML = '<option value="">Choose your state\u2026</option>' + codes.map(function (c) {
      return '<option value="' + c + '">' + esc(STATE_NAME[c] || c) + "</option>";
    }).join("");
    sel.addEventListener("change", function (e) { picked = e.target.value; renderState(); });

    get(["profile"]).then(function (d) {
      profile = d.profile || {};
      if (profile.state && (D.AG_OFFICES || {})[profile.state]) {
        picked = profile.state;
        sel.value = picked;
      }
      renderState();
    });
  }

  function renderState() {
    var out = $("#rp-out"); if (!out) return;
    if (!picked || !(D.AG_OFFICES || {})[picked]) {
      out.innerHTML = '<p class="muted" style="margin-top:8px">Pick a state to get its attorney general\u2019s office and complaint intake. Tip: set your state in your profile and this chooses itself.</p>';
      return;
    }
    var o = D.AG_OFFICES[picked];
    var name = STATE_NAME[picked] || picked;
    var formBtn = o.form
      ? '<a class="btn" href="' + esc(o.form) + '" target="_blank" rel="noopener">File a consumer complaint \u2197</a> <span class="rp-verified">direct link \u00b7 verified Aug 2026</span>'
      : '<a class="btn" href="' + formSearch(o.site) + '" target="_blank" rel="noopener">Find the current complaint form \u2197</a> <span class="rp-verified rp-verified-soft">site-scoped search of ' + esc(host(o.site)) + "</span>";

    var licensing = (D.STATE_NOTES && D.STATE_NOTES[picked])
      ? '<p class="rp-note"><strong>Extra leverage in ' + esc(name) + ":</strong> " + esc(D.STATE_NOTES[picked]) + "</p>"
      : "";

    out.innerHTML =
      '<div class="rp-office">' +
      "<h3>" + esc(name) + " Attorney General</h3>" +
      '<p><a href="' + esc(o.site) + '" target="_blank" rel="noopener">' + esc(host(o.site)) + " \u2197</a> \u2014 official office site (consumer-protection division handles fraud and deceptive practices).</p>" +
      "<p>" + formBtn + "</p>" +
      licensing +
      "</div>";
  }

  /* ---------------- init ---------------- */
  if (hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !mounted) return;
      if (ch.profile) {
        profile = ch.profile.newValue || {};
        if (!picked && profile.state && (D.AG_OFFICES || {})[profile.state]) {
          picked = profile.state;
          var sel = $("#rp-state"); if (sel) sel.value = picked;
          renderState();
        }
      }
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="report"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

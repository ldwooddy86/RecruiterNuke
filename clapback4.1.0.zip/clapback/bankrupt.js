/* Clapback — "Bankruptcy & discharge" module.
 * Defensive only. General information, not legal advice. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, B = window.CBB, D = window.PDS;
  var mounted = false;
  var prof = {};
  var mapMode = "slap";   // slap | rate | ch13

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  /* Which states contain a district in the SLAP top 15, and with what count.
     Top-10 counts are per-district; the "also" group is shown without a
     count because the published ordering could not be confirmed. */
  function slapByState() {
    var by = {};
    B.SLAP.top.forEach(function (t) {
      if (!by[t.st]) by[t.st] = { n: 0, dists: [] };
      by[t.st].n += t.post;
      by[t.st].dists.push(t.d + " (" + t.post + ")");
    });
    B.SLAP.also.st.forEach(function (s) {
      if (!by[s]) by[s] = { n: 0, dists: [], grouped: true };
      by[s].grouped = true;
    });
    return by;
  }

  function mount() {
    var view = X.$("#view-bankrupt");
    /* load() re-reads the profile, so a state saved after this module first
       mounted still reaches the map's "you are here" and the circuit lookup. */
    if (!view || mounted) { if (mounted) load(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Bankruptcy &amp; discharge</h1>' +
      '<p class="lede">Two things live on this page. Where student loan discharges actually happen — which has a genuinely surprising answer — and what consumer bankruptcy looks like across the country, because the same federal statute produces wildly different outcomes depending on which courthouse you walk into.</p>' +

      /* ---- the gap ---- */
      '<div class="card danger">' +
      '<h2 id="gap-head"></h2>' +
      '<div class="grid-3" id="gap-stats"></div>' +
      '<p class="muted" id="gap-rownote"></p>' +
      '<p id="gap-quote" style="font-size:15px"></p>' +
      '<p class="muted" id="gap-span"></p>' +
      '<div class="callout callout-warn" id="gap-point"></div>' +
      X.srcLine("Jason Iuliano, 99 Am. Bankr. L.J. Iss. 3 (2025)", B.THE_GAP.url) +
      '</div>' +

      /* ---- the map ---- */
      '<h2 id="slap-head"></h2>' +
      '<p class="muted" id="slap-lead"></p>' +
      '<div class="card">' +
      '<div class="chips" id="map-mode">' +
      '<button class="chip active" data-map="slap">Student loan discharge filings</button>' +
      '<button class="chip" data-map="rate">Bankruptcy filing rate</button>' +
      '<button class="chip" data-map="ch13">Chapter 13 share</button>' +
      '</div>' +
      '<p class="muted" id="map-caption"></p>' +
      '<div id="bk-grid" class="gm-grid" role="group" aria-label="US state grid"></div>' +
      '<div class="gm-legend" id="map-legend"></div>' +
      '<div id="map-detail" style="margin-top:14px"></div>' +
      '</div>' +

      '<div class="card">' +
      '<h3>The districts where these cases are filed</h3>' +
      '<p class="muted" id="slap-method"></p>' +
      '<div id="slap-top"></div>' +
      '<div class="callout callout-info" id="slap-also"></div>' +
      '<p class="muted" id="slap-derived"></p>' +
      '<p class="muted" id="slap-zero"></p>' +
      '<div class="btn-row">' + X.a("The study ↗", B.SLAP.url) + '</div>' +
      '</div>' +

      /* ---- why ---- */
      '<div class="card">' +
      '<h3 id="why-head"></h3>' +
      '<p id="why-body"></p>' +
      '<div class="callout callout-warn" id="why-evidence"></div>' +
      '<p id="why-kicker"></p>' +
      '<p id="why-real"></p>' +
      '<p class="muted" id="why-pardo"></p>' +
      '<div class="callout callout-info" id="why-sowhat"></div>' +
      '</div>' +

      '<div class="card danger"><h3>What nobody publishes</h3><p id="slap-gap"></p></div>' +

      /* ---- circuits ---- */
      '<h2>The legal test where you live</h2>' +
      '<div class="card">' +
      '<p>Most circuits apply the <strong>Brunner</strong> test. The Eighth applies a <strong>totality of the circumstances</strong> test, which is doctrinally more flexible. Two are unsettled: the First declined to pick a test in <em>In re Nash</em> (2006) — though its Bankruptcy Appellate Panel uses totality — and the D.C. Circuit has no circuit-level precedent at all. Read the note underneath before you draw conclusions from any of that.</p>' +
      '<div id="circ-you"></div>' +
      '<h4 style="margin-top:16px">Brunner’s three prongs</h4>' +
      '<ol class="tidy" id="brunner"></ol>' +
      '<div id="circ-list" style="margin-top:16px"></div>' +
      '<div class="callout callout-info" id="circ-note"></div>' +
      '</div>' +

      /* ---- the guidance ---- */
      '<h2 id="gd-head"></h2>' +
      '<div class="card">' +
      '<p id="gd-body"></p>' +
      '<h4 style="margin-top:14px">Presumptions that your inability to pay will persist</h4>' +
      '<ul class="tidy" id="gd-pres"></ul>' +
      '<p class="muted" id="gd-presnote"></p>' +
      '<div class="callout callout-info" id="gd-results"></div>' +
      '<p class="muted" id="gd-formnote"></p>' +
      '<div class="btn-row">' + X.a("The Attestation form ↗", B.GUIDANCE.form, "btn btn-sm") + X.a("Justice Dept. hub ↗", B.GUIDANCE.hub) + '</div>' +
      '</div>' +
      '<div class="card danger">' +
      '<h3 id="gv-head"></h3><p id="gv-body"></p>' +
      '<div class="callout callout-warn" id="gv-caveat"></div>' +
      '<p class="muted" id="gv-note"></p>' +
      '</div>' +

      /* ---- process ---- */
      '<h2 id="pr-head"></h2>' +
      '<div id="pr-steps"></div>' +
      '<div class="card">' +
      '<h3 id="prose-head"></h3>' +
      '<p id="prose-yes"></p><p id="prose-no"></p>' +
      '<div class="callout callout-info" id="prose-honest"></div>' +
      '</div>' +
      '<div class="card"><h3>Partial discharge</h3><p id="bk-partial"></p></div>' +
      '<div class="card"><h3>If you’re in Chapter 13</h3><p id="bk-ch13loans"></p></div>' +

      /* ---- national picture ---- */
      '<h2>Consumer bankruptcy, nationally</h2>' +
      '<div class="grid-4" id="nat-stats"></div>' +
      '<p class="muted" id="nat-context"></p>' +
      '<div class="card"><h3 id="ch13-head"></h3>' +
      '<p id="ch13-body"></p><p class="fineprint" id="ch13-bodysrc"></p><p id="ch13-spread"></p>' +
      '<div class="grid-2">' +
      '<div class="card mini"><div class="li-main">Highest Chapter 13 districts</div><div id="ch13-high"></div></div>' +
      '<div class="card mini"><div class="li-main">Lowest</div><div id="ch13-low"></div></div>' +
      '</div>' +
      '<div class="callout callout-warn" id="ch13-compound"></div>' +
      '<p id="ch13-race"></p><p class="fineprint" id="ch13-racesrc"></p>' +
      '<p class="muted" id="ch13-fees"></p>' +
      '<div class="callout callout-info" id="ch13-use"></div>' +
      '</div>' +

      /* ---- what it does ---- */
      '<h2>What bankruptcy does and doesn’t wipe out</h2>' +
      '<div class="grid-2">' +
      '<div class="card"><h3>Generally discharged</h3><ul class="tidy" id="bk-yes"></ul></div>' +
      '<div class="card"><h3>Generally not</h3><div id="bk-no"></div><p class="muted" id="bk-ndnote"></p></div>' +
      '</div>' +
      '<div class="callout callout-warn" id="bk-liens"></div>' +
      '<div class="card"><h3 id="mb-head"></h3><p id="mb-body"></p>' +
      '<p class="muted" id="mb-dispute"></p><div class="callout callout-info" id="mb-safe"></div>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="bills">Try the medical bill tools first →</button></div></div>' +

      /* ---- stay, means, credit ---- */
      '<div class="card"><h3 id="st-head"></h3><p id="st-body"></p>' +
      '<h4 style="margin-top:12px">What it does not stop</h4><ul class="tidy" id="st-not"></ul>' +
      '<div class="callout callout-info" id="st-evict"></div>' +
      '<div class="callout callout-warn" id="st-util"></div>' +
      '<p class="muted" id="st-repeat"></p></div>' +
      '<div class="card"><h3 id="mn-head"></h3><p id="mn-body"></p>' +
      '<div class="callout callout-info" id="mn-trap"></div>' +
      '<p class="muted" id="mn-vol"></p>' +
      '<h4 style="margin-top:12px">Filing fees</h4><div id="mn-fees" class="link-list"></div>' +
      '<p class="muted" id="mn-feenote"></p><p id="mn-waiver"></p>' +
      '<div class="btn-row">' + X.a("Current means-test figures ↗", B.MEANS.url, "btn btn-sm") + '</div></div>' +
      '<div class="card"><h3 id="cr-head"></h3><p id="cr-law"></p>' +
      '<div class="callout callout-info" id="cr-honest"></div><p class="muted" id="cr-caveat"></p></div>' +

      /* ---- help ---- */
      '<h2>Before you file, and where to get help</h2>' +
      '<div class="card"><h3 id="co-head"></h3><div id="co-list" class="link-list"></div><p class="muted" id="co-note"></p></div>' +
      '<div class="card"><h3>Free help</h3><div id="bk-help" class="link-list"></div><div class="callout callout-warn" id="bk-prep"></div></div>' +

      /* ---- letters ---- */
      '<h2>Templates</h2>' +
      '<div class="card"><div id="bk-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">General legal information, not legal advice, and no attorney-client relationship. Bankruptcy is one of the areas where a lawyer changes outcomes most, and consultations are frequently free. Every figure here links to its source except where a line says otherwise, verified ' + X.esc(B.UPDATED) + '. Where Clapback could not verify something — a national Chapter 7 discharge rate, per-capita discharge outcomes, self-represented success rates — it says so instead of guessing.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    /* the gap */
    X.$("#gap-head").textContent = B.THE_GAP.head;
    var gs = X.$("#gap-stats"); gs.innerHTML = "";
    B.THE_GAP.rows.forEach(function (r) {
      var box = X.el("div", "stat");
      var n = X.el("div", "stat-num", r.big);
      box.appendChild(n);
      box.appendChild(X.el("div", "stat-lbl", r.t));
      gs.appendChild(box);
    });
    X.$("#gap-quote").textContent = B.THE_GAP.quote;
    if (X.$("#gap-rownote")) X.$("#gap-rownote").textContent = B.THE_GAP.rowNote;
    X.$("#gap-span").textContent = B.THE_GAP.span;
    X.$("#gap-point").innerHTML = "<strong>" + X.esc(B.THE_GAP.point) + "</strong>";

    /* slap */
    X.$("#slap-head").textContent = B.SLAP.head;
    X.$("#slap-lead").textContent = B.SLAP.lead;
    X.$("#slap-method").textContent = B.SLAP.method;
    var st = X.$("#slap-top"); st.innerHTML = "";
    B.SLAP.top.forEach(function (t, i) {
      var row = X.el("div", "gm-scale-row");
      var main = X.el("div", "gm-scale-main");
      main.appendChild(X.el("div", "li-main", (i + 1) + ". " + t.d));
      main.appendChild(X.el("div", "li-note", t.cir + " Circuit  ·  " + t.post + " cases after the guidance, " + t.pre + " before"));
      var bar = X.el("div", "gm-scale-bar");
      bar.style.width = Math.round(t.post / B.SLAP.top[0].post * 100) + "%";
      main.appendChild(bar);
      row.appendChild(main);
      st.appendChild(row);
    });
    X.$("#slap-also").innerHTML = "<strong>Also in the top 15.</strong> " + X.esc(B.SLAP.also.t);
    X.$("#slap-derived").textContent = B.SLAP.derived;
    X.$("#slap-zero").textContent = B.SLAP.zero;
    X.$("#slap-gap").textContent = B.SLAP.gap;

    var W = B.SLAP.why;
    X.$("#why-head").textContent = W.head;
    X.$("#why-body").textContent = W.body;
    X.$("#why-evidence").innerHTML = "<strong>The evidence says no.</strong> " + X.esc(W.evidence) + " <span class='muted'>(" + X.esc(W.evidenceSrc) + ")</span>";
    X.$("#why-kicker").textContent = W.kicker;
    X.$("#why-real").textContent = W.real;
    X.$("#why-pardo").textContent = W.pardo;
    X.$("#why-sowhat").innerHTML = "<strong>What this means for you.</strong> " + X.esc(W.soWhat);

    /* brunner + circuits */
    var br = X.$("#brunner"); br.innerHTML = "";
    B.BRUNNER.forEach(function (s) { br.appendChild(X.el("li", null, s)); });
    var cl = X.$("#circ-list"); cl.innerHTML = "";
    Object.keys(B.CIRCUITS).forEach(function (k) {
      var c = B.CIRCUITS[k];
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", k + " Circuit — " + c.t));
      l.appendChild(X.el("div", "li-note", c.c));
      l.appendChild(X.el("div", "law-eff", c.states.join(", ")));
      row.appendChild(l);
      cl.appendChild(row);
    });
    X.$("#circ-note").innerHTML = "<strong>Two corrections.</strong> " + X.esc(B.CIRCUIT_NOTE);

    /* guidance */
    var G = B.GUIDANCE;
    X.$("#gd-head").textContent = G.head;
    X.$("#gd-body").textContent = G.body;
    var gp = X.$("#gd-pres"); gp.innerHTML = "";
    G.presumptions.forEach(function (s) { gp.appendChild(X.el("li", null, s)); });
    X.$("#gd-presnote").textContent = G.presumptionNote;
    X.$("#gd-results").innerHTML = "<strong>What happens when people actually file.</strong> " + X.esc(G.results);
    X.$("#gd-formnote").textContent = G.formNote;
    X.$("#gv-head").textContent = G.volatile.head;
    X.$("#gv-body").textContent = G.volatile.body;
    X.$("#gv-caveat").innerHTML = "<strong>But.</strong> " + X.esc(G.volatile.caveat);
    X.$("#gv-note").textContent = G.volatile.note;

    /* process */
    X.$("#pr-head").textContent = B.PROCESS.head;
    var ps = X.$("#pr-steps"); ps.innerHTML = "";
    B.PROCESS.steps.forEach(function (s, i) {
      var card = X.el("div", "wstep");
      card.appendChild(X.el("div", "wstep-n", String(i + 1)));
      var body = X.el("div", "wstep-b");
      body.appendChild(X.el("h4", null, s.n));
      body.appendChild(X.el("p", null, s.t));
      card.appendChild(body);
      ps.appendChild(card);
    });
    X.$("#prose-head").textContent = B.PROCESS.prose.head;
    X.$("#prose-yes").textContent = B.PROCESS.prose.yes;
    X.$("#prose-no").textContent = B.PROCESS.prose.no;
    X.$("#prose-honest").innerHTML = "<strong>And the honest part.</strong> " + X.esc(B.PROCESS.prose.honest);
    X.$("#bk-partial").textContent = B.PARTIAL;
    X.$("#bk-ch13loans").textContent = B.CH13_LOANS;

    /* national */
    var N = B.NATIONAL;
    var ns = X.$("#nat-stats"); ns.innerHTML = "";
    [[N.consumer.toLocaleString("en-US"), "Consumer filings nationwide, " + N.period],
     [N.rate.toFixed(1), "Per 100,000 people, 50 states + DC"],
     [N.ch13share.toFixed(1) + "%", "Filed under Chapter 13"],
     [N.yoy.split(",")[0], "Year over year"]].forEach(function (p) {
      var box = X.el("div", "stat");
      var n = X.el("div", "stat-num", p[0]); n.style.fontSize = "20px";
      box.appendChild(n);
      box.appendChild(X.el("div", "stat-lbl", p[1]));
      ns.appendChild(box);
    });
    X.$("#nat-context").textContent = N.context;

    var C = B.CH13_STORY;
    X.$("#ch13-head").textContent = C.head;
    X.$("#ch13-body").textContent = C.body;
    X.$("#ch13-spread").innerHTML = "<strong>" + X.esc(C.spread) + "</strong>";
    var hi = X.$("#ch13-high"); hi.innerHTML = B.CH13_HIGH.map(function (r) {
      return '<div class="gm-scale-row"><div class="gm-scale-main"><div class="li-note">' + X.esc(r.d) + " — <strong>" + r.v + "%</strong></div>" +
        '<div class="gm-scale-bar" style="width:' + r.v + '%"></div></div></div>';
    }).join("");
    var lo = X.$("#ch13-low"); lo.innerHTML = B.CH13_LOW.map(function (r) {
      return '<div class="gm-scale-row"><div class="gm-scale-main"><div class="li-note">' + X.esc(r.d) + " — <strong>" + r.v + "%</strong></div>" +
        '<div class="gm-scale-bar" style="width:' + (r.v * 3) + '%"></div></div></div>';
    }).join("");
    X.$("#ch13-compound").innerHTML = "<strong>Two maps, not one.</strong> " + X.esc(C.compound);
    if (X.$("#ch13-bodysrc")) X.$("#ch13-bodysrc").innerHTML = X.srcLine(C.bodySrc, C.bodyUrl);
    X.$("#ch13-race").textContent = C.race;
    X.$("#ch13-racesrc").textContent = C.raceSrc;
    X.$("#ch13-fees").textContent = C.fees;
    X.$("#ch13-use").innerHTML = "<strong>What to do with this.</strong> " + X.esc(C.use);

    /* dischargeable */
    var by = X.$("#bk-yes"); by.innerHTML = "";
    B.DISCHARGEABLE.forEach(function (s) { by.appendChild(X.el("li", null, s)); });
    var bn = X.$("#bk-no"); bn.innerHTML = "";
    B.NOT_DISCHARGEABLE.forEach(function (n) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", n.n));
      l.appendChild(X.el("div", "li-note", n.c));
      if (n.ch13) {
        var c13 = X.el("div", "li-note", "Chapter 13: " + n.ch13);
        c13.style.color = "#b45309";
        l.appendChild(c13);
      }
      row.appendChild(l);
      bn.appendChild(row);
    });
    X.$("#bk-ndnote").textContent = B.ND_NOTE;
    X.$("#bk-liens").innerHTML = "<strong>The most misunderstood point in bankruptcy.</strong> " + X.esc(B.LIENS);

    var M = B.MEDICAL_BK;
    X.$("#mb-head").textContent = M.head;
    X.$("#mb-body").textContent = M.body;
    X.$("#mb-dispute").textContent = M.dispute;
    X.$("#mb-safe").innerHTML = "<strong>The defensible statement.</strong> " + X.esc(M.safe);

    var ST = B.STAY;
    X.$("#st-head").textContent = ST.head;
    X.$("#st-body").innerHTML = X.esc(ST.body) + " <span class='muted'>(" + X.esc(ST.cite) + ")</span>";
    var sn = X.$("#st-not"); sn.innerHTML = "";
    ST.notStop.forEach(function (s) { sn.appendChild(X.el("li", null, s)); });
    X.$("#st-util").innerHTML = "<strong>A correction worth making.</strong> " + X.esc(ST.utilities) + " (" + X.esc(ST.utilCite) + ")";
    X.$("#st-evict").innerHTML = "<strong>The eviction exception has a cure.</strong> " + X.esc(ST.evictCure);
    X.$("#st-repeat").textContent = ST.repeat;

    var MN = B.MEANS;
    X.$("#mn-head").textContent = MN.head;
    X.$("#mn-body").textContent = MN.body;
    X.$("#mn-trap").innerHTML = "<strong>The useful part.</strong> " + X.esc(MN.trap);
    X.$("#mn-vol").textContent = MN.volatile;
    var mf = X.$("#mn-fees"); mf.innerHTML = "";
    MN.fees.forEach(function (f) {
      var row = X.el("div", "link-item");
      row.appendChild(X.el("div", "li-main", f.n));
      row.appendChild(X.el("div", "dollar", f.v));
      mf.appendChild(row);
    });
    X.$("#mn-feenote").textContent = MN.feeNote;
    X.$("#mn-waiver").textContent = MN.waiver;

    var CR = B.CREDIT;
    X.$("#cr-head").textContent = CR.head;
    X.$("#cr-law").innerHTML = X.esc(CR.law) + " <span class='muted'>(" + X.esc(CR.cite) + ")</span>";
    X.$("#cr-honest").innerHTML = "<strong>The framing that actually matters.</strong> " + X.esc(CR.honest);
    X.$("#cr-caveat").textContent = CR.caveat;

    var CO = B.COUNSELING;
    X.$("#co-head").textContent = CO.head;
    var col = X.$("#co-list"); col.innerHTML = "";
    [CO.pre, CO.post].forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.n));
      l.appendChild(X.el("div", "li-note", c.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Approved providers ↗", c.u);
      row.appendChild(w);
      col.appendChild(row);
    });
    X.$("#co-note").textContent = CO.note;

    var hp = X.$("#bk-help"); hp.innerHTML = "";
    B.HELP.forEach(function (h) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", h.n));
      l.appendChild(X.el("div", "li-note", h.t));
      row.appendChild(l);
      var w = X.el("div"); w.innerHTML = X.a("Open ↗", h.u, "btn btn-sm");
      row.appendChild(w);
      hp.appendChild(row);
    });
    X.$("#bk-prep").innerHTML = "<strong>One warning.</strong> " + X.esc(B.PREPARER_WARN);

    X.letterCards(X.$("#bk-letters"), "bk", function () { return {}; });

    /* map mode switching */
    X.$("#map-mode").addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      X.$$("#map-mode .chip").forEach(function (x) { x.classList.toggle("active", x === c); });
      mapMode = c.dataset.map;
      renderGrid();
    });
    X.$("#bk-grid").addEventListener("click", function (e) {
      var b = e.target.closest(".gm-cell"); if (!b) return;
      showState(b.dataset.st);
    });
  }

  function load() {
    X.profile().then(function (p) { prof = p; renderAll(); });
  }
  function renderAll() { renderGrid(); renderCircuitYou(); }

  function renderGrid() {
    var grid = X.$("#bk-grid"); if (!grid) return;
    var slap = slapByState();
    var maxRate = 412.3, maxSlap = 244;

    var caption, legend;
    if (mapMode === "slap") {
      caption = "Shaded where a federal bankruptcy district inside that state ranks in the national top 15 for student loan discharge cases FILED between November 2022 and October 2024. This is filings, not outcomes, and it is district data mapped onto states — a state may contain several districts, only one of which is shaded here. It is the only district-level picture that exists.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> Most filings &nbsp; <span class="gm-swatch" style="--heat:.45"></span> Top 15 &nbsp; <span class="gm-swatch" style="--heat:0"></span> No top-15 district';
    } else if (mapMode === "rate") {
      caption = "Consumer bankruptcy filings per 100,000 people, for the 12 months ending June 30, 2026. Fully verified against the Administrative Office's published totals. Click any state for its detail.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> 412 per 100k (Alabama) &nbsp; <span class="gm-swatch" style="--heat:.4"></span> National average, 168 &nbsp; <span class="gm-swatch" style="--heat:0"></span> 37 (Alaska)';
    } else {
      caption = "The share of consumer filings that are Chapter 13 — a three-to-five-year payment plan — rather than Chapter 7. Chapter 13 only discharges your debt if you complete the plan, and nationally fewer than half do.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> 75% Chapter 13 &nbsp; <span class="gm-swatch" style="--heat:.4"></span> National average, 37% &nbsp; <span class="gm-swatch" style="--heat:0"></span> 8%';
    }
    X.$("#map-caption").textContent = caption;
    X.$("#map-legend").innerHTML = legend;

    grid.innerHTML = Object.keys(D.TILE_GRID || {}).map(function (code) {
      var pos = D.TILE_GRID[code];
      var heat = 0, label = STATE_NAME[code] || code, badge = "";
      var s = B.STATES[code];

      if (mapMode === "slap") {
        var sl = slap[code];
        if (sl && sl.n) { heat = Math.min(1, sl.n / maxSlap); badge = String(sl.n); label += " — " + sl.dists.join("; "); }
        else if (sl && sl.grouped) { heat = 0.4; badge = "•"; label += " — contains a top-15 district"; }
        else { label += " — no district in the national top 15"; }
      } else if (mapMode === "rate" && s) {
        heat = Math.min(1, s[2] / maxRate);
        badge = String(Math.round(s[2]));
        label += " — " + s[2] + " consumer filings per 100,000";
      } else if (mapMode === "ch13" && s) {
        heat = Math.min(1, s[3] / 75);
        badge = String(Math.round(s[3]));
        label += " — " + s[3] + "% of consumer filings are Chapter 13";
      }

      var cls = "gm-cell" + (heat > 0.55 ? " hot" : "") + (code === prof.state ? " mine" : "");
      return '<button class="' + cls + '" data-st="' + code + '" style="grid-column:' + (pos[0] + 1) + ";grid-row:" + (pos[1] + 1) +
        ";--heat:" + heat.toFixed(2) + '" aria-label="' + X.esc(label) + '" title="' + X.esc(label) + '">' +
        "<span>" + code + "</span>" + (badge ? "<em>" + X.esc(badge) + "</em>" : "") + "</button>";
    }).join("");
  }

  function showState(code) {
    var out = X.$("#map-detail"); if (!out) return;
    var s = B.STATES[code];
    var slap = slapByState()[code];
    var name = STATE_NAME[code] || code;
    if (!s) { out.innerHTML = ""; return; }

    var rank = Object.keys(B.STATES).sort(function (a, b) { return B.STATES[b][2] - B.STATES[a][2]; }).indexOf(code) + 1;
    var html = '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(name) + '</div>' +
      '<span class="status-pill pill-amber">#' + rank + ' of 51 by filing rate</span></div>' +
      '<p><strong>' + s[0].toLocaleString("en-US") + '</strong> consumer bankruptcy filings in the year to June 30, 2026 — <strong>' + s[2] + '</strong> per 100,000 people, against a national average of ' + B.NATIONAL.rate + '.</p>' +
      '<p><strong>' + s[3] + '%</strong> were Chapter 13 (national average ' + B.NATIONAL.ch13share + '%). Of Chapter 13 cases that ended in the 12 months to December 2024, <strong>' + s[4] + '%</strong> ended with the plan completed (national average 49.4%).</p>';

    if (slap && slap.dists && slap.dists.length) {
      html += '<div class="callout callout-info"><strong>Student loan discharge filings.</strong> ' +
        X.esc(slap.dists.join("; ")) + ' — among the 15 districts filing the most in the country.</div>';
    } else if (slap && slap.grouped) {
      html += '<div class="callout callout-info"><strong>Student loan discharge filings.</strong> A district in this state is among the national top 15 by filings.</div>';
    }

    /* circuit */
    var cir = null;
    Object.keys(B.CIRCUITS).forEach(function (k) {
      if (B.CIRCUITS[k].states.indexOf(code) >= 0) cir = { k: k, c: B.CIRCUITS[k] };
    });
    if (cir) {
      html += '<p class="muted"><strong>' + X.esc(cir.k) + ' Circuit — ' + X.esc(cir.c.t) + '.</strong> ' + X.esc(cir.c.c) + '</p>';
    }
    html += '</div>';
    out.innerHTML = html;
    out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function renderCircuitYou() {
    var out = X.$("#circ-you"); if (!out) return;
    var st = prof.state;
    if (!st) { out.innerHTML = '<p class="muted">Set your state in your profile and Clapback will show which test applies where you live.</p>'; return; }
    var cir = null;
    Object.keys(B.CIRCUITS).forEach(function (k) {
      if (B.CIRCUITS[k].states.indexOf(st) >= 0) cir = { k: k, c: B.CIRCUITS[k] };
    });
    if (!cir) { out.innerHTML = ""; return; }
    out.innerHTML = '<div class="risk-banner risk-caution"><div class="risk-ic">§</div><div>' +
      '<div class="risk-label">' + X.esc(X.stateName(st)) + ' is in the ' + X.esc(cir.k) + ' Circuit — ' + X.esc(cir.c.t) + '.</div>' +
      '<div class="risk-sub">' + X.esc(cir.c.c) + '</div></div></div>';
  }

  X.bootstrap("bankrupt", mount);
})();

/* Clapback — "Medical bills" module.
 * Works only on YOUR OWN bills. No network requests. Nothing leaves this device.
 */
(function () {
  "use strict";
  var X = window.CBX, M = window.CBM;
  var mounted = false;
  var bills = [];

  function bill(i) { return bills[i] || {}; }

  /* ---------------- mount ---------------- */
  function mount() {
    var view = X.$("#view-bills");
    if (!view || mounted) { if (mounted) renderAll(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Medical bills</h1>' +
      '<p class="lede">A medical bill is a <strong>claim</strong>, not a verdict. Before you pay it, negotiate it, or panic about it, three things have to happen: you get the itemized version, you check it against what your insurer actually said you owe, and you find out whether you were supposed to be offered financial assistance first. Most people skip all three and pay a number that was never final.</p>' +

      '<div class="callout callout-info">' +
      '<strong>The order of operations matters.</strong> Paying first, or setting up a payment plan first, throws away every piece of leverage you have. Itemize → compare to the EOB → apply for assistance → then negotiate what actually remains. The <em>Financial assistance</em> tab handles step three, and it is the step that most often takes the bill to zero.' +
      '</div>' +

      /* ---- bill tracker ---- */
      '<div class="card">' +
      '<h2>Your bills</h2>' +
      '<p class="muted">Add a bill and Clapback works out which deadlines are running on it. Stored only on this device.</p>' +
      '<div class="ev-form" id="bill-form">' +
      '<div class="ev-field"><label class="field" for="b-provider">Provider or hospital</label><input class="input" id="b-provider" placeholder="e.g. St. Mary’s Medical Center"></div>' +
      '<div class="ev-field"><label class="field" for="b-acct">Account number</label><input class="input" id="b-acct" placeholder="Optional"></div>' +
      '<div class="ev-field"><label class="field" for="b-amount">Amount billed</label><input class="input" id="b-amount" type="number" min="0" step="0.01" placeholder="0.00"></div>' +
      '<div class="ev-field"><label class="field" for="b-dos">Date of service</label><input class="input" id="b-dos" type="date"></div>' +
      '<div class="ev-field"><label class="field" for="b-first">Date of the first bill after discharge</label><input class="input" id="b-first" type="date"><div class="hint">This one date drives the 120-day and 240-day charity care clocks. Find it on your earliest statement.</div></div>' +
      '<div class="ev-field"><label class="field" for="b-type">Kind of provider</label><select class="input" id="b-type">' +
      '<option value="nonprofit">Nonprofit hospital (most hospitals)</option>' +
      '<option value="forprofit">For-profit hospital</option>' +
      '<option value="physician">Physician practice or clinic</option>' +
      '<option value="other">Lab, imaging, ambulance, or other</option>' +
      '</select></div>' +
      '<div class="ev-field"><label class="field" for="b-ins">Were you insured for this?</label><select class="input" id="b-ins">' +
      '<option value="yes">Yes — I have coverage</option>' +
      '<option value="no">No — uninsured or self-pay</option>' +
      '</select></div>' +
      '<div class="ev-field-wide"><button class="btn" id="b-add">Add this bill</button></div>' +
      '</div>' +
      '<div id="bill-list"></div>' +
      '</div>' +

      /* ---- EOB vs bill ---- */
      '<h2>The one check worth doing first</h2>' +
      '<div class="card">' +
      '<h3>Is the bill bigger than your EOB says you owe?</h3>' +
      '<p>Your insurer’s Explanation of Benefits has a <strong>patient responsibility</strong> line. If the provider’s bill is larger than that number for the same claim, the provider is charging you part of its own contractual write-off — which is a prohibited balance bill. This check needs no coding knowledge, no clinical judgment, and no lawyer, and it produces an unambiguous answer.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="eob-pr">Patient responsibility on the EOB</label><input class="input" id="eob-pr" type="number" min="0" step="0.01" placeholder="0.00"></div>' +
      '<div class="ev-field"><label class="field" for="eob-bill">Amount the provider is billing you</label><input class="input" id="eob-bill" type="number" min="0" step="0.01" placeholder="0.00"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="eob-run">Compare</button></div>' +
      '</div>' +
      '<div id="eob-out"></div>' +
      '<div id="gc-list" class="link-list" style="margin-top:14px"></div>' +
      X.srcLine("Medicare Claims Processing Manual, Ch. 22 § 60.1 (CMS)", M.GROUP_CODES_SRC) +
      '</div>' +

      /* ---- No Surprises Act ---- */
      '<h2>Surprise bills — what federal law actually covers</h2>' +
      '<div class="card"><div id="nsa-covered" class="link-list"></div></div>' +
      '<div class="card danger"><h3>And what it doesn’t</h3><div id="nsa-gaps" class="link-list"></div></div>' +
      '<div class="card">' +
      '<h3>Services where nobody can ask you to sign away these protections</h3>' +
      '<p class="muted">A provider may only request a waiver in two situations — post-stabilization care, and non-emergency care by an out-of-network provider at an in-network facility. Even then, a waiver may <strong>never</strong> be requested for any of these:</p>' +
      '<ul class="tidy" id="nsa-noconsent"></ul>' +
      '<p class="muted" id="nsa-timing"></p>' +
      X.srcLine("45 CFR 149.420(b) (eCFR)", M.NSA.noConsentUrl) +
      '</div>' +

      /* ---- PPDR ---- */
      '<div class="card">' +
      '<h3>Uninsured or self-pay? The $400 dispute</h3>' +
      '<p>If you got a Good Faith Estimate and the bill came in at least <strong>$400 more</strong> than that provider’s estimate, you can start a federal Patient-Provider Dispute Resolution. While it’s pending the provider may not send you to collections, may not threaten to, must pause any collections already started, may not charge late fees, and may not retaliate.</p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="pp-gfe">Good Faith Estimate for this provider</label><input class="input" id="pp-gfe" type="number" min="0" step="0.01" placeholder="0.00"></div>' +
      '<div class="ev-field"><label class="field" for="pp-bill">Total billed by that provider</label><input class="input" id="pp-bill" type="number" min="0" step="0.01" placeholder="0.00"></div>' +
      '<div class="ev-field"><label class="field" for="pp-date">Date of the initial bill</label><input class="input" id="pp-date" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="pp-run">Check eligibility</button></div>' +
      '</div>' +
      '<div id="pp-out"></div>' +
      '<p class="muted" style="margin-top:12px">The $400 is measured <strong>per provider</strong> against that provider’s own estimate line — not against the total of every estimate you received. There’s a $25 administrative fee, non-refundable, but deducted from what you owe if you win.</p>' +
      '<div class="btn-row">' + X.a("Start a dispute at CMS ↗", M.NSA.ppdr, "btn btn-sm") + X.a("File a complaint ↗", M.NSA.complaint, "btn btn-ghost btn-sm") + '</div>' +
      '<div class="callout callout-info" style="margin-top:12px"><strong>No Surprises Help Desk: ' + X.esc(M.NSA.helpDesk) + '</strong><br>' + X.esc(M.NSA.helpDeskHours) + '</div>' +
      '</div>' +

      /* ---- error taxonomy ---- */
      '<h2>What to look for, line by line</h2>' +
      '<p class="muted">Once you have the itemized bill and the medical records side by side, these are the patterns. Ranked roughly by how often they turn into real money.</p>' +
      '<div id="err-list"></div>' +

      /* ---- prices ---- */
      '<h2>Is this price even reasonable?</h2>' +
      '<div class="card"><div id="price-facts"></div></div>' +
      '<div class="card"><h3>Free tools that work</h3><div id="price-tools" class="link-list"></div></div>' +
      '<div class="card danger"><h3>Two tools everyone still recommends that no longer work</h3><div id="price-stale"></div></div>' +
      '<div class="card"><h3>Looking up a code</h3><div id="code-tools" class="link-list"></div></div>' +

      /* ---- records ---- */
      '<h2>Your medical records</h2>' +
      '<div class="card">' +
      '<p id="rec-why" class="muted"></p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="rec-date">Date you sent the records request</label><input class="input" id="rec-date" type="date"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="rec-run">Work out the deadline</button></div>' +
      '</div>' +
      '<div id="rec-out"></div>' +
      '<h4 style="margin-top:16px">What they may charge you</h4>' +
      '<ul class="tidy" id="rec-fees"></ul>' +
      '<p class="muted" id="rec-feenote"></p>' +
      '<div class="callout callout-info" id="rec-nohold"></div>' +
      X.srcLine("45 CFR 164.524 (eCFR)", M.RECORDS.url) +
      '</div>' +

      /* ---- stats ---- */
      '<h2>The numbers — and the number we won’t repeat</h2>' +
      '<div class="grid-2" id="stat-cards"></div>' +
      '<div class="callout callout-warn" id="stat-honesty"></div>' +

      /* ---- letters ---- */
      '<h2>Letters</h2>' +
      '<p class="muted">Filled in from your profile. Everything in [square brackets] needs your details. Nothing is sent anywhere — you copy or print and send it yourself.</p>' +
      '<div class="card"><div id="bill-letters" class="link-list"></div></div>' +

      '<p class="disclaimer">Not legal or medical advice. Billing and coverage rules change, and your plan documents and your state’s law may give you more than the federal floor described here. Every claim on this page links to its source — verified ' + X.esc(M.UPDATED) + '. For anything high-stakes, talk to a patient advocate, a legal aid office, or a lawyer.</p>';

    wire();
    renderStatic();
    load();
  }

  /* ---------------- static renders ---------------- */
  function renderStatic() {
    /* group codes */
    var gc = X.$("#gc-list"); gc.innerHTML = "";
    M.GROUP_CODES.forEach(function (g) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      var main = X.el("div", "li-main", g.c + " — " + g.n);
      l.appendChild(main);
      l.appendChild(X.el("div", "li-note", g.t));
      row.appendChild(l);
      var tag = X.el("span", "status-pill " + (g.who === "provider" ? "status-ban" : g.who === "patient" ? "status-amber" : "status-none"),
        g.who === "provider" ? "Provider absorbs it" : g.who === "patient" ? "You may owe it" : "Depends");
      row.appendChild(tag);
      gc.appendChild(row);
    });

    /* NSA */
    var cov = X.$("#nsa-covered"); cov.innerHTML = "";
    M.NSA.covered.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.k));
      l.appendChild(X.el("div", "li-note", c.t + (c.cite ? "  — " + c.cite : "")));
      row.appendChild(l);
      if (c.url) { var w = X.el("div"); w.innerHTML = X.a("Source ↗", c.url); row.appendChild(w); }
      cov.appendChild(row);
    });
    var gaps = X.$("#nsa-gaps"); gaps.innerHTML = "";
    M.NSA.gaps.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.k));
      l.appendChild(X.el("div", "li-note", c.t));
      row.appendChild(l);
      if (c.url) { var w = X.el("div"); w.innerHTML = X.a("Source ↗", c.url); row.appendChild(w); }
      gaps.appendChild(row);
    });
    var nc = X.$("#nsa-noconsent"); nc.innerHTML = "";
    M.NSA.noConsent.forEach(function (s) { nc.appendChild(X.el("li", null, s)); });
    X.$("#nsa-timing").textContent = M.NSA.consentTiming;

    /* errors */
    var ee = X.$("#err-list"); ee.innerHTML = "";
    M.BILL_ERRORS.forEach(function (e) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", e.name));
      var badge = X.el("span", "status-pill " + (e.risk === "high" ? "status-red" : "status-amber"), e.risk === "high" ? "High value" : "Worth checking");
      head.appendChild(badge);
      card.appendChild(head);
      var body = X.el("div");
      body.appendChild(X.el("p", null, e.what));
      var spot = X.el("p", "law-tip"); spot.innerHTML = "<strong>How to spot it.</strong> " + X.esc(e.spot);
      body.appendChild(spot);
      if (e.why) { var w = X.el("p", "muted"); w.textContent = e.why; body.appendChild(w); }
      if (e.url) { var s = X.el("div"); s.innerHTML = X.srcLine(e.cite, e.url); body.appendChild(s); }
      card.appendChild(body);
      ee.appendChild(card);
    });

    /* prices */
    var pf = X.$("#price-facts"); pf.innerHTML = "";
    M.PRICE_FACTS.forEach(function (f) {
      var d = X.el("div"); d.style.marginBottom = "14px";
      d.appendChild(X.el("div", "li-main", f.n));
      d.appendChild(X.el("div", "li-note", f.t));
      if (f.caveat) { var c = X.el("div", "muted"); c.style.marginTop = "4px"; c.textContent = f.caveat; d.appendChild(c); }
      var s = X.el("div"); s.innerHTML = X.srcLine(f.src, f.u); d.appendChild(s);
      pf.appendChild(d);
    });
    var pt = X.$("#price-tools"); pt.innerHTML = "";
    M.PRICE_TOOLS.forEach(function (t) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      var m = X.el("div", "li-main", t.n);
      l.appendChild(m);
      l.appendChild(X.el("div", "li-note", t.t));
      row.appendChild(l);
      var r = X.el("div"); r.innerHTML = X.a("Open ↗", t.u);
      row.appendChild(r);
      pt.appendChild(row);
    });
    var ps = X.$("#price-stale"); ps.innerHTML = "";
    M.PRICE_STALE.forEach(function (t) {
      var d = X.el("div"); d.style.marginBottom = "10px";
      d.appendChild(X.el("div", "li-main", t.n));
      d.appendChild(X.el("div", "li-note", t.t));
      ps.appendChild(d);
    });
    var ct = X.$("#code-tools"); ct.innerHTML = "";
    M.CODE_TOOLS.forEach(function (t) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      var m = X.el("div", "li-main", t.n);
      l.appendChild(m);
      l.appendChild(X.el("div", "li-note", t.t));
      row.appendChild(l);
      var r = X.el("div"); r.innerHTML = X.a(t.free ? "Open ↗" : "About it ↗", t.u, t.free ? "btn btn-ghost btn-sm" : "btn btn-ghost btn-sm");
      row.appendChild(r);
      ct.appendChild(row);
    });

    /* records */
    X.$("#rec-why").textContent = M.RECORDS.why;
    var rf = X.$("#rec-fees"); rf.innerHTML = "";
    M.RECORDS.fees.forEach(function (f) { rf.appendChild(X.el("li", null, f)); });
    X.$("#rec-feenote").textContent = M.RECORDS.feeNote;
    X.$("#rec-nohold").innerHTML = "<strong>They cannot hold your records over an unpaid bill.</strong> " + X.esc(M.RECORDS.noHold) +
      " If they do, that is a complaint to the HHS Office for Civil Rights — within 180 days. " + X.a("OCR complaint portal ↗", M.RECORDS.ocr, "btn btn-ghost btn-sm");

    /* stats */
    var sc = X.$("#stat-cards"); sc.innerHTML = "";
    M.DENIAL_STATS.forEach(function (s) {
      var c = X.el("div", "card mini");
      var n = X.el("div", "stat-num", s.big); n.style.fontSize = "28px";
      c.appendChild(n);
      c.appendChild(X.el("div", "li-note", s.t));
      var src = X.el("div"); src.innerHTML = X.srcLine(s.src, s.u); c.appendChild(src);
      sc.appendChild(c);
    });
    X.$("#stat-honesty").innerHTML = "<strong>The number we won’t repeat.</strong> " + X.esc(M.STAT_HONESTY);

    /* letters */
    X.letterCards(X.$("#bill-letters"), "bills", function () {
      var b = bills.length ? bills[bills.length - 1] : {};
      return {
        to: b.provider ? b.provider + "\nPatient Financial Services\n[address]" : "",
        acct: b.acct || "", amount: b.amount ? X.money(b.amount) : "",
        dos: b.dos ? X.fmtShort(X.parseDate(b.dos)) : "", provider: b.provider || ""
      };
    });
  }

  /* ---------------- interactive ---------------- */
  function wire() {
    X.$("#b-add").addEventListener("click", addBill);

    X.$("#eob-run").addEventListener("click", function () {
      var pr = parseFloat(X.$("#eob-pr").value), bl = parseFloat(X.$("#eob-bill").value);
      var out = X.$("#eob-out"); out.innerHTML = "";
      if (!isFinite(pr) || !isFinite(bl)) { out.innerHTML = '<div class="callout callout-warn">Enter both numbers.</div>'; return; }
      var diff = bl - pr;
      if (diff > 0.005) {
        out.innerHTML = '<div class="risk-banner risk-high"><div class="risk-ic">⚠</div><div>' +
          '<div class="risk-label">You are being billed ' + X.esc(X.money(diff)) + ' more than your EOB says you owe.</div>' +
          '<div class="risk-sub">That difference is presumptively an improper balance bill — the provider charging you part of its own contractual write-off. Send the balance-billing letter below, and copy your insurer’s member services. The insurer often intervenes, because the provider is violating its network contract.</div>' +
          '</div></div>';
      } else if (diff < -0.005) {
        out.innerHTML = '<div class="risk-banner risk-low"><div class="risk-ic">✓</div><div>' +
          '<div class="risk-label">The bill is ' + X.esc(X.money(-diff)) + ' LESS than your EOB patient-responsibility line.</div>' +
          '<div class="risk-sub">Nothing wrong here — the provider may have applied a discount or a payment. Keep the EOB either way.</div>' +
          '</div></div>';
      } else {
        out.innerHTML = '<div class="risk-banner risk-low"><div class="risk-ic">✓</div><div>' +
          '<div class="risk-label">These match.</div>' +
          '<div class="risk-sub">The billed amount equals your patient responsibility. That doesn’t mean the underlying charges are right — the itemized bill is still worth reading — but this particular problem isn’t present.</div>' +
          '</div></div>';
      }
    });

    X.$("#pp-run").addEventListener("click", function () {
      var gfe = parseFloat(X.$("#pp-gfe").value), bl = parseFloat(X.$("#pp-bill").value);
      var dt = X.parseDate(X.$("#pp-date").value);
      var out = X.$("#pp-out"); out.innerHTML = "";
      if (!isFinite(gfe) || !isFinite(bl)) { out.innerHTML = '<div class="callout callout-warn">Enter the estimate and the billed amount.</div>'; return; }
      var over = bl - gfe;
      var html = "";
      if (over >= M.NSA.ppdrThreshold) {
        html += '<div class="risk-banner risk-high"><div class="risk-ic">⚑</div><div>' +
          '<div class="risk-label">Eligible on the dollar test — the bill is ' + X.esc(X.money(over)) + ' over the estimate.</div>' +
          '<div class="risk-sub">That clears the $400 threshold. You must also have been uninsured or self-pay for this care and have received a Good Faith Estimate, and the care must have been furnished on or after January 1, 2022.</div>' +
          '</div></div>';
      } else {
        html += '<div class="risk-banner risk-caution"><div class="risk-ic">–</div><div>' +
          '<div class="risk-label">' + X.esc(X.money(Math.max(0, over))) + ' over the estimate — below the $400 threshold.</div>' +
          '<div class="risk-sub">Federal dispute resolution isn’t available on this bill. The itemized-bill review, financial assistance, and negotiation are still open to you, and all three often do more.</div>' +
          '</div></div>';
      }
      if (dt) {
        var due = X.addDays(dt, M.NSA.ppdrDays);
        var u = X.urgency(X.iso(due));
        html += '<div class="callout ' + (u.cls === "sev-high" ? "callout-warn" : "callout-info") + '" style="margin-top:12px">' +
          '<strong>Your deadline: ' + X.esc(X.fmt(due)) + '</strong> — ' + X.esc(u.label) + '.<br>' +
          'The initiation notice must be postmarked within 120 calendar days of receiving the initial bill.' +
          '</div>';
        if (over >= M.NSA.ppdrThreshold) {
          html += '<div class="btn-row"><button class="btn btn-sm" id="pp-track">Add this deadline to my tracker</button></div>';
        }
      } else {
        html += '<p class="muted" style="margin-top:10px">Add the date of the initial bill and Clapback will work out your 120-day deadline.</p>';
      }
      out.innerHTML = html;
      var t = X.$("#pp-track");
      if (t) t.addEventListener("click", function () {
        X.addDeadline({ kind: "ppdr", label: "No Surprises Act dispute (PPDR) — initiation notice must be postmarked", due: X.iso(X.addDays(dt, M.NSA.ppdrDays)), note: "Bill exceeded the Good Faith Estimate by " + X.money(over) + ". Start at cms.gov/medical-bill-rights/help/dispute-a-bill" });
      });
    });

    X.$("#rec-run").addEventListener("click", function () {
      var d = X.parseDate(X.$("#rec-date").value);
      var out = X.$("#rec-out"); out.innerHTML = "";
      if (!d) { out.innerHTML = '<div class="callout callout-warn">Enter the date you sent the request.</div>'; return; }
      var due = X.addDays(d, M.RECORDS.days);
      var ext = X.addDays(d, M.RECORDS.days + M.RECORDS.ext);
      var u = X.urgency(X.iso(due));
      out.innerHTML = '<div class="callout callout-info">' +
        '<strong>They must act by ' + X.esc(X.fmt(due)) + '</strong> — ' + X.esc(u.label) + '.<br>' +
        'They may take one extension to ' + X.esc(X.fmt(ext)) + ', but only with a written statement of the reason and the date they will finish. No written extension notice means the 30-day deadline stands.' +
        '</div>' +
        '<div class="btn-row"><button class="btn btn-sm" id="rec-track">Add to my tracker</button></div>';
      X.$("#rec-track").addEventListener("click", function () {
        X.addDeadline({ kind: "records", label: "Medical records must be produced (HIPAA right of access)", due: X.iso(due), note: "If nothing arrives and you got no written extension notice, complain to HHS OCR — within 180 days." });
      });
    });
  }

  /* ---------------- bill store ---------------- */
  function addBill() {
    var b = {
      provider: X.$("#b-provider").value.trim(),
      acct: X.$("#b-acct").value.trim(),
      amount: parseFloat(X.$("#b-amount").value) || 0,
      dos: X.$("#b-dos").value,
      first: X.$("#b-first").value,
      type: X.$("#b-type").value,
      ins: X.$("#b-ins").value,
      at: Date.now()
    };
    if (!b.provider) { X.toast("Add the provider name"); return; }
    bills.push(b);
    X.set({ medBills: bills }).then(function () {
      ["#b-provider", "#b-acct", "#b-amount", "#b-dos", "#b-first"].forEach(function (s) { X.$(s).value = ""; });
      X.toast("Bill added");
      renderBills();
    });
  }
  function load() {
    X.get(["medBills"]).then(function (d) {
      bills = Array.isArray(d.medBills) ? d.medBills : [];
      renderBills();
    });
  }
  function renderAll() { renderBills(); }

  function renderBills() {
    var host = X.$("#bill-list"); if (!host) return;
    host.innerHTML = "";
    if (!bills.length) {
      host.innerHTML = '<p class="muted">No bills added yet.</p>';
      return;
    }
    bills.forEach(function (b, i) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", b.provider + (b.amount ? " — " + X.money(b.amount) : "")));
      var del = X.el("button", "ev-del", "Remove");
      del.addEventListener("click", function () {
        bills.splice(i, 1);
        X.set({ medBills: bills }).then(renderBills);
      });
      head.appendChild(del);
      card.appendChild(head);

      var meta = X.el("div", "muted");
      var bits = [];
      if (b.acct) bits.push("Account " + b.acct);
      if (b.dos) bits.push("Service " + X.fmtShort(X.parseDate(b.dos)));
      if (b.ins === "no") bits.push("Uninsured / self-pay");
      meta.textContent = bits.join("  ·  ");
      card.appendChild(meta);

      /* what's running on this bill */
      var plan = X.el("div"); plan.style.marginTop = "10px";
      var items = [];

      if (b.type === "nonprofit" && b.first) {
        var f = X.parseDate(b.first);
        var d120 = X.addDays(f, 120), d240 = X.addDays(f, 240);
        var u120 = X.urgency(X.iso(d120)), u240 = X.urgency(X.iso(d240));
        items.push({
          h: "They cannot take an extraordinary collection action before " + X.fmtShort(d120),
          t: "120 days from your first post-discharge bill. Reporting you to a credit bureau, suing you, garnishing wages, or placing a lien before that date is a problem for them. " + (u120.label ? "(" + u120.label + ")" : ""),
          due: X.iso(d120), kind: "eca120", label: "Earliest date this hospital may start an extraordinary collection action"
        });
        items.push({
          h: "Your financial assistance application window runs to " + X.fmtShort(d240),
          t: "240 days from that same first bill. This right survives even if collection has already started — and if you're approved, they must reverse what they did. " + (u240.label ? "(" + u240.label + ")" : ""),
          due: X.iso(d240), kind: "fap240", label: "Last day to apply for this hospital’s financial assistance"
        });
      } else if (b.type === "nonprofit" && !b.first) {
        items.push({ h: "Add the date of your first bill after discharge", t: "It's the single date that drives both charity care clocks. Everything on the Financial assistance tab keys off it.", due: "", kind: "", label: "" });
      }
      if (b.type === "forprofit" || b.type === "physician" || b.type === "other") {
        items.push({ h: "Section 501(r) doesn’t apply here", t: "Charity care obligations bind tax-exempt hospital facilities. For-profit hospitals, physician practices, labs, imaging centers, and ambulance companies aren't covered — though many have their own hardship policies, and your state may still require assistance. Ask anyway, in writing.", due: "", kind: "", label: "" });
      }
      if (b.ins === "no") {
        items.push({ h: "You were entitled to a Good Faith Estimate", t: "If this was scheduled care and you were self-pay, the provider owed you a written estimate. If the bill came in $400 or more above it, use the dispute calculator above.", due: "", kind: "", label: "" });
      }
      if (b.ins === "yes") {
        items.push({ h: "Compare it to your EOB before anything else", t: "Get the Explanation of Benefits for this claim and check the patient-responsibility line against what they're billing. That's the check above.", due: "", kind: "", label: "" });
      }

      items.forEach(function (it) {
        var row = X.el("div", "link-item");
        var l = X.el("div");
        l.appendChild(X.el("div", "li-main", it.h));
        l.appendChild(X.el("div", "li-note", it.t));
        row.appendChild(l);
        if (it.due) {
          var btn = X.el("button", "btn btn-ghost btn-sm", "Track");
          btn.addEventListener("click", function () {
            X.addDeadline({ kind: it.kind, label: it.label + " — " + b.provider, due: it.due, note: "Bill: " + b.provider + (b.acct ? ", account " + b.acct : "") });
          });
          row.appendChild(btn);
        }
        plan.appendChild(row);
      });
      card.appendChild(plan);
      host.appendChild(card);
    });
  }

  X.bootstrap("bills", mount);
})();

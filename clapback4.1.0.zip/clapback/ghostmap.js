/* Clapback — "Ghost map" module, real-data edition.
 * The map shades from DOCUMENTED public action — AG enforcement, bills passed,
 * bills introduced — every colored state backed by a dated, sourced item in the
 * tracker below (snapshot researched for this release; Clapback makes no network
 * requests, so the feed ships as data and the follow-links keep you current).
 * The user's own incident log remains as their private evidence tool and feeds
 * the agency scale. Nothing here is invented: public items carry sources, and
 * personal items are labeled as the user's own.
 */
(function () {
  "use strict";
  var D = window.PDS;
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function get(keys) { return hasChrome ? chrome.storage.local.get(keys) : Promise.resolve({}); }
  function set(obj) { return hasChrome ? chrome.storage.local.set(obj) : Promise.resolve(); }
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });
  var KIND_LABEL = {};
  (D.GHOST_KINDS || []).forEach(function (k) { KIND_LABEL[k.k] = k.label; });

  var log = [];
  var profile = {};
  var feedFilter = "all";     // all | enforcement | legislation | courts | data | context
  var feedState = "";          // "" or state code — set by clicking the map
  var mounted = false;

  function gdUrl(name) { return "https://www.glassdoor.com/Search/results.htm?keyword=" + encodeURIComponent(name); }
  function bbbUrl(name) { return "https://www.bbb.org/search?find_text=" + encodeURIComponent(name); }
  function redditUrl(name) { return "https://www.reddit.com/search/?q=" + encodeURIComponent('"' + name + '" recruiter'); }

  /* Map category per state, derived from the documented feed. */
  function stateStatus() {
    var by = {};
    (D.GHOST_FEED || []).forEach(function (f) {
      if (!f.st) return;
      if (!by[f.st]) by[f.st] = { items: 0, rank: 0, label: "" };
      by[f.st].items++;
      var rank = 0, label = "";
      if (f.kind === "enforcement") { rank = 3; label = "AG enforcement activity"; }
      else if (f.kind === "legislation" && /Passed both houses/i.test(f.status)) { rank = 2; label = "Bill passed legislature"; }
      else if (f.kind === "legislation") { rank = 1; label = "Bill introduced / in committee"; }
      if (rank > by[f.st].rank) { by[f.st].rank = rank; by[f.st].label = label; }
    });
    return by;
  }
  var RANK_HEAT = { 3: "1", 2: "0.72", 1: "0.4", 0: "0" };

  /* ---------------- mount ---------------- */

  function mount() {
    var view = $("#view-ghostmap");
    if (!view || mounted) { if (mounted) renderAll(); return; }
    mounted = true;

    view.innerHTML =
      '<h1 id="ghostmap-h1">Ghost map</h1>' +
      '<p class="lede">Ghost jobs stopped being just a gripe: an attorney general is <strong>investigating LinkedIn</strong> over them, New York\u2019s legislature has <strong>passed the first US ghost-job bill</strong>, and four more states have bills moving. The map shades every state by its <strong>documented action</strong> \u2014 each colored state is backed by a dated, sourced item in the tracker below. Your own incident log lives further down: private, exportable, and the raw material for complaints that keep this map filling in.</p>' +

      '<div class="card">' +
      '<h2>Documented action by state</h2>' +
      '<div id="gm-grid" class="gm-grid" role="group" aria-label="US state grid \u2014 shading shows documented ghost-job enforcement and legislation"></div>' +
      '<div class="gm-legend">' +
      '<span class="gm-swatch" style="--heat:1"></span><span>AG enforcement</span>' +
      '<span class="gm-swatch" style="--heat:.72"></span><span>passed legislature</span>' +
      '<span class="gm-swatch" style="--heat:.4"></span><span>bill introduced</span>' +
      '<span class="gm-swatch" style="--heat:0"></span><span>none documented</span>' +
      '<span class="gm-mystate">\u2b1c your state</span>' +
      '</div>' +
      '<p id="gm-summary" class="muted" aria-live="polite"></p>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Lawsuit &amp; law tracker</h2>' +
      '<p class="muted">Snapshot researched <strong>' + esc(D.GHOST_FEED_UPDATED || "") + "</strong> \u2014 shipped with this version because Clapback makes no network requests of its own. Every item is dated, statused precisely (an investigation is not a lawsuit; a passed bill is not a signed law), and sourced \u2014 primary sources where they exist. The follow links keep you current between Clapback updates.</p>" +
      '<div class="chips" id="gm-feed-chips" role="tablist" aria-label="Filter tracker"></div>' +
      '<div id="gm-feed-scope" class="muted hidden"></div>' +
      '<div id="gm-feed"></div>' +
      '<div class="gm-follow"><strong>Follow it live:</strong> ' +
      (D.GHOST_FOLLOW || []).map(function (f) { return '<a href="' + esc(f.u) + '" target="_blank" rel="noopener">' + esc(f.n) + " \u2197</a>"; }).join(" \u00b7 ") +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>What the reports say</h2>' +
      '<p class="muted">The social-media noise, measured \u2014 every number below names its survey and links its source. No composite scores, no vibes-as-data.</p>' +
      '<ul class="tidy">' +
      (D.GHOST_STATS || []).map(function (s) {
        return "<li><strong>" + esc(s.stat) + ".</strong> <a href=\"" + esc(s.u) + '" target="_blank" rel="noopener">' + esc(s.src) + " \u2197</a></li>";
      }).join("") +
      '</ul>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Your evidence log</h2>' +
      '<p class="muted">Private, on-device, exportable. Log what you personally run into \u2014 it feeds your agency scale below and exports as an evidence pack for the <button class="btn btn-ghost btn-sm" data-goto="report">Report it</button> tab. Personal entries never touch the map above: that\u2019s documented public action only.</p>' +
      '<div class="ghost-fields">' +
      '<select id="gm-state" aria-label="State"></select>' +
      '<select id="gm-kind" aria-label="What happened"></select>' +
      '<input type="text" id="gm-org" list="gm-org-list" placeholder="Company / agency (optional)" aria-label="Company or agency">' +
      '<input type="text" id="gm-note" placeholder="Note \u2014 role, posting link, date seen\u2026 (optional)" aria-label="Note">' +
      '</div>' +
      '<datalist id="gm-org-list">' +
      (D.AGENCIES || []).map(function (a) { return '<option value="' + esc(a.name) + '">'; }).join("") +
      '</datalist>' +
      '<button class="btn" id="gm-add">Add to my log</button>' +
      '<span id="gm-added" class="rp-verified hidden">logged \u2713</span>' +
      '<div id="gm-entries"></div>' +
      '<div class="agency-letter-actions">' +
      '<button class="btn btn-ghost" id="gm-export-csv">Export CSV</button>' +
      '<button class="btn btn-ghost" id="gm-export-json">Export JSON</button>' +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<h2>Your agency scale</h2>' +
      '<p class="muted">Companies ranked by <strong>your logged incidents</strong>, each paired with the public record \u2014 Glassdoor interviews, the BBB file, and what people are saying on Reddit. No regulator publishes per-agency ghosting complaints, so Clapback shows your record plus theirs, and invents nothing in between.</p>' +
      '<div id="gm-scale"></div>' +
      '</div>';

    // feed filter chips
    var chips = $("#gm-feed-chips");
    var kinds = [["all", "All"], ["enforcement", "Enforcement"], ["legislation", "Legislation"], ["courts", "Courts"], ["data", "Analysis"], ["context", "Context"]];
    chips.innerHTML = kinds.map(function (k, i) {
      return '<button class="chip' + (i === 0 ? " active" : "") + '" data-feed="' + k[0] + '" role="tab" aria-selected="' + (i === 0) + '">' + k[1] + "</button>";
    }).join("");
    chips.addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      feedFilter = c.dataset.feed;
      chips.querySelectorAll(".chip").forEach(function (x) {
        x.classList.toggle("active", x === c);
        x.setAttribute("aria-selected", x === c ? "true" : "false");
      });
      renderFeed();
    });

    // log selects
    var sel = $("#gm-state");
    var codes = Object.keys(D.TILE_GRID || {}).sort(function (a, b) {
      return (STATE_NAME[a] || a) < (STATE_NAME[b] || b) ? -1 : 1;
    });
    sel.innerHTML = codes.map(function (c) {
      return '<option value="' + c + '">' + esc(STATE_NAME[c] || c) + "</option>";
    }).join("");
    var kindSel = $("#gm-kind");
    kindSel.innerHTML = (D.GHOST_KINDS || []).map(function (k) {
      return '<option value="' + esc(k.k) + '">' + esc(k.label) + "</option>";
    }).join("");

    $("#gm-add").addEventListener("click", addEntry);
    $("#gm-entries").addEventListener("click", function (e) {
      var b = e.target.closest("button[data-del]"); if (!b) return;
      log.splice(parseInt(b.dataset.del, 10), 1);
      set({ ghostLog: log }).then(renderAll);
    });
    $("#gm-grid").addEventListener("click", function (e) {
      var cell = e.target.closest("button[data-st]"); if (!cell) return;
      feedState = (feedState === cell.dataset.st) ? "" : cell.dataset.st;
      sel.value = cell.dataset.st;
      renderGrid();
      renderFeed();
    });
    $("#gm-export-csv").addEventListener("click", function () { exportLog("csv"); });
    $("#gm-export-json").addEventListener("click", function () { exportLog("json"); });

    get(["ghostLog", "profile"]).then(function (d) {
      log = Array.isArray(d.ghostLog) ? d.ghostLog : [];
      profile = d.profile || {};
      if (profile.state && (D.TILE_GRID || {})[profile.state]) sel.value = profile.state;
      renderAll();
    });
  }

  function addEntry() {
    var entry = {
      st: $("#gm-state").value, kind: $("#gm-kind").value,
      org: ($("#gm-org").value || "").trim(), note: ($("#gm-note").value || "").trim(),
      at: Date.now()
    };
    if (!entry.st || !entry.kind) return;
    log.push(entry);
    set({ ghostLog: log }).then(function () {
      $("#gm-org").value = ""; $("#gm-note").value = "";
      var tick = $("#gm-added");
      tick.classList.remove("hidden");
      setTimeout(function () { tick.classList.add("hidden"); }, 1600);
      renderAll();
    });
  }

  /* ---------------- rendering ---------------- */

  function renderAll() { renderGrid(); renderFeed(); renderEntries(); renderScale(); }

  function renderGrid() {
    var grid = $("#gm-grid"); if (!grid) return;
    var status = stateStatus();
    grid.innerHTML = Object.keys(D.TILE_GRID || {}).map(function (code) {
      var pos = D.TILE_GRID[code];
      var s = status[code];
      var heat = s ? RANK_HEAT[s.rank] : "0";
      var labelBits = STATE_NAME[code] || code;
      if (s) labelBits += " \u2014 " + s.label + " (" + s.items + " tracked item" + (s.items === 1 ? "" : "s") + ")";
      else labelBits += " \u2014 no documented action in this snapshot";
      var cls = "gm-cell" + (parseFloat(heat) > 0.55 ? " hot" : "") +
        (code === profile.state ? " mine" : "") +
        (code === feedState ? " picked" : "");
      return '<button class="' + cls + '" data-st="' + code + '" style="grid-column:' + (pos[0] + 1) + ";grid-row:" + (pos[1] + 1) + ";--heat:" + heat + '" aria-label="' + esc(labelBits) + '" title="' + esc(labelBits) + '">' +
        "<span>" + code + "</span>" + (s ? "<em>" + s.items + "</em>" : "") +
        "</button>";
    }).join("");

    var acted = Object.keys(status).length;
    $("#gm-summary").textContent = "Documented action in " + acted + " states as of " + (D.GHOST_FEED_UPDATED || "this snapshot") + " \u2014 1 AG investigation (TX), 1 bill through both houses (NY), bills moving in PA, NJ, CA, and KY. Click a state to filter the tracker; click again to clear.";
  }

  function renderFeed() {
    var box = $("#gm-feed"); if (!box) return;
    var scope = $("#gm-feed-scope");
    if (feedState) {
      scope.classList.remove("hidden");
      scope.innerHTML = "Showing items for <strong>" + esc(STATE_NAME[feedState] || feedState) + "</strong> \u2014 click the state again to clear.";
    } else { scope.classList.add("hidden"); scope.innerHTML = ""; }

    var items = (D.GHOST_FEED || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; })
      .filter(function (f) { return feedFilter === "all" || f.kind === feedFilter; })
      .filter(function (f) { return !feedState || f.st === feedState; });

    if (!items.length) {
      box.innerHTML = '<p class="muted" style="margin-top:8px">No tracked items match \u2014 clear the filters, or check the follow links: if it happened after ' + esc(D.GHOST_FEED_UPDATED || "this snapshot") + ", it\u2019s out there but not in this snapshot yet.</p>";
      return;
    }
    box.innerHTML = items.map(function (f) {
      var pill = f.kind === "enforcement" ? "pill-red" : f.kind === "legislation" ? "pill-green" : "pill-gray";
      return '<div class="gm-feed-item">' +
        '<div class="gm-feed-head">' +
        '<span class="gm-feed-date">' + esc(f.date) + "</span>" +
        (f.st ? '<span class="seg-badge">' + esc(STATE_NAME[f.st] || f.st) + "</span>" : "") +
        '<span class="gm-feed-status">' + esc(f.status) + "</span>" +
        "</div>" +
        "<strong>" + esc(f.title) + "</strong>" +
        '<p class="gm-feed-sum">' + esc(f.sum) + "</p>" +
        '<div class="gm-feed-src">Sources: ' + (f.src || []).map(function (s) {
          return '<a href="' + esc(s.u) + '" target="_blank" rel="noopener">' + esc(s.n) + " \u2197</a>";
        }).join(" \u00b7 ") + "</div>" +
        "</div>";
    }).join("");
  }

  function renderEntries() {
    var box = $("#gm-entries"); if (!box) return;
    if (!log.length) { box.innerHTML = ""; return; }
    var items = log.map(function (e, i) { return { e: e, i: i }; }).reverse();
    box.innerHTML = '<div class="gm-entrylist">' + items.map(function (x) {
      var e = x.e;
      return '<div class="gm-entry">' +
        "<strong>" + esc(e.st) + "</strong> \u00b7 " + esc(KIND_LABEL[e.kind] || e.kind) +
        (e.org ? " \u00b7 " + esc(e.org) : "") +
        (e.note ? ' <span class="muted">\u2014 ' + esc(e.note) + "</span>" : "") +
        ' <span class="muted">(' + new Date(e.at).toLocaleDateString() + ")</span>" +
        ' <button class="btn btn-ghost btn-sm" data-del="' + x.i + '" aria-label="Delete entry">\u00d7</button>' +
        "</div>";
    }).join("") + "</div>";
  }

  function renderScale() {
    var box = $("#gm-scale"); if (!box) return;
    var byOrg = {};
    var nameIndex = {};
    (D.AGENCIES || []).forEach(function (a) { nameIndex[a.name.toLowerCase()] = a; });
    log.forEach(function (e) {
      if (!e.org) return;
      var key = e.org.toLowerCase();
      if (!byOrg[key]) byOrg[key] = { display: e.org, agency: nameIndex[key] || null, kinds: {}, n: 0 };
      byOrg[key].n++;
      byOrg[key].kinds[e.kind] = (byOrg[key].kinds[e.kind] || 0) + 1;
    });
    var rows = Object.keys(byOrg).map(function (k) { return byOrg[k]; })
      .sort(function (a, b) { return b.n - a.n; });

    if (!rows.length) {
      box.innerHTML = '<p class="muted">No incidents with a company attached yet. Add the agency name when you log \u2014 directory names autocomplete \u2014 and your scale builds itself.</p>';
      return;
    }
    var max = rows[0].n;
    box.innerHTML = rows.map(function (r) {
      var name = r.agency ? r.agency.name : r.display;
      var kindBits = Object.keys(r.kinds).map(function (k) {
        return '<span class="seg-badge">' + esc((KIND_LABEL[k] || k).split(" (")[0]) + " \u00d7" + r.kinds[k] + "</span>";
      }).join(" ");
      return '<div class="gm-scale-row">' +
        '<div class="gm-scale-bar" style="--heat:' + (r.n / max).toFixed(2) + '"></div>' +
        '<div class="gm-scale-main"><strong>' + esc(name) + "</strong> \u2014 " + r.n + " logged " + kindBits +
        (r.agency ? ' <span class="muted">(' + esc(r.agency.domain) + ")</span>" : ' <span class="muted">(not in directory \u2014 vet before engaging)</span>') +
        "</div>" +
        '<div class="gm-scale-actions">' +
        '<a class="btn btn-ghost btn-sm" href="' + gdUrl(name) + '" target="_blank" rel="noopener">Glassdoor \u2197</a>' +
        '<a class="btn btn-ghost btn-sm" href="' + bbbUrl(name) + '" target="_blank" rel="noopener">BBB \u2197</a>' +
        '<a class="btn btn-ghost btn-sm" href="' + redditUrl(name) + '" target="_blank" rel="noopener">Reddit \u2197</a>' +
        "</div>" +
        "</div>";
    }).join("");
  }

  /* ---------------- export ---------------- */

  function exportLog(kind) {
    if (!log.length) return;
    var blob, fname;
    if (kind === "csv") {
      var head = "date,state,kind,company,note\n";
      var rows = log.map(function (e) {
        var cells = [new Date(e.at).toISOString().slice(0, 10), e.st, KIND_LABEL[e.kind] || e.kind, e.org || "", e.note || ""];
        return cells.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(",");
      }).join("\n");
      blob = new Blob([head + rows], { type: "text/csv" });
      fname = "clapback-ghost-log.csv";
    } else {
      blob = new Blob([JSON.stringify({ app: "clapback", kind: "ghostLog", exportedAt: new Date().toISOString(), entries: log }, null, 2)], { type: "application/json" });
      fname = "clapback-ghost-log.json";
    }
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }

  /* ---------------- init ---------------- */
  if (hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== "local" || !mounted) return;
      if (ch.ghostLog) { log = ch.ghostLog.newValue || []; renderEntries(); renderScale(); }
      if (ch.profile) { profile = ch.profile.newValue || {}; renderGrid(); }
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  var navBtn = document.querySelector('[data-view="ghostmap"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

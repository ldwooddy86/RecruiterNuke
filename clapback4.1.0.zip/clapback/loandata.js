/*
 * Clapback — student loans dataset  (window.CBS)
 *
 * SAME CHARTER: your own loans, your own file, your own case. No network
 * requests. Every external check is a link you choose to open.
 *
 * THIS TAB HAS A SPECIAL PROBLEM. Federal student loan rules changed more
 * between July 2025 and July 2026 than in the previous decade. Almost every
 * explainer online is stale: it describes SAVE as a live plan, Grad PLUS as
 * available, Fresh Start as open, and IDR forgiveness as tax-free. All four
 * are wrong now. Where Clapback states a rule, it states when the rule took
 * effect and links the regulation.
 *
 * Two facts in here are VOLATILE and marked as such in the UI:
 *   - whether involuntary collections are running today
 *   - whether the DOJ bankruptcy guidance is still in force
 * Clapback tells you what it last verified and tells you to re-check. It does
 * not pretend to know today's answer, because being wrong about a paused
 * garnishment is worse than saying "check this."
 *
 * Verified August 22–23, 2026.
 */
window.CBS = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  /* ================================================================== */
  /* WHAT CHANGED — the 2025 law                                         */
  /* ================================================================== */
  var LAW = {
    cite: "Public Law 119-21, approved July 4, 2025 (H.R. 1)",
    naming: "You will see this called the “One Big Beautiful Bill Act.” That short title was struck in the Senate and is not the enacted name — the law has no official short title, and the Department of Education itself calls it the Working Families Tax Cuts Act. If you cite it in a letter or a filing, cite Public Law 119-21.",
    url: "https://www.govinfo.gov/app/details/PLAW-119publ21",
    ruleUrl: "https://www.federalregister.gov/documents/2026/05/01/2026-08556/reimagining-and-improving-student-education-federal-student-loan-program-final-regulations",
    changes: [
      { n: "Grad PLUS loans eliminated", d: "For periods of instruction beginning July 1, 2026. Borrowers already enrolled and already holding Grad PLUS for that program as of June 30, 2026 can keep borrowing for up to three more years or until they finish, whichever is shorter — same program, same school." },
      { n: "Parent PLUS capped", d: "$20,000 per year per dependent student, $65,000 aggregate per dependent student, from July 1, 2026. Parents borrowing before that date keep the old limits for three more years or until the program ends." },
      { n: "New graduate and lifetime caps", d: "Graduate: $20,500/year, $100,000 aggregate. Professional: $50,000/year, $200,000 aggregate. And a $257,500 lifetime cap across all federal student loans, excluding Parent PLUS." },
      { n: "A new repayment plan — RAP", d: "The Repayment Assistance Plan opened July 1, 2026. It is available to any Direct Loan borrower regardless of when the loan was made — except Parent PLUS, which is excluded." },
      { n: "Most income-driven plans are ending", d: "SAVE is already dead. ICR and PAYE terminate July 1, 2028. IBR survives indefinitely, but only for Direct Loans made before July 1, 2026." },
      { n: "Deferments narrowed", d: "For loans disbursed on or after July 1, 2027, unemployment deferment and economic hardship deferment are eliminated outright, and general forbearance is capped at nine months in any 24-month period. Loans disbursed before that date keep the old rules — the trigger is the loan's disbursement date, not your situation." },
      { n: "Rehabilitation twice", d: "From July 1, 2027 you may rehabilitate a loan out of default up to twice in its lifetime, instead of once. The minimum monthly payment rises from $5 to $10." },
      { n: "Borrower defense rolled back", d: "The 2023 borrower defense regulations do not apply to loans originated before July 1, 2035. The rules in place just before 2023 govern instead." }
    ]
  };

  /* ================================================================== */
  /* REPAYMENT PLANS                                                     */
  /* ================================================================== */
  var RAP = {
    name: "Repayment Assistance Plan (RAP)",
    live: "Open since July 1, 2026",
    cite: "34 CFR 685.209",
    url: "https://www.ecfr.gov/current/title-34/subtitle-B/chapter-VI/part-685/subpart-B/section-685.209",
    /* Annual base payment as a percentage of TOTAL AGI — not discretionary income. */
    brackets: [
      { max: 10000, flat: 120, pct: 0 },
      { max: 20000, pct: 1 }, { max: 30000, pct: 2 }, { max: 40000, pct: 3 },
      { max: 50000, pct: 4 }, { max: 60000, pct: 5 }, { max: 70000, pct: 6 },
      { max: 80000, pct: 7 }, { max: 90000, pct: 8 }, { max: 100000, pct: 9 },
      { max: Infinity, pct: 10 }
    ],
    perDependent: 50,
    floor: 10,
    forgiveYears: 30,
    forgivePayments: 360,
    good: [
      "Unpaid interest that your on-time payment doesn't cover is not charged. Your balance cannot grow the way it does on the old plans.",
      "If an on-time payment reduces principal by less than $50, the government makes up the difference — up to $50 a month toward principal.",
      "On-time RAP payments count toward Public Service Loan Forgiveness.",
      "It is open to borrowers with loans of any vintage, not only new ones."
    ],
    bad: [
      "Forgiveness takes 360 payments over at least 30 years — longer than any plan it replaces.",
      "The percentage applies to your TOTAL adjusted gross income, not to discretionary income above a poverty-line protection. At low incomes that is a meaningful difference.",
      "Parent PLUS loans, and any consolidation loan that repaid a Parent PLUS, cannot use RAP at all.",
      "The brackets are steps, not a smooth curve — so there are cliffs. See the calculator."
    ],
    cliff: "The rate applies to your WHOLE adjusted gross income, not just the part inside the bracket, so each $10,000 boundary is a step rather than a slope. The effect is largest at the bottom: at $20,000 of AGI the base is 1% \u2014 about $17 a month \u2014 and at $20,001 it is 2%, about $33. Higher up the steps are proportionally smaller (8% to 9% at the $90,000 line is a 12.5% jump, not a doubling), and at the $10,000 line the $10 monthly floor absorbs it entirely. Worth checking your own boundary before you take a small raise or a bonus, but a doubling is the bottom-bracket case, not the general one."
  };

  var PLANS = [
    { n: "Repayment Assistance Plan (RAP)", open: true, who: "Any Direct Loan borrower, any loan date. Not Parent PLUS.", pay: "1%–10% of total AGI, minus $50 per dependent, minimum $10/month", forgive: "360 payments / 30 years", pslf: true },
    { n: "Income-Based Repayment (IBR)", open: true, who: "Only Direct Loans made BEFORE July 1, 2026. Not Parent PLUS, not defaulted loans.", pay: "10% of discretionary income if your first loans came on or after July 1, 2014; otherwise 15%", forgive: "20 years (240 payments) or 25 years (300 payments), matching the rate above", pslf: true, note: "The partial-financial-hardship requirement to enter IBR was removed." },
    { n: "Tiered Standard", open: true, who: "Loans made on or after July 1, 2026 — and once you hold any such loan, this becomes your standard option.", pay: "Fixed, $50/month minimum", forgive: "None — it's a payoff schedule: 10 years under $25k, 15 years to $50k, 20 years to $100k, 25 years above", pslf: "depends", note: "Read this one carefully, because the usual summary is wrong in both directions. Tiered Standard is not NAMED as a PSLF-qualifying plan, but 34 CFR 685.219 also qualifies any other plan whose monthly payment is at least the 10-year standard amount. If your balance is under $25,000 your Tiered Standard schedule IS ten years, so the payment meets that test and should count. Above $25,000 the schedule stretches to 15, 20 or 25 years, the payment drops below the 10-year standard amount, and it stops counting. If you are pursuing PSLF with a balance over $25,000, this plan is a trap — get on RAP." },
    { n: "Standard (10-year)", open: true, who: "Pre-July 2026 loans", pay: "Fixed over 10 years", forgive: "None", pslf: true },
    { n: "Graduated / Extended", open: true, who: "Pre-July 2026 loans", pay: "Rising, or stretched to 25 years", forgive: "None", pslf: "depends", note: "Same rule as Tiered Standard: these count toward PSLF only in a month where the payment is at least the 10-year standard amount \u2014 which for a stretched or early-graduated schedule usually means not at all. Don\u2019t plan a PSLF timeline on these." },
    { n: "PAYE", open: false, closes: "July 1, 2028", who: "Existing enrollees", pay: "10% of discretionary income", forgive: "20 years", pslf: true },
    { n: "ICR", open: false, closes: "July 1, 2028", who: "Existing enrollees", pay: "20% of discretionary income, or a fixed 12-year schedule", forgive: "25 years", pslf: true, note: "PSLF credit for ICR payments runs only through June 30, 2028." },
    { n: "SAVE", open: false, closes: "Already ended — by a court-approved settlement, 2026", who: "Nobody. 7.5 million borrowers are being moved off it.", pay: "—", forgive: "—", pslf: false }
  ];

  var SAVE = {
    head: "If you were on SAVE, read this first",
    body: "SAVE ended when a court approved a settlement between the Department and the State of Missouri, announced in December 2025. Roughly 7.5 million borrowers were enrolled. Servicers began sending transition notices July 1, 2026, and you get 90 days from your notice to pick a plan. Miss that window and you are placed automatically into Standard or Tiered Standard — not into an income-driven plan.",
    danger: "Two things about the SAVE forbearance that cost people real money. Interest resumed accruing during 2025 — widely reported as August 1, though Clapback could not confirm that date on a government page — so the balance has been growing. And months spent in that forbearance do not count toward PSLF or toward income-driven forgiveness. The Department told PSLF borrowers plainly that they must switch off SAVE to start making qualifying payments again.",
    honest: "Clapback could not find a single sentence on a government page saying in so many words that SAVE forbearance months don't count toward IDR forgiveness. That conclusion rests on the Department's instruction to PSLF borrowers, servicers' general rule that ineligible forbearance doesn't count, and a nonprofit advocacy group's explicit statement. Strongly supported — but not a quoted federal rule, and Clapback won't pretend otherwise.",
    buyback: "If you have already reached 120 months of qualifying employment, PSLF Buyback may let you pay for those forbearance months and convert them into qualifying payments. It only works if the buyback actually results in forgiveness.",
    url: "https://www.ed.gov/about/news/press-release/us-department-of-education-announces-next-steps-borrowers-enrolled-unlawful-save-plan"
  };

  /* ================================================================== */
  /* MONEY — rates, fees, and one deadline that's close                  */
  /* ================================================================== */
  var RATES = {
    year: "Loans first disbursed July 1, 2026 – June 30, 2027",
    rows: [
      { n: "Direct Subsidized & Unsubsidized — undergraduate", v: "6.52%" },
      { n: "Direct Unsubsidized — graduate / professional", v: "8.07%" },
      { n: "Direct PLUS (Parent, and grandfathered Grad PLUS)", v: "9.07%" }
    ],
    fees: "Origination fees: 1.057% on Direct Subsidized and Unsubsidized, 4.228% on Direct PLUS.",
    url: "https://fsapartners.ed.gov/knowledge-center/library/electronic-announcements/2026-06-04/interest-rates-federal-direct-loans-first-disbursed-between-july-1-2026-and-june-30-2027"
  };

  var AUTOPAY = {
    head: "A 1% interest cut, and the enrollment deadline is close",
    body: "The auto-pay interest reduction rose from 0.25% to a full 1.0% — the existing quarter point plus an extra three quarters. It applies to Direct Loans disbursed on or after July 1, 2012, took effect July 1, 2026, and runs through June 30, 2028.",
    deadline: "2026-09-30",
    deadlineText: "You must be enrolled in auto pay by September 30, 2026.",
    already: "Already on auto pay? The extra 0.75% is applied for you. Not enrolled? Log into your servicer account and turn it on.",
    catch: "The Department's announcement does not spell out how the reduction interacts with deferment or forbearance. Interest reductions of this kind normally apply to interest actually accruing and being paid, so if you are parked in the old SAVE forbearance, ask your servicer directly whether you are getting it \u2014 don't assume either way.",
    url: "https://www.ed.gov/about/news/press-release/us-department-of-education-announces-student-loan-interest-rate-reduction"
  };

  /* ================================================================== */
  /* DEFAULT AND COLLECTIONS                                             */
  /* ================================================================== */
  var DEFAULT_ = {
    timeline: [
      { d: "Day 1", t: "Delinquent the day after a missed due date." },
      { d: "About 90 days", t: "The delinquency is reported to the credit bureaus. Servicers generally report monthly once an account is 90 days past due, escalating through 120, 150 and 180+ day statuses. The exact trigger is servicer practice, not a published federal rule, so treat 90 days as the typical point rather than a legal deadline." },
      { d: "270 days", t: "Default. 34 CFR 685.102(b) — the failure to pay has \u201cpersisted for 270 days.\u201d This is the number that matters." },
      { d: "After default + 30 days\u2019 notice", t: "Involuntary collections become available. There is no separate 360-day waiting period \u2014 that number circulates widely and is not in the regulations. What the law actually requires is that the Department mail you notice at least 30 days before garnishment starts (34 CFR 34.4), and give you a chance to object and be heard." },
      { d: "After default", t: "Collection costs added, loss of deferment, forbearance and income-driven repayment eligibility, loss of federal aid eligibility, and negative credit reporting for up to 7 years from the delinquency." }
    ],
    volatile: {
      head: "Is anyone actually garnishing right now? Clapback will not guess.",
      body: "Involuntary collections resumed on May 5, 2025 after the pandemic pause. Then, on January 16, 2026, the Department PAUSED them again — both wage garnishment and Treasury offset — with no announced end date. Clapback confirmed the pause was still in place as of June 24, 2026 and found no announcement resuming it since.",
      warn: "But the pause was expressly tied to implementing reforms that went live on July 1, 2026 — which is exactly the trigger you would expect for resuming. Absence of an announcement is not proof. Check the Department's newsroom before you assume your tax refund or your wages are safe. Being told your refund is protected when garnishment has restarted is the worst thing this tool could do to you.",
      url: "https://www.ed.gov/about/news/press-release/us-department-of-education-delays-involuntary-collections-amid-ongoing-student-loan-repayment-improvements",
      check: "https://www.ed.gov/about/news"
    },
    garnish: {
      head: "Administrative wage garnishment — 15%, and no court needed",
      body: "The Department may take up to 15% of your disposable pay. It must mail written notice to your last known address at least 30 days before starting, and you have a right to a hearing. If you were involuntarily separated from a job, nothing may be deducted until you have been re-employed continuously for at least 12 months.",
      cite: "20 U.S.C. 1095a",
      url: "https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title20-section1095a&num=0&edition=prelim",
      compare: "Here is the part people get backwards. The ordinary consumer-debt cap is 25% of disposable earnings, so student loans at 15% actually take a SMALLER share \u2014 and the low-wage floor is the same either way: 34 CFR 34.19 applies the identical federal protection for the amount above 30 times the minimum wage. The real difference isn't the percentage or the floor. It's that a private creditor has to sue you and win a judgment first, and the Department doesn't. It garnishes administratively.",
      compareCite: "34 CFR 34.19; 15 U.S.C. 1673(a)",
      avoid: "You can stop it by entering a repayment agreement and making the first payment. Act inside the 30-day notice window and request the hearing in writing \u2014 do not wait to see whether the deduction actually appears."
    },
    offset: {
      head: "Treasury offset — your refund and your benefits",
      body: "Tax refunds and federal benefit payments can be withheld. Social Security retirement and disability can be offset up to 15% of the monthly benefit, but only down to a floor: $9,000 a year — $750 a month — is exempt from offset. SSI and Veterans benefits cannot be taken at all.",
      cite: "31 U.S.C. 3716(c)(3)(A) for the $9,000 exemption; 31 CFR 285.4(e) for the 15% cap",
      url: "https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title31-section3716&num=0&edition=prelim",
      ruleUrl: "https://www.ecfr.gov/current/title-31/subtitle-B/chapter-II/subchapter-A/part-285/subpart-A/section-285.4",
      note: "Two different sources, and it matters if you are arguing about it. The $9,000-a-year floor \u2014 $750 a month \u2014 is in the statute, is fixed, and has not moved since enactment. The 15% ceiling is Treasury's regulation, not the statute. SSI and VA benefits stay out of reach because Treasury's rule defines which benefit payments are offsettable, not because the statute exempts them by name.",
      avoid: "The way to stop an offset is to get out of default \u2014 rehabilitation or consolidation \u2014 or to resolve the debt before the offset runs. Respond to the notice you receive within the window it states, in writing, and keep proof of the date."
    },
    freshstart: "Fresh Start, the temporary program that let defaulted borrowers return to good standing, has closed. A great deal of advice still describes it as available. Clapback could not verify a single authoritative end-date announcement, so it will not state one \u2014 what it can tell you is to check your own status at MyEdDebt.ed.gov rather than trusting any page that says the window is still open.",
    /* The single most important decision in default. */
    exit: [
      { n: "Rehabilitation", time: "9 payments over 10 months", credit: "The default notation is REMOVED from your credit report", times: "Once per loan — twice, for loans from July 1, 2027", cost: "Payment is based on an income-driven calculation; minimum $5 (rising to $10 for post-July-2027 loans). If the offered payment is unaffordable, you can demand a recalculation based on documented income and expenses.", best: true },
      { n: "Consolidation", time: "About 4–6 weeks", credit: "The default record STAYS on your credit report, up to 7 years", times: "No once-only limit on the three-payment route. (The separate SIX-payment route used to restore federal aid eligibility can be used only once \u2014 34 CFR 685.102(b)(1). The two get conflated constantly.)", cost: "Outstanding interest is capitalized and collection costs are added \u2014 but capped. 34 CFR 685.220 limits collection costs on consolidating a defaulted loan to 18.5% of outstanding principal and interest. If you are quoted more, say so in writing.", best: false }
    ],
    exitRule: "This is the highest-stakes choice in the whole default process, and it is genuinely a trade-off. Rehabilitation is slow but it takes the default off your credit report. Consolidation is fast but leaves it there. If you need to move quickly — a mortgage application, a security clearance, a garnishment already running — consolidation may be right anyway. If you have ten months, rehabilitation is usually worth them.",
    rehabCaveat: "One precision point: rehabilitation removes the DEFAULT. It does not erase the 90-, 120-, 150- and 180-day late marks reported before you defaulted. Anyone telling you it cleans your credit report is overselling it.",
    rehabCite: "34 CFR 685.211",
    rehabUrl: "https://www.ecfr.gov/current/title-34/subtitle-B/chapter-VI/part-685/subpart-B/section-685.211",
    consolCite: "34 CFR 685.220(d); 34 CFR 685.102(b)",
    stats: "As of the first quarter of 2026, just over 10% of student loan balances were past due \u2014 near pre-pandemic levels \u2014 and the New York Fed counted roughly 3.6 million borrowers newly in default across late 2025 and early 2026. Read those numbers carefully: defaults only started appearing on credit reports in late 2025 because the 270-day clock had just run, and roughly 7 million former SAVE borrowers remain largely unreported. The Fed itself warns of distortions from re-reporting. This is not clean trend data.",
    statsUrl: "https://libertystreeteconomics.newyorkfed.org/2026/05/federal-student-loan-defaults-return-after-pandemic-pause/"
  };

  var NOSOL = {
    head: "Federal student loans have no statute of limitations. None.",
    body: "Congress eliminated it in 1991. The statute says no limitation shall terminate the period within which suit may be filed, a judgment enforced, or an offset or garnishment initiated. A federal student loan does not age out, ever.",
    cite: "20 U.S.C. 1091a(a), as amended by the Higher Education Technical Amendments of 1991",
    url: "https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title20-section1091a&num=0&edition=prelim",
    flip: "Private student loans are the opposite. They are ordinary contract debts governed by your state's limitations period — most often three to six years, though a few states run to ten — and they DO age out. That makes the statute of limitations one of the strongest defenses to a private student loan lawsuit, and it makes a “good faith” partial payment on an old private loan one of the most expensive mistakes you can make. In many states a payment restarts the clock; in others only a signed written acknowledgment does. Check your own state in the Court kit before you send a dollar."
  };

  /* ================================================================== */
  /* SERVICERS AND TOOLS                                                 */
  /* ================================================================== */
  var SERVICERS = [
    { n: "Edfinancial", p: "1-855-337-6884", u: "https://edfinancial.studentaid.gov" },
    { n: "Nelnet", p: "1-888-486-4722", u: "https://nelnet.studentaid.gov" },
    { n: "Aidvantage (Maximus)", p: "1-800-722-1300", u: "https://aidvantage.studentaid.gov" },
    { n: "MOHELA", p: "1-888-866-4352", u: "https://mohela.studentaid.gov" },
    { n: "ECSI", p: "1-866-313-3797", u: "https://borrowerefpls.ed.gov" },
    { n: "Central Research (CRI)", p: "", u: "https://cri.studentaid.gov" },
    { n: "Default Resolution Group — for defaulted loans", p: "1-800-621-3115", u: "https://myeddebt.ed.gov" }
  ];
  var SERVICER_NOTE = "Navient, Great Lakes, and FedLoan Servicing are no longer Direct Loan servicers. Any guide still listing them is out of date. Your loans may be split across more than one servicer — log in at StudentAid.gov with your FSA ID and check each one.";

  var TOOLS = [
    { n: "Your loan dashboard", t: "Every federal loan you have, who services it, and your balances. Start here.", u: "https://studentaid.gov" },
    { n: "Aid Summary", t: "The full record of your federal aid. This replaced the old NSLDS borrower site — don't use any nslds.ed.gov link.", u: "https://studentaid.gov/aid-summary/" },
    { n: "Loan Simulator", t: "Compare what each repayment plan would actually cost you.", u: "https://studentaid.gov/loan-simulator" },
    { n: "PSLF Help Tool", t: "Check whether your employer qualifies and generate the form.", u: "https://studentaid.gov/pslf/" },
    { n: "Apply for a repayment plan", t: "The income-driven / RAP application.", u: "https://studentaid.gov/idr" },
    { n: "Who's my servicer?", t: "If you don't know who to call.", u: "https://studentaid.gov/manage-loans/repayment/servicers" },
    { n: "Defaulted loans", t: "Check default status, Fresh Start enrollment, and rehabilitation.", u: "https://myeddebt.ed.gov" }
  ];

  var ESCALATE = [
    { n: "1. Your servicer", t: "Always first, and always in writing where you can. Keep the reference number." },
    { n: "2. FSA Feedback Center", t: "The Department's own complaint intake.", u: "https://studentaid.gov/feedback-center" },
    { n: "3. FSA Ombudsman Group", t: "Described by the Department as a final resource after other customer service avenues. Bring: the problem and its cause, what resolution you want, your documentation, and a record of what you already tried. 800-433-3243.", u: "https://studentaid.gov/feedback-ombudsman/disputes/prepare" },
    { n: "4. Your state's student loan ombudsman", t: "Fifteen states and DC have one. Several are genuinely effective and far more responsive than the federal lane." },
    { n: "5. CFPB", t: "Creates a record and forces a company response. Be realistic about what it delivers — see the note below.", u: "https://www.consumerfinance.gov/complaint/" },
    { n: "6. Your state attorney general", t: "Often the sharpest tool for an individual problem." }
  ];
  var CFPB_NOTE = "An honest word about the CFPB route. Complaint intake works and companies still respond. But the Bureau has been through heavy staffing turmoil, its Private Education Loan Ombudsman post has not been continuously filled, and the office's stated emphasis is systemic issues rather than individual case work. Clapback could not verify specific dates for any of that from a primary source and will not state them. File the complaint anyway — it creates a record and triggers a response — but don't treat it as adjudication of your case.";

  /* ================================================================== */
  /* DISCHARGE AND FORGIVENESS                                           */
  /* ================================================================== */
  var DISCHARGE = [
    { id: "pslf", n: "Public Service Loan Forgiveness", who: "120 qualifying monthly payments after October 2007, on Direct Loans, while working full time (at least 30 hours a week on average) for a government body at any level or a 501(c)(3).",
      note: "Qualifying plans are the income-driven plans, the 10-year Standard, a consolidation standard plan with a 10-year term, RAP, and any plan whose payment equals or exceeds the 10-year standard amount. Tiered Standard is not on that list.",
      tax: "Not taxable. Permanently.", cite: "34 CFR 685.219", auto: false },
    { id: "tpd", n: "Total and Permanent Disability discharge", who: "Three routes: a Social Security disability determination, a VA rating, or certification by a physician, nurse practitioner, physician assistant, or licensed psychologist.",
      note: "Often automatic. The Department data-matches with the Social Security Administration and the VA and discharges without an application. If you are disabled and still being billed, that is worth a phone call today.",
      tax: "Not taxable — made permanent by the 2025 law, which applies to discharges after December 31, 2025. To claim the exclusion you must put your Social Security number on the return \u2014 26 U.S.C. 108(f)(5)(C) requires the taxpayer's SSN, and only the taxpayer's.", cite: "34 CFR 685.213", auto: true },
    { id: "bd", n: "Borrower defense to repayment", who: "Your school misled you or broke the law in ways related to your loan.",
      note: "The rules moved backwards in 2025: the 2023 regulations do not apply to loans originated before July 1, 2035, and the pre-2023 standards govern instead. That is a materially harder standard.",
      tax: "Likely not taxable, under a 2020 IRS revenue procedure covering closed school and defense-to-repayment discharges.", cite: "P.L. 119-21 § 85001", auto: false },
    { id: "closed", n: "Closed school discharge", who: "You withdrew no more than 180 days before your school closed, and didn't finish the program elsewhere or through a teach-out.",
      note: "Automatic one year after the closure date if you didn't complete the program somewhere else.",
      tax: "Likely not taxable, same 2020 revenue procedure.", cite: "34 CFR 685.214", auto: true },
    { id: "false", n: "False certification discharge", who: "The school certified you falsely — ability-to-benefit, a disqualifying condition for the occupation, a forged signature, or identity theft.",
      note: "The Secretary may discharge without an application where the Department already has the information. Identity theft evidence can be a court determination, an FTC identity theft affidavit, a police report, or credit bureau dispute records.",
      tax: "Treat as uncertain; ask a tax preparer.", cite: "34 CFR 685.215", auto: true },
    { id: "refund", n: "Unpaid refund discharge", who: "Your school owed you a refund and never paid it. Covers that portion of the loan.",
      note: "Automatic for closed schools. For open schools you must show you're not attending, couldn't resolve it with the school, and the Department couldn't resolve it in 120 days. No discharge if you completed 60% or more of the loan period.",
      tax: "Treat as uncertain.", cite: "34 CFR 685.216", auto: false },
    { id: "death", n: "Death discharge", who: "On the death of the borrower — or, for a Parent PLUS, on the death of the student it was borrowed for.",
      note: "A death certificate, a certified copy, an accurate photocopy, or verification through an authoritative government database. Servicers generally still require someone to submit it, so it is not reliably automatic in practice.",
      tax: "Not taxable. Permanently.", cite: "34 CFR 685.212", auto: false },
    { id: "idr", n: "Income-driven repayment forgiveness", who: "The balance left after 20 or 25 years of qualifying payments — or 30 years under RAP.",
      note: "This is the backstop for people who will never pay the balance off.",
      tax: "TAXABLE as of January 1, 2026. See the tax section — this changed and it matters enormously.", cite: "34 CFR 685.209", auto: true },
    { id: "teacher", n: "Teacher Loan Forgiveness", who: "Five complete consecutive academic years teaching full time in a low-income school or educational service agency.",
      note: "Up to $17,500 for certain math, science and special education teachers; $5,000 otherwise.",
      tax: "Not taxable. Permanently.", cite: "", auto: false },
    { id: "bk", n: "Bankruptcy discharge", who: "Undue hardship, proved in a separate lawsuit inside your bankruptcy case.",
      note: "Far more achievable than its reputation since November 2022 — but almost nobody tries. See the Bankruptcy & discharge tab.",
      tax: "Not taxable — the general bankruptcy exclusion applies.", cite: "11 U.S.C. 523(a)(8)", auto: false }
  ];

  var PSLF_VACATUR = {
    head: "One PSLF rule you may have read about was struck down",
    body: "A rule published October 31, 2025 (90 FR / FR doc 2025-19729) would have excluded employers with a “substantial illegal purpose” from PSLF eligibility, effective July 1, 2026. It was challenged in Commonwealth of Massachusetts v. U.S. Department of Education, No. 1:25-cv-13244 (D. Mass.), and according to NASFAA’s litigation tracker the court vacated the entire rule on June 30, 2026 — one day before it was to take effect — so it never went into force.",
    trap: "Here is the trap: the published Code of Federal Regulations still contains that text. If you read 34 CFR 685.219 today you will see the exclusion, because the CFR was never corrected. Do not read your employer’s eligibility off the regulation text without checking the docket.",
    honest: "Clapback is telling you to disregard published regulatory text, which is a serious thing to say, so here is exactly what it rests on: a docket number and an association’s litigation tracker — not a copy of the court’s order, which Clapback could not retrieve. The rule itself is verified and still visible in the eCFR. If this matters to your PSLF eligibility, pull the docket or ask your servicer in writing before you rely on either reading.",
    ruleUrl: "https://www.federalregister.gov/documents/2025/10/31/2025-19729/william-d-ford-federal-direct-loan-direct-loan-program",
    url: "https://www.nasfaa.org/litigation"
  };

  var TAX = {
    head: "The tax rule changed on January 1, 2026, and it is expensive",
    body: "The broad exclusion that made discharged federal student debt tax-free applied only to discharges through December 31, 2025. It expired. Forgiveness received in 2026 or later under an income-driven plan — IBR, ICR, PAYE, and by extension RAP — is generally taxable income to you.",
    src: "IRS Taxpayer Advocate, March 2026",
    url: "https://www.taxpayeradvocate.irs.gov/news/tax-tips/what-to-know-about-student-loan-forgiveness-and-your-taxes/2026/03/",
    free: [
      "Public Service Loan Forgiveness — not taxable, permanently",
      "Teacher Loan Forgiveness — not taxable, permanently",
      "Total and Permanent Disability discharge — not taxable, made permanent by the 2025 law",
      "Death discharge — not taxable, same provision",
      "Borrower defense and closed school — likely not taxable under Rev. Proc. 2020-11",
      "Bankruptcy discharge — not taxable under the general bankruptcy exclusion"
    ],
    taxed: [
      "Income-driven repayment forgiveness received in 2026 or later — IBR, ICR, PAYE, and RAP"
    ],
    insolvency: "One large exception that most coverage of this leaves out: 26 U.S.C. 108(a)(1)(B) excludes cancelled debt to the extent you were INSOLVENT immediately before the discharge — that is, your liabilities exceeded your assets. The people who reach 20- or 25-year income-driven forgiveness are disproportionately the people that describes. It is not automatic; you claim it on IRS Form 982 and you have to be able to document the balance sheet. Raise it with a tax preparer before you accept a five-figure tax bill as inevitable.",
    states: "Some states tax forgiven student debt even where the federal government doesn't, and about 20 states plus DC simply follow the federal rules — which now means IDR forgiveness is state-taxable there too. Ask a tax preparer in your state before you plan around a forgiveness date. A 25-year forgiveness that arrives with a five-figure tax bill is a nasty surprise.",
    plan: "If you are on track for income-driven forgiveness, this is worth planning for now rather than discovering in the year it lands."
  };

  var VOLUMES = {
    head: "Where student loan discharges actually happen",
    lead: "This question has a surprising answer, and almost every article about student loan discharge gets it backwards by focusing on bankruptcy.",
    admin: "In fiscal year 2024, the Department of Education discharged about $28.7 billion of federal student debt through six administrative programs: Public Service Loan Forgiveness ($17.8B), Total and Permanent Disability ($4.9B), borrower defense ($4.7B), death discharge ($1.0B), Teacher Loan Forgiveness ($147M), and closed school ($33M).",
    adminSrc: "Congressional Research Service In Focus IF13120 (Nov 13, 2025), drawing on ED Agency Financial Reports",
    adminUrl: "https://www.everycrsreport.com/reports/IF13120.html",
    bk: "In the same year, 692 borrowers in the entire country filed the bankruptcy lawsuit required to attempt a student loan discharge. Of the resolved cases the same researcher counted, about 87% ended in a full or partial discharge — so the constraint is not that these lose, it is that almost nobody files one.",
    bkSrc: "Jason Iuliano, “Bridging the Student Loan Bankruptcy Gap,” 99 Am. Bankr. L.J. Iss. 3 (2025)",
    bkUrl: "https://www.ablj.org/bridging-the-student-loan-bankruptcy-gap-vol-99-issue-3-html/",
    ratio: "$28.7 billion discharged administratively in one year, against 692 people nationwide who filed the bankruptcy lawsuit. Administrative discharge is not the alternative to bankruptcy \u2014 it is where essentially all student loan discharge happens.",
    caveat: "Clapback will not put a single ratio on that, because the two figures are not the same unit and cannot honestly be divided. The administrative figure is DOLLARS discharged; the Congressional Research Service says plainly that borrower counts for these programs are not publicly available. The bankruptcy figure is a count of lawsuits filed. The direction and the order of magnitude of the gap are not in doubt. A precise ratio would be invented, so there isn't one here.",
    takeaway: "So: if you are looking for a discharge, the administrative programs are overwhelmingly where discharges happen, and they should be your first stop — not your last resort. Bankruptcy is a real option that far too few people use, and the Bankruptcy & discharge tab covers it properly. But check whether you already qualify for one of the programs above before you assume court is the only road."
  };

  /* ================================================================== */
  /* PRIVATE LOANS                                                       */
  /* ================================================================== */
  var PRIVATE = {
    asym: "Private student loans carry none of the federal protections. No income-driven repayment. No Public Service Loan Forgiveness. No total and permanent disability discharge as a matter of right. No rehabilitation out of default. No entitlement to deferment or forbearance. Some lenders offer versions of these voluntarily, entirely at their discretion — read your promissory note, because whatever it says is what you have.",
    refi: {
      head: "The one-way door",
      body: "Refinancing a federal loan into a private loan permanently forfeits every federal protection — income-driven repayment, deferment, forbearance, Public Service Loan Forgiveness, teacher forgiveness, the military interest-rate cap, and death and disability discharge. There is no route back. A private loan cannot be converted into a federal one.",
      url: "https://www.consumerfinance.gov/ask-cfpb/should-i-consolidate-refinance-student-loans-en-561/"
    },
    have: [
      { n: "A statute of limitations", t: "Unlike federal loans, private student loans age out under your state's limitations period — most often three to six years, ten in a few states. This is the single strongest defense to an old private student loan lawsuit. See the Court kit for your state's period." },
      { n: "FDCPA and FCRA protection", t: "Once a third-party collector or a debt buyer is involved, the full debt collection and credit reporting rules apply. See the Collectors and Credit file tabs." },
      { n: "Cosigner protections", t: "Federal law bars lenders from declaring an auto-default triggered by a cosigner's death or bankruptcy. Many loans also have a cosigner release provision after a set number of on-time payments — read your note and ask for it in writing." },
      { n: "State UDAP law and your state ombudsman", t: "Fifteen states and DC have a student loan ombudsman, and roughly 19 jurisdictions license student loan servicers." }
    ],
    lawsuit: {
      head: "If a private student loan trust sues you",
      body: "Private student loans were bundled and securitized, and the resulting trusts have a documented history of suing without the paperwork to prove they own the specific account. The defenses that matter:",
      defenses: [
        "Standing and chain of title. The plaintiff must prove an unbroken chain of properly executed assignments to YOUR account. A generic bill of sale referencing a pool of accounts proves nothing about you.",
        "Statute of limitations — and note that acceleration starts the clock. A collection letter demanding the total balance is a valid acceleration, and the limitations period then runs on the whole debt from that date. Courts have thrown out suits on exactly this.",
        "Borrowing statutes and choice of law. Some states apply the shorter of their own period or the other jurisdiction's, which can import a much shorter deadline.",
        "Capacity to sue. A common-law trust may lack the capacity to sue in its own name — the suit may have to be brought by the trustee."
      ],
      ncslt: "About the National Collegiate Student Loan Trusts specifically: the federal enforcement action against them is over. The CFPB sued in 2017, a court rejected the first settlement in 2020, the Third Circuit held in 2024 that the trusts ARE covered by federal consumer law — and then in April 2025 the case was voluntarily dismissed WITH PREJUDICE. The settlement \u2014 which would have required at least $21.6 million in redress and penalties \u2014 never took effect. No audit of the 800,000 loans happened, and no injunction against suing on unverified debt exists.",
      ncsltPoint: "Which inverts the practical lesson rather than ending it. With no regulator-imposed audit and no injunction, the individual defenses above are now the only real check on these suits. That makes them more important to you in 2026, not less.",
      ncsltUrl: "https://www.consumerfinance.gov/enforcement/actions/national-collegiate-student-loan-trusts/"
    },
    /* The most actionable point in the whole tab. */
    nonqualified: {
      head: "Some private student loans are not protected from discharge at all",
      body: "The bankruptcy code protects three categories: loans made or guaranteed by a government body or funded by a government or nonprofit; obligations to repay funds received as an educational benefit, scholarship or stipend; and “qualified education loans” as the tax code defines them. A private loan that falls outside all three is dischargeable like an ordinary credit card — with no undue hardship showing at all.",
      cases: "Three federal appeals courts have held that the “educational benefit” category covers conditional grants like ROTC and health-service scholarships, not private loans: Homaidan v. Sallie Mae (2d Cir. 2021), Crocker v. Navient (5th Cir. 2019), and McDaniel v. Navient (10th Cir. 2020).",
      list: [
        "Loans to attend a school not eligible for federal aid — unaccredited or foreign institutions",
        "Bar exam and other professional exam study loans",
        "Medical and dental residency and relocation loans",
        "Any amount borrowed above the school's cost of attendance",
        "Loans to a student enrolled less than half time",
        "Loans for expenses that are not qualified higher education expenses"
      ],
      listSrc: "That taxonomy comes from a CFPB bulletin issued in March 2023. Be aware the bulletin was subsequently withdrawn as part of a broad rescission of Bureau guidance in 2025 — Clapback could not pin the exact date to a primary source and will not state one. The withdrawal does not change the law: the statute and the three appellate decisions are untouched. Cite the statute and the cases, not the bulletin.",
      irigoyen: "One more thing worth knowing: a bankruptcy appellate panel held in 2024 that a debt falling outside the student loan exception is discharged by the ordinary discharge order, with no separate lawsuit needed. If your loan is genuinely non-qualifying, you may not need an adversary proceeding at all — but this is exactly the point to get a lawyer's read rather than acting on a website.",
      cite: "11 U.S.C. 523(a)(8)(B); 26 U.S.C. 221(d)(1)",
      url: "https://www.law.cornell.edu/uscode/text/11/523"
    },
    navient: "Two Navient matters have closed. The 2022 multistate attorney general settlement and the CFPB's 2024 action both provided relief; restitution under the CFPB matter is distributed by an administrator, automatically, with no application — Clapback could not verify a mailing date from a primary source, so if you are waiting on one, check the CFPB's page for that action rather than any date you read elsewhere. If you believe you were covered and got nothing, that is a question for your state attorney general or the case administrator, not a new claim you can file."
  };

  /* ================================================================== */
  /* STATE LEVEL                                                         */
  /* ================================================================== */
  var OMBUDSMEN = {
    CA: { n: "Student Loan Servicing Ombudsperson", ag: "Dept. of Financial Protection & Innovation", p: "(866) 275-2677", u: "https://dfpi.ca.gov/consumers/student-loans/contact-us/", c: "https://dfpi.ca.gov/submit-a-complaint/" },
    CO: { n: "Student Loan Ombudsperson", ag: "Dept. of Law (Attorney General)", p: "(720) 508-6975", e: "CSLSA@coag.gov", u: "https://coag.gov/office-sections/consumer-protection/consumer-credit-unit/student-loan-servicers-act/", c: "https://coag.gov/file-complaint/credit-and-debt-complaint/" },
    CT: { n: "Office of the Student Loan Ombudsperson", ag: "Dept. of Banking", p: "860-710-1014", e: "studentloanombuds@ct.gov", u: "https://portal.ct.gov/dob/student-loan-ombudsperson/student-loan-ombudsperson-office", c: "https://portal.ct.gov/dob/consumer/consumer-complaints/student-loan-servicer",
      warn: "The Banking Department's page said this office would transition to the Office of Higher Education on July 1, 2026. That date has passed — confirm the current contact before relying on it." },
    DC: { n: "Office of the Student Loan Ombudsman", ag: "Dept. of Insurance, Securities and Banking", p: "202-727-8000", e: "DCLoanHelp@dc.gov", u: "https://disb.dc.gov/page/meet-student-loan-ombudsman" },
    IL: { n: "Student Loan Helpline", ag: "Attorney General", p: "1-800-455-2456", u: "https://www.illinoisattorneygeneral.gov/consumer-protection/student-loan-debt-assistance/", c: "https://www.illinoisattorneygeneral.gov/File-A-Complaint/",
      warn: "Directories often call this an “ombudsman.” The Attorney General's own page calls it the Student Loan Helpline — use that name when you call." },
    ME: { n: "Student Loan Ombudsman", ag: "Bureau of Consumer Credit Protection", p: "207-624-8527 (800-332-8529 in Maine)", e: "CCP.PFR@maine.gov", u: "https://www.maine.gov/pfr/consumercredit/consumer/student_loans.html", c: "https://www.maine.gov/pfr/consumercredit/complaint.htm" },
    MD: { n: "Student Loan Ombudsman", ag: "Office of Financial Regulation, Dept. of Labor", p: "410-230-6077 (1-888-784-0136)", e: "studentloan.ombudsman@maryland.gov", u: "https://www.labor.maryland.gov/finance/consumers/frslombud.shtml", c: "https://labor.maryland.gov/finance/consumers/frslcomplaints.shtml" },
    MA: { n: "Student Loan Assistance Unit", ag: "Attorney General", p: "(888) 830-6277", u: "https://www.mass.gov/student-loan-assistance", c: "https://www.mass.gov/forms/submit-a-student-loan-help-request" },
    MN: { n: "Student Loan Advocate", ag: "Dept. of Commerce", p: "651-539-1500 (800-657-3602 Greater MN)", e: "Student.Loan.Advocate.COMM@state.mn.us", u: "https://mn.gov/commerce/money/consumer/student-loans/index.jsp", c: "https://mn.gov/commerce/consumer/file-a-complaint/other-complaints.jsp" },
    NJ: { n: "Student Loan Ombudsman", ag: "Dept. of Banking and Insurance", p: "1-800-446-7467", u: "https://www.nj.gov/dobi/division_consumers/finance/studentloan/index.html",
      warn: "The position exists and was designated in 2020, but no dedicated line or email is published — route through the Department's banking complaint form. Personnel may have changed." },
    NV: { n: "Student Loan Ombudsman", ag: "Office of the State Treasurer", p: "(888) 477-2667", e: "SLO@nevadatreasurer.gov", u: "https://nvigate.gov/programs/ombudsman/" },
    OR: { n: "Student Loan Ombuds", ag: "Division of Financial Regulation", p: "888-877-4894", e: "DFR.bankingproducthelp@dcbs.oregon.gov", u: "https://dfr.oregon.gov/help/student-loan-help/pages/index.aspx", c: "https://dfr.oregon.gov/help/student-loan-help/Pages/student-loan-complaint-form.aspx" },
    RI: { n: "Student Loan Protection Center", ag: "General Treasurer and Attorney General, jointly", p: "(401) 274-4400", u: "https://studentloanrightsri.com/",
      warn: "Rhode Island runs a joint protection center rather than a named ombudsman office. Clapback could not verify an individual ombudsman position." },
    VA: { n: "Office of the Qualified Education Loan Ombudsman", ag: "State Council of Higher Education (SCHEV)", p: "(804) 786-2832", e: "studentloan@schev.edu", u: "https://www.schev.edu/students/student-loan-advising/private-loan", c: "https://www.schev.edu/students/resources/student-complaints" },
    WA: { n: "Office of Student Loan Advocacy", ag: "Washington Student Achievement Council", p: "(360) 753-7800", e: "loanadvocate@wsac.wa.gov", u: "https://wsac.wa.gov/loan-advocacy", c: "https://www.studentcomplaints.wa.gov/hc/en-us" },
    NY: { n: "Student loan servicer complaints", ag: "Dept. of Financial Services", p: "800-342-3736", u: "https://www.dfs.ny.gov/consumers/student_protection", c: "https://www.dfs.ny.gov/complaint",
      warn: "New York is widely listed as having a student loan ombudsman. Clapback could not find a dedicated office. Financial Services handles servicer complaints, and the state also points borrowers to EDCAP, a nonprofit helpline run by the Community Service Society at (888) 614-5004 — not a state office, but a real one." }
  };
  var OMBUDS_NOTE = "Clapback lists only the offices it could verify against an official government page. If your state isn't here it may still regulate servicers — try your state attorney general's consumer protection line. And note that a state office generally cannot compel the federal Department of Education; its leverage is over servicers and private lenders.";

  var LICENSING = {
    note: "Roughly 19 jurisdictions have enacted a student loan servicer licensing law, often called a Student Loan Borrower Bill of Rights: Connecticut, California, Illinois, Washington, Colorado, Virginia, Minnesota, Oregon, Louisiana, Maine, Maryland, New Jersey, New York, Rhode Island, Massachusetts, Oklahoma, Kentucky, Nevada, and the District of Columbia.",
    caveat: "That roster comes from an advocacy organization's legislative tracker, not a government source, and Clapback did not verify the individual enactment years. Treat it as a lead worth following rather than a legal conclusion — but note it lines up with the ombudsman offices that were verified.",
    what: "Where these laws apply, servicers must be licensed and must meet standards of conduct — accurate information, prompt and correct handling of payments, an explanation of your options, payment history on request, and timely dispute resolution. Illinois expanded its law in August 2025 to require income share agreement providers to be licensed as servicers too.",
    pra: "Whether these laws give you a private right of action varies and Clapback could not verify it for any state. Ask your state ombudsman or a consumer attorney.",
    preempt: "There is a long-running fight over whether these state laws are preempted as applied to servicers of federal loans. It is unresolved. Your state office can tell you what it is currently able to act on."
  };

  var LRAP = {
    fed: [
      { n: "National Health Service Corps", t: "Loan repayment for primary care, dental, and behavioral health clinicians serving in designated shortage areas.", u: "https://nhsc.hrsa.gov/loan-repayment" },
      { n: "Nurse Corps Loan Repayment", t: "60% of your outstanding qualifying balance for two years of full-time service at a critical shortage facility or as nurse faculty, with an optional third year adding 25% of the original balance. Note the award is taxable.", u: "https://bhw.hrsa.gov/funding/apply-loan-repayment/nurse-corps" },
      { n: "NIH Loan Repayment Programs", t: "Up to $50,000 a year for researchers, plus NIH pays the IRS 39% of the annual repayment as tax assistance. Both are reported as taxable income.", u: "https://grants.nih.gov/funding/funding-categories/lrp" },
      { n: "Indian Health Service", t: "Loan repayment for health professionals serving American Indian and Alaska Native communities.", u: "https://www.ihs.gov/loanrepayment/" },
      { n: "Public Service Loan Forgiveness", t: "Not a repayment program but the biggest forgiveness route by far — and it covers far more employers than people assume.", u: "https://studentaid.gov/pslf/" }
    ],
    state: {
      head: "State loan repayment programs",
      body: "Forty-six states and territories receive federal grant funding to run their own loan repayment programs for primary care, mental and behavioral health, and dental clinicians serving underserved areas. These are separate from — and can stack with — the federal programs above.",
      states: ["AK","AZ","AR","CA","CO","CT","DE","GA","HI","ID","IL","IN","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NM","NY","ND","OH","OK","OR","PA","RI","TN","TX","UT","VT","VA","WA","WV","WI","WY"],
      find: "https://nhsc.hrsa.gov/loan-repayment/state-loan-repayment-program",
      gap: "Clapback lists the states that receive this federal grant. It does NOT publish a table of state teacher, lawyer, or veterinarian repayment programs, because those could not be verified against official sources and inventing agency URLs is exactly the failure this tool refuses. If you teach, practice law in public service, or work in veterinary medicine, search your state's higher education agency plus “loan repayment” — those programs are real and often generous, but you should land on the real page, not one Clapback guessed at."
    }
  };

  return {
    UPDATED: UPDATED, LAW: LAW, RAP: RAP, PLANS: PLANS, SAVE: SAVE,
    RATES: RATES, AUTOPAY: AUTOPAY, DEFAULT_: DEFAULT_, NOSOL: NOSOL,
    SERVICERS: SERVICERS, SERVICER_NOTE: SERVICER_NOTE, TOOLS: TOOLS,
    ESCALATE: ESCALATE, CFPB_NOTE: CFPB_NOTE,
    DISCHARGE: DISCHARGE, PSLF_VACATUR: PSLF_VACATUR, TAX: TAX, VOLUMES: VOLUMES,
    PRIVATE: PRIVATE, OMBUDSMEN: OMBUDSMEN, OMBUDS_NOTE: OMBUDS_NOTE,
    LICENSING: LICENSING, LRAP: LRAP
  };
})();

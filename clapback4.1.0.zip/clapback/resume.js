/* Clapback — Résumé & applications module
 * Self-contained. Runs entirely on-device. Makes no network requests.
 * Scope, on purpose, matches the rest of this app: it only ever works on
 * YOUR resume and on text YOU choose to paste. It does not look up,
 * identify, or profile any person, recruiter, or company.
 */
(function () {
  "use strict";

  // ---- Industry knowledge (aggregate, public conventions — no individuals) ----
  const INDUSTRIES = [
    {
      id: "software", label: "Software / Engineering",
      sections: ["Summary", "Technical skills", "Experience", "Projects", "Education"],
      verbs: ["Built", "Shipped", "Designed", "Architected", "Automated", "Optimized", "Migrated", "Debugged", "Scaled", "Led"],
      keywords: ["APIs", "CI/CD", "unit testing", "cloud (AWS/GCP/Azure)", "Git", "REST", "SQL", "code review", "Agile", "microservices"],
      summary: "%ROLE% with %YEARS% building and shipping reliable software. Strengths in %SKILL1% and %SKILL2%; comfortable owning features end to end.",
      notes: ["Lead bullets with a verb + what you built + measurable impact (latency, uptime, users, cost).", "List languages/frameworks in a scannable skills block near the top — ATS keyword-matches against it."]
    },
    {
      id: "data", label: "Data / Analytics",
      sections: ["Summary", "Technical skills", "Experience", "Projects", "Education"],
      verbs: ["Analyzed", "Modeled", "Forecasted", "Automated", "Visualized", "Cleaned", "Segmented", "Quantified", "Reported", "Validated"],
      keywords: ["SQL", "Python", "dashboards", "A/B testing", "ETL", "statistics", "Tableau/Power BI", "data modeling", "KPIs", "experimentation"],
      summary: "%ROLE% turning messy data into decisions. Depth in %SKILL1% and %SKILL2%; translates analysis into plain-English recommendations.",
      notes: ["Quantify outcomes: % lift, $ saved, hours automated, decisions influenced.", "Name the tools explicitly — ATS filters often key on 'SQL', 'Python', specific BI tools."]
    },
    {
      id: "healthcare", label: "Healthcare / Nursing",
      sections: ["Summary", "Licenses & certifications", "Experience", "Skills", "Education"],
      verbs: ["Assessed", "Administered", "Coordinated", "Monitored", "Educated", "Documented", "Triaged", "Advocated", "Collaborated", "Stabilized"],
      keywords: ["patient care", "EHR/EMR", "HIPAA", "BLS/ACLS", "care plans", "medication administration", "charting", "vitals", "interdisciplinary team", "patient education"],
      summary: "%ROLE% with %YEARS% delivering safe, patient-centered care. Skilled in %SKILL1% and %SKILL2%; calm and precise under pressure.",
      notes: ["Put licenses/certs high and exact (RN, license #, state, BLS/ACLS with dates).", "Lead with patient volume, unit/setting, and safety or outcome metrics."]
    },
    {
      id: "finance", label: "Finance / Accounting",
      sections: ["Summary", "Skills", "Experience", "Certifications", "Education"],
      verbs: ["Reconciled", "Forecasted", "Audited", "Analyzed", "Reduced", "Budgeted", "Modeled", "Reported", "Streamlined", "Advised"],
      keywords: ["GAAP", "financial modeling", "forecasting", "reconciliation", "Excel", "audit", "AP/AR", "variance analysis", "ERP (NetSuite/SAP)", "close process"],
      summary: "%ROLE% with %YEARS% owning accurate numbers and clear reporting. Strong in %SKILL1% and %SKILL2%; built for tight closes and clean audits.",
      notes: ["Show $ scale (budgets, portfolios, savings) and cycle times (close in X days).", "Name certifications (CPA, CFA) and ERP systems — both are common ATS filters."]
    },
    {
      id: "legal", label: "Legal",
      sections: ["Summary", "Bar admissions", "Experience", "Skills", "Education"],
      verbs: ["Drafted", "Negotiated", "Advised", "Researched", "Litigated", "Reviewed", "Filed", "Managed", "Resolved", "Counseled"],
      keywords: ["legal research", "contract drafting", "due diligence", "compliance", "litigation", "discovery", "regulatory", "Westlaw/Lexis", "negotiation", "case management"],
      summary: "%ROLE% with %YEARS% across %SKILL1% and %SKILL2%. Precise drafter and pragmatic advisor who moves matters to resolution.",
      notes: ["List bar admissions and jurisdictions clearly near the top.", "Quantify matters (caseload, deal size, outcomes) where confidentiality allows."]
    },
    {
      id: "marketing", label: "Marketing / SEO",
      sections: ["Summary", "Skills", "Experience", "Results", "Education"],
      verbs: ["Grew", "Launched", "Ranked", "Optimized", "Tested", "Scaled", "Positioned", "Converted", "Automated", "Analyzed"],
      keywords: ["SEO", "content strategy", "PPC", "analytics (GA4)", "conversion rate", "email", "A/B testing", "keyword research", "CRO", "campaign management"],
      summary: "%ROLE% with %YEARS% driving measurable growth through %SKILL1% and %SKILL2%. Data-led and channel-agnostic.",
      notes: ["Lead every bullet with a number: traffic, rankings, CAC, ROAS, conversion lift.", "Mirror the posting's channel keywords (SEO vs. paid vs. lifecycle) in your skills block."]
    },
    {
      id: "sales", label: "Sales / Business development",
      sections: ["Summary", "Highlights", "Experience", "Skills", "Education"],
      verbs: ["Closed", "Exceeded", "Prospected", "Negotiated", "Expanded", "Built", "Retained", "Grew", "Won", "Forecasted"],
      keywords: ["quota attainment", "pipeline", "CRM (Salesforce/HubSpot)", "prospecting", "negotiation", "account management", "closing", "SaaS", "territory", "forecasting"],
      summary: "%ROLE% with %YEARS% consistently beating quota. Strong in %SKILL1% and %SKILL2%; builds pipeline and closes.",
      notes: ["Open with quota % attainment, revenue closed, and ranking (e.g., top 5%).", "Numbers first, every line: $, %, deal count, ramp time."]
    },
    {
      id: "trades", label: "Skilled trades (HVAC / Plumbing / Electrical)",
      sections: ["Summary", "Licenses & certifications", "Experience", "Skills", "Education"],
      verbs: ["Installed", "Repaired", "Diagnosed", "Maintained", "Inspected", "Serviced", "Retrofitted", "Troubleshot", "Certified", "Completed"],
      keywords: ["licensed", "EPA 608", "installation", "preventive maintenance", "troubleshooting", "code compliance", "service calls", "safety (OSHA)", "blueprints", "estimates"],
      summary: "%ROLE% with %YEARS% of hands-on %SKILL1% and %SKILL2%. Licensed, safety-first, and reliable on every call.",
      notes: ["Put license type/number, state, and certifications (EPA 608, OSHA) up top.", "Quantify: jobs/day, first-time-fix rate, callback rate, systems serviced."]
    },
    {
      id: "pm", label: "Project / Construction management",
      sections: ["Summary", "Skills", "Experience", "Certifications", "Education"],
      verbs: ["Delivered", "Coordinated", "Scheduled", "Budgeted", "Managed", "Reduced", "Oversaw", "Negotiated", "Resolved", "Planned"],
      keywords: ["scheduling", "budget management", "stakeholder communication", "risk management", "MS Project", "subcontractors", "safety", "scope", "on-time delivery", "procurement"],
      summary: "%ROLE% with %YEARS% delivering projects on time and on budget. Strong in %SKILL1% and %SKILL2%; keeps stakeholders aligned.",
      notes: ["Lead with budget size, timeline, team size, and on-time/under-budget results.", "Name your PM tools and certifications (PMP, OSHA-30) explicitly."]
    },
    {
      id: "education", label: "Education / Teaching",
      sections: ["Summary", "Certifications", "Experience", "Skills", "Education"],
      verbs: ["Taught", "Designed", "Improved", "Mentored", "Assessed", "Differentiated", "Led", "Collaborated", "Integrated", "Raised"],
      keywords: ["curriculum design", "classroom management", "assessment", "differentiated instruction", "IEP", "student outcomes", "EdTech", "lesson planning", "parent communication", "state standards"],
      summary: "%ROLE% with %YEARS% raising student outcomes through %SKILL1% and %SKILL2%. Inclusive, organized, and data-informed.",
      notes: ["Put certification/licensure and grade/subject bands near the top.", "Quantify outcomes: score gains, pass rates, students served."]
    },
    {
      id: "customer", label: "Customer service / Support",
      sections: ["Summary", "Skills", "Experience", "Education"],
      verbs: ["Resolved", "Supported", "Improved", "Handled", "De-escalated", "Retained", "Trained", "Documented", "Exceeded", "Streamlined"],
      keywords: ["CSAT", "ticketing (Zendesk)", "SLA", "de-escalation", "troubleshooting", "onboarding", "retention", "phone/email/chat", "knowledge base", "first-contact resolution"],
      summary: "%ROLE% with %YEARS% keeping customers happy and retained. Strong in %SKILL1% and %SKILL2%; calm under volume.",
      notes: ["Lead with CSAT, resolution time, ticket volume, and retention numbers.", "Name the support tools you know — common ATS filters."]
    },
    {
      id: "general", label: "General / Other",
      sections: ["Summary", "Skills", "Experience", "Education"],
      verbs: ["Improved", "Led", "Built", "Managed", "Created", "Streamlined", "Increased", "Reduced", "Delivered", "Coordinated"],
      keywords: ["communication", "problem-solving", "project coordination", "leadership", "process improvement", "reporting", "collaboration", "time management", "analysis", "organization"],
      summary: "%ROLE% with %YEARS% and a track record in %SKILL1% and %SKILL2%. Reliable, organized, and outcome-focused.",
      notes: ["Every bullet: verb + what you did + result (number wherever possible).", "Read the posting and echo its exact skill words in your skills block."]
    }
  ];

  const STOP = new Set("a an the and or but if then of to in on for with at by from as is are was were be been being this that these those you your we our it its their his her they them i me my us he she do does did have has had not no yes will would can could should may might must about into over under out up down off than too very more most such own same so can't cant per via etc within across their them our your you're we're job role work team company please apply applicant candidate position ideal strong excellent required requirements responsibilities preferred plus".split(/\s+/));

  const WEAK = [
    { re: /\bresponsible for\b/gi, tip: "‘responsible for’ → lead with an action verb (Managed, Owned, Ran)." },
    { re: /\bduties included\b/gi, tip: "‘duties included’ → replace with what you actually achieved." },
    { re: /\bhelped (?:to )?\b/gi, tip: "‘helped’ is vague → name your specific contribution." },
    { re: /\bworked on\b/gi, tip: "‘worked on’ → say what you built, shipped, or delivered." },
    { re: /\bassisted with\b/gi, tip: "‘assisted with’ → state your direct action and result." },
    { re: /\bteam player\b/gi, tip: "‘team player’ is filler → show collaboration with a concrete example." },
    { re: /\bresults[- ]driven\b/gi, tip: "‘results-driven’ is filler → show the result instead." },
    { re: /\bhard[- ]working\b/gi, tip: "‘hard-working’ is filler → let an achievement demonstrate it." }
  ];

  // ---------- utilities ----------
  const $ = (s, r) => (r || document).querySelector(s);
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const esc = (s) => (s || "").replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));

  function syllables(word) {
    word = word.toLowerCase().replace(/[^a-z]/g, "");
    if (word.length <= 3) return word.length ? 1 : 0;
    word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, "").replace(/^y/, "");
    const m = word.match(/[aeiouy]{1,2}/g);
    return m ? m.length : 1;
  }
  function readability(text) {
    const clean = (text || "").trim();
    if (!clean) return null;
    const sentences = clean.split(/[.!?]+(?:\s|$)/).filter(s => s.trim().length);
    const words = clean.match(/[A-Za-z0-9'’-]+/g) || [];
    if (!words.length) return null;
    const nS = Math.max(sentences.length, 1), nW = words.length;
    const nSyl = words.reduce((a, w) => a + syllables(w), 0);
    const grade = 0.39 * (nW / nS) + 11.8 * (nSyl / nW) - 15.59;
    const ease = 206.835 - 1.015 * (nW / nS) - 84.6 * (nSyl / nW);
    const longSentences = sentences.filter(s => (s.match(/\S+/g) || []).length > 25).length;
    const passive = (clean.match(/\b(?:was|were|been|being|is|are|be)\b\s+\w+(?:ed|en)\b/gi) || []).length;
    const weak = [];
    WEAK.forEach(w => { if (w.re.test(clean)) weak.push(w.tip); w.re.lastIndex = 0; });
    return {
      grade: Math.max(0, Math.round(grade * 10) / 10),
      ease: Math.round(ease),
      words: nW, sentences: nS,
      avgSentence: Math.round((nW / nS) * 10) / 10,
      longSentences, passive, weak
    };
  }
  function keywordsFrom(text, topN) {
    const words = (text.toLowerCase().match(/[a-z][a-z+.#-]{2,}/g) || []);
    const freq = {};
    words.forEach(w => { if (!STOP.has(w) && w.length > 2) freq[w] = (freq[w] || 0) + 1; });
    return Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, topN || 20).map(x => x[0]);
  }

  // ---------- state ----------
  let industry = INDUSTRIES[0];
  let experiences = [{ title: "", org: "", dates: "", bullets: "" }];

  // ---------- render ----------
  function mount() {
    const view = $("#view-resume");
    if (!view || view.dataset.mounted) return;
    view.dataset.mounted = "1";

    view.innerHTML = `
      <h1>Résumé &amp; applications</h1>
      <div class="wip-banner" role="note">🚧 <strong>Work in progress.</strong> The résumé generation section is under active development — it works, but expect rough edges and changes in upcoming updates. Everything stays on your device either way.</div>
      <p class="lede">
        Build an ATS-friendly résumé tuned to your target industry, then grade it for readability and match it against a
        posting you're applying to — <strong>entirely on your device</strong>. Nothing here looks up or profiles any
        person or company; it only works on your résumé and on text you paste.
      </p>

      <div class="chips" id="resume-industry" role="group" aria-label="Target industry"></div>

      <div class="grid resume-grid">
        <div class="card">
          <h3>Your details</h3>
          <div class="field"><label for="r-name">Name</label><input class="input" id="r-name" autocomplete="off" placeholder="Jordan Rivera"></div>
          <div class="field"><label for="r-contact">Contact line</label><input class="input" id="r-contact" autocomplete="off" placeholder="City, ST · you@email.com · (555) 555-5555 · linkedin.com/in/…"></div>
          <div class="two">
            <div class="field"><label for="r-role">Target role/title</label><input class="input" id="r-role" autocomplete="off" placeholder="Senior Software Engineer"></div>
            <div class="field"><label for="r-years">Years of experience</label><input class="input" id="r-years" autocomplete="off" placeholder="6 years"></div>
          </div>
          <div class="field">
            <label for="r-summary">Professional summary <span class="muted">(leave blank to auto-draft)</span></label>
            <textarea class="input" id="r-summary" rows="3" placeholder="Auto-drafted from your industry, role, and top skills — or write your own."></textarea>
          </div>

          <h3 style="margin-top:14px">Experience</h3>
          <div id="r-exp"></div>
          <button class="btn btn-ghost btn-sm" id="r-add-exp">+ Add another role</button>

          <div class="field" style="margin-top:14px"><label for="r-education">Education / certifications</label><textarea class="input" id="r-education" rows="2" placeholder="B.S. Computer Science, State University, 2019 · AWS Solutions Architect"></textarea></div>
          <div class="field"><label for="r-skills">Skills <span class="muted">(comma-separated — suggestions below)</span></label><textarea class="input" id="r-skills" rows="2" placeholder="Click suggested keywords, or type your own"></textarea></div>
          <div class="chips" id="r-skill-suggest" aria-label="Suggested skills"></div>

          <div class="btn-row" style="margin-top:12px">
            <button class="btn" id="r-build">Build résumé</button>
            <button class="btn btn-ghost btn-sm" id="r-copy">Copy</button>
            <button class="btn btn-ghost btn-sm" id="r-download">Download .txt</button>
            <button class="btn btn-ghost btn-sm" id="r-print">Print / PDF</button>
          </div>
          <p class="muted" id="r-industry-notes" style="margin-top:10px"></p>
        </div>

        <div class="card">
          <h3>Preview</h3>
          <pre id="r-output" class="resume-out" aria-live="polite">Fill in your details and press <strong>Build résumé</strong>.</pre>
        </div>
      </div>

      <div class="card">
        <h3>Readability grade</h3>
        <p class="muted">Runs a Flesch–Kincaid grade on your résumé (or any text you paste) and flags what tends to slow a reader down. Aim for grade 8–11 and short, active sentences.</p>
        <textarea class="input" id="r-read-input" rows="4" placeholder="Paste résumé text to grade, or press ‘Grade my résumé’ after building."></textarea>
        <div class="btn-row"><button class="btn btn-sm" id="r-grade">Grade this text</button><button class="btn btn-ghost btn-sm" id="r-grade-resume">Grade my résumé</button></div>
        <div id="r-read-out"></div>
      </div>

      <div class="card">
        <h3>Match a posting</h3>
        <p class="muted">Paste a job description <em>you're applying to</em>. This pulls its most frequent skill words and shows which already appear in your résumé, plus the posting's own reading level so you can mirror its language. It analyzes the text you paste — it does not identify or profile the poster.</p>
        <textarea class="input" id="r-jd" rows="5" placeholder="Paste the job posting text here…"></textarea>
        <div class="btn-row"><button class="btn btn-sm" id="r-match">Compare to my résumé</button></div>
        <div id="r-match-out"></div>
      </div>

      <div class="card">
        <h3>What ATS &amp; recruiters generally scan for</h3>
        <ul class="tidy">
          <li><strong>Keyword match to the posting.</strong> Applicant tracking systems rank you on overlap with the job's own words. Echo the posting's real skill terms (honestly) in a clear skills block.</li>
          <li><strong>Simple, parseable formatting.</strong> Standard section headers (Summary, Experience, Skills, Education), no tables/columns/text-boxes/images, one column, common fonts. Fancy layouts get scrambled on parse.</li>
          <li><strong>File type &amp; naming.</strong> Submit the format the posting asks for; a text-based PDF or .docx parses well. Name it <code>First-Last-Role.pdf</code>.</li>
          <li><strong>Reverse-chronological, dated.</strong> Most recent first, with month/year ranges. Unexplained gaps and undated roles hurt parsing and reads.</li>
          <li><strong>Contact basics up top.</strong> Name, city/state, email, phone, one profile link — as text, not in a header/footer (some parsers skip those).</li>
          <li><strong>Impact over duties.</strong> Every bullet: action verb + what you did + a measurable result. Numbers survive both the parser and the six-second human skim.</li>
        </ul>
        <p class="muted">🔒 Everything on this screen stays in your browser. Nothing is sent anywhere.</p>
      </div>
    `;

    renderIndustry();
    renderExp();
    renderSuggest();

    $("#r-add-exp").addEventListener("click", () => { experiences.push({ title: "", org: "", dates: "", bullets: "" }); renderExp(); });
    $("#r-build").addEventListener("click", build);
    $("#r-copy").addEventListener("click", copyOut);
    $("#r-download").addEventListener("click", download);
    $("#r-print").addEventListener("click", printOut);
    $("#r-grade").addEventListener("click", () => grade($("#r-read-input").value));
    $("#r-grade-resume").addEventListener("click", () => { const t = $("#r-output").textContent; $("#r-read-input").value = t.startsWith("Fill in") ? "" : t; grade($("#r-read-input").value); });
    $("#r-match").addEventListener("click", match);
  }

  function renderIndustry() {
    const wrap = $("#resume-industry"); wrap.innerHTML = "";
    INDUSTRIES.forEach(ind => {
      const b = el("button", "chip" + (ind.id === industry.id ? " active" : ""), ind.label);
      b.addEventListener("click", () => { industry = ind; renderIndustry(); renderSuggest(); updateNotes(); });
      wrap.appendChild(b);
    });
    updateNotes();
  }
  function updateNotes() {
    const n = $("#r-industry-notes"); if (n) n.innerHTML = "<strong>Tips for " + esc(industry.label) + ":</strong> " + industry.notes.map(esc).join(" ");
  }
  function renderExp() {
    const wrap = $("#r-exp"); wrap.innerHTML = "";
    experiences.forEach((x, i) => {
      const box = el("div", "exp-box");
      box.innerHTML = `
        <div class="two">
          <div class="field"><label>Title</label><input class="input rx" data-i="${i}" data-k="title" value="${esc(x.title)}" placeholder="Software Engineer"></div>
          <div class="field"><label>Employer</label><input class="input rx" data-i="${i}" data-k="org" value="${esc(x.org)}" placeholder="Acme Inc., City ST"></div>
        </div>
        <div class="field"><label>Dates</label><input class="input rx" data-i="${i}" data-k="dates" value="${esc(x.dates)}" placeholder="Jan 2022 – Present"></div>
        <div class="field"><label>Achievements <span class="muted">(one per line — start each with a verb + result)</span></label><textarea class="input rx" data-i="${i}" data-k="bullets" rows="3" placeholder="Cut API latency 40% by adding a caching layer serving 2M requests/day">${esc(x.bullets)}</textarea></div>
      `;
      if (experiences.length > 1) {
        const rm = el("button", "btn btn-ghost btn-sm", "Remove this role");
        rm.addEventListener("click", () => { experiences.splice(i, 1); renderExp(); });
        box.appendChild(rm);
      }
      wrap.appendChild(box);
    });
    wrap.querySelectorAll(".rx").forEach(inp => inp.addEventListener("input", e => {
      const i = +e.target.dataset.i, k = e.target.dataset.k; experiences[i][k] = e.target.value;
    }));
  }
  function renderSuggest() {
    const wrap = $("#r-skill-suggest"); wrap.innerHTML = "";
    industry.keywords.forEach(kw => {
      const b = el("button", "chip", "+ " + kw);
      b.addEventListener("click", () => {
        const field = $("#r-skills"); const cur = field.value.split(",").map(s => s.trim()).filter(Boolean);
        if (!cur.some(c => c.toLowerCase() === kw.toLowerCase())) { cur.push(kw); field.value = cur.join(", "); }
      });
      wrap.appendChild(b);
    });
  }

  function autoSummary() {
    const role = $("#r-role").value.trim() || industry.label + " professional";
    const years = $("#r-years").value.trim() || "several years of experience";
    const skills = $("#r-skills").value.split(",").map(s => s.trim()).filter(Boolean);
    const s1 = skills[0] || industry.keywords[0], s2 = skills[1] || industry.keywords[1];
    return industry.summary.replace("%ROLE%", role).replace("%YEARS%", years).replace("%SKILL1%", s1).replace("%SKILL2%", s2);
  }

  function build() {
    const name = $("#r-name").value.trim() || "Your Name";
    const contact = $("#r-contact").value.trim();
    const summary = $("#r-summary").value.trim() || autoSummary();
    const education = $("#r-education").value.trim();
    const skills = $("#r-skills").value.split(",").map(s => s.trim()).filter(Boolean);

    const L = [];
    L.push(name.toUpperCase());
    if (contact) L.push(contact);
    L.push("");
    if (summary) { L.push("SUMMARY"); L.push(wrap(summary)); L.push(""); }
    if (skills.length) { L.push("SKILLS"); L.push(skills.join(" · ")); L.push(""); }

    const hasExp = experiences.some(x => x.title || x.org || x.bullets);
    if (hasExp) {
      L.push("EXPERIENCE");
      experiences.forEach(x => {
        if (!(x.title || x.org || x.bullets)) return;
        const head = [x.title, x.org].filter(Boolean).join(" — ") + (x.dates ? "   (" + x.dates + ")" : "");
        L.push(head.trim());
        x.bullets.split("\n").map(b => b.trim()).filter(Boolean).forEach(b => L.push("  • " + b.replace(/^[•\-*]\s*/, "")));
        L.push("");
      });
    }
    if (education) { L.push("EDUCATION & CERTIFICATIONS"); education.split("\n").map(s => s.trim()).filter(Boolean).forEach(s => L.push(s)); L.push(""); }

    const out = L.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
    $("#r-output").textContent = out;
    if (window.__pdsToast) window.__pdsToast("Résumé built");
  }
  function wrap(text, width) {
    width = width || 92; const words = text.split(/\s+/); let line = "", out = [];
    words.forEach(w => { if ((line + " " + w).trim().length > width) { out.push(line.trim()); line = w; } else line += " " + w; });
    if (line.trim()) out.push(line.trim());
    return out.join("\n");
  }

  function currentText() { const t = $("#r-output").textContent; return t.startsWith("Fill in") ? "" : t; }
  function copyOut() {
    const t = currentText(); if (!t) return;
    navigator.clipboard && navigator.clipboard.writeText(t).then(() => window.__pdsToast && window.__pdsToast("Copied"));
  }
  function download() {
    const t = currentText(); if (!t) return;
    const name = ($("#r-name").value.trim() || "resume").replace(/\s+/g, "-");
    const blob = new Blob([t], { type: "text/plain" }); const url = URL.createObjectURL(blob);
    const a = el("a"); a.href = url; a.download = name + "-resume.txt"; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }
  function printOut() {
    const t = currentText(); if (!t) return;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write("<pre style=\"font:13px/1.5 Georgia,serif;white-space:pre-wrap;padding:32px;max-width:740px;margin:auto\">" + esc(t) + "</pre>");
    w.document.close(); w.focus(); w.print();
  }

  function badge(label, val, good) {
    return "<span class=\"pill\" style=\"background:" + (good ? "rgba(52,168,83,.15)" : "rgba(234,179,8,.18)") + "\">" + esc(label) + ": <strong>" + esc(String(val)) + "</strong></span> ";
  }
  function grade(text) {
    const r = readability(text); const box = $("#r-read-out");
    if (!r) { box.innerHTML = "<p class=\"muted\">Paste some text (or build your résumé) first.</p>"; return; }
    const gGood = r.grade <= 11.5, sGood = r.avgSentence <= 20, pGood = r.passive <= 3;
    let html = "<div class=\"read-badges\">" +
      badge("Grade level", r.grade, gGood) +
      badge("Reading ease", r.ease + "/100", r.ease >= 40) +
      badge("Avg sentence", r.avgSentence + " words", sGood) +
      badge("Long sentences", r.longSentences, r.longSentences === 0) +
      badge("Passive hits", r.passive, pGood) +
      "</div>";
    const notes = [];
    if (!gGood) notes.push("Grade is a bit high — shorten sentences and swap in plainer words. Résumés read best around grade 8–11.");
    if (!sGood) notes.push("Sentences run long — most résumé bullets should be under ~20 words.");
    if (r.longSentences) notes.push(r.longSentences + " sentence(s) over 25 words — break them up.");
    if (!pGood) notes.push("Several passive constructions — switch to active verbs (‘Led’, ‘Built’, ‘Cut’).");
    r.weak.forEach(w => notes.push(w));
    if (!notes.length) notes.push("Clean and readable — active voice, tight sentences. 👍");
    html += "<ul class=\"tidy\">" + notes.map(n => "<li>" + esc(n) + "</li>").join("") + "</ul>";
    box.innerHTML = html;
  }

  function match() {
    const jd = $("#r-jd").value.trim(); const box = $("#r-match-out");
    if (!jd) { box.innerHTML = "<p class=\"muted\">Paste a posting first.</p>"; return; }
    const resume = (currentText() + " " + $("#r-skills").value + " " + experiences.map(x => x.bullets).join(" ")).toLowerCase();
    const kws = keywordsFrom(jd, 22);
    const have = kws.filter(k => resume.includes(k));
    const miss = kws.filter(k => !resume.includes(k));
    const r = readability(jd);
    let html = "";
    if (r) html += "<p class=\"muted\">Posting reads at about <strong>grade " + r.grade + "</strong> (" + r.avgSentence + " words/sentence). Aim to match its tone and formality.</p>";
    html += "<p><strong>Already in your résumé (" + have.length + "):</strong></p><div class=\"chips\">" +
      (have.length ? have.map(k => "<span class=\"chip active\">" + esc(k) + "</span>").join("") : "<span class=\"muted\">none yet</span>") + "</div>";
    html += "<p style=\"margin-top:10px\"><strong>In the posting but not your résumé (" + miss.length + "):</strong></p><div class=\"chips\">" +
      (miss.length ? miss.map(k => "<span class=\"chip\">" + esc(k) + "</span>").join("") : "<span class=\"muted\">great overlap!</span>") + "</div>";
    html += "<p class=\"muted\" style=\"margin-top:10px\">Add any of the missing terms that <em>honestly</em> describe you — don't keyword-stuff. These are the posting's own words, which is what an ATS scores against.</p>";
    box.innerHTML = html;
  }

  // ---------- init ----------
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  // Re-mount safety if the view is revealed later
  const navBtn = document.querySelector('[data-view="resume"]');
  if (navBtn) navBtn.addEventListener("click", mount);
})();

/*
 * Clapback — bankruptcy & student loan discharge dataset  (window.CBB)
 *
 * Rebuilt August 23, 2026 against a 25-tab compiled statistics workbook whose
 * own Caveats tab is the best short guide to how these numbers get misused.
 * Three of its traps are honoured here directly:
 *
 *   1. Calendar year, fiscal year and rolling-12-month are three different
 *      clocks. The state table and the headline totals are CALENDAR 2025.
 *      The rolling window to June 2026 is carried separately and labelled.
 *   2. The Administrative Office publishes no state totals and no per-capita
 *      rate. Both are computed here — districts summed to states, filings
 *      over Census Vintage 2025 population — and said to be computed.
 *   3. Delaware and DC per-capita rates are corporate venue choice, not
 *      household distress. Both are flagged in the interface, not silently
 *      ranked.
 *
 * On the geography of student loan discharge: no government agency publishes
 * student-loan-specific discharge data by district or state. The judiciary
 * publishes adversary proceeding counts per district but does not code them
 * by nature of suit. The only district-level map that exists was built by
 * hand from PACER dockets by three law professors, and it counts FILINGS,
 * not outcomes. Clapback publishes that map, labels it precisely, and states
 * the gap rather than inventing the rest.
 *
 * Verified August 23, 2026. Not legal advice.
 */
window.CBB = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  /* ================================================================== */
  /* NATIONAL TOTALS                                                     */
  /* ================================================================== */
  var NATIONAL = {
    period: "calendar year 2025",
    total: 574314,
    consumer: 549577,
    business: 24737,
    ch7: 342465,      // consumer only, CY2025
    ch13: 206570,    // consumer only, CY2025
    yoy: "+11.0% overall",
    rate: 166.3,
    ch13share: 37.6,
    src: "Administrative Office of the U.S. Courts, Table F-2",
    url: "https://www.uscourts.gov/data-news/data-tables/2025/12/31/bankruptcy-filings/f-2",
    prUrl: "https://www.uscourts.gov/data-news/judiciary-news/2026/07/28/bankruptcies-rise-122-percent",
    context: "Filings have risen every quarter since mid-2022 and CY2025 was the fourth straight year of increase. They remain far below the historic peaks: 2005 and 2010 each exceeded 1.5 million, and 2005 is a legislative artifact — the rush to file before the BAPCPA reforms took effect that October. Use 2010, not 2005, as the modern high-water mark.",
    recent: {
      head: "The most recent 12 months",
      period: "the 12 months ending June 30, 2026",
      total: 608511, consumer: 581570, business: 26941,
      ch7: 366863, ch13: 214153, rate: 168.4, ch13share: 36.9,
      yoy: "+12.0% consumer, +12.2% overall",
      url: "https://www.uscourts.gov/data-news/data-tables/2026/06/30/bankruptcy-filings/f-2",
      note: "A rolling 12-month window, not a calendar year. It overlaps CY2025 by half. Don't add the two together and don't compare a rolling window against a calendar year as though they were the same clock — that is the single most common error in bankruptcy reporting."
    }
  };

  /* ================================================================== */
  /* STATE TABLE — consumer filings, CALENDAR YEAR 2025                  */
  /* [ consumer filings, population, per 100k, Ch13 share %, Ch13        */
  /*   completion % ]. Filings and share: AO Table F-2, CY2025, districts */
  /*   summed to states. Completion: AO BAPCPA Report Table 6, cases      */
  /*   TERMINATED in CY2025 — plans completed over total terminated.      */
  /*   Two tables, same year, different cohorts. Flagged in the UI.       */
  /* ================================================================== */
  var STATES = {
    AL: [20636, 5193088, 397.4, 70.8, 47.6], MS: [9774, 2954160, 330.9, 53.6, 47.2],
    TN: [21638, 7315076, 295.8, 56.6, 38.2], NV: [9408, 3282188, 286.6, 15.8, 37.9],
    GA: [31593, 11302748, 279.5, 53.4, 38.4], KY: [12129, 4606864, 263.3, 45.3, 52.2],
    IN: [18210, 6973333, 261.1, 43.4, 49.5], AR: [6997, 3114791, 224.6, 55.8, 49.1],
    UT: [7912, 3538904, 223.6, 34.4, 39.0], LA: [10231, 4618189, 221.5, 73.2, 40.7],
    DE: [2331, 1059952, 219.9, 24.4, 58.2], MI: [22269, 10127884, 219.9, 32.0, 47.2],
    OH: [26110, 11900510, 219.4, 23.5, 50.4], IL: [26409, 12719141, 207.6, 41.7, 44.6],
    MD: [12405, 6265347, 198.0, 36.3, 40.4], OR: [8202, 4273586, 191.9, 21.8, 46.7],
    FL: [44661, 23462518, 190.4, 28.3, 41.2], OK: [7453, 4123288, 180.8, 17.4, 53.0],
    VA: [15959, 8880107, 179.7, 39.5, 50.8], MN: [10260, 5830405, 176.0, 23.0, 58.0],
    WI: [10171, 5972787, 170.3, 34.9, 48.1], MO: [10613, 6270541, 169.3, 43.2, 50.1],
    AZ: [12891, 7623818, 169.1, 16.4, 48.1], NJ: [14171, 9548215, 148.4, 36.2, 41.9],
    CO: [8641, 6012561, 143.7, 17.6, 52.1], KS: [4213, 2977220, 141.5, 44.7, 68.8],
    NE: [2796, 2018006, 138.6, 33.7, 68.6], CA: [54492, 39355309, 138.5, 16.9, 41.0],
    ID: [2474, 2029733, 121.9, 7.3, 50.2], TX: [38066, 31709821, 120.0, 35.6, 32.0],
    WA: [9346, 8001020, 116.8, 19.7, 58.9], NY: [23186, 20002427, 115.9, 30.0, 23.5],
    IA: [3738, 3238387, 115.4, 16.7, 49.6], PA: [13965, 13059432, 106.9, 44.1, 51.2],
    WV: [1785, 1766147, 101.1, 17.6, 63.4], CT: [3671, 3688496, 99.5, 15.6, 39.4],
    WY: [572, 588753, 97.2, 14.7, 22.8], RI: [1077, 1114521, 96.6, 25.7, 46.7],
    SC: [5210, 5570274, 93.5, 64.6, 42.6], DC: [618, 693645, 89.1, 21.5, 32.4],
    NC: [9847, 11197968, 87.9, 63.5, 57.4], HI: [1194, 1432820, 83.3, 39.8, 57.8],
    NM: [1660, 2125498, 78.1, 12.9, 50.0], ND: [620, 799358, 77.6, 10.2, 72.1],
    MT: [830, 1144694, 72.5, 15.8, 62.8], SD: [669, 935094, 71.5, 23.6, 56.7],
    MA: [5085, 7154084, 71.1, 30.0, 40.9], NH: [935, 1415342, 66.1, 27.7, 46.9],
    VT: [283, 644663, 43.9, 21.9, 57.4], ME: [595, 1414874, 42.1, 20.0, 69.1],
    AK: [238, 737270, 32.3, 26.1, 37.0]
  };
  var STATE_NOTE = "Consumer (non-business) filings for calendar year 2025, from Table F-2 of the Administrative Office of the U.S. Courts, with districts summed to states. The AO publishes no state-total table and no per-capita rate — both are computed here, against Census Vintage 2025 population. The Chapter 13 completion column is a different table and a different cohort: BAPCPA Report Table 6, Chapter 13 cases TERMINATED during CY2025, which were mostly filed three to five years earlier. Rate columns and completion columns are not the same people.";
  var STATE_NOTE_URL = "https://www.uscourts.gov/data-news/data-tables/2025/12/31/bankruptcy-abuse-prevention-and-consumer-protection-act-bapcpa/bapcpa-6";
  var STATE_CAVEAT = "Two states in this table are not measuring what the others measure. Delaware and the District of Columbia are distorted by corporate Chapter 11 venue choice against very small resident populations — 596 of Delaware\u2019s 2,331 CY2025 filings, more than a quarter, were Chapter 11, and its 19% year-over-year drop is almost entirely Chapter 11 traffic moving to Texas. Neither figure tells you anything about household distress there. Read both with that in mind.";
  var STATE_HEADLINE = "Alabama files consumer bankruptcy at more than twelve times the rate of Alaska \u2014 397 per 100,000 against 32. Same federal statute, same forms, same court system, a twelve-fold spread.";

  var CH13_HIGH = [
    { d: "Louisiana", v: 73.2 }, { d: "Alabama", v: 70.8 }, { d: "South Carolina", v: 64.6 },
    { d: "North Carolina", v: 63.5 }, { d: "Tennessee", v: 56.6 }, { d: "Arkansas", v: 55.8 },
    { d: "Mississippi", v: 53.6 }, { d: "Georgia", v: 53.4 }, { d: "Kentucky", v: 45.3 }
  ];
  var CH13_LOW = [
    { d: "Idaho", v: 7.3 }, { d: "North Dakota", v: 10.2 }, { d: "New Mexico", v: 12.9 },
    { d: "Wyoming", v: 14.7 }, { d: "Connecticut", v: 15.6 }, { d: "Nevada", v: 15.8 },
    { d: "Montana", v: 15.8 }, { d: "Arizona", v: 16.4 }, { d: "Iowa", v: 16.7 }
  ];
  var CH13_LISTNOTE = "State-level Chapter 13 share, CY2025. Individual districts run wider still: Alabama Middle files 83.1% of its cases under Chapter 13, Louisiana Western 79.6%, Tennessee Western 72.3%.";
  var CH13_STORY = {
    head: "The chapter you file matters enormously, and where you live largely decides it",
    body: "Chapter 7 wipes out qualifying debt in about four months. Chapter 13 puts you on a three-to-five-year payment plan, and you only get the discharge if you finish. Of the Chapter 13 cases that ended in CY2025, 44.6% ended with the plan completed. And that number is falling every year.",
    bodySrc: "Administrative Office of the U.S. Courts, BAPCPA Report Table 6",
    bodyUrl: "https://www.uscourts.gov/data-news/data-tables/2025/12/31/bankruptcy-abuse-prevention-and-consumer-protection-act-bapcpa/bapcpa-6",
    trend: [
      { y: "2021", v: 58.0 }, { y: "2022", v: 56.4 }, { y: "2023", v: 52.3 },
      { y: "2024", v: 49.4 }, { y: "2025", v: 44.6 }
    ],
    trendNote: "Chapter 13 completion has fallen every single year since 2021 — 58% to 44.6%, a 13-point slide in four years. Of the 101,709 CY2025 dismissals, 51,333 were for failure to make plan payments. More people are being routed into five-year plans at the same time as fewer of those plans are finishing.",
    denominators: "Two different figures circulate and both are right. The Administrative Office\u2019s 44.6% counts cases closed that year by dismissal or plan completion — a denominator that excludes cases converted to Chapter 7. Court-record studies that follow filers instead find roughly a third of Chapter 13 filers ever reach a discharge. Use the AO figure for \u2018of cases that ended, how many finished\u2019; use about a third for \u2018if I file Chapter 13, what are my odds\u2019. They answer different questions.",
    spread: "The share of consumer filings that are Chapter 13 runs from 73% in Louisiana to 7% in Idaho — and at district level from 83% in the Middle District of Alabama to under 8%. A ten-fold spread under one federal statute.",
    shift: "The Chapter 13 belt is not static. It is spreading north and inland: Kentucky went from 26.8% of filings in 2012 to 45.3% in 2025, Indiana 27.2% to 43.4%, Missouri 27.4% to 43.2%, Michigan 16.8% to 32.0%, Maryland 19.4% to 36.3%. Texas moved the other way — 55.0% to 35.6%, the largest decline of any state.",
    compound: "Chapter 13 share and Chapter 13 completion are two different measures, and a state can be bad on both. Tennessee is one: 56.6% of its filings are Chapter 13, well above the 37.6% national share, and only 38.2% of its Chapter 13 plans finish, well below the 44.6% national rate. Georgia is 53.4% and 38.4%. Compare both map modes for your own state before you accept advice about which chapter to file.",
    race: "There is peer-reviewed evidence that this is not neutral. A 2025 study found Black filers use Chapter 13 at 46% versus 23% for white filers, and that minority filers face a Chapter 13 dismissal rate 12.7 points higher — with the researchers attributing at least 15% of that gap, after controls, to taste-based or inaccurate statistical bias. An earlier audit study found attorneys recommended Chapter 13 more often to couples cued as Black, on identical financial facts. A separate analysis of all consumer filings found Chapter 13 made up 49% of filings from majority-Black ZIP codes against 28% from majority-white ones, and that cases from majority-Black ZIPs were more than twice as likely to be dismissed.",
    raceSrc: "Argyle, Indarte, Iverson & Palmer, NBER Working Paper 33575 (2025); Braucher, Cohen & Lawless, Journal of Empirical Legal Studies (2012); ProPublica analysis of consumer filings",
    raceUrl: "https://www.nber.org/system/files/working_papers/w33575/w33575.pdf",
    fees: "The structural explanation is fees, and it is now quantified rather than merely asserted. Chapter 7 counsel generally must be paid UP FRONT — a median around $1,411, roughly $1,200 in the study that measured it — while Chapter 13 attorney fees can be paid out of the plan over time. A 2017 study of \u2018no money down\u2019 filings found debtors steered into Chapter 13 largely because they could not raise the Chapter 7 fee, and that those filers ended up paying about $2,000 MORE in total. People are being sorted into the worse-completing chapter by their inability to pay in advance.",
    feesSrc: "Foohey, Lawless, Porter & Thorne, \u2018No Money Down Bankruptcy,\u2019 90 S. Cal. L. Rev. 1055 (2017); Consumer Bankruptcy Project attorney fee medians",
    use: "What to do with this: if you are in a high-Chapter-13 state and someone steers you toward Chapter 13, ask directly why Chapter 7 is not right for you, ask what the completion rate is in that district, and ask whether the recommendation is being driven by what you can pay today rather than by what you need. All three are fair questions and a good lawyer will answer them. If the up-front fee is the only obstacle, ask about the Chapter 7 fee waiver — available below 150% of the federal poverty line — before accepting a five-year plan."
  };

  /* ================================================================== */
  /* WHERE STUDENT LOAN DISCHARGE ACTUALLY HAPPENS                       */
  /* ================================================================== */
  var SLAP = {
    head: "Where student loan discharge cases are filed",
    lead: "This is the map, and it comes with a caveat that matters: it shows where cases are FILED, not where they succeed. No dataset anywhere breaks down student loan discharge OUTCOMES by geography.",
    src: "Belisa Pang, Dalié Jiménez & Matthew A. Bruckner, “Full Discharge Ahead? An Empirical First Look at the New Student Loan Discharge Process in Bankruptcy,” 41 Emory Bankruptcy Developments Journal 259 (2025), Table 1",
    url: "https://scholarlycommons.law.emory.edu/ebdj/vol41/iss2/3/",
    method: "Built by hand from PACER and Bloomberg Law dockets across all 94 bankruptcy districts, covering November 18, 2022 through October 15, 2024 — the 23 months after the Justice Department's new guidance. Total: 2,514 cases, a 330% increase over the comparable period before it.",
    /* Top 10 are consistent across extractions. Ranks 11–15 share the same
       values but the extracted ordering was internally inconsistent, so they
       are presented as an unordered group. */
    top: [
      { d: "District of Minnesota", st: "MN", cir: "8th", post: 244, pre: 8 },
      { d: "Western District of Washington", st: "WA", cir: "9th", post: 114, pre: 4 },
      { d: "Middle District of Florida", st: "FL", cir: "11th", post: 107, pre: 13 },
      { d: "Northern District of Ohio", st: "OH", cir: "6th", post: 100, pre: 14 },
      { d: "Northern District of Illinois", st: "IL", cir: "7th", post: 84, pre: 12 },
      { d: "District of Oregon", st: "OR", cir: "9th", post: 72, pre: 12 },
      { d: "Central District of California", st: "CA", cir: "9th", post: 67, pre: 34 },
      { d: "Southern District of Indiana", st: "IN", cir: "7th", post: 63, pre: 7 },
      { d: "Eastern District of Michigan", st: "MI", cir: "6th", post: 56, pre: 22 },
      { d: "Eastern District of Tennessee", st: "TN", cir: "6th", post: 56, pre: 0 }
    ],
    also: { d: "Also in the top 15, values confirmed but their exact order not", st: ["GA", "VA", "AL", "AZ", "NV"],
      t: "Northern District of Georgia (54), Western District of Virginia (54), Middle District of Alabama (52), District of Arizona (50), and District of Nevada (43). Clapback shows these as a group rather than a ranked list because three separate readings of the published table returned an ordering that contradicts a descending sort. The values are almost certainly right; the ranks among them are not worth asserting." },
    derived: "Clapback's arithmetic on the article's figures: those top 15 districts account for about 48% of every student loan discharge case filed in the country, from 16% of the districts. Minnesota alone is about 10% of the national total.",
    zero: "Four districts had none at all in either period: South Dakota, the Virgin Islands, Guam, and the Northern Mariana Islands.",
    /* The counterintuitive part — and the reason to publish this honestly. */
    why: {
      head: "Why Minnesota? Not the legal test — and this is the most useful thing on this page",
      body: "The obvious explanation is the circuit split. The Eighth Circuit, which includes Minnesota, uses a “totality of the circumstances” test rather than the stricter Brunner test every other deciding circuit applies. It looks like the answer. It isn't.",
      evidence: "The leading empirical study found no statistically significant difference in outcomes between Brunner circuits and the Eighth Circuit. Its author put it plainly: identical debtors filing in a Brunner circuit and a totality circuit should expect similar outcomes.",
      evidenceSrc: "Jason Iuliano, 86 American Bankruptcy Law Journal 495 (2012)",
      kicker: "And the geography argues against the doctrinal explanation too: Minnesota is first by a wide margin, but no other Eighth Circuit district appears in the top 15 at all. If the test were driving it, the whole circuit would light up.",
      real: "The researchers attribute the concentration to early adopters — courts and local consumer bankruptcy bars that took up the new process, “potentially due to greater awareness, resources, or a more proactive legal community.” Note the correlation: four courts published their own guidance on their websites, and one of them, the Western District of Washington, ranks second nationally.",
      pardo: "A separate study of every undue hardship case in one district found that case characteristics the law deems irrelevant — attorney experience and which judge you drew — significantly affected outcomes. Geography matters here, but the operative unit may be the courtroom, not the circuit.",
      soWhat: "What this means for you: your circuit's legal test is not your destiny, and being outside Minnesota is not a reason to give up. What predicts whether these cases get filed is whether local lawyers know the process exists. That is a question you can answer with a phone call — ask a consumer bankruptcy attorney in your area whether they have filed one under the 2022 Justice Department guidance."
    },
    gap: "The honest gap: the federal judiciary publishes adversary proceeding counts for every bankruptcy district, but does not code them by nature of suit — so no government dataset shows where student loan discharge cases are filed. The Justice Department surveyed all 94 U.S. Attorney's Offices and published no geographic breakdown at all. And nothing anywhere — government or academic — breaks down student loan discharge OUTCOMES by district or state. Clapback will not build a map out of numbers that don't exist."
  };

  var THE_GAP = {
    head: "The number that should change how you think about this",
    rows: [
      { big: "139,000", t: "student loan borrowers filed for bankruptcy in 2024." },
      { big: "692", t: "of them filed the separate lawsuit required to try to discharge the loans — about 1 in 201." },
      { big: "~87%", t: "of the resolved cases one researcher counted ended in a full or partial discharge." }
    ],
    rowNote: "That 87% is Jason Iuliano's own count of 652 resolved cases. The Justice Department reports 98%. Iuliano questions the Department's methodology, so Clapback shows the lower, independently derived number and tells you the other exists.",
    quote: "Over the longer run the ratio is worse still. The researcher who compiled the filing data put it this way, about the whole 2011–2024 period: for every five hundred student loan borrowers in bankruptcy, 499 give up without even attempting to discharge their student loans.",
    span: "Across 2011–2024, more than three million student loan borrowers filed for bankruptcy. 7,293 — two-tenths of one percent — even attempted a student loan discharge. The 2024 rate, 1 in 201, is several times better than that long-run average and still leaves 99.5% not trying.",
    src: "Jason Iuliano, “Bridging the Student Loan Bankruptcy Gap,” 99 Am. Bankr. L.J. Iss. 3 (2025)",
    url: "https://www.ablj.org/bridging-the-student-loan-bankruptcy-gap-vol-99-issue-3-html/",
    point: "The barrier is not that these cases lose — most of the few that are brought succeed. The barrier is that almost nobody files one. One caution on the causal story: success rates were climbing before 2022 too (39% in 2007, 61% in 2017, 87% after the reforms), and the researcher behind those numbers reads the rise as a longer-term pattern rather than something the 2022 guidance alone produced."
  };


  /* ================================================================== */
  /* THE LONG TREND — AO Table F-2, calendar years                       */
  /* ================================================================== */
  var TREND = {
    head: "Fourteen years of filings",
    note: "Total filings, calendar years, from the Administrative Office's Table F-2. The shape matters more than any single year: bankruptcy collapsed after 2010, bottomed out in the pandemic, and has climbed every year since 2022.",
    peakNote: "2005 is deliberately excluded from the chart scale. Its 2,078,415 filings are a legislative artifact — the rush to file before the BAPCPA reforms took effect that October — and CY2006 promptly collapsed to 617,660. Anyone using 2005 as a trend point is misleading you. 2010's 1,593,081 is the honest modern high-water mark.",
    years: [
      { y: 2012, t: 1221091 }, { y: 2013, t: 1071932 }, { y: 2014, t: 936795 },
      { y: 2015, t: 844495 }, { y: 2016, t: 794960 }, { y: 2017, t: 789020 },
      { y: 2018, t: 773418 }, { y: 2019, t: 774940 }, { y: 2020, t: 544463 },
      { y: 2021, t: 413616 }, { y: 2022, t: 387721 }, { y: 2023, t: 452990 },
      { y: 2024, t: 517308 }, { y: 2025, t: 574314 }
    ],
    since: "Filings have risen for four consecutive years: +16.8% in 2023, +14.2% in 2024, +11.0% in 2025. CY2025's 574,314 is still only 36% of the 2010 peak.",
    src: "Administrative Office of the U.S. Courts, Table F-2",
    url: "https://www.uscourts.gov/statistics-reports/caseload-statistics-data-tables"
  };

  /* ================================================================== */
  /* OUTCOMES — who actually gets a discharge                            */
  /* ================================================================== */
  var OUTCOMES = {
    head: "The single biggest predictor of whether you get a discharge",
    lead: "It is not your income, your debt load, or your state. It is whether you had a lawyer.",
    rep: [
      { c: "Chapter 7", w: "97.7%", p: "about 75%", note: "Discharge rate" },
      { c: "Chapter 13", w: "40%", p: "12%", note: "Discharge rate (a further 7% of represented cases converted to Chapter 7)" }
    ],
    repSrc: "Federal Judicial Center Integrated Database, 2013–2022",
    repPoint: "A self-represented Chapter 13 filer has roughly a one-in-eight chance of finishing. With counsel it is two in five. That is the widest outcome gap anywhere in this dataset, and it is the strongest argument for spending an hour with a lawyer before you file anything — most consultations are free, and about 88–90% of filers do use one.",
    headline: "Across all filers: about 95% of Chapter 7 cases end in discharge, against about a third of Chapter 13 cases.",
    timing: {
      head: "How long it takes",
      rows: [
        { c: "Chapter 7", n: "326,942 cases", mean: "164 days", median: "109 days" },
        { c: "Chapter 13", n: "181,834 cases", mean: "1,102 days", median: "1,045 days" }
      ],
      note: "CY2025 terminations. The median Chapter 7 case closes in under four months. The median Chapter 13 case runs nearly three years — and that median includes every case that was dismissed early, so a completed plan runs longer still.",
      src: "AO BAPCPA Report Table 3, CY2025"
    },
    repeat: "Of the 204,165 Chapter 13 cases filed in CY2025, 65,810 — 32.2% — reported a prior bankruptcy in the preceding eight years. A third of Chapter 13 filers have been here before, which is what a 44.6% completion rate produces downstream.",
    zip: {
      head: "The disparity is geographic and it is stark",
      rows: [
        { m: "Chapter 13 share of filings, 2008–2015", b: "49%", w: "28%" },
        { m: "Chapter 13 cases ending in discharge, 2008–2010", b: "39%", w: "58%" },
        { m: "Discharge rate in W.D. Tennessee, by census tract", b: "22%", w: "40%" }
      ],
      note: "Odds of dismissal were more than twice as high in majority-Black ZIP codes.",
      src: "ProPublica analysis of all consumer bankruptcy filings"
    }
  };

  /* ================================================================== */
  /* WHO FILES                                                           */
  /* ================================================================== */
  var WHO = {
    head: "Who actually files",
    note: "Consumer Bankruptcy Project, filings 2013–2023. Survey-based, so read these as the profile of people who file rather than as population statistics.",
    rows: [
      { k: "Aged 65 or older", v: "18%", n: "Was 2% in 1991. The fastest-changing fact in consumer bankruptcy." },
      { k: "Aged 75 or older", v: "3.3%", n: "Was 0.3% in 1991 — an elevenfold increase in share." },
      { k: "Women", v: "57%", n: "In 1981, men were 54% of filers." },
      { k: "Single women", v: "37%", n: "Single men, 16%." },
      { k: "Black households", v: "27–28%", n: "Against 14% of the U.S. population." },
      { k: "Homeowners", v: "43%", n: "35% of Chapter 7 filers; 59% of Chapter 13 filers." },
      { k: "Represented by an attorney", v: "88–90%", n: "About 7% file pro se; about 4% use a petition preparer." }
    ],
    graying: "Filings per 1,000 people aged 65–74 went from 1.2 in 1991 to 3.6 by 2013–2016. For those 75 and over, 0.3 to 1.3. The share of all filers who are 65+ rose 479% across that span, and has kept climbing since. Bankruptcy is aging faster than the country is.",
    grayingSrc: "Thorne, Foohey, Lawless & Porter, 'Graying of U.S. Bankruptcy'; 'Debt's Grip' (2025)",
    sweatbox: {
      head: "How long people struggle first",
      body: "Two thirds of filers struggled for more than two years before filing — up from 43.8% in 2007 — and 30% struggled five years or more. The mean is over three years. This is the opposite of the impulsive-filer story.",
      went: [
        { k: "Went without dental care", v: 69.8 }, { k: "Went without needed medical attention", v: 60.1 },
        { k: "Skipped prescriptions", v: 59.0 }, { k: "Sold or pawned property", v: 47.9 },
        { k: "Were uninsured at some point", v: 46.9 }, { k: "Went without food", v: 31.9 },
        { k: "Went without utilities", v: 22.1 }, { k: "Sold their house", v: 11.5 }
      ],
      note: "Reported by filers who struggled longest before filing. The delay is not free — it is paid for in foregone care.",
      src: "Foohey, Lawless, Porter & Thorne, 'Life in the Sweatbox' (2018)"
    }
  };

  /* ================================================================== */
  /* WHAT DRIVES PEOPLE THERE                                            */
  /* ================================================================== */
  var CAUSES = {
    head: "What actually drives consumer bankruptcy",
    rows: [
      { k: "Cited debt collection as a contributor", v: "More than 75%", s: "Consumer Bankruptcy Project, 2013–2023" },
      { k: "Arrived after a lawsuit, foreclosure, repossession or garnishment", v: "About 50%", s: "Consumer Bankruptcy Project, 2013–2023" },
      { k: "Cited any medical contributor", v: "66.5%", s: "Himmelstein et al., AJPH 2019" },
      { k: "Cited medical expenses specifically", v: "58.5%", s: "Himmelstein et al., AJPH 2019" },
      { k: "Cited illness-related work loss", v: "44.3%", s: "Himmelstein et al., AJPH 2019" },
      { k: "Bankruptcies CAUSED by hospitalization, ages 25–64", v: "About 4%", s: "Dobkin, Finkelstein, Kluender & Notowidigdo, NEJM 2018" }
    ],
    dispute: "The 66.5% and the 4% are the most misquoted pair of numbers in this field, and both are correct. The 66.5% is the share of surveyed filers who AGREED that a medical factor contributed — a prevalence question answered by survey. The 4% is the share of bankruptcies CAUSED by hospitalization — a causal question answered with a comparison group of people who did not go bankrupt. A high share of filers can have medical debt while hospitalization causes only a small share of filings, because filers arrive with many overlapping stressors. Note also that the 4% study looked at hospitalizations only: it excludes chronic illness, outpatient care, prescriptions, and long-run income loss.",
    debtPoint: "The finding that gets the least attention is the one most within your control: more than three quarters of filers cited debt collection, and about half arrived after a lawsuit or a garnishment. Those are the stages Clapback's other tabs are built for — and they come before this one."
  };

  /* ================================================================== */
  /* WHAT IT COSTS                                                       */
  /* ================================================================== */
  var COSTS = {
    head: "What filing actually costs",
    court: [
      { c: "Chapter 7", fee: 245, admin: 78, trustee: 15, total: 338 },
      { c: "Chapter 13", fee: 235, admin: 78, trustee: 0, total: 313 },
      { c: "Chapter 11", fee: 1167, admin: 571, trustee: 0, total: 1738 },
      { c: "Chapter 12", fee: 200, admin: 78, trustee: 0, total: 278 }
    ],
    courtNote: "Court fees only. A date trap worth knowing: the AO's master fee schedule carries an 'Effective December 1, 2023' header, but no chapter case filing fee actually changed then. The header date is not the fees' date.",
    attorney: [
      { k: "Median Chapter 7 attorney fee", v: "$1,411", n: "Generally payable UP FRONT, before filing." },
      { k: "Median Chapter 13 attorney fee", v: "$4,345", n: "Generally paid through the plan over time." },
      { k: "Pre-filing credit counseling", v: "$15–$30 typical", n: "$50 or less is presumed reasonable under 28 CFR 58.21, and the fee must be waived if household income is under 150% of the federal poverty line." },
      { k: "Pre-discharge debtor education", v: "About $35", n: "Waivers available on the same basis." }
    ],
    waiver: "Chapter 7 filers below 150% of the federal poverty line may apply to have the $338 waived entirely. Ask about this before you conclude you cannot afford Chapter 7 — because the alternative you will be offered is a five-year plan that completes less than half the time.",
    noLook: "Chapter 13 attorney fees are set district by district as a presumptively reasonable 'no-look' amount, and there is no national figure. Two examples: the Eastern District of Wisconsin set $5,500 base and $6,000 with mortgage mediation effective May 2024; the Mississippi districts set $4,600 effective May 2025. Ask your court's number rather than accepting a quote in the abstract.",
    src: "Bankruptcy Court Miscellaneous Fee Schedule; Consumer Bankruptcy Project; Foohey et al. (2017)",
    url: "https://www.uscourts.gov/services-forms/fees/bankruptcy-court-miscellaneous-fee-schedule"
  };

  /* ================================================================== */
  /* STUDENT LOAN ADVERSARY PROCEEDINGS — the trend that answers the      */
  /* question people actually ask                                        */
  /* ================================================================== */
  var SLAP_TREND = {
    head: "Student loan discharge attempts, 2011 to 2024",
    note: "Adversary proceedings filed seeking a student loan discharge. This is the clearest single picture of what the 2022 Justice Department guidance did — and of how small the whole phenomenon remains.",
    years: [
      { y: 2011, n: 643 }, { y: 2012, n: 736 }, { y: 2013, n: 690 }, { y: 2014, n: 685 },
      { y: 2015, n: 674 }, { y: 2016, n: 604 }, { y: 2017, n: 447 }, { y: 2018, n: 404 },
      { y: 2019, n: 273 }, { y: 2020, n: 295 }, { y: 2021, n: 306 }, { y: 2022, n: 249 },
      { y: 2023, n: 595 }, { y: 2024, n: 692 }
    ],
    story: "Attempts fell by more than half between 2012 and 2019 and bottomed at 249 in 2022 — the year the guidance was issued in November. 2023, the first full year under the attestation process, ran 595: up 139%. 2024's 692 is higher than any year since 2013.",
    scale: "Now the deflating part. In 2023 roughly 37,000 bankruptcy filers would have qualified to try. 595 did — about 1.6%. The process works and essentially nobody uses it.",
    money: "Mean debt discharged in 2022–23 cases was $85,000; the median discharge represented 97% of the debt at issue.",
    src: "Jason Iuliano, 99 Am. Bankr. L.J. Iss. 3 (2025); Pang, Jiménez & Bruckner, 41 Emory Bankr. Dev. J. 259 (2025)",
    url: "https://www.ablj.org/bridging-the-student-loan-bankruptcy-gap-vol-99-issue-3-html/",
    disagree: "The two leading studies disagree on volume — they count from different dockets over different windows — but agree entirely on the conclusion: use of this remedy is a rounding error against the number of people eligible for it."
  };

  /* ================================================================== */
  /* THE LAW                                                             */
  /* ================================================================== */
  var CIRCUITS = {
    "1st": { t: "Unsettled", c: "In re Nash (1st Cir. 2006) declined to choose a test. The circuit's Bankruptcy Appellate Panel applies totality of the circumstances.", states: ["ME", "MA", "NH", "RI"] },
    "2nd": { t: "Brunner", c: "Brunner v. New York State Higher Education Services Corp. (2d Cir. 1987) — where the test comes from.", states: ["CT", "NY", "VT"] },
    "3rd": { t: "Brunner", c: "In re Faish (3d Cir. 1995)", states: ["DE", "NJ", "PA"] },
    "4th": { t: "Brunner", c: "In re Frushour (4th Cir. 2005)", states: ["MD", "NC", "SC", "VA", "WV"] },
    "5th": { t: "Brunner — strictest", c: "In re Gerhardt (5th Cir. 2003). Described as requiring a showing that repayment would impose intolerable difficulties — a hardening of Brunner, not a softening.", states: ["LA", "MS", "TX"] },
    "6th": { t: "Brunner", c: "Oyler v. ECMC (6th Cir. 2005)", states: ["KY", "MI", "OH", "TN"] },
    "7th": { t: "Brunner", c: "In re Roberson (7th Cir. 1993); applied flexibly in Krieger v. ECMC (7th Cir. 2013)", states: ["IL", "IN", "WI"] },
    "8th": { t: "Totality of the circumstances", c: "Long v. ECMC (8th Cir. 2003). Looks at past, present and reasonably reliable future resources; reasonable and necessary living expenses; and any other relevant circumstances.", states: ["AR", "IA", "MN", "MO", "NE", "ND", "SD"] },
    "9th": { t: "Brunner", c: "In re Pena (9th Cir. 1998)", states: ["AK", "AZ", "CA", "HI", "ID", "MT", "NV", "OR", "WA"] },
    "10th": { t: "Brunner — expressly softened", c: "ECMC v. Polleys (10th Cir. 2004): the terms must be applied so that debtors who truly cannot afford to repay may have their loans discharged, and an overly restrictive reading fails the Code's fresh-start purpose.", states: ["CO", "KS", "NM", "OK", "UT", "WY"] },
    "11th": { t: "Brunner", c: "In re Cox (11th Cir. 2003)", states: ["AL", "FL", "GA"] },
    "DC": { t: "No circuit-level precedent", c: "The bankruptcy court applies Brunner.", states: ["DC"] }
  };
  var CIRCUIT_NOTE = "Two corrections to things you may have read. The Second Circuit never softened Brunner — a 2020 bankruptcy court decision that read it leniently was reversed by the district court. And the Tenth Circuit's softening is real and quotable, which makes it the most useful case to cite outside the Eighth Circuit. But remember the outcome evidence: the doctrinal map is uneven, and the evidence that it drives results is weak.";
  var BRUNNER = [
    "You cannot maintain a minimal standard of living for yourself and your dependents, based on current income and expenses, if forced to repay.",
    "Additional circumstances indicate that this inability is likely to persist for a significant portion of the repayment period.",
    "You have made good faith efforts to repay."
  ];

  var GUIDANCE = {
    head: "What changed in November 2022",
    date: "November 17, 2022",
    body: "The Justice Department, working with the Department of Education, issued guidance creating a standardized process. You complete an Attestation form and give it to the Assistant U.S. Attorney handling your case. If it shows present inability to pay (measured against IRS collection standards), future inability to pay, and good faith efforts to repay, the government may stipulate to the facts establishing undue hardship and recommend discharge to the court.",
    presumptions: [
      "You are 65 or older",
      "You have a disability or chronic injury affecting your income",
      "You were unemployed for at least 5 of the last 10 years",
      "You are currently unemployed",
      "You did not get the degree the loan was for",
      "The school closed",
      "You cannot get work in the field you trained for",
      "Your current income is not enough and is unlikely to rise",
      "The loan has been in repayment status, other than in-school, for at least 10 years"
    ],
    presumptionNote: "Any one of these creates a presumption that your inability to pay will persist — the prong that historically sank the most cases. The form also takes “other circumstances,” so not matching this list is not the end of the inquiry. Read Section III of the form itself rather than screening yourself out on a summary.",
    results: "The Justice Department reported 632 cases in the first ten months, with 99% of decided cases producing a full or partial discharge. By March 2024 it reported 1,220 cases and 98% providing relief. An independent academic count of 652 resolved cases found 87% successful, 502 of them — 77% — resolved by settlement, with exactly one decided on the merits.",
    resultsNote: "Clapback could not independently source the frequently repeated “mean discharge of $85,000” or the claim that 97% of borrowers entered the process voluntarily, so neither is stated here as fact.",
    form: "https://www.justice.gov/civil/media/1316521/dl?inline",
    formNote: "The Attestation form was last revised May 2025. Important filing instruction, verbatim from the form: it should be submitted to the Assistant U.S. Attorney handling the case, and should NOT be filed with the court unless the court or an attorney directs it.",
    hub: "https://www.justice.gov/ust/student-loan-guidance",
    volatile: {
      head: "Is the guidance still in force? Clapback's honest answer",
      body: "It appears to be, and Clapback found no evidence of rescission. The Justice Department's U.S. Trustee page still hosts the guidance, the fact sheet and the form, and was updated March 17, 2026. The Civil Division's forms page still lists all of it and was updated July 10, 2026. The form itself was revised in May 2025, under the current administration.",
      caveat: "But that is continued maintenance and non-rescission, not an affirmative re-endorsement — Clapback found no 2025 or 2026 statement reaffirming it. And there is a live open question: in March 2026 the Departments of Education and Treasury signed an agreement moving management of roughly $180 billion in defaulted federal loans to Treasury. Nothing Clapback could find addresses how that affects who you name as defendant, who receives the Attestation, or whether the guidance governs Treasury-held loans. Ask the U.S. Attorney's office or a bankruptcy attorney before relying on the workflow for a defaulted loan.",
      note: "You may notice the Justice Department press releases about this now sit under an /archives/ path. That is routine archiving of prior-administration press content, not a policy change — the substantive guidance and the form sit on live pages updated in 2026."
    }
  };

  var PROCESS = {
    head: "What actually happens",
    steps: [
      { n: "Filing bankruptcy does NOT discharge student loans", t: "This surprises almost everyone. A covered student loan survives your discharge automatically unless you file a separate lawsuit inside the bankruptcy case — an adversary proceeding — and win it. Chapter 7 or Chapter 13 makes no difference to this." },
      { n: "There is no filing fee", t: "The court's fee schedule charges $350 for filing an adversary complaint, and then says in terms: this fee must not be charged if the debtor is the plaintiff. Filing costs you nothing." },
      { n: "Service is the trap", t: "You must serve the United States at THREE separate addresses: the Civil Process Clerk at your district's U.S. Attorney's office, the Attorney General in Washington, and the Department of Education's Office of General Counsel. Getting this wrong defeats a large share of self-represented filers. Get it right the first time." },
      { n: "The Attestation comes next", t: "After service, the government attorney should provide you with the Attestation form and your loan account history. You complete it and return it to them — not to the court." },
      { n: "Then it is a negotiation, not a trial", t: "The United States and its agencies get 35 days from issuance of the summons to answer, rather than the 30 days an ordinary defendant gets — Bankruptcy Rule 7012(a). In practice the government routinely asks for extensions and courts routinely grant them, so expect this to run months rather than weeks; check your own court's local rules and scheduling order for the real dates. Of 652 resolved cases studied, 502 ended in settlement and exactly one was decided on the merits. This is a paperwork process, not a trial practice." }
    ],
    prose: {
      head: "Can you do it yourself?",
      yes: "Mechanically, yes. There is no filing fee, the process is a negotiation rather than a trial, and the Attestation is a form. One pre-2022 study found attorney representation did not significantly improve outcomes, though that was a different regime.",
      no: "But the three-address service requirement defeats many self-represented litigants, and the Attestation requires an IRS collection-standards analysis with supporting income documentation.",
      honest: "Clapback could find no study reporting self-represented versus represented success rates under the 2022 guidance, and will not publish a number. One data point that is worth more than a guess: the filings cluster in districts where the local consumer bankruptcy bar adopted the process. That is an argument that finding a lawyer who has done one is the binding constraint — so start by asking."
    }
  };

  var PARTIAL = "Courts can discharge part of a student loan, and the Justice Department describes outcomes as full or partial discharge. The Sixth and Ninth Circuits permit it, requiring undue hardship as to the portion discharged; the Eighth Circuit's appellate panel requires a loan-by-loan analysis where there are several loans. Clapback found no circuit that flatly forbids it. Under the 2022 guidance partial discharges have become the minority outcome — the median discharge is now 100% of the debt.";

  var CH13_LOANS = "If you are in Chapter 13 with student loans, know three things. Your plan payment on an unsecured student loan is usually far below the contractual amount, so the loan defaults during the bankruptcy and interest keeps running. Many courts now permit separate classification so the loan can be treated better, but it is contested and court-by-court. And at plan completion you still owe the balance, with accrued interest capitalized — many Chapter 13 debtors exit owing more than they entered owing. A 2023 rule would have given forgiveness credit for plan months, but it was enjoined in 2024 and its status after the 2025 statutory changes is unverified. Don't count on it.";

  /* ================================================================== */
  /* GENERAL BANKRUPTCY                                                  */
  /* ================================================================== */
  var DISCHARGEABLE = [
    "Credit card balances", "Medical bills", "Personal loans, payday loans, signature loans",
    "Most money judgments from ordinary civil suits", "Deficiency balances after repossession or foreclosure",
    "Old utility bills, old rent, broken leases", "Collection accounts and most debts sold to debt buyers"
  ];
  var NOT_DISCHARGEABLE = [
    { n: "Most taxes", c: "§ 523(a)(1)" },
    { n: "Debts from fraud or a materially false written financial statement", c: "§ 523(a)(2)" },
    { n: "Debts you failed to list, unless the creditor had actual timely notice", c: "§ 523(a)(3)" },
    { n: "Fraud or defalcation as a fiduciary, embezzlement, larceny", c: "§ 523(a)(4)" },
    { n: "Child support and alimony", c: "§ 523(a)(5)" },
    { n: "Willful and malicious injury to person or property", c: "§ 523(a)(6)", ch13: "In Chapter 13 only injury to a PERSON survives — willful and malicious injury to property is discharged. § 1328(a)(4)" },
    { n: "Fines, penalties and forfeitures payable to a government unit and not compensating an actual loss — civil as well as criminal", c: "§ 523(a)(7)" },
    { n: "Student loans — unless you win an undue hardship proceeding", c: "§ 523(a)(8)" },
    { n: "Debts from death or injury caused by drunk driving", c: "§ 523(a)(9)" },
    { n: "Criminal restitution and criminal fines", c: "§ 523(a)(13)" },
    { n: "Divorce property-settlement obligations, as distinct from support", c: "§ 523(a)(15)", ch13: "Discharged in Chapter 13 — § 1328(a) does not carry this exception over. Support under § 523(a)(5) survives either way." }
  ];
  var ND_NOTE = "This list is the Chapter 7 exceptions. Chapter 13's discharge under § 1328(a) is broader on two of them, flagged above — which is one real reason to compare the chapters rather than assume Chapter 7 is always the stronger discharge.";
  var LIENS = "The most misunderstood point in bankruptcy: discharge kills your personal liability, not a valid lien. A mortgage holder or car lender can still foreclose or repossess. If you want to keep the house or the car, the loan has to be dealt with separately.";
  var MEDICAL_BK = {
    head: "Medical debt is fully dischargeable",
    body: "It is ordinary unsecured debt. The statute lists every exception to discharge and medical debt appears in none of them. One caveat: a medical bill charged to a credit card is still dischargeable, but a very recent large charge could draw a fraud objection — medical necessity makes that hard to sustain, but the mechanism exists.",
    dispute: "On how much of bankruptcy is “medical,” researchers genuinely disagree and Clapback will not pick a side. A 2019 survey found 66.5% of debtors cited at least one medical contributor — a prevalence-among-filers question, answered by a survey of a sample of filers, not a count of all of them. A 2018 study in the New England Journal of Medicine found hospitalization causes about 4% of personal bankruptcies among non-elderly adults — a causal question requiring a comparison group of people who didn't go bankrupt. Both are right about their own question. A high share of filers can have medical debt while hospitalization causes only a small share of filings, because filers usually arrive with many overlapping stressors. Note too that the 4% study looked at hospitalizations only, excluding chronic illness, outpatient care, prescriptions, and long-run income loss.",
    safe: "The defensible statement: medical debt is dischargeable, and medical bills are among the most commonly reported contributors to consumer bankruptcy — though how often they are the cause rather than one factor among many is contested."
  };

  var STAY = {
    head: "The automatic stay",
    body: "Filing triggers it instantly — no hearing, no judge's signature. It stops lawsuits mid-case, wage garnishment, repossession, foreclosure, bank levies and setoffs, and all collection calls and letters.",
    cite: "11 U.S.C. § 362",
    notStop: [
      "Criminal proceedings",
      "Establishing paternity, or establishing or modifying child support; custody and visitation; domestic violence proceedings",
      "Collecting child support from property that isn't part of the bankruptcy estate — including wage withholding for support",
      "Tax audits, deficiency notices, demands for returns, and tax assessments",
      "An eviction where the landlord already had a judgment for possession before you filed — but see the cure right below, this one is not absolute"
    ],
    evictCure: "That last exception has a way out that almost nothing tells you about. Under § 362(l), if your state's law would let you cure the entire money default even after the judgment, you can file a certification saying so along with your petition and deposit with the court clerk the rent that comes due in the next 30 days. Do that and the stay applies to the eviction after all. It is a narrow, fast-moving right — the certification goes in with the petition — so if you are facing a possession judgment, raise § 362(l) with a lawyer or your local legal aid before you file, not after.",
    utilities: "One correction worth making, because a lot of guidance gets it wrong: utility protection is NOT the automatic stay. It is a separate section, and it gives you 20 days to provide adequate assurance of payment — usually a deposit. Miss that and service can be cut off.",
    utilCite: "11 U.S.C. § 366",
    repeat: "If you had one case dismissed in the past year, the stay ends automatically after 30 days unless you move to extend it. If you had two or more dismissed, no stay arises at all unless you ask the court for one. This matters most for exactly the people most likely to need it."
  };

  var CREDIT = {
    head: "What it does to your credit — the honest version",
    law: "The statute permits reporting a bankruptcy for up to 10 years, and it makes no distinction between Chapter 7 and Chapter 13. The familiar 7-year figure for Chapter 13 is voluntary credit bureau policy, not law — the bureaus remove Chapter 13 early to encourage repayment chapters.",
    cite: "15 U.S.C. § 1681c(a)(1)",
    honest: "And the framing that actually matters: if you are considering bankruptcy, you usually do not have good credit to protect. By the time someone weighs it, the report typically already carries charge-offs, collections and 120-plus-day delinquencies — each independently reportable for seven years and each already suppressing the score. Bankruptcy discharges those accounts and stops the bleeding. Scores often rise within a year or two of discharge because balances go to zero and the delinquency stream ends.",
    caveat: "Clapback did not verify specific score-recovery timelines or mortgage waiting periods, so it won't quote you numbers on those. The direction of the effect and the reporting periods are solid."
  };

  var MEANS = {
    head: "The means test, in one paragraph",
    body: "It decides whether you can use Chapter 7. Start with your average monthly income over the six full calendar months before you file — including a non-filing spouse's contributions, excluding Social Security. Annualize it and compare to the median family income for your state and household size. At or below median, you pass. Above it, you deduct allowed expenses using IRS standards plus secured and priority debt payments; abuse is presumed if what's left over 60 months exceeds $17,150, or exceeds $10,275 and is at least 25% of your unsecured debt.",
    trap: "The most practically useful thing about it: the lookback is backward-looking. Someone who just lost a job may still show high income and fail — and simply waiting a few months can flip the result.",
    volatile: "The U.S. Trustee reissues these numbers on a schedule. The census median family income tables changed on November 1, 2025 and again on April 1, 2026; the administrative expense multipliers and IRS standards changed on July 15, 2026. Clapback deliberately does not ship any of them, because a hardcoded table would be wrong within months. Pull the current ones from the U.S. Trustee, and check which date stamp applies to the table you are reading.",
    url: "https://www.justice.gov/ust/means-testing",
    fees: [
      { n: "Chapter 7", v: "$338" }, { n: "Chapter 13", v: "$313" },
      { n: "Chapter 11", v: "$1,738" }, { n: "Chapter 12", v: "$278" }
    ],
    feeNote: "A trap in the official fee schedule: it lists only the administrative and surcharge components, so reading it alone gives you $93 for Chapter 7. The real total is $338.",
    waiver: "There is a fee waiver for Chapter 7 — Official Form 103B — if your household income is below 150% of the federal poverty line and you cannot pay in installments. There is no fee waiver for Chapter 13, though installments are available in any chapter. Having paid an attorney does not by itself disqualify you."
  };

  var COUNSELING = {
    head: "Two required courses, commonly confused",
    pre: { n: "Pre-filing credit counseling", t: "Within 180 days BEFORE you file. Skip it and you cannot file.", u: "https://www.justice.gov/ust/list-credit-counseling-agencies-approved-pursuant-11-usc-111" },
    post: { n: "Pre-discharge debtor education", t: "AFTER you file, before discharge. Skip it and your discharge is denied.", u: "https://www.justice.gov/ust/list-approved-providers-personal-financial-management-instructional-courses-debtor-education" },
    note: "Both lists are searchable by state and judicial district. Alabama and North Carolina are Bankruptcy Administrator districts rather than U.S. Trustee districts, so approval there runs through the Bankruptcy Administrator — worth knowing, since those are two of the highest-filing states in the country."
  };

  var HELP = [
    { n: "Filing without an attorney", t: "The federal judiciary's own guidance. Note that court staff and judges are barred from giving you legal advice.", u: "https://www.uscourts.gov/court-programs/bankruptcy/filing-without-attorney" },
    { n: "Legal Services Corporation", t: "Find the legal aid organization serving your area.", u: "https://www.lsc.gov/about-lsc/what-legal-aid/i-need-legal-help" },
    { n: "ABA Free Legal Answers", t: "Free answers from pro bono attorneys in 40+ jurisdictions.", u: "https://abafreelegalanswers.org/" },
    { n: "Approved credit counseling agencies", t: "The required pre-filing course, by state.", u: "https://www.justice.gov/ust/credit-counseling-and-debtor-education-providers" }
  ];
  var PREPARER_WARN = "Bankruptcy petition preparers may only type your information into the forms. They cannot give legal advice, cannot sign for you, and cannot accept court fees. The official forms are free from the courts — nobody should charge you for the forms themselves.";

  return {
    UPDATED: UPDATED, NATIONAL: NATIONAL, STATES: STATES, STATE_NOTE: STATE_NOTE, STATE_NOTE_URL: STATE_NOTE_URL, STATE_HEADLINE: STATE_HEADLINE,
    STATE_CAVEAT: STATE_CAVEAT,
    CH13_HIGH: CH13_HIGH, CH13_LOW: CH13_LOW, CH13_LISTNOTE: CH13_LISTNOTE, CH13_STORY: CH13_STORY,
    TREND: TREND, OUTCOMES: OUTCOMES, WHO: WHO, CAUSES: CAUSES, COSTS: COSTS, SLAP_TREND: SLAP_TREND,
    SLAP: SLAP, THE_GAP: THE_GAP, CIRCUITS: CIRCUITS, CIRCUIT_NOTE: CIRCUIT_NOTE, BRUNNER: BRUNNER,
    GUIDANCE: GUIDANCE, PROCESS: PROCESS, PARTIAL: PARTIAL, CH13_LOANS: CH13_LOANS,
    DISCHARGEABLE: DISCHARGEABLE, NOT_DISCHARGEABLE: NOT_DISCHARGEABLE, ND_NOTE: ND_NOTE, LIENS: LIENS,
    MEDICAL_BK: MEDICAL_BK, STAY: STAY, CREDIT: CREDIT, MEANS: MEANS,
    COUNSELING: COUNSELING, HELP: HELP, PREPARER_WARN: PREPARER_WARN
  };
})();

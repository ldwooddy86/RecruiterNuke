/*
 * Clapback — substance use & harm reduction dataset  (window.CBU)
 *
 * DESIGN CONSTRAINT, stated up front because it shapes everything here:
 * Clapback makes zero network requests. That means it CANNOT ship a live
 * directory of treatment facilities. A stale facility record — a clinic that
 * closed, a number that changed — is not a minor bug in this context. It is
 * someone calling a dead line in the worst hour of their life.
 *
 * So this file ships two things and refuses to ship a third:
 *   1. National entry points, checked against the operating agency's own page
 *      wherever that page carries the detail. Where it does not — two SAMHSA
 *      extras are the live example — the line says so rather than implying a
 *      verification that did not happen.
 *   2. A LAUNCHER. You type a ZIP, Clapback builds the correct query URL into
 *      the federal locators. Those locators are always current because they
 *      are live services; Clapback never caches their contents.
 *   3. It does NOT ship a facility list. Not even a dated snapshot.
 *
 * Every deep link carries a plain fallback next to it — the bare domain and
 * the phone number — because a zero-network tool cannot detect at runtime
 * that a query parameter has silently stopped working.
 *
 * Verified August 23, 2026. Not medical advice.
 */
window.CBU = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  /* ================================================================== */
  /* EMERGENCY — always first, always visible                            */
  /* ================================================================== */
  var EMERGENCY = {
    head: "If someone is overdosing right now",
    steps: [
      "Call 911. Do this even if you have naloxone — an overdose is a medical emergency and naloxone can wear off before the drug does.",
      "Give naloxone if you have it. Nasal spray into one nostril. It cannot hurt someone who is not overdosing on opioids.",
      "Lay them on their side so they cannot choke. Do this before you wait for anything.",
      "Try to keep them awake and breathing. If they are not breathing normally, rescue breaths help — that step comes from SAMHSA and harm reduction training rather than from CDC's lay-bystander sequence, and Clapback flags the difference rather than blurring it.",
      "Wait 2 to 3 minutes. If there is no response, give a second dose. Stronger opioids like fentanyl often need more than one.",
      "Stay. Do not leave them alone — stay until help arrives, or for at least four hours, to be sure breathing stays normal."
    ],
    signs: [
      "Unconscious, or cannot be woken",
      "Slow or shallow breathing, difficulty breathing, or choking, gurgling or snoring sounds from someone you cannot wake — this last one is the sign lay bystanders most often recognise, and the one most often mistaken for ordinary sleep",
      "Discoloured skin — especially lips and fingernails",
      "Small, constricted “pinpoint” pupils that do not react to light"
    ],
    src: "CDC — signs, naloxone and the response sequence",
    url: "https://www.cdc.gov/overdose-prevention/reversing-overdose/about-naloxone.html",
    stayUrl: "https://www.cdc.gov/stop-overdose/caring/naloxone.html",
    staySrc: "The four-hour figure is CDC's, from its naloxone care page rather than the overdose-signs page — both are linked.",
    samaritan: "Most states have Good Samaritan laws that give some protection from drug-possession charges to people who call 911 for an overdose. They vary a great deal in what they cover, and Clapback shows what it could verify for your state below — but the calculus does not change: call anyway."
  };

  var XYLAZINE = {
    head: "If xylazine (“tranq”) may be involved",
    body: "Xylazine is not an opioid — it is a sedative — so naloxone will not reverse it. Give naloxone anyway. Xylazine is almost always mixed with fentanyl, and naloxone reverses the opioid part, which is the part most likely to stop someone breathing.",
    critical: "The thing that gets people killed here: the person may stay unconscious even after the naloxone has worked correctly, because the xylazine sedation continues. Do not conclude the naloxone failed and give up. Call 911, keep giving rescue breaths, and stay.",
    breathing: "First responders report that rescue breaths matter especially with xylazine, because it slows breathing directly.",
    wounds: "Xylazine causes severe wounds that can appear away from any injection site — and that people report even when they smoke or snort rather than inject. They become badly infected and they need medical care, not home treatment.",
    attrib: "Two claims here are NIDA's rather than CDC's, and Clapback separates them rather than putting everything under one badge: the wounds-away-from-injection-sites finding, and “almost always mixed with fentanyl” — CDC's own seizure data is narrower than that phrase implies. The response guidance is CDC verbatim: give naloxone anyway, naloxone will not reverse xylazine, rescue breaths especially matter.",
    src: "CDC on xylazine; NIDA on xylazine",
    url: "https://www.cdc.gov/overdose-prevention/about/what-you-should-know-about-xylazine.html",
    nidaUrl: "https://nida.nih.gov/research-topics/xylazine"
  };

  /* ================================================================== */
  /* NATIONAL LINES — checked against the operator's page; anything the   */
  /* operator does not publish is labelled unverified, not asserted.      */
  /* ================================================================== */
  var LINES = [
    {
      n: "988 Suicide & Crisis Lifeline", num: "988", crisis: true,
      t: "Call or text 988. Free, 24/7, for any mental health or substance use crisis — not only suicide.",
      extra: "Spanish: call 988 and press 2, or text AYUDA to 988. Deaf or hard of hearing: videophone to 988, or dial 711 then 988. Veterans: press 1. Over 240 languages by interpreter on voice calls.",
      chat: "https://chat.988lifeline.org/",
      u: "https://988lifeline.org/"
    },
    {
      n: "SAMHSA National Helpline", num: "1-800-662-4357", crisis: false,
      t: "Free, confidential, 24/7, 365 days. Treatment referral and information — English and Spanish.",
      extra: "This is a referral line, not a counselling line. Two extras are widely published but are NOT currently listed on SAMHSA's own helpline page, so treat them as probably-live rather than verified: TTY 1-800-487-4889, and texting your five-digit ZIP code to 435748. The main number above is verified.",
      u: "https://www.samhsa.gov/find-help/helplines/national-helpline"
    },
    {
      n: "Veterans Crisis Line", num: "988 then press 1", crisis: true,
      t: "Also text 838255. You do not have to be enrolled in VA benefits or health care to use it.",
      u: "https://www.veteranscrisisline.net/"
    },
    {
      n: "Poison Control", num: "1-800-222-1222", crisis: true,
      t: "24/7, free, confidential. Interpretation in 161 languages. Use for any suspected poisoning or unknown substance.",
      u: "https://poisonhelp.hrsa.gov/about-us"
    },
    {
      n: "Disaster Distress Helpline", num: "1-800-985-5990", crisis: true,
      t: "Call or text. 24/7, multilingual, all US states and territories. For distress after a disaster.",
      u: "https://www.samhsa.gov/find-help/helplines/disaster-distress-helpline"
    },
    {
      n: "211", num: "211", crisis: false,
      t: "Dial 211 for local referrals — health, housing, food, utilities. Coverage and hours vary by area.",
      u: "https://www.211.org/"
    },
    {
      n: "NAMI HelpLine", num: "1-800-950-6264", crisis: false,
      t: "Information and support. Text NAMI to 62640, or email helpline@nami.org.",
      warn: "NOT a crisis line, and NOT 24/7 — Monday to Friday, 10am to 10pm Eastern. NAMI says so themselves. If it is 2am and you are in crisis, use 988.",
      u: "https://www.nami.org/help/"
    }
  ];

  var LGBTQ = {
    head: "One thing Clapback will not let you find out the hard way",
    body: "The 988 Lifeline's specialised LGBTQI+ service — the “press 3” option — was closed on July 17, 2025. A great deal of advice, including printed material still in circulation, still tells people to press 3. As of August 23, 2026 that menu option remains closed. 988 itself still answers, and still serves everyone.",
    moving: "This is the most likely item on this page to change. HHS committed publicly in June 2026 to relaunching a specialised service within the year, and it had not launched as of late July 2026. Check the 988 FAQ before relying on either state of affairs.",
    alt: "The Trevor Project runs an independent 24/7 line for LGBTQ+ young people: call 1-866-488-7386, or text START to 678-678. It is not government-run.",
    altUrl: "https://www.thetrevorproject.org/get-help/",
    src: "SAMHSA / 988 Lifeline FAQ",
    url: "https://988lifeline.org/faq/calling-the-988-lifeline/faq-are-there-specialized-services-for-lgbtqi-youth-who-reach-out-to-988/"
  };

  /* ================================================================== */
  /* THE LAUNCHER — ZIP in, correct federal locator URL out              */
  /* Each entry: how to build the URL, and the fallback if it breaks.    */
  /* ================================================================== */
  var LOCATORS = [
    {
      id: "findtreatment",
      n: "findtreatment.gov — SAMHSA treatment locator",
      t: "The federal directory of substance use and mental health treatment facilities. Filter by what you need: opioid treatment programs, buprenorphine, outpatient, inpatient, sliding-scale payment.",
      build: function (zip) { return "https://findtreatment.gov/locator?sAddr=" + encodeURIComponent(zip) + "&submit=Go"; },
      fallback: "https://findtreatment.gov/",
      fallbackNote: "If the ZIP does not pre-fill, use the plain site and type it into the search box — or call the SAMHSA Helpline on 1-800-662-4357 and let a person do the search for you.",
      primary: true
    },
    {
      id: "hrsa",
      n: "HRSA — find a community health center",
      t: "Federally funded health centers. They see you whether or not you have insurance, and charge on a sliding scale based on what you can pay. Many but not all offer behavioural health and medication for opioid use disorder — ask when you call.",
      build: function (zip) { return "https://findahealthcenter.hrsa.gov/?zip=" + encodeURIComponent(zip) + "&radius=20"; },
      fallback: "https://findahealthcenter.hrsa.gov/",
      fallbackNote: "If the ZIP does not pre-fill, search from the plain site."
    },
    {
      id: "otp",
      n: "Opioid Treatment Program directory",
      t: "SAMHSA-certified programs — the only places that can dispense methadone for opioid use disorder.",
      fallback: "https://www.samhsa.gov/find-help/locators/opioid-treatment-program-directory",
      fallbackNote: "Clapback could not verify a working ZIP deep-link format for this directory, so it links the landing page rather than guessing a URL. findtreatment.gov also lists opioid treatment programs and does support ZIP search.",
      noZip: true
    },
    {
      id: "naloxone",
      n: "NEXT Distro — free naloxone by mail",
      t: "A non-profit that mails naloxone free, with a state-by-state selector covering all 50 states, DC and Puerto Rico.",
      fallback: "https://nextdistro.org/naloxone",
      fallbackNote: "Their own request: they prioritise people who use drugs and those close to them. If you have insurance and a pharmacy nearby, buy it over the counter instead and leave the mail supply for people who cannot.",
      noZip: true
    }
  ];

  var LOCATOR_NOTE = "Clapback builds these links on your device and never opens them for you. Nothing you type here leaves this browser — there is no search, no lookup, no request. The link only does anything when you click it, and then it is an ordinary visit to a government website.";
  var LOCATOR_HONEST = "One honest limitation. Because Clapback makes no network requests, it cannot tell whether a federal site has quietly changed how its search links work. Every locator below therefore carries a plain fallback — the bare address and, where there is one, a phone number — so that if the ZIP does not pre-fill you still land somewhere useful. Verified " + UPDATED + ".";

  var MUTUAL = [
    { n: "SMART Recovery", t: "Secular, science-based, meetings online and in person", u: "https://meetings.smartrecovery.org/meetings/" },
    { n: "Narcotics Anonymous", t: "Twelve-step, worldwide meeting search", u: "https://www.na.org/meetingsearch/" },
    { n: "Alcoholics Anonymous", t: "Twelve-step, worldwide meeting search", u: "https://www.aa.org/find-aa" },
    { n: "Al-Anon", t: "For families and friends of people who drink", u: "https://al-anon.org/al-anon-meetings/" },
    { n: "Nar-Anon", t: "For families and friends of people who use drugs", u: "https://www.nar-anon.org/find-a-meeting" },
    { n: "NIAAA Alcohol Treatment Navigator", t: "Evidence-based guidance on choosing alcohol treatment. No commercial sponsors, which is rarer than it should be.", u: "https://alcoholtreatment.niaaa.nih.gov/" }
  ];

  /* ================================================================== */
  /* WHAT THE EVIDENCE ACTUALLY SHOWS                                    */
  /* ================================================================== */
  var MOUD = {
    head: "Medication for opioid use disorder: what the evidence shows",
    lead: "This is the part most often got wrong, in both directions. Medication is not “replacing one addiction with another” — and it is also not a cure that works for everyone. Here is what the studies actually found.",
    rows: [
      { m: "Methadone", all: "53% lower", od: "59% lower", n: "Adjusted hazard ratio 0.47 all-cause (95% CI 0.32–0.71), 0.41 opioid-related (0.24–0.70), against no medication." },
      { m: "Buprenorphine", all: "37% lower", od: "38% lower", n: "Adjusted hazard ratio 0.63 all-cause (0.46–0.87), 0.62 opioid-related (0.41–0.92)." },
      { m: "Naltrexone", all: "no benefit detected", od: "no benefit detected", n: "Hazard ratios of 1.44 and 1.42, with confidence intervals spanning 1 (0.84–2.46 and 0.73–2.79). The study could not detect an effect in either direction, and both point estimates sat above 1. That is not the same as showing it does not work; see below." }
    ],
    src: "Larochelle et al., Annals of Internal Medicine 2018;169(3):137–145 — Massachusetts adults followed after a non-fatal overdose",
    url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC6387681/",
    honest: "Three caveats Clapback will not bury. These are observational studies — you cannot ethically randomise people to no treatment — so “associated with substantially lower mortality” is honest and “causes a 53% reduction” is not. The percentages are point estimates converted from hazard ratios, and the real range is wider than a single number suggests — methadone's all-cause interval spans 29% to 68% lower. And the access gap is itself a finding: in that study only 11% of people got methadone and 17% got buprenorphine after surviving an overdose.",
    naltrexone: "On naltrexone specifically — and the usual defence of it is as incomplete as the table above is harsh. In the head-to-head trial, buprenorphine WON on the primary measure: counting everyone assigned to each arm, 65% relapsed on naltrexone against 57% on buprenorphine, a statistically significant difference. That is the headline result and Clapback states it first. The reason, though, was induction failure rather than the drug failing — naltrexone requires being fully off opioids before starting, and only 72% of people assigned to it managed to start at all, against 94% for buprenorphine. Among those who did get started, relapse rates were statistically indistinguishable. So: much harder to get onto, comparable once you are on it. Methadone and buprenorphine remain the two with direct mortality evidence behind them.",
    naltrexoneSrc: "Lee et al., The Lancet 2018;391(10118):309–318 (X:BOT trial)",
    naltrexoneUrl: "https://pmc.ncbi.nlm.nih.gov/articles/PMC5806119"
  };

  var METHADONE = {
    head: "The methadone rules changed permanently in 2024, and most guidance has not caught up",
    body: "SAMHSA's rewrite of 42 CFR Part 8 made the pandemic-era flexibilities permanent. Two changes matter enormously and are still widely misreported.",
    changes: [
      { n: "The one-year requirement is gone", t: "You no longer need a documented year-long history of opioid use to be admitted. A moderate-to-severe opioid use disorder diagnosis, or a risk of recurrence, is enough." },
      { n: "Take-home doses can start immediately", t: "The rigid time-served gate was replaced by clinical judgement. Federal rules now permit up to 7 days of take-home doses in the first two weeks, up to 14 days through day 30, and up to 28 days after that." },
      { n: "Counselling is not a precondition", t: "A program may not withhold your medication because you have not attended counselling." },
      { n: "Telehealth initiation is allowed", t: "Methadone initiation normally requires audio-visual, with a narrow audio-only path when video is not available to the patient AND the patient is with a licensed practitioner. Buprenorphine and naltrexone can be started audio-only." }
    ],
    ceiling: "The single most important caveat on this page. These are federal CEILINGS, not floors. Your state, and your individual program, may be more restrictive — legitimately. If you walk into a clinic quoting “28 days of take-homes” and are told no, they may well be right. What the federal rule gives you is the ability to ask, and to know that a blanket refusal on the old grounds is no longer required by federal law.",
    cite: "42 CFR Part 8; 89 FR 7528 (Feb 2, 2024), effective April 2, 2024, compliance October 2, 2024",
    url: "https://www.ecfr.gov/current/title-42/chapter-I/subchapter-A/part-8/subpart-C/section-8.12",
    frUrl: "https://www.federalregister.gov/documents/2024/02/02/2024-01693/medications-for-the-treatment-of-opioid-use-disorder"
  };

  var NALOXONE = {
    head: "Naloxone is over the counter. Get some before you need it.",
    body: "Three nasal sprays are approved for sale without a prescription: Narcan 4mg (the first, approved March 2023), RiVive 3mg, and Rextovy 4mg (approved June 2026). Pharmacies, convenience stores, online. No prescription, no conversation with a doctor, no pharmacist gatekeeping.",
    who: "Worth carrying if you use opioids, if anyone in your household is prescribed them, if you work anywhere the public gathers, or if you have a family member in recovery. Most overdoses happen at home, in front of someone.",
    free: "Free naloxone is widely available too — state health departments, local harm reduction programs, and NEXT Distro by mail. Check your state card below.",
    src: "U.S. Food and Drug Administration",
    url: "https://www.fda.gov/news-events/press-announcements/fda-broadens-access-over-counter-naloxone-nasal-spray-opioid-overdose"
  };

  /* ================================================================== */
  /* YOUR RIGHTS                                                         */
  /* ================================================================== */
  var RIGHTS = [
    {
      n: "Your treatment records are more protected than ordinary medical records",
      cite: "42 CFR Part 2",
      body: "Records from a federally assisted substance use treatment program get protection that goes beyond HIPAA. HIPAA lets providers share records fairly freely for treatment, payment and operations. Part 2 generally prohibits disclosing information that identifies you as having a substance use disorder without your consent or a court order.",
      key: "The protection people most need to know about: Part 2 records cannot be used against you in a legal proceeding without your consent or a court order and subpoena. That includes criminal cases, custody disputes, and employment litigation.",
      honest: "Be aware the February 2024 rewrite cut both ways. It added breach notification and real enforcement penalties — but it also moved to a single consent covering all future treatment, payment and operations disclosures, which means records flow more freely downstream once you sign. It is not purely a strengthening, and Clapback will not describe it as one. Compliance date was February 16, 2026, so the rule is fully operative now.",
      url: "https://www.hhs.gov/hipaa/part-2/index.html"
    },
    {
      n: "Your insurance must cover addiction treatment comparably to physical health",
      cite: "Mental Health Parity and Addiction Equity Act",
      body: "A plan covering mental health and substance use benefits may not impose greater restrictions on them than on medical and surgical benefits — in copays, visit limits, and in the harder-to-see things: prior authorisation, network adequacy, out-of-network reimbursement.",
      key: "What you can actually do: write and ask for the plan's medical necessity criteria and the reasoning behind your denial. Federal law requires a response within 30 days. Then internal appeal within 180 days, then external review within four months of the final denial.",
      honest: "An important qualification, because most explainers omit it. The 2024 rules that added detailed comparative-analysis requirements are under a federal non-enforcement policy pending litigation — announced May 2025 and covering the period until the case resolves plus 18 months. The underlying STATUTORY obligations still bind, and the 2013 regulations still apply. So you can still request the comparative analysis for a non-quantitative limitation; what you get back may be thinner than the newer rule intended. This is the most volatile item on this page — check before relying on it.",
      who: "Who enforces it depends on your plan: the Department of Labor for private employer plans, CMS for state and local government employee plans, your state insurance regulator for individual and fully insured plans. It does not apply to Medicare.",
      url: "https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/understanding-your-mental-health-and-substance-use-disorder-benefits",
      complain: "https://beta.dol.gov/about/agencies/ebsa/ask-ebsa"
    },
    {
      n: "Being on methadone or buprenorphine is a protected disability",
      cite: "Americans with Disabilities Act — DOJ guidance",
      body: "The Justice Department is explicit: medication taken under a licensed practitioner's supervision is not “illegal use of drugs” under the ADA. Someone on prescribed methadone is not currently using illegal drugs, whatever an employer or a facility assumes.",
      key: "Protected: people in treatment or recovery, people on prescribed medication for opioid use disorder, people with a past disorder, people wrongly regarded as having one, and people associated with someone who does. DOJ's own examples of illegal discrimination include a nursing home refusing patients on medication, a jail refusing to continue a prescription, and a town blocking a treatment centre because neighbours objected.",
      honest: "What is NOT protected: current illegal drug use, recent enough to justify a reasonable belief it is ongoing. But note the exception that matters most to the people reading this — you cannot be denied health or rehabilitation SERVICES on that basis alone.",
      url: "https://www.ada.gov/resources/opioid-use-disorder/",
      complain: "https://civilrights.justice.gov/"
    },
    {
      n: "You can take job-protected leave to get treatment",
      cite: "29 CFR 825.119 (FMLA)",
      body: "Treatment for substance abuse by a health care provider, or by a provider on referral from one, qualifies for FMLA leave. So does leave to care for a family member in treatment.",
      key: "Absence because of USE, rather than for treatment, does not qualify.",
      honest: "The catch, stated plainly because it surprises people: an employer may still terminate under an established, uniformly applied, communicated policy on substance abuse. What it may not do is fire you FOR exercising the right to seek treatment. That is a subtle line and a consequential one — worth an employment lawyer's hour before you rely on it.",
      url: "https://www.ecfr.gov/current/title-29/subtitle-B/chapter-V/subchapter-C/part-825/subpart-A/section-825.119"
    }
  ];

  var COMPLAIN = [
    { n: "Insurance parity — private employer plan", w: "Dept. of Labor, EBSA", p: "1-866-444-3272", u: "https://beta.dol.gov/about/agencies/ebsa/ask-ebsa" },
    { n: "Insurance parity — state or local government plan", w: "CMS", p: "1-877-267-2323 ext. 6-1565", u: "https://www.cms.gov/marketplace/private-health-insurance/mental-health-parity-addiction-equity" },
    { n: "Disability discrimination — any", w: "DOJ Civil Rights Division", p: "800-514-0301", u: "https://civilrights.justice.gov/" },
    { n: "Discrimination by a health care provider", w: "HHS Office for Civil Rights", p: "1-800-368-1019", u: "https://www.hhs.gov/civil-rights/filing-a-complaint/index.html" },
    { n: "Employment discrimination", w: "EEOC", p: "800-669-4000", u: "https://www.eeoc.gov/" }
  ];

  /* ================================================================== */
  /* STATE LAW LAYER — harm reduction legality, verified                 */
  /* dce: 'all' | 'fentanyl' | 'partial' | 'illegal'                     */
  /* ssp: 'express' | 'implicit' | 'none'                                */
  /* ================================================================== */
  var DCE_LABEL = {
    all: "Legal — all drug checking equipment",
    fentanyl: "Legal for fentanyl test strips only",
    partial: "Partly restricted",
    illegal: "Still treated as illegal paraphernalia"
  };
  var SSP_LABEL = {
    express: "Expressly authorised by statute",
    implicit: "Implicitly permitted, not expressly authorised",
    none: "No state authorisation"
  };

  var STATE_LAW = {
    AL: { dce: "fentanyl", ssp: "none" }, AK: { dce: "all", ssp: "express" },
    AZ: { dce: "fentanyl", ssp: "express" }, AR: { dce: "partial", ssp: "implicit" },
    CA: { dce: "partial", ssp: "express" }, CO: { dce: "all", ssp: "express" },
    CT: { dce: "all", ssp: "express" }, DE: { dce: "fentanyl", ssp: "express" },
    DC: { dce: "partial", ssp: "express" }, FL: { dce: "fentanyl", ssp: "express" },
    GA: { dce: "fentanyl", ssp: "express" }, HI: { dce: "fentanyl", ssp: "express" },
    ID: { dce: "fentanyl", ssp: "express" }, IL: { dce: "all", ssp: "express" },
    IN: { dce: "illegal", ssp: "express" }, IA: { dce: "illegal", ssp: "none" },
    KS: { dce: "fentanyl", ssp: "none" }, KY: { dce: "fentanyl", ssp: "express" },
    LA: { dce: "fentanyl", ssp: "express" }, ME: { dce: "all", ssp: "express" },
    MD: { dce: "all", ssp: "express" }, MA: { dce: "partial", ssp: "express" },
    MI: { dce: "partial", ssp: "implicit" }, MN: { dce: "all", ssp: "express" },
    MS: { dce: "fentanyl", ssp: "none" }, MO: { dce: "fentanyl", ssp: "express" },
    MT: { dce: "partial", ssp: "implicit" }, NE: { dce: "all", ssp: "none" },
    NV: { dce: "all", ssp: "express" }, NH: { dce: "partial", ssp: "express" },
    NJ: { dce: "all", ssp: "express" }, NM: { dce: "partial", ssp: "express" },
    NY: { dce: "all", ssp: "express" }, NC: { dce: "partial", ssp: "express" },
    ND: { dce: "illegal", ssp: "express" }, OH: { dce: "partial", ssp: "express" },
    OK: { dce: "fentanyl", ssp: "express" }, OR: { dce: "all", ssp: "express" },
    PA: { dce: "all", ssp: "express" }, RI: { dce: "all", ssp: "express" },
    SC: { dce: "all", ssp: "none" }, SD: { dce: "fentanyl", ssp: "none" },
    TN: { dce: "fentanyl", ssp: "express" }, TX: { dce: "illegal", ssp: "none" },
    UT: { dce: "all", ssp: "express" }, VT: { dce: "all", ssp: "express" },
    VA: { dce: "all", ssp: "express" }, WA: { dce: "all", ssp: "express" },
    WV: { dce: "all", ssp: "express" }, WI: { dce: "fentanyl", ssp: "express" },
    WY: { dce: "all", ssp: "none" }
  };

  var LAW_NOTE = "Two separate legal questions, from two separate trackers. Drug checking equipment — fentanyl test strips and similar — comes from the Network for Public Health Law's 50-state survey, whose most recent full edition covers 2024. Syringe services program authorisation comes from the Legislative Analysis and Public Policy Association's summary, published June 2026.";
  var LAW_CAVEAT = "Read this before acting on it. The drug-checking survey is 2024-vintage and states have moved since — Virginia broadened its exemption in 2025, and this table reflects that rather than the survey. A 2026 brief reporting the same totals is NOT independent corroboration, because it is built on the same 2024 survey; Clapback initially treated it as confirmation and that was wrong. So: verify your own state's current statute before you rely on legality. Note too that even where equipment is restricted, several states carve out an exception permitting syringe services programs to distribute it.";
  var LAW_URL_DCE = "https://www.networkforphl.org/resources/legality-of-drug-checking-equipment-in-the-united-states/";
  var LAW_URL_SSP = "https://legislativeanalysis.org/syringe-services-programs-summary-of-state-laws/";
  var LAW_SSP_REALITY = "Legality and reality are not the same thing, in both directions. Syringe services programs operate in some states whose statutes do not expressly authorise them — sometimes under local ordinance, sometimes simply tolerated — and conversely, a state authorising them does not mean one exists near you. Clapback saw a widely repeated count of operating programs but could not trace it to a publishing tracker, so it is not printed here. Check findtreatment.gov and your state health department for what actually exists where you are.";
  var LAW_GS = "Thirty-nine states extend their overdose Good Samaritan protections to drug checking equipment as well as to the person who calls for help.";

  return {
    UPDATED: UPDATED,
    EMERGENCY: EMERGENCY, XYLAZINE: XYLAZINE,
    LINES: LINES, LGBTQ: LGBTQ,
    LOCATORS: LOCATORS, LOCATOR_NOTE: LOCATOR_NOTE, LOCATOR_HONEST: LOCATOR_HONEST,
    MUTUAL: MUTUAL,
    MOUD: MOUD, METHADONE: METHADONE, NALOXONE: NALOXONE,
    RIGHTS: RIGHTS, COMPLAIN: COMPLAIN,
    STATE_LAW: STATE_LAW, DCE_LABEL: DCE_LABEL, SSP_LABEL: SSP_LABEL,
    LAW_NOTE: LAW_NOTE, LAW_CAVEAT: LAW_CAVEAT, LAW_URL_DCE: LAW_URL_DCE,
    LAW_URL_SSP: LAW_URL_SSP, LAW_SSP_REALITY: LAW_SSP_REALITY, LAW_GS: LAW_GS
  };
})();

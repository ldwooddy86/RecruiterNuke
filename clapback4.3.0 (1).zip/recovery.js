/* Clapback — "Find help" module (substance use & harm reduction).
 * Builds locator links on-device from a ZIP you type. Makes no network
 * requests and stores nothing about what you searched for.
 */
(function () {
  "use strict";
  var X = window.CBX, U = window.CBU;
  var mounted = false;
  var prof = {};

  function mount() {
    var view = X.$("#view-recovery");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Find help</h1>' +
      '<p class="lede">Treatment, medication, harm reduction and the rights that go with them. Clapback holds no directory of clinics — a stale phone number is worse than none in this situation — so instead it builds the right search into the live federal locators from a ZIP code you type here, on this device. Nothing you enter is sent anywhere or saved.</p>' +

      /* ---- emergency, always first ---- */
      '<div class="card danger">' +
      '<h2 id="em-head"></h2>' +
      '<ol class="tidy" id="em-steps"></ol>' +
      '<h4 style="margin-top:14px">Signs of an opioid overdose</h4>' +
      '<ul class="tidy" id="em-signs"></ul>' +
      '<div class="callout callout-info" id="em-samaritan"></div>' +
      '<p class="fineprint" id="em-staysrc"></p>' +
      X.srcLine("CDC — overdose signs and naloxone", U.EMERGENCY.url) +
      '</div>' +

      '<div class="card danger">' +
      '<h3 id="xy-head"></h3><p id="xy-body"></p>' +
      '<div class="callout callout-warn" id="xy-critical"></div>' +
      '<p id="xy-breathing"></p><p class="muted" id="xy-wounds"></p>' +
      '<p class="muted" id="xy-attrib"></p>' +
      '<div class="btn-row">' + X.a("CDC on xylazine ↗", U.XYLAZINE.url, "btn btn-sm") + X.a("NIDA on xylazine ↗", U.XYLAZINE.nidaUrl) + '</div>' +
      '</div>' +

      /* ---- national lines ---- */
      '<h2>Lines that answer</h2>' +
      '<div id="ln-list"></div>' +
      '<div class="card danger"><h3 id="lg-head"></h3><p id="lg-body"></p>' +
      '<p class="muted" id="lg-moving"></p>' +
      '<div class="callout callout-info" id="lg-alt"></div>' +
      X.srcLine("SAMHSA / 988 Lifeline FAQ", U.LGBTQ.url) + '</div>' +

      /* ---- the launcher ---- */
      '<h2>Find treatment near a ZIP code</h2>' +
      '<div class="card">' +
      '<p class="muted" id="loc-note"></p>' +
      '<div class="ev-form">' +
      '<div class="ev-field"><label class="field" for="rz-zip">ZIP code</label><input class="input" id="rz-zip" type="text" inputmode="numeric" maxlength="5" pattern="[0-9]{5}" placeholder="e.g. 78701" autocomplete="postal-code"></div>' +
      '<div class="ev-field-wide"><button class="btn" id="rz-run">Build my links</button></div>' +
      '</div>' +
      '<div id="rz-out"></div>' +
      '<p class="muted" id="loc-honest" style="margin-top:14px"></p>' +
      '</div>' +

      '<div class="card"><h3>Meetings and peer support</h3>' +
      '<p class="muted">Free, everywhere, and not a substitute for medication if you have an opioid use disorder — the evidence on that is in the next section. Many people use both.</p>' +
      '<div id="mu-list" class="link-list"></div></div>' +

      /* ---- evidence ---- */
      '<h2 id="md-head"></h2>' +
      '<div class="card">' +
      '<p class="lede" style="font-size:15px" id="md-lead"></p>' +
      '<div class="cmp-wrap"><table class="cmp"><thead><tr><th>Medication</th><th>All-cause death</th><th>Overdose death</th></tr></thead><tbody id="md-rows"></tbody></table></div>' +
      '<div id="md-notes" class="link-list"></div>' +
      '<div class="callout callout-warn" id="md-honest"></div>' +
      '<p id="md-naltrexone"></p><p class="fineprint" id="md-nsrc"></p>' +
      X.srcLine("Larochelle et al., Annals of Internal Medicine 2018", U.MOUD.url) +
      '</div>' +

      '<div class="card"><h3 id="me-head"></h3><p id="me-body"></p>' +
      '<div id="me-changes" class="link-list"></div>' +
      '<div class="callout callout-warn" id="me-ceiling"></div>' +
      '<div class="btn-row">' + X.a("The regulation ↗", U.METHADONE.url, "btn btn-sm") + X.a("The final rule ↗", U.METHADONE.frUrl) + '</div>' +
      '</div>' +

      '<div class="card"><h3 id="nx-head"></h3><p id="nx-body"></p>' +
      '<p id="nx-who"></p><p class="muted" id="nx-free"></p>' +
      X.srcLine("U.S. Food and Drug Administration", U.NALOXONE.url) + '</div>' +

      /* ---- state law ---- */
      '<h2>What is legal where you are</h2>' +
      '<div class="card">' +
      '<div class="ev-field" style="max-width:340px"><label class="field" for="rs-state">Your state</label><span id="rs-state-host"></span></div>' +
      '<div id="rs-out" style="margin-top:12px"></div>' +
      '<p class="muted" id="law-note"></p>' +
      '<div class="callout callout-warn" id="law-caveat"></div>' +
      '<div class="callout callout-info" id="law-reality"></div>' +
      '<p class="muted" id="law-gs"></p>' +
      '<div class="btn-row">' + X.a("Drug checking equipment tracker ↗", U.LAW_URL_DCE, "btn btn-sm") + X.a("Syringe services tracker ↗", U.LAW_URL_SSP) + '</div>' +
      '</div>' +

      /* ---- rights ---- */
      '<h2>Your rights</h2>' +
      '<div id="rt-list"></div>' +
      '<div class="card"><h3>Where to complain, and to whom</h3>' +
      '<p class="muted">Matching the right regulator to the right problem is most of the battle — the wrong one will simply not act, and the clock keeps running.</p>' +
      '<div id="rt-complain" class="link-list"></div></div>' +

      '<p class="disclaimer">Not medical or legal advice. Clapback is not a treatment provider and has no relationship with any facility, program or manufacturer — nothing here is a referral and nobody pays to appear on this page. Every clinical claim links to the study or regulation it came from, verified ' + X.esc(U.UPDATED) + '. If you are in crisis right now, call or text 988.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    var E = U.EMERGENCY;
    X.$("#em-head").textContent = E.head;
    var es = X.$("#em-steps"); es.innerHTML = "";
    E.steps.forEach(function (t) { es.appendChild(X.el("li", null, t)); });
    var sg = X.$("#em-signs"); sg.innerHTML = "";
    E.signs.forEach(function (t) { sg.appendChild(X.el("li", null, t)); });
    X.$("#em-samaritan").innerHTML = "<strong>Calling 911 and Good Samaritan laws.</strong> " + X.esc(E.samaritan);
    X.$("#em-staysrc").innerHTML = X.esc(E.staySrc) + " " + X.a("CDC naloxone care page ↗", E.stayUrl);

    var Y = U.XYLAZINE;
    X.$("#xy-head").textContent = Y.head;
    X.$("#xy-body").textContent = Y.body;
    X.$("#xy-critical").innerHTML = "<strong>The mistake that kills people here.</strong> " + X.esc(Y.critical);
    X.$("#xy-breathing").textContent = Y.breathing;
    X.$("#xy-wounds").textContent = Y.wounds;
    X.$("#xy-attrib").textContent = Y.attrib;

    /* lines */
    var ll = X.$("#ln-list"); ll.innerHTML = "";
    U.LINES.forEach(function (l) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", l.n));
      head.appendChild(X.el("span", "status-pill " + (l.crisis ? "pill-red" : "pill-ban"), l.crisis ? "Crisis · 24/7" : "Information"));
      card.appendChild(head);
      var num = X.el("div");
      num.style.cssText = "font-size:21px;font-weight:800;margin:6px 0 4px;letter-spacing:.2px";
      num.textContent = l.num;
      card.appendChild(num);
      card.appendChild(X.el("p", null, l.t));
      if (l.extra) card.appendChild(X.el("p", "muted", l.extra));
      if (l.warn) {
        var w = X.el("div", "callout callout-warn"); w.style.margin = "10px 0 0"; w.textContent = l.warn;
        card.appendChild(w);
      }
      var row = X.el("div", "btn-row"); row.style.marginTop = "10px";
      row.innerHTML = X.a("Their page ↗", l.u, "btn btn-sm") + (l.chat ? X.a("Chat online ↗", l.chat) : "");
      card.appendChild(row);
      ll.appendChild(card);
    });

    var G = U.LGBTQ;
    X.$("#lg-head").textContent = G.head;
    X.$("#lg-body").textContent = G.body;
    X.$("#lg-moving").textContent = G.moving;
    X.$("#lg-alt").innerHTML = "<strong>What still exists.</strong> " + X.esc(G.alt) + " " + X.a("The Trevor Project ↗", G.altUrl);

    X.$("#loc-note").textContent = U.LOCATOR_NOTE;
    X.$("#loc-honest").textContent = U.LOCATOR_HONEST;
    X.$("#rz-run").addEventListener("click", buildLinks);
    X.$("#rz-zip").addEventListener("keydown", function (e) { if (e.key === "Enter") buildLinks(); });

    var mu = X.$("#mu-list"); mu.innerHTML = "";
    U.MUTUAL.forEach(function (m) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", m.n));
      l.appendChild(X.el("div", "li-note", m.t));
      row.appendChild(l);
      var a = X.el("div"); a.innerHTML = X.a("Open ↗", m.u, "btn btn-sm");
      row.appendChild(a);
      mu.appendChild(row);
    });

    /* MOUD */
    var M = U.MOUD;
    X.$("#md-head").textContent = M.head;
    X.$("#md-lead").textContent = M.lead;
    X.$("#md-rows").innerHTML = M.rows.map(function (r) {
      return "<tr><td>" + X.esc(r.m) + '</td><td class="num">' + X.esc(r.all) + '</td><td class="num">' + X.esc(r.od) + "</td></tr>";
    }).join("");
    var mn = X.$("#md-notes"); mn.innerHTML = "";
    M.rows.forEach(function (r) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", r.m));
      l.appendChild(X.el("div", "li-note", r.n));
      row.appendChild(l);
      mn.appendChild(row);
    });
    X.$("#md-honest").innerHTML = "<strong>Two caveats Clapback will not bury.</strong> " + X.esc(M.honest);
    X.$("#md-naltrexone").textContent = M.naltrexone;
    X.$("#md-nsrc").textContent = M.naltrexoneSrc;

    var ME = U.METHADONE;
    X.$("#me-head").textContent = ME.head;
    X.$("#me-body").textContent = ME.body;
    var mc = X.$("#me-changes"); mc.innerHTML = "";
    ME.changes.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.n));
      l.appendChild(X.el("div", "li-note", c.t));
      row.appendChild(l);
      mc.appendChild(row);
    });
    X.$("#me-ceiling").innerHTML = "<strong>Ceilings, not floors.</strong> " + X.esc(ME.ceiling) +
      " <span class='muted'>(" + X.esc(ME.cite) + ")</span>";

    var N = U.NALOXONE;
    X.$("#nx-head").textContent = N.head;
    X.$("#nx-body").textContent = N.body;
    X.$("#nx-who").textContent = N.who;
    X.$("#nx-free").textContent = N.free;

    /* law notes */
    X.$("#law-note").textContent = U.LAW_NOTE;
    X.$("#law-caveat").innerHTML = "<strong>Read this before acting on it.</strong> " + X.esc(U.LAW_CAVEAT);
    X.$("#law-reality").innerHTML = "<strong>Legality is not availability.</strong> " + X.esc(U.LAW_SSP_REALITY);
    X.$("#law-gs").textContent = U.LAW_GS;

    /* rights */
    var rl = X.$("#rt-list"); rl.innerHTML = "";
    U.RIGHTS.forEach(function (r) {
      var card = X.el("div", "card");
      var h = X.el("h3", null, r.n);
      card.appendChild(h);
      card.appendChild(X.el("div", "law-eff", r.cite));
      card.appendChild(X.el("p", null, r.body));
      var k = X.el("div", "callout callout-info");
      k.innerHTML = "<strong>What you can do.</strong> " + X.esc(r.key);
      card.appendChild(k);
      if (r.who) card.appendChild(X.el("p", "muted", r.who));
      if (r.honest) {
        var ho = X.el("div", "callout callout-warn");
        ho.innerHTML = "<strong>And the honest part.</strong> " + X.esc(r.honest);
        card.appendChild(ho);
      }
      var row = X.el("div", "btn-row");
      row.innerHTML = X.a("The source ↗", r.url, "btn btn-sm") + (r.complain ? X.a("File a complaint ↗", r.complain) : "");
      card.appendChild(row);
      rl.appendChild(card);
    });

    var cl = X.$("#rt-complain"); cl.innerHTML = "";
    U.COMPLAIN.forEach(function (c) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", c.n));
      l.appendChild(X.el("div", "li-note", c.w + " · " + c.p));
      row.appendChild(l);
      var a = X.el("div"); a.innerHTML = X.a("Open ↗", c.u, "btn btn-sm");
      row.appendChild(a);
      cl.appendChild(row);
    });
  }

  /* Builds locator URLs from a ZIP typed on this device. No request is made;
     the links only do anything when the user clicks one. */
  function buildLinks() {
    var raw = (X.$("#rz-zip").value || "").trim();
    var out = X.$("#rz-out");
    var zip = raw.replace(/[^0-9]/g, "").slice(0, 5);
    if (zip.length !== 5) {
      out.innerHTML = '<div class="callout callout-warn">Enter a five-digit ZIP code. Clapback does not look it up or check that it exists — it just puts it into the search link for you.</div>';
      return;
    }
    var html = '<div class="risk-banner risk-low"><div class="risk-ic">→</div><div>' +
      '<div class="risk-label">Links built for ' + X.esc(zip) + '.</div>' +
      '<div class="risk-sub">These open the live federal locators. Clapback has not contacted any of them and does not know what they will show.</div>' +
      '</div></div>';

    U.LOCATORS.forEach(function (L) {
      var url = (!L.noZip && L.build) ? L.build(zip) : L.fallback;
      html += '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(L.n) + '</div>' +
        (L.primary ? '<span class="status-pill pill-ban">Start here</span>' : "") + '</div>' +
        '<p>' + X.esc(L.t) + '</p>' +
        '<div class="btn-row">' +
        X.a(L.noZip ? "Open ↗" : "Search " + zip + " ↗", url, "btn btn-sm") +
        (L.noZip ? "" : X.a("Plain site ↗", L.fallback)) +
        '</div>' +
        '<p class="muted" style="margin:10px 0 0">' + X.esc(L.fallbackNote) + '</p>' +
        '</div>';
    });
    html += '<div class="callout callout-info"><strong>If the links do not behave.</strong> ' +
      'Call the SAMHSA National Helpline on <strong>1-800-662-4357</strong> — free, confidential, 24 hours, English and Spanish — and a person will run the search for you. ' +
      'You can also text your ZIP code to <strong>435748</strong>.</div>';
    out.innerHTML = html;
  }

  function load() {
    X.profile().then(function (p) {
      prof = p;
      var host = X.$("#rs-state-host");
      if (host) {
        host.innerHTML = X.stateSelect("rs-state", p.state, "Select a state…");
        X.$("#rs-state").addEventListener("change", renderState);
      }
      var z = X.$("#rz-zip");
      if (z && !z.value && p.zip) z.value = p.zip;
      renderState();
    });
  }

  function refresh() {
    X.profile().then(function (p) {
      prof = p;
      var sel = X.$("#rs-state");
      if (sel && !sel.value && p.state) sel.value = p.state;
      var z = X.$("#rz-zip");
      if (z && !z.value && p.zip) z.value = p.zip;
      renderState();
    });
  }

  function renderState() {
    var out = X.$("#rs-out"); if (!out) return;
    var st = X.$("#rs-state") ? X.$("#rs-state").value : prof.state;
    if (!st) {
      out.innerHTML = '<p class="muted">Pick your state and Clapback will show what it verified about drug checking equipment and syringe services there.</p>';
      return;
    }
    var L = U.STATE_LAW[st];
    if (!L) { out.innerHTML = '<p class="muted">No verified entry for that jurisdiction.</p>'; return; }

    var dceCls = L.dce === "all" ? "pill-ban" : L.dce === "illegal" ? "pill-red" : "pill-amber";
    var sspCls = L.ssp === "express" ? "pill-ban" : L.ssp === "none" ? "pill-red" : "pill-amber";
    var name = X.stateName(st);

    var dceExtra = L.dce === "illegal"
      ? "In this state, possessing or distributing drug checking equipment may still be charged as drug paraphernalia. Several states in this position nonetheless carve out an exception permitting syringe services programs to distribute it — check whether yours does before assuming."
      : L.dce === "fentanyl"
        ? "The exemption here covers fentanyl test strips specifically, not drug checking equipment generally. Strips that test for other substances may still fall under the paraphernalia statute."
        : L.dce === "partial"
          ? "Possession is generally permitted here but distribution or sale is restricted — which in practice affects harm reduction programs more than individuals."
          : "Possession, free distribution and sale are all permitted.";

    var sspExtra = L.ssp === "none"
      ? "No state statute authorises syringe services programs here. That does not always mean none operate — see the note below."
      : L.ssp === "implicit"
        ? "No express authorising statute, but syringe exchange is permitted indirectly — usually through a definition or an exemption from the paraphernalia law."
        : "Syringe services programs are expressly authorised by statute.";

    out.innerHTML =
      '<div class="law-card"><div class="law-head"><div class="law-name">Drug checking equipment — ' + X.esc(name) + '</div>' +
      '<span class="status-pill ' + dceCls + '">' + X.esc(U.DCE_LABEL[L.dce]) + '</span></div>' +
      '<p>' + X.esc(dceExtra) + '</p></div>' +
      '<div class="law-card"><div class="law-head"><div class="law-name">Syringe services programs — ' + X.esc(name) + '</div>' +
      '<span class="status-pill ' + sspCls + '">' + X.esc(U.SSP_LABEL[L.ssp]) + '</span></div>' +
      '<p>' + X.esc(sspExtra) + '</p></div>';
  }

  X.bootstrap("recovery", mount);
})();

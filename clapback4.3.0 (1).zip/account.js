/* Clapback — "The record" module (public accountability).
 * Official acts only, every claim cited. No network requests.
 */
(function () {
  "use strict";
  var X = window.CBX, A = window.CBA, U = window.CBU, D = window.PDS;
  var mounted = false;
  var prof = {};
  var mapMode = "expansion";   // expansion | dce | ssp

  var STATE_NAME = {};
  (D.STATES || []).forEach(function (p) { STATE_NAME[p[0]] = p[1]; });

  function mount() {
    var view = X.$("#view-account");
    if (!view || mounted) { if (mounted) load(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>The record</h1>' +
      '<p class="lede">Who voted for what, where the settlement money went, and which policy choices your state actually made. Every line on this page is an official act with a link to the government record behind it — because a citation is the only kind of criticism that cannot be waved away.</p>' +

      '<div class="card">' +
      '<h2 id="ch-head"></h2><p id="ch-body"></p>' +
      '<div class="callout callout-warn" id="ch-refuse"></div>' +
      '<p id="ch-use"></p>' +
      '</div>' +

      /* ---- the money ---- */
      '<h2 id="se-head"></h2>' +
      '<div class="card">' +
      '<div class="grid-2" style="margin-bottom:12px">' +
      '<div class="card mini"><div class="stat-num" style="font-size:26px" id="se-total"></div><div class="li-note">Total across all opioid settlements</div></div>' +
      '<div class="card mini"><div class="stat-num" style="font-size:26px">~41%</div><div class="li-note">Of 2024 receipts actually spent or committed</div></div>' +
      '</div>' +
      '<p id="se-body"></p>' +
      '<p class="muted" id="se-totalnote"></p>' +
      '<div class="btn-row">' + X.a("Official state allocations ↗", A.SETTLEMENT.officialUrl, "btn btn-sm") + X.a("Purdue settlement terms ↗", A.SETTLEMENT.purdueUrl) + '</div>' +
      '</div>' +

      '<div class="card"><h3 id="sp-head"></h3>' +
      '<div id="sp-rows" class="link-list"></div>' +
      '<div class="callout callout-warn" id="sp-note"></div>' +
      '<p class="muted" id="sp-earlier"></p>' +
      '<p class="fineprint" id="sp-src"></p>' +
      '</div>' +

      /* ---- findings ---- */
      '<h2>Documented findings</h2>' +
      '<p class="muted">Three of these. Read the status label on each — one is an established comptroller finding, one is contested by the agency it concerns, and one is journalism rather than a government audit. They are not the same weight and Clapback will not present them as though they were.</p>' +
      '<div id="fi-list"></div>' +

      '<div class="card"><h3 id="tp-head"></h3><p id="tp-body"></p>' +
      '<div id="tp-states"></div>' +
      '<div class="callout callout-warn" id="tp-honest"></div>' +
      '<div class="btn-row">' + X.a("The analysis ↗", A.TRANSPARENCY.url, "btn btn-sm") + X.a("State-by-state tracker ↗", A.TRANSPARENCY.everything) + X.a("NASHP tracker ↗", A.TRANSPARENCY.nashp) + '</div>' +
      '</div>' +

      /* ---- the votes ---- */
      '<h2>The votes</h2>' +
      '<p class="muted">Official roll calls only, linked to the Clerk of the House and the Senate. Tallies are as recorded.</p>' +
      '<div id="vo-list"></div>' +

      /* ---- a named member's record ---- */
      '<h2 id="mem-head"></h2>' +
      '<div class="card">' +
      '<div class="law-head"><div class="law-name" id="mem-who"></div><span class="status-pill pill-none" id="mem-seat"></span></div>' +
      '<div class="law-eff" id="mem-covers"></div>' +
      '<p id="mem-why"></p><p class="muted" id="mem-method"></p>' +
      '</div>' +
      '<div class="card danger"><h3 id="mh-head"></h3><div id="mh-parts" class="link-list"></div>' +
      '<div class="callout callout-warn" id="mh-sharp"></div></div>' +

      '<h3 style="margin-top:22px">The votes that carry individual signal</h3>' +
      '<p class="muted">Four of these broke from a meaningful share of his own conference. The rest were party-line, which says more about the party than the person — they are marked as such.</p>' +
      '<div id="mem-votes"></div>' +

      '<div class="card"><h3 id="nv-head"></h3><div id="nv-rows" class="link-list"></div>' +
      '<p class="muted" id="nv-comm"></p></div>' +

      '<div class="card"><h3 id="mm-head"></h3><p id="mm-body"></p>' +
      '<div id="mm-rows" class="link-list"></div>' +
      '<p class="muted" id="mm-note"></p>' +
      '<div class="callout callout-warn" id="mm-kill"></div>' +
      '<p id="mm-leadership"></p>' +
      '<p class="fineprint" id="mm-caution"></p>' +
      '<div class="btn-row">' + X.a("FEC candidate record ↗", A.MEMBER.money.fecUrl, "btn btn-sm") + X.a("Leadership PAC ↗", A.MEMBER.money.pacUrl) + '</div></div>' +

      '<div class="card"><h2 id="cn-head"></h2>' +
      '<div class="callout callout-info" id="cn-why"></div>' +
      '<div id="cn-items"></div>' +
      '<p class="muted" id="cn-direction"></p><p class="muted" id="cn-other"></p></div>' +

      '<div class="card"><h3 id="sc-head2"></h3><p id="sc-body2"></p>' +
      '<p id="sc-useful"></p><div class="callout callout-warn" id="sc-sample"></div></div>' +

      '<div class="card"><h3 id="gp-head"></h3><ul class="tidy" id="gp-rows"></ul></div>' +

      '<div class="card"><h3 id="cx-head"></h3><p id="cx-body"></p>' +
      '<div id="cx-rows" class="link-list"></div>' +
      '<p class="muted" id="cx-note"></p>' +
      '<div class="btn-row">' + X.a("His official contact page ↗", A.MEMBER.contact.u, "btn btn-sm") + '</div></div>' +

      '<div class="card"><h3 id="lu-head"></h3><p id="lu-body"></p>' +
      '<div id="lu-links" class="link-list"></div>' +
      '<div class="callout callout-info" id="lu-honest"></div>' +
      '</div>' +

      /* ---- money ---- */
      '<div class="card"><h2 id="mo-head"></h2><p id="mo-body"></p>' +
      '<div id="mo-links" class="link-list"></div>' +
      '<p id="mo-figures"></p><p class="fineprint" id="mo-fsrc"></p>' +
      '<div class="callout callout-warn" id="mo-caution"></div>' +
      '</div>' +

      /* ---- the scorecard map ---- */
      '<h2>What your state chose</h2>' +
      '<div class="card">' +
      '<p class="muted" id="sc-note"></p>' +
      '<div class="chips" id="ac-mode">' +
      '<button class="chip active" data-acmap="expansion">Medicaid expansion</button>' +
      '<button class="chip" data-acmap="dce">Fentanyl test strips</button>' +
      '<button class="chip" data-acmap="ssp">Syringe services</button>' +
      '</div>' +
      '<p class="muted" id="ac-caption"></p>' +
      '<div id="ac-grid" class="gm-grid" role="group" aria-label="US state grid"></div>' +
      '<div class="gm-legend" id="ac-legend"></div>' +
      '<div id="ac-detail" style="margin-top:14px"></div>' +
      '</div>' +

      '<div class="card"><h3 id="ev-head"></h3><p id="ev-body"></p>' +
      '<div class="callout callout-warn" id="ev-against"></div>' +
      '<p class="muted" id="ev-limits"></p>' +
      X.srcLine("Kravitz-Wirtz et al., JAMA Network Open (2020)", A.EVIDENCE.url) +
      '</div>' +

      '<div class="card"><h3 id="od-head"></h3><p id="od-body"></p>' +
      '<p id="od-uneven"></p><p class="muted" id="od-caveat"></p>' +
      '<div class="btn-row">' + X.a("CDC release ↗", A.OVERDOSE.url, "btn btn-sm") + X.a("Rates by state ↗", A.OVERDOSE.stateUrl) + '</div>' +
      '</div>' +

      '<div class="card"><h3>Verified state oversight bodies</h3>' +
      '<p class="muted" id="ov-note"></p>' +
      '<div id="ov-list" class="link-list"></div></div>' +

      /* ---- what to do ---- */
      '<h2 id="ac-head"></h2>' +
      '<div class="card"><div id="ac-steps" class="link-list"></div>' +
      '<div class="callout callout-info" id="ac-close"></div></div>' +

      '<p class="disclaimer">Public record, compiled and cited. Clapback takes no position on any candidate, party or election, endorses nobody, and is not affiliated with any campaign or advocacy organisation. Figures compiled from government sources except where a line says otherwise, verified ' + X.esc(A.UPDATED) + '. Where a widely repeated claim could not be traced to a primary source it is marked as such rather than printed.</p>';

    renderStatic();
    load();
  }

  function linkList(host, rows, kf, tf, uf) {
    var el = X.$(host); if (!el) return;
    el.innerHTML = "";
    rows.forEach(function (r) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", r[kf]));
      if (r[tf]) l.appendChild(X.el("div", "li-note", r[tf]));
      row.appendChild(l);
      if (uf && r[uf]) {
        var a = X.el("div"); a.innerHTML = X.a("Open ↗", r[uf], "btn btn-sm");
        row.appendChild(a);
      }
      el.appendChild(row);
    });
  }

  function renderStatic() {
    var C = A.CHARTER;
    X.$("#ch-head").textContent = C.head;
    X.$("#ch-body").textContent = C.body;
    X.$("#ch-refuse").innerHTML = "<strong>What this page refuses to be.</strong> " + X.esc(C.refuse);
    X.$("#ch-use").textContent = C.use;

    var S = A.SETTLEMENT;
    X.$("#se-head").textContent = S.head;
    X.$("#se-total").textContent = S.total;
    X.$("#se-body").textContent = S.body;
    X.$("#se-totalnote").textContent = S.totalNote;

    X.$("#sp-head").textContent = S.spend.head;
    linkList("#sp-rows", S.spend.rows.map(function (r) { return { k: r.k, t: r.v }; }), "k", "t");
    X.$("#sp-note").innerHTML = "<strong>The part that is hardest to defend.</strong> " + X.esc(S.spend.note);
    X.$("#sp-earlier").textContent = S.spend.earlier;
    X.$("#sp-src").innerHTML = X.esc(S.spend.src) + " · " + X.a("Tracking project ↗", S.spend.url) + " · " + X.a("2022–23 database ↗", S.spend.earlierUrl);

    /* findings */
    var fl = X.$("#fi-list"); fl.innerHTML = "";
    A.FINDINGS.forEach(function (f) {
      var card = X.el("div", "card");
      if (f.status !== "journalism") card.className = "card danger";
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", f.head));
      var pill = f.status === "established" ? ["pill-red", "Established finding"]
        : f.status === "contested" ? ["pill-amber", "Contested"]
          : ["pill-none", "Journalism"];
      head.appendChild(X.el("span", "status-pill " + pill[0], pill[1]));
      card.appendChild(head);
      var meta = X.el("div", "law-eff", f.where + (f.amount ? " · " + f.amount : ""));
      card.appendChild(meta);
      card.appendChild(X.el("p", null, f.body));
      if (f.quote) {
        var q = X.el("div", "callout callout-info");
        q.innerHTML = "&ldquo;" + X.esc(f.quote) + "&rdquo; <span class='muted'>&mdash; " + X.esc(f.quoteWho) + "</span>";
        card.appendChild(q);
      }
      if (f.dispute) {
        var dd = X.el("div", "callout callout-warn");
        dd.innerHTML = "<strong>" + (f.status === "contested" ? "How to describe this accurately." : "The rest of the finding.") + "</strong> " + X.esc(f.dispute);
        card.appendChild(dd);
      }
      if (f.context) card.appendChild(X.el("p", "muted", f.context));
      var row = X.el("div", "btn-row");
      row.innerHTML = X.a("The source document ↗", f.url, "btn btn-sm") +
        (f.url2 ? X.a("Second source ↗", f.url2) : "") +
        (f.url3 ? X.a("The reporting ↗", f.url3) : "");
      card.appendChild(row);
      card.appendChild(X.el("div", "fineprint", f.src));
      fl.appendChild(card);
    });

    var T = A.TRANSPARENCY;
    X.$("#tp-head").textContent = T.head;
    X.$("#tp-body").textContent = T.body;
    X.$("#tp-states").innerHTML = '<p class="muted" style="margin-top:10px">The twelve that promised: ' +
      T.states.map(function (s) { return '<span class="tag">' + X.esc(s) + "</span>"; }).join(" ") + "</p>";
    X.$("#tp-honest").innerHTML = "<strong>Why Clapback stops short here.</strong> " + X.esc(T.honest);

    /* votes */
    var vl = X.$("#vo-list"); vl.innerHTML = "";
    A.VOTES.forEach(function (v) {
      var card = X.el("div", "card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", v.n));
      head.appendChild(X.el("span", "status-pill pill-none", v.bill));
      card.appendChild(head);
      card.appendChild(X.el("p", null, v.what));
      var tbl = X.el("div", "cmp-wrap");
      tbl.innerHTML = '<table class="cmp"><thead><tr><th>Chamber</th><th>Date</th><th>Recorded vote</th><th></th></tr></thead><tbody>' +
        v.rows.map(function (r) {
          return "<tr><td>" + X.esc(r.ch) + "</td><td>" + X.esc(r.date) + '</td><td class="num">' + X.esc(r.tally) +
            "</td><td>" + X.a("Roll call ↗", r.u) + "</td></tr>";
        }).join("") + "</tbody></table>";
      card.appendChild(tbl);
      var h = X.el("div", "callout callout-info");
      h.innerHTML = "<strong>Read this before you quote it.</strong> " + X.esc(v.honest);
      card.appendChild(h);
      var row = X.el("div", "btn-row");
      row.innerHTML = X.a("The bill ↗", v.billUrl, "btn btn-sm") + (v.prior ? X.a("The 2023 vote that died ↗", v.prior) : "");
      card.appendChild(row);
      vl.appendChild(card);
    });


    /* ---- the named member ---- */
    var M = A.MEMBER;
    X.$("#mem-head").textContent = M.head;
    X.$("#mem-who").textContent = M.who;
    X.$("#mem-seat").textContent = M.seat;
    X.$("#mem-covers").textContent = M.covers;
    X.$("#mem-why").textContent = M.why;
    X.$("#mem-method").textContent = M.method;

    X.$("#mh-head").textContent = M.headline.head;
    linkList("#mh-parts", M.headline.parts, "n", "t");
    X.$("#mh-sharp").innerHTML = "<strong>The sentence the record supports.</strong> " + X.esc(M.headline.sharp);

    var mv = X.$("#mem-votes"); mv.innerHTML = "";
    M.votes.forEach(function (v) {
      var card = X.el("div", v.dev ? "card danger" : "card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", v.n));
      head.appendChild(X.el("span", "status-pill " + (v.dev ? "pill-red" : "pill-none"), v.dev ? "Broke from his party" : "Party-line"));
      card.appendChild(head);
      card.appendChild(X.el("div", "law-eff", v.bill + " · " + v.date + " · Roll call " + v.roll));
      var row = X.el("div", "card-fact");
      row.appendChild(X.el("b", null, "His vote"));
      var vv = X.el("strong", null, v.v);
      vv.style.color = "#b91c1c";
      row.appendChild(vv);
      card.appendChild(row);
      var t = X.el("div", "card-fact");
      t.appendChild(X.el("b", null, "Result"));
      t.appendChild(document.createTextNode(v.tally + " · " + v.split));
      card.appendChild(t);
      if (v.note) card.appendChild(X.el("p", "muted", v.note));
      var br = X.el("div", "btn-row");
      br.innerHTML = X.a("The roll call ↗", v.u, "btn btn-sm");
      card.appendChild(br);
      mv.appendChild(card);
    });

    X.$("#nv-head").textContent = M.never.head;
    linkList("#nv-rows", M.never.rows, "k", "v");
    X.$("#nv-comm").textContent = M.never.committees;

    var MM = M.money;
    X.$("#mm-head").textContent = MM.head;
    X.$("#mm-body").textContent = MM.body;
    linkList("#mm-rows", MM.rows.map(function (r) { return { k: r.k, t: r.v }; }), "k", "t");
    X.$("#mm-note").textContent = MM.note;
    X.$("#mm-kill").innerHTML = "<strong>Why this cuts against the obvious argument.</strong> " + X.esc(MM.kill);
    X.$("#mm-leadership").textContent = MM.leadership;
    X.$("#mm-caution").textContent = MM.caution;

    var CN = M.counter;
    X.$("#cn-head").textContent = CN.head;
    X.$("#cn-why").innerHTML = "<strong>Why the counter-evidence is in the same tab.</strong> " + X.esc(CN.why);
    var ci = X.$("#cn-items"); ci.innerHTML = "";
    CN.items.forEach(function (it) {
      var card = X.el("div", "law-card");
      var head = X.el("div", "law-head");
      head.appendChild(X.el("div", "law-name", it.n));
      head.appendChild(X.el("span", "status-pill pill-ban", "Cuts the other way"));
      card.appendChild(head);
      card.appendChild(X.el("p", null, it.t));
      if (it.fix) {
        var f = X.el("div", "callout callout-warn");
        f.innerHTML = "<strong>A correction Clapback is making out loud.</strong> " + X.esc(it.fix);
        card.appendChild(f);
      }
      var br = X.el("div", "btn-row");
      br.innerHTML = X.a("The record ↗", it.u, "btn btn-sm");
      card.appendChild(br);
      ci.appendChild(card);
    });
    X.$("#cn-direction").textContent = CN.direction;
    X.$("#cn-other").textContent = CN.other;

    var SC = M.scorecards;
    X.$("#sc-head2").textContent = SC.head;
    X.$("#sc-body2").textContent = SC.body;
    X.$("#sc-useful").textContent = SC.useful;
    X.$("#sc-sample").innerHTML = "<strong>Check the sample size.</strong> " + X.esc(SC.sample);

    X.$("#gp-head").textContent = M.gaps.head;
    var gr = X.$("#gp-rows"); gr.innerHTML = "";
    M.gaps.rows.forEach(function (t) { gr.appendChild(X.el("li", null, t)); });

    var CX = M.contact;
    X.$("#cx-head").textContent = CX.head;
    X.$("#cx-body").textContent = CX.body;
    linkList("#cx-rows", CX.rows.map(function (r) { return { k: r.k, t: r.v }; }), "k", "t");
    X.$("#cx-note").textContent = CX.note;

    var L = A.LOOKUP;
    X.$("#lu-head").textContent = L.head;
    X.$("#lu-body").textContent = L.body;
    linkList("#lu-links", L.links, "n", "t", "u");
    X.$("#lu-honest").innerHTML = "<strong>One genuine limitation.</strong> " + X.esc(L.honest);

    var M = A.MONEY;
    X.$("#mo-head").textContent = M.head;
    X.$("#mo-body").textContent = M.body;
    linkList("#mo-links", M.links, "n", "t", "u");
    X.$("#mo-figures").textContent = M.figures;
    X.$("#mo-fsrc").textContent = M.figuresSrc;
    X.$("#mo-caution").innerHTML = "<strong>Before you quote a number at someone.</strong> " + X.esc(M.caution);

    X.$("#sc-note").textContent = A.SCORECARD_NOTE;

    var E = A.EVIDENCE;
    X.$("#ev-head").textContent = E.head;
    X.$("#ev-body").textContent = E.body;
    X.$("#ev-against").innerHTML = "<strong>And the finding that runs the other way.</strong> " + X.esc(E.against);
    X.$("#ev-limits").textContent = E.limits;

    var O = A.OVERDOSE;
    X.$("#od-head").textContent = O.head;
    X.$("#od-body").textContent = O.body;
    X.$("#od-uneven").innerHTML = "<strong>" + X.esc(O.uneven) + "</strong>";
    X.$("#od-caveat").textContent = O.caveat;

    X.$("#ov-note").textContent = A.OVERSIGHT_NOTE;
    var ov = X.$("#ov-list"); ov.innerHTML = "";
    Object.keys(A.OVERSIGHT).forEach(function (st) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", X.stateName(st)));
      l.appendChild(X.el("div", "li-note", "Official settlement oversight or allocation page"));
      row.appendChild(l);
      var a = X.el("div"); a.innerHTML = X.a("Open ↗", A.OVERSIGHT[st], "btn btn-sm");
      row.appendChild(a);
      ov.appendChild(row);
    });

    var AC = A.ACT;
    X.$("#ac-head").textContent = AC.head;
    linkList("#ac-steps", AC.steps, "n", "t");
    X.$("#ac-close").innerHTML = "<strong>" + X.esc(AC.close) + "</strong>";

    X.$("#ac-mode").addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      X.$$("#ac-mode .chip").forEach(function (x) { x.classList.toggle("active", x === c); });
      mapMode = c.dataset.acmap;
      renderGrid();
    });
    X.$("#ac-grid").addEventListener("click", function (e) {
      var b = e.target.closest(".gm-cell"); if (!b) return;
      showState(b.dataset.st);
    });
  }

  function load() { X.profile().then(function (p) { prof = p; renderGrid(); }); }

  /* Heat here means "policy Clapback is flagging", not "bad place to live".
     The caption says so every time, in every mode. */
  function renderGrid() {
    var grid = X.$("#ac-grid"); if (!grid) return;
    var caption, legend;
    if (mapMode === "expansion") {
      caption = "Shaded where the state has NOT adopted the Affordable Care Act's Medicaid expansion as of August 2026. Medicaid is the largest single payer for substance use disorder treatment in the United States, which is why this is on this page. Wisconsin is shaded but flagged — it has not adopted the expansion, but covers adults to 100% of the poverty line by waiver, so it has no coverage gap.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> Has not adopted &nbsp; <span class="gm-swatch" style="--heat:0"></span> Adopted';
    } else if (mapMode === "dce") {
      caption = "Shaded by how far the state restricts drug checking equipment — fentanyl test strips and similar. Darkest where possession or distribution may still be charged as drug paraphernalia; mid where the exemption covers fentanyl strips only or distribution is restricted; unshaded where all forms are legal. 2024-vintage survey data — verify your own state's current statute.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> Still illegal &nbsp; <span class="gm-swatch" style="--heat:.55"></span> Partial or fentanyl-only &nbsp; <span class="gm-swatch" style="--heat:0"></span> Fully legal';
    } else {
      caption = "Shaded where no state statute authorises syringe services programs. Mid shading means permitted indirectly rather than expressly authorised. Note that programs operate in some unshaded-by-law states anyway — legality and availability are different questions.";
      legend = '<span class="gm-swatch" style="--heat:1"></span> No authorisation &nbsp; <span class="gm-swatch" style="--heat:.5"></span> Implicit only &nbsp; <span class="gm-swatch" style="--heat:0"></span> Expressly authorised';
    }
    X.$("#ac-caption").textContent = caption;
    X.$("#ac-legend").innerHTML = legend;

    grid.innerHTML = Object.keys(D.TILE_GRID || {}).map(function (code) {
      var pos = D.TILE_GRID[code];
      var law = U.STATE_LAW[code] || {};
      var heat = 0, badge = "", label = STATE_NAME[code] || code;
      if (mapMode === "expansion") {
        heat = A.NON_EXPANSION.indexOf(code) >= 0 ? 1 : 0;
        label += heat ? " — has not adopted Medicaid expansion" : " — adopted";
        if (code === "WI") badge = "*";
      } else if (mapMode === "dce") {
        heat = law.dce === "illegal" ? 1 : law.dce === "fentanyl" ? 0.55 : law.dce === "partial" ? 0.4 : 0;
        label += " — " + (U.DCE_LABEL[law.dce] || "not recorded");
      } else {
        heat = law.ssp === "none" ? 1 : law.ssp === "implicit" ? 0.5 : 0;
        label += " — " + (U.SSP_LABEL[law.ssp] || "not recorded");
      }
      var cls = "gm-cell" + (heat > 0.55 ? " hot" : "") + (code === prof.state ? " mine" : "");
      return '<button class="' + cls + '" data-st="' + code + '" style="grid-column:' + (pos[0] + 1) +
        ";grid-row:" + (pos[1] + 1) + ";--heat:" + heat.toFixed(2) + '" aria-label="' + X.esc(label) +
        '" title="' + X.esc(label) + '">' +
        '<span class="gm-abbr">' + code + "</span>" +
        (badge ? '<span class="gm-val">' + badge + "</span>" : "") +
        "</button>";
    }).join("");

    if (prof.state) showState(prof.state);
  }

  function showState(code) {
    var out = X.$("#ac-detail"); if (!out) return;
    var law = U.STATE_LAW[code] || {};
    var name = STATE_NAME[code] || code;
    var noExp = A.NON_EXPANSION.indexOf(code) >= 0;

    var html = '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(name) + '</div>' +
      '<span class="status-pill ' + (noExp ? "pill-amber" : "pill-ban") + '">' +
      (noExp ? "No Medicaid expansion" : "Medicaid expansion adopted") + '</span></div>';

    if (code === "WI") {
      html += '<div class="callout callout-info"><strong>Wisconsin is the edge case.</strong> It has not adopted the ACA expansion, but it covers adults to 100% of the federal poverty level through a waiver, so it has no coverage gap. Anyone putting it in a list with the other nine non-expansion states without saying this is overstating the case.</div>';
    }
    html += "<p><strong>Drug checking equipment:</strong> " + X.esc(U.DCE_LABEL[law.dce] || "not recorded") + "</p>" +
      "<p><strong>Syringe services programs:</strong> " + X.esc(U.SSP_LABEL[law.ssp] || "not recorded") + "</p>";

    if (A.OVERSIGHT[code]) {
      html += '<div class="btn-row">' + X.a("Official settlement page for " + X.esc(name) + " ↗", A.OVERSIGHT[code], "btn btn-sm") + "</div>";
    } else {
      html += '<p class="muted">Clapback did not verify an official settlement oversight page for this state. That does not mean there is none — start with your state attorney general’s site and the two trackers linked above.</p>';
    }
    var f = A.FINDINGS.filter(function (x) { return x.st === code; })[0];
    if (f) {
      html += '<div class="callout callout-warn"><strong>There is a documented finding for this state.</strong> ' +
        X.esc(f.head) + " — " + X.esc(f.amount) + ". See the findings section above, including how it is disputed.</div>";
    }
    html += "</div>";
    out.innerHTML = html;
  }

  X.bootstrap("account", mount);
})();

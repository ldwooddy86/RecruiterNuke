/*
 * Clapback — public accountability dataset  (window.CBA)
 *
 * THE RULE THIS FILE IS BUILT ON, and it is not decoration:
 * Nothing appears here unless it is an OFFICIAL ACT with a citation. A recorded
 * vote. An audited expenditure. A statute on the books. A settlement term.
 * No characterisations of anyone's motives, no personal life, no contact
 * details, no calls to action directed at an individual.
 *
 * That constraint is not squeamishness — it is what makes the thing work. A
 * sourced roll-call vote cannot be argued with. A joke can be waved away, and
 * an unsourced accusation hands the subject an easy win. So: every row below
 * carries the government URL it came from, journalism is labelled as
 * journalism, and where a widely repeated figure could not be traced to a
 * primary source it is marked rather than printed.
 *
 * Where a finding is disputed, the dispute is shown. The Arizona audit below
 * is a documentation finding that the audited agency contests, and the related
 * lawsuit was voluntarily dropped rather than decided — both facts are on the
 * card, because leaving either off would be the kind of thing this file exists
 * to avoid. An earlier draft said "dismissed"; that was wrong and the
 * correction is stated on the card rather than quietly made.
 *
 * Verified August 23, 2026.
 */
window.CBA = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  var CHARTER = {
    head: "What this page is, and what it refuses to be",
    body: "Every claim on this page is an official act — a recorded vote, an audited expenditure, a statute, a settlement term — and carries a link to the government record it came from. Where the source is journalism rather than government, it says so.",
    refuse: "What you will not find here: anyone's home, family, staff or personal life; characterisations of motive; unsourced accusations; or any suggestion about what to do to a particular person. Those things are not merely off-limits, they are counterproductive. A voting record is unanswerable. An insult is a gift to the person receiving it.",
    use: "The intended use is the boring one. Look up what your own representatives actually did, check whether your state spent the settlement money on treatment, and if the answer bothers you, say so at a public meeting or in a letter that cites the record."
  };

  /* ================================================================== */
  /* THE MONEY                                                           */
  /* ================================================================== */
  var SETTLEMENT = {
    head: "The opioid settlement money",
    body: "Litigation against opioid manufacturers, distributors and pharmacies produced settlements paying out to states and localities over roughly eighteen years. The distributors and Johnson & Johnson agreement is the largest single piece; the Purdue and Sackler settlement of $7.4 billion took effect on May 1, 2026, front-loaded into its first three years and requiring the public release of more than thirty million documents.",
    total: "$58.58 billion",
    totalNote: "Global total across all defendants as of April 2026 — and stated by its own compiler as a figure that WILL be $58.58 billion once one remaining settlement is finalised, so read it as near-final rather than closed. Compiled by OpioidSettlementTracker.com — an independent project run by attorney Christine Minhee, not a government source. The official per-state allocation figures are published by the settlement administrator, linked below.",
    totalUrl: "https://www.opioidsettlementtracker.com/globalsettlementtracker",
    officialUrl: "https://www.nationalopioidofficialsettlement.com/Home/StateAllocationAmounts",
    purdueUrl: "https://www.michigan.gov/ag/news/press-releases/2026/05/01/purdue-sackler-opioid-settlement-goes-into-effect",
    spend: {
      head: "Where it has actually gone",
      rows: [
        { k: "Received by states and localities in 2024", v: "$6.5B+" },
        { k: "Spent or committed", v: "$2.7B — about 41%" },
        { k: "Went to treatment", v: "$615M (23%)" },
        { k: "Went to harm reduction", v: "$491M (18%)" },
        { k: "Went to recovery services", v: "$450M (17%)" },
        { k: "Untrackable — no public documentation", v: "About 20%" }
      ],
      note: "In sixteen states, more than 30% of settlement spending had no public documentation at all. Roughly 9% of tracked spending went to prevention activities the researchers characterised as having questionable evidence behind them — community concerts, school speakers, mixed martial arts demonstrations.",
      src: "Johns Hopkins Bloomberg School of Public Health, National Settlement Fund Tracking Project (2024) — academic, not government",
      url: "https://opioidprinciples.jhsph.edu/2024-national-settlement-fund-tracking-project-what-we-learned/",
      earlier: "An earlier joint database covering 2022–2023 — KFF Health News with Johns Hopkins and Shatterproof — catalogued more than 7,000 individual expenditures against the $6 billion received in that period, found roughly a third of it had no public accounting, and identified more than $240 million spent on purposes outside the settlements' remediation terms.",
      earlierUrl: "https://kffhealthnews.org/public-health/opioid-settlement-funds-detailed-database-state-county-city-spending/"
    }
  };

  /* Documented findings. `status` distinguishes what has actually been
     established from what is contested — do not flatten these. */
  var FINDINGS = [
    {
      st: "AZ", where: "Arizona", amount: "$50.9 million",
      head: "State auditors could not verify a corrections-department spend",
      status: "contested",
      body: "The Arizona Auditor General's Single Audit Report, released May 13, 2026, found that the Department of Corrections, Rehabilitation and Reentry “spent $50.9 million of opioid settlement monies but lacks records supporting they were spent for approved purposes.” That the spending went to hepatitis C treatment for incarcerated people comes from the Attorney General's own settlement page, not from the audit — the audit does not use the term.",
      quote: "When Agreement monies are not spent as intended, less monies are available for uses that benefit the State and its residents, such as for approved opioid abatement strategies outlined in the Agreement.",
      quoteWho: "Arizona Auditor General",
      dispute: "State this precisely or not at all. The finding is a DOCUMENTATION deficiency, not an adjudicated finding of illegality. The department agreed to a corrective action plan by September 30, 2026 while maintaining the expenditure was appropriate — and its substantive defence belongs here too: it estimates at least 95% of the inmates treated contracted hepatitis C through intravenous opioid use. Separately, the Attorney General's 2024 suit over a larger legislative transfer did not fail on the merits. After a judge dissolved the order blocking the transfer, the Attorney General VOLUNTARILY DROPPED the case in June 2024, and the judge's stated reasoning went to whether an Attorney General can bind how the state spends money through a litigation settlement — not to the evidence. Anyone describing that as a court rejecting the claim is overstating it. So was Clapback, until this was corrected.",
      context: "Arizona received $1.14 billion in national settlements. Reporting by KJZZ, Arizona's public radio station, describes roughly $150 million redirected by the Legislature and Governor to the prison system, with a further $40 million proposed.",
      src: "The $50.9M finding: Arizona Auditor General, Single Audit Report (May 13, 2026) — official. The hepatitis C characterisation: Arizona Attorney General's One Arizona page — official. The legislative transfers and the dropped lawsuit: KJZZ — journalism, not government.",
      url: "https://npr.brightspotcdn.com/19/a2/9720c5c14c6db3a36a60fad4a869/single-audit-report-state-of-arizona-20260513.pdf",
      url2: "https://www.azag.gov/issues/opioids/one-arizona-agreement/state",
      url3: "https://www.kjzz.org/news/2024-06-28/mayes-drops-lawsuit-over-opioid-settlement-funds-in-arizona-budget"
    },
    {
      st: "NJ", where: "Irvington Township, New Jersey", amount: "$632,502.16",
      head: "A state comptroller itemised two “awareness” concerts",
      status: "established",
      body: "The New Jersey Office of the State Comptroller found in July 2025 that Irvington Township spent $632,502.16 in opioid settlement funds on two Opioid Awareness Day concerts. The itemisation is the part worth reading: $368,500 on entertainment and musical performances, $115,398 on billboard advertising, $53,525 on additional promotional materials, a separate $16,000 on mobile billboards featuring the Mayor, $34,445 on t-shirts, $29,161 on food vending equipment including popcorn and cotton candy machines, $12,648 on luxury VIP trailers for performers, and $11,000 on generators.",
      dispute: "The Comptroller also found the spending decisions were made in a single directors' meeting with no health experts consulted, and identified a conflict of interest: businesses owned by or connected to a township employee were hired through a non-public, non-competitive process that the same employee controlled, while he drew roughly $180,000 in salary across 2021–24.",
      src: "New Jersey Office of the State Comptroller (July 8, 2025) — official",
      url: "https://www.nj.gov/comptroller/reports/2025/approved/20250708.shtml"
    },
    {
      st: null, where: "Multiple states and towns", amount: "$61 million+",
      head: "Settlement money spent on law enforcement equipment",
      status: "journalism",
      body: "Reporting by KFF Health News, published November 2025, identified more than $61 million of 2024 settlement spending going to law-enforcement purposes. Among the itemised examples: about $12,000 in Alexandria, Indiana for rifle suppressors; about $21,000 in Mooresville, Indiana for Tasers; about $49,000 in Hardy County, West Virginia for body cameras and Tasers; about $70,000 in Lewisburg, West Virginia for a drug task force officer, guns, vehicles and car window tinting; more than $67,000 in Oak Hill, West Virginia for a drone and surveillance cameras; and about $15,000 in Clarkdale, Arizona for drones.",
      dispute: "Whether these purchases fall inside the settlements' abatement terms is genuinely arguable in some cases and plainly not in others — and the settlements themselves permit some law-enforcement-adjacent spending. Colorado, Indiana, California, Kansas and Virginia have issued guidance restricting equipment purchases with these funds.",
      src: "KFF Health News (November 3, 2025) — journalism, not government",
      url: "https://kffhealthnews.org/news/article/opioid-settlements-law-enforcement-spending-states-towns-guns-narcan/"
    }
  ];

  var TRANSPARENCY = {
    head: "Twelve states promised full transparency. Seven delivered.",
    body: "An analysis by KFF Health News with OpioidSettlementTracker.com tested twelve states that had made written commitments to report 100% of their settlement spending publicly. The test had three parts: are specific dollar amounts stated, can a member of the public actually find the report by searching for it, and are vendors and uses described. Seven of the twelve passed.",
    states: ["Arizona", "Colorado", "Delaware", "Idaho", "Massachusetts", "Minnesota", "Missouri", "New Hampshire", "New Jersey", "Oregon", "South Carolina", "Utah"],
    honest: "Clapback shows the twelve states that made the promise but NOT which seven passed. The breakdown is published inside a graphic rather than in text, and three separate attempts to read it produced conflicting assignments. Publishing a state in the wrong column would be exactly the sort of error this page exists to avoid, so the headline stands and the individual assignments do not. Read the article's graphic yourself if you need them.",
    src: "KFF Health News and OpioidSettlementTracker.com (November 2024) — journalism",
    url: "https://kffhealthnews.org/news/article/state-opioid-settlement-funds-transparency-update/",
    everything: "https://www.opioidsettlementtracker.com/everything",
    nashp: "https://nashp.org/state-tracker/state-opioid-settlement-spending-decisions/"
  };

  /* ================================================================== */
  /* THE VOTES — official roll calls only                                */
  /* ================================================================== */
  var VOTES = [
    {
      bill: "H.R. 1 (2025)", n: "The 2025 reconciliation law — Medicaid provisions",
      what: "A budget reconciliation package containing substantial changes to Medicaid, the largest single payer for substance use disorder treatment in the United States.",
      rows: [
        { ch: "Senate", date: "July 1, 2025", tally: "50–50, Vice President breaking the tie", u: "https://www.senate.gov/legislative/LIS/roll_call_votes/vote1191/vote_119_1_00372.htm" },
        { ch: "House", date: "July 3, 2025", tally: "218–214 (R 218–2, D 0–212)", u: "https://clerk.house.gov/Votes/2025190" }
      ],
      honest: "One vote, many subjects. This was an omnibus reconciliation bill and a member's vote cannot honestly be described as a vote specifically about addiction treatment. What it is: a recorded position on a package whose Medicaid provisions affect who can pay for that treatment.",
      billUrl: "https://www.congress.gov/bill/119th-congress/house-bill/1/actions"
    },
    {
      bill: "H.R. 2483", n: "SUPPORT for Patients and Communities Reauthorization Act of 2025",
      what: "Reauthorised the main federal addiction-response statute. Enables first responders to access and administer naloxone, expands treatment for pregnant and postpartum women, strengthens state prescription drug monitoring, and continues funding for Comprehensive Opioid Recovery Centers. Signed into law.",
      rows: [
        { ch: "House", date: "June 4, 2025", tally: "366–57 (R 188–27, D 178–30)", u: "https://clerk.house.gov/Votes/2025151" },
        { ch: "Senate", date: "September 18, 2025", tally: "Passed — no roll call recorded", u: "https://www.congress.gov/bill/119th-congress/house-bill/2483/all-actions" }
      ],
      honest: "The interesting thing here is not the passage — it is the delay. A near-identical reauthorisation passed the House 386–37 in December 2023 and then died in the Senate, leaving the underlying authorities lapsed for the better part of two years before this vehicle carried them through.",
      prior: "https://clerk.house.gov/Votes/2023715",
      billUrl: "https://www.congress.gov/bill/119th-congress/house-bill/2483/all-actions"
    },
    {
      bill: "H.R. 27 / S. 331", n: "HALT Fentanyl Act",
      what: "Made class-wide scheduling of fentanyl-related substances permanent.",
      rows: [
        { ch: "House", date: "February 6, 2025", tally: "312–108 (R 214–1, D 98–107)", u: "https://clerk.house.gov/Votes/202533" },
        { ch: "Senate", date: "March 14, 2025", tally: "84–16", u: "https://www.senate.gov/legislative/LIS/roll_call_votes/vote1191/vote_119_1_00127.htm" }
      ],
      honest: "This is the roll call worth actually reading, because it is the one where the party lines break. House Democrats split almost exactly down the middle, 98 to 107. Both sides of that split were arguing about the same evidence — whether class-wide scheduling reduces overdose deaths or mainly increases sentences. If you want to know what your own representative thinks about drug policy, this vote tells you more than any of the others.",
      billUrl: "https://www.congress.gov/bill/119th-congress/senate-bill/331"
    }
  ];


  /* ================================================================== */
  /* A NAMED MEMBER'S RECORD                                             */
  /*                                                                     */
  /* Publishing one person's voting record is the sharpest thing on this */
  /* page and the easiest to get wrong. Three rules govern this block:   */
  /*                                                                     */
  /*  1. Every vote is a Clerk roll call, verified individually. All 19  */
  /*     consumer-finance rows below were checked against clerk.house.gov*/
  /*     and every tally and party split matched exactly.                */
  /*  2. The counter-evidence ships WITH the votes, at the same weight,  */
  /*     in the same tab. Publishing the votes alone would be the exact  */
  /*     failure this file exists to prevent.                            */
  /*  3. No motive, no personal life, no family, no home. Official acts  */
  /*     and published constituent-service contact only.                 */
  /*                                                                     */
  /* One claim in the source material was false and is corrected below:  */
  /* Higgins is an original COSPONSOR of the flood insurance bill, not   */
  /* its lead sponsor. Rep. Frank Pallone introduced it. That error was  */
  /* in the counter-evidence, which is the worst place for one.          */
  /* ================================================================== */
  var MEMBER = {
    head: "One member's record, in full",
    who: "Rep. Clay Higgins",
    seat: "Republican, Louisiana's 3rd congressional district",
    covers: "115th through 119th Congress — January 2017 to August 2026",
    why: "Clapback publishes this one because Louisiana's 3rd district is where the debt-defense material in the Louisiana tab applies, and because the CFPB is the federal agency that would supervise the collectors described there. It is a demonstration of the method, not a statement about the person.",
    method: "Every row below is a recorded floor vote with a link to the Clerk of the House. Each was verified individually against the Clerk's own record; all tallies and party splits matched. Where a bill's official short title differs from its common name, both are given, because a citation that does not match the record is worse than no citation.",

    headline: {
      head: "What the record shows, in three parts",
      parts: [
        { n: "On consumer financial protection, the pattern is consistent", t: "Every CFPB-related roll call went against the agency's authority or funding. Every consumer-side bill drew a no vote or an absence. On four votes he went further than a large share of his own conference." },
        { n: "But “bought by corporate donors” is not supportable", t: "The entire identifiable consumer-finance donor footprint is roughly $18,000 to $24,000 across two cycles — about 1% of receipts. Zero from payday lenders. Zero from credit unions. He has never sat on the committee with jurisdiction, so the industry has little reason to invest. Realtors and homebuilders each gave more than the banking industry did." },
        { n: "And there is a real, narrow anti-corporate record", t: "He is an original cosponsor of a bipartisan flood insurance bill that caps insurer compensation and bans engineering-report manipulation, and he opened an Oversight investigation into CVS Health. Leaving these out would not make the case stronger — it would make it discreditable." }
      ],
      sharp: "The sentence the record actually supports: he votes against consumer financial protection with near-perfect consistency and occasional extra aggression, and nobody had to buy him to get it. That is harder to rebut than a corruption story, because the corruption story falls apart on inspection."
    },

    /* dev: true = broke from a meaningful share of his own party. Those are
       the votes that carry individual signal. The rest say more about the
       party than the person, and are labelled that way. */
    votes: [
      { dev: true, bill: "Perry Amdt. 18 to H.R. 4664", n: "Amendment cutting CFPB funding to zero", date: "Nov 8, 2023", roll: "626", yr: "2023",
        v: "AYE", tally: "Failed 140–286", split: "R 140–78, D 0–208. All 140 ayes were Republican — 78 Republicans voted no.",
        note: "The amendment reduced the bill's CFPB appropriation by $635,000,000, which was the entire amount appropriated. The Rules Committee and the Republican Cloakroom both summarised it as reducing CFPB funding to $0.",
        u: "https://clerk.house.gov/evs/2023/roll626.xml" },
      { dev: true, bill: "H.R. 4445", n: "Ending forced arbitration for sexual assault and harassment claims", date: "Feb 7, 2022", roll: "033", yr: "2022",
        v: "NAY", tally: "Passed 335–97", split: "R 113–97, D 222–0. A majority of voting Republicans supported it.",
        note: "The sharpest single item in the record. Not a party-line vote he can point to, and nothing to do with Louisiana's economy. Became law.",
        u: "https://clerk.house.gov/evs/2022/roll033.xml" },
      { dev: true, bill: "H.R. 5378", n: "Lower Costs, More Transparency Act — hospital price transparency and PBM reporting", date: "Dec 11, 2023", roll: "708", yr: "2023",
        v: "NAY", tally: "Passed 320–71", split: "R 166–40, D 154–31. Both parties split.",
        note: "Seven months earlier he had told a hearing that PBMs should “get your retirement in order.” The rhetoric and the roll call do not match, and that tension is his to explain rather than Clapback's to resolve.",
        u: "https://clerk.house.gov/evs/2023/roll708.xml" },
      { dev: true, bill: "H.R. 4544", n: "American Access to Banking Act — streamlining new bank and credit union charters", date: "May 20, 2026", roll: "178", yr: "2026",
        v: "NAY", tally: "Passed 405–4", split: "One of four no votes in the entire House.",
        note: "The other three were Biggs (R-AZ), Miller (R-IL) and Self (R-TX). The bill was sponsored by Rep. Maxine Waters (D-CA) and concerns de novo charter applications — caseworkers, mentorship, capital-raising review.",
        u: "https://clerk.house.gov/evs/2026/roll178.xml" },

      { bill: "H.J.Res. 111", n: "Congressional Review Act resolution killing the CFPB arbitration rule", date: "Jul 25, 2017", roll: "412", yr: "2017",
        v: "AYE", tally: "Passed 231–190", split: "R 231–1, D 0–189. Party-line.",
        note: "Became P.L. 115-74. Because it passed under the Congressional Review Act, the agency is permanently barred from issuing a substantially similar rule. This is the measure that would have let consumers bring class actions against financial companies instead of individual arbitration.",
        u: "https://clerk.house.gov/evs/2017/roll412.xml" },
      { bill: "H.R. 10", n: "Financial CHOICE Act — restructuring CFPB authority", date: "Jun 8, 2017", roll: "299", yr: "2017",
        v: "YEA", tally: "Passed 233–186", split: "R 233–1. Party-line. Died in the Senate.",
        u: "https://clerk.house.gov/evs/2017/roll299.xml" },
      { bill: "S.J.Res. 57", n: "CRA resolution on CFPB auto-lending discrimination guidance", date: "May 8, 2018", roll: "171", yr: "2018",
        v: "YEA", tally: "Passed 234–175", split: "R 223–1, D 11–174.", note: "Enacted as P.L. 115-172.",
        u: "https://clerk.house.gov/evs/2018/roll171.xml" },
      { bill: "S.J.Res. 15", n: "Repealing the OCC “true lender” rule", date: "Jun 24, 2021", roll: "181", yr: "2021",
        v: "NAY", tally: "Passed 218–208", split: "R 1–208, D 217–0. Party-line — not a deviation.",
        note: "A no vote here was a vote to KEEP the rule. The true lender rule is the mechanism that lets high-rate nonbank lenders route triple-digit interest through out-of-state bank charters to preempt state rate caps.",
        u: "https://clerk.house.gov/evs/2021/roll181.xml" },
      { bill: "H.R. 3299", n: "Protecting Consumers' Access to Credit Act — the “Madden fix”", date: "Feb 14, 2018", roll: "078", yr: "2018",
        v: "YEA", tally: "Passed 245–171", split: "R 229–1, D 16–170. Died in the Senate.",
        note: "The statutory foundation for the same rent-a-bank structure.",
        u: "https://clerk.house.gov/evs/2018/roll078.xml" },
      { bill: "H.R. 2547", n: "Comprehensive Debt Collection Improvement Act", date: "May 13, 2021", roll: "141", yr: "2021",
        v: "NAY", tally: "Passed 215–207", split: "R 0–206. Party-line.",
        note: "Would have barred collecting time-barred debt, created a medical debt grace period, and indexed FDCPA damages to inflation. The most directly relevant bill in this list to anyone reading the Louisiana tab.",
        u: "https://clerk.house.gov/evs/2021/roll141.xml" },
      { bill: "H.R. 1500", n: "Consumers First Act", date: "May 22, 2019", roll: "228", yr: "2019",
        v: "NO", tally: "Passed 231–191", split: "R 0–191. Party-line.",
        u: "https://clerk.house.gov/evs/2019/roll228.xml" },
      { bill: "S.J.Res. 32", n: "CRA resolution killing the CFPB small business lending rule", date: "Dec 1, 2023", roll: "690", yr: "2023",
        v: "YEA", tally: "Passed 221–202", split: "R 215–0. Vetoed.",
        u: "https://clerk.house.gov/evs/2023/roll690.xml" },
      { bill: "S.J.Res. 18", n: "CRA resolution killing the CFPB overdraft fee cap", date: "Apr 9, 2025", roll: "096", yr: "2025",
        v: "YEA", tally: "Passed 217–211", split: "R 217–1. Signed into law.",
        u: "https://clerk.house.gov/evs/2025/roll096.xml" },
      { bill: "S.J.Res. 28", n: "CRA resolution ending CFPB supervision of big-tech payment apps", date: "Apr 9, 2025", roll: "095", yr: "2025",
        v: "YEA", tally: "Passed 219–211", split: "R 219–0. Signed into law.",
        u: "https://clerk.house.gov/evs/2025/roll095.xml" },
      { bill: "H.R. 1", n: "Motion to concur in the Senate amendment — the 2025 reconciliation law", date: "Jul 3, 2025", roll: "190", yr: "2025",
        v: "AYE", tally: "Passed 218–214", split: "R 218–2, D 0–212.",
        note: "The question was concurrence in the Senate amendment, not original passage. Among much else, the law cut the CFPB's funding cap from 12% to 6.5% of Federal Reserve operating expenses.",
        u: "https://clerk.house.gov/evs/2025/roll190.xml" },
      { bill: "H.R. 1423", n: "FAIR Act — ending forced arbitration generally", date: "Sep 20, 2019", roll: "540", yr: "2019",
        v: "NO", tally: "Passed 225–186", split: "R 2–183. Party-line.",
        u: "https://clerk.house.gov/evs/2019/roll540.xml" },
      { bill: "H.R. 963", n: "FAIR Act of 2022", date: "Mar 17, 2022", roll: "081", yr: "2022",
        v: "NAY", tally: "Passed 222–209", split: "R 1–209. Party-line.",
        u: "https://clerk.house.gov/evs/2022/roll081.xml" },
      { bill: "H.R. 3621", n: "Comprehensive CREDIT Act — FCRA overhaul including medical debt reporting limits", date: "Jan 29, 2020", roll: "031", yr: "2020",
        v: "NOT VOTING", tally: "Passed 221–189", split: "Every voting Republican opposed. The absence did not change the outcome.",
        note: "The Clerk's record carries the bill's original title, “Student Borrower Credit Improvement Act.” As passed it was the Comprehensive CREDIT Act of 2020. The citation will look like a mismatch and is not one.",
        u: "https://clerk.house.gov/evs/2020/roll031.xml" },
      { bill: "S. 2155", n: "Dodd-Frank rollback raising the systemic-risk threshold", date: "May 22, 2018", roll: "216", yr: "2018",
        v: "NOT VOTING", tally: "Passed 258–159", split: "R 225–1.",
        note: "He was absent for every vote that day. Ordinary absence, not a deliberate abstention — Clapback flags this because an absence read as a statement would be unfair.",
        u: "https://clerk.house.gov/evs/2018/roll216.xml" }
    ],

    never: {
      head: "What the record does not contain",
      rows: [
        { k: "Committee jurisdiction", v: "None. He has never served on House Financial Services — nor Ways and Means, Energy and Commerce, or Judiciary. Every vote above is a floor vote. Verified across all five Congresses." },
        { k: "Sponsored legislation in consumer finance", v: "None found." },
        { k: "Public explanation", v: "No press release, floor statement or interview found on the CFPB, arbitration, payday lending, credit reporting or debt collection. The four deviating votes are unexplained on the public record." }
      ],
      committees: "119th Congress: Armed Services (Readiness; Seapower and Projection Forces), Oversight and Government Reform — where he chairs the Federal Law Enforcement Subcommittee — and the Select Subcommittee on January 6. He withdrew from Homeland Security in August 2025 after nine years."
    },

    money: {
      head: "Follow the money — and then stop following it",
      body: "This is where a “bought and paid for” argument dies, and leading with it hands the other side an easy win.",
      rows: [
        { k: "Payday and consumer lenders", v: "$0" },
        { k: "Credit unions", v: "$0" },
        { k: "American Bankers Association BankPAC", v: "$16,000" },
        { k: "Regions Financial Corp PAC", v: "$2,000" },
        { k: "For comparison — National Association of Realtors", v: "$15,000" },
        { k: "For comparison — Home Builders", v: "$9,000" }
      ],
      note: "Roughly $18,000 to $24,000 in identifiable consumer-finance PAC money across two cycles, about 1% of receipts. What he actually raises is district-economy money: energy and petrochemical, sugar, rice, maritime, and Lafayette-based healthcare. LA-03 contains the Sabine Pass and Calcasieu Pass LNG terminals, the Lake Charles petrochemical corridor, and the state's sugarcane and rice belt.",
      kill: "He raised about $998,000 in 2023–24 against a median House incumbent's $2.1 million, in a district he won by roughly 44 points with no primary opponent. Donor money is not buying anything here, because he does not need it to win and does not sit on the committees that would make him worth buying. Anyone arguing the financial industry bankrolled him gets refuted by the FEC filings in about ten minutes.",
      leadership: "The one money story that does land is his leadership PAC. In 2025–26 it spent 90.7% on operating expenses and 1.5% — $2,000 — on candidates. Its year-end 2025 filing shows $19,277 to a Washington Mardi Gras krewe and $14,563 to Hilton hotels. More went to the krewe than to every candidate combined. None of it is illegal; it is simply the clearest available answer to what the money actually does.",
      caution: "Clapback carries these figures with a flag: they were rebuilt from raw FEC filings covering 2023–2026 only, because OpenSecrets was inaccessible during the research. Career industry rankings and donors coded by employer are missing, which probably understates energy-linked money. Do not publish a “compared to the average member” claim off this data.",
      fecUrl: "https://www.fec.gov/data/candidate/H6LA03148/",
      pacUrl: "https://www.fec.gov/data/committee/C00652305/"
    },

    counter: {
      head: "The counter-evidence — and why it is here",
      why: "Every item below is real, sourced, and cuts against the pattern above. Clapback publishes them in the same tab at the same weight, because an argument built only on the votes is one a fact-checker dismantles in an afternoon — and because a reader is entitled to the parts that complicate the picture.",
      items: [
        { n: "He is an original cosponsor of a genuinely anti-insurer bill", correction: true,
          t: "H.R. 5484, the National Flood Insurance Program Reauthorization and Reform Act of 2025, introduced September 18, 2025. Section 302 caps compensation paid to private “Write Your Own” insurers and redirects the savings to means-tested assistance. Section 409 prohibits manipulation of engineering reports — a direct response to the post-Sandy scandal where insurers doctored reports to deny claims. Section 102 caps annual premium increases at 9%. Endorsed by the American Policyholders Association, the National League of Cities and the U.S. Conference of Mayors.",
          fix: "The correction: the bill was introduced by Rep. Frank Pallone (D-NJ), with Higgins as an original cosponsor — the text reads “Mr. Pallone (for himself and Mr. Higgins of Louisiana).” The source material Clapback worked from called Higgins the lead sponsor. That was backwards, and it is exactly the kind of error a hostile reader uses to discredit everything around it.",
          u: "https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr5484.xml" },
        { n: "He opened an investigation into CVS Health",
          t: "September 4, 2025, as chairman of the Oversight Subcommittee on Federal Law Enforcement, co-signed with Chairman Comer. The demand concerns CVS allegedly using confidential patient data to mass-text Louisiana pharmacy customers urging them to lobby against a state PBM reform bill. It seeks all CVS documents on patient-data use, in every state, from January 1, 2020 forward.",
          u: "https://oversight.house.gov/release/comer-and-higgins-investigate-cvs-healths-use-of-confidential-patient-information-to-lobby-louisiana-state-legislature/" },
        { n: "He said it out loud, in a hearing",
          t: "“You PBMs out there, hey, get your retirement in order because the end of your era of pushing Americans around like this is closing.” House Oversight, May 23, 2023. Verified verbatim in the published transcript. Seven months later he voted against the main bipartisan PBM transparency bill, with 40 of 206 Republicans.",
          u: "https://www.govinfo.gov/content/pkg/CHRG-118hhrg52570/html/CHRG-118hhrg52570.htm" },
        { n: "He voted for the Fourth Amendment Is Not For Sale Act",
          t: "April 17, 2024, roll call 136, passed 219–199 with Republicans splitting 123–90. A data-broker measure, and a vote against his own leadership and the Intelligence Committee.",
          u: "https://clerk.house.gov/evs/2024/roll136.xml" },
        { n: "He sponsored a bipartisan seafood import bill",
          t: "H.R. 2715, the Destruction of Hazardous Imports Act, passed the House by voice vote on July 20, 2026 after a 43–0 committee vote. Higgins is the sponsor; Rep. Troy Carter (D-LA) is the lead Democratic cosponsor. Sustained protectionism against free-trade orthodoxy.",
          u: "https://www.govinfo.gov/bulkdata/BILLSTATUS/119/hr/BILLSTATUS-119hr2715.xml" }
      ],
      direction: "One qualification that matters. Most of his other breaks from party are breaks from the RIGHT — against spending deals, against omnibus bills — not from a populist anti-corporate position. Anyone claiming he is an anti-corporate maverick runs into a 96th-percentile conservatism ranking.",
      other: "Also on the record and pointing the other way: he accepted and publicised the U.S. Chamber of Commerce's Spirit of Enterprise Award; he sponsored a bill giving insurers five years of federal tax deductions with no affordability guarantee for consumers; he voted against seven days of paid sick leave for rail workers in November 2022; and in November 2025 he was the sole no vote, 427–1, on releasing the Epstein files."
    },

    scorecards: {
      head: "On advocacy scorecards — mostly useless here",
      body: "Most scorecards measure party, not person, and quoting the wrong one weakens an argument rather than strengthening it. His AFL-CIO lifetime score of 8% sounds damning until you learn the House Republican average is 1% — his is above the norm. His ProgressivePunch score is mid-pack among Republicans, not extreme.",
      useful: "Three do differentiate: the Lugar Center Bipartisan Index ranked him 372nd of 435 in the 118th; the National Taxpayers Union scored him 91% against a House Republican average of 86%; and GovTrack's ideology measure moved him from the 57th to the 92nd percentile among House Republicans between 2022 and 2024.",
      sample: "And check the sample size before quoting any of them. Heritage Action's 119th Congress score rests on 20 items, NFIB's on 9, Club for Growth's on 19 — against roughly 1,241 recorded House votes in a year. A “100%” is 20 for 20, not a comprehensive record. Cite the roll calls, not the grades."
    },

    gaps: {
      head: "What Clapback could not verify",
      rows: [
        "OpenSecrets was inaccessible during the underlying research, so the donor picture covers 2023–2026 only and is rebuilt from raw FEC filings.",
        "His DW-NOMINATE score was not retrieved — the most methodologically rigorous ideology measure available, and it is missing here.",
        "His full cosponsorship list is unverified, so a PBM or antitrust cosponsorship could exist that this missed.",
        "The self-reported constituent-casework figure from his annual report has no independent verification.",
        "2025–26 financial figures are partial: campaign through July 18, 2026, committees through June 30, 2026."
      ]
    },

    contact: {
      head: "How to reach your own representative",
      body: "These are the published constituent-service numbers from his official House site. Contacting your representative about legislation is the ordinary civic use of this page — and a letter that cites a roll call number goes in a different pile from one that does not.",
      rows: [
        { k: "Washington", v: "(202) 225-2031" },
        { k: "Lafayette", v: "(337) 703-6105" },
        { k: "Lake Charles", v: "(337) 656-2833" }
      ],
      u: "https://clayhiggins.house.gov/contact/",
      note: "If Louisiana's 3rd district is not yours, use the official lookup above to find who actually represents you. That is the only version of this that is any use to you."
    }
  };

  var LOOKUP = {
    head: "Look up your own representatives",
    body: "The point of the votes above is not the national tally. It is finding out what the person who represents you did. These are the official government tools — Clapback links them and never queries them.",
    links: [
      { n: "Find your Representative", t: "Official House lookup by ZIP code, with a link to the member's own site.", u: "https://www.house.gov/representatives/find-your-representative" },
      { n: "Your Senators", t: "Official Senate contact directory, by state.", u: "https://www.senate.gov/senators/senators-contact.htm" },
      { n: "Find your member on Congress.gov", t: "Sponsored and cosponsored legislation, committee assignments, full profile.", u: "https://www.congress.gov/members/find-your-member" },
      { n: "House roll call votes by year", t: "Every recorded House vote, official Clerk of the House.", u: "https://clerk.house.gov/evs/2025/index.asp" },
      { n: "Senate roll call votes", t: "Every recorded Senate vote, official.", u: "https://www.senate.gov/legislative/votes_new.htm" }
    ],
    honest: "One genuine limitation. Congress.gov organises member pages around legislation they sponsored, not around every vote they cast — there is no official “here is this member's complete voting record” page. To reconstruct one you need the roll-call lists above, or a non-governmental aggregator such as GovTrack. Clapback flags that rather than pretending the official tools do something they do not."
  };

  var MONEY = {
    head: "Industry money is public. Here is where it actually lives.",
    body: "Campaign contributions are filed with the Federal Election Commission and lobbying spending is filed with the Senate under the Lobbying Disclosure Act. Both are searchable by anyone, for free, and both are the actual system of record — aggregator sites are compiled FROM these filings.",
    links: [
      { n: "FEC — individual contributions", t: "Searchable by contributor employer and occupation, which is how contributions get attributed to an industry. The primary source.", u: "https://www.fec.gov/data/receipts/individual-contributions/" },
      { n: "FEC — browse all data", t: "Candidates, committees, spending.", u: "https://www.fec.gov/data/browse-data/" },
      { n: "Senate Lobbying Disclosure Act database", t: "Every registered lobbying filing. The statutory source for all lobbying totals you see quoted anywhere.", u: "https://lda.gov/system/public/" },
      { n: "OpenSecrets — pharmaceuticals & health products", t: "A non-governmental aggregator that compiles FEC and LDA filings into an industry view. Useful, but a secondary source.", u: "https://www.opensecrets.org/industries/summary?ind=H04" }
    ],
    figures: "Pharmaceutical and health products lobbying ran $121.4 million in the first quarter of 2025 and $105.4 million in the second — $226.8 million across the half year, about $22 million more than the same period in 2024, In the second quarter alone it outspent the next largest sector, electronics, by roughly 38%. That 38% is a quarterly comparison, not a half-year one; Clapback had it attached to the wrong figure until this was corrected.",
    figuresSrc: "OpenSecrets analysis of Senate Lobbying Disclosure Act filings — aggregator, not government",
    caution: "A methodological warning that matters if you are about to quote a number at someone. OpenSecrets' “Pharmaceuticals/Health Products” category is broad: it includes health insurers and device makers alongside drug manufacturers. If you say “pharma gave Senator X this much,” the figure probably includes UnitedHealth and AHIP. Either use the category's full name, or drill into specific manufacturer PACs in the FEC data — where the attribution is exact and nobody can argue with it."
  };

  /* ================================================================== */
  /* STATE POLICY SCORECARD — statute and status, not opinion            */
  /* ================================================================== */
  var NON_EXPANSION = ["AL", "FL", "GA", "KS", "MS", "SC", "TN", "TX", "WI", "WY"];
  var EXPANSION_NOTE = "Ten states have not adopted the Affordable Care Act's Medicaid expansion as of August 2026. Wisconsin is a genuine edge case and is flagged separately wherever it appears: it has not adopted the expansion, but it covers adults to 100% of the federal poverty level through a waiver, so it has no coverage gap. Treating it identically to the other nine would be misleading.";
  var EXPANSION_SRC = "KFF, Status of State Medicaid Expansion Decisions (updated August 21, 2026)";
  var EXPANSION_URL = "https://www.kff.org/medicaid/status-of-state-medicaid-expansion-decisions/";

  var EVIDENCE = {
    head: "Does Medicaid expansion change overdose deaths? Carefully.",
    body: "A study in JAMA Network Open examined 3,109 counties across 49 states and DC from 2001 to 2017. It found Medicaid expansion associated with 6% lower total opioid overdose mortality, 11% lower heroin deaths, and 10% lower deaths involving synthetic opioids other than methadone.",
    against: "And the finding that runs the other way, which Clapback includes because omitting it would be exactly the cherry-picking this page is supposed to avoid: the same study found methadone-related deaths 11% HIGHER in expansion states.",
    limits: "Three limits worth stating before anyone quotes this at a hearing. It establishes association, not causation — the authors' own title says so. The data ends in 2017, before the worst of the illicitly-manufactured fentanyl wave, so it cannot tell you what expansion does under current conditions. And the intervals are Bayesian credible intervals rather than confidence intervals.",
    src: "Kravitz-Wirtz, Davis, Ponicki, Rivera-Aguirre, Marshall, Martins & Cerdá, JAMA Network Open (2020)",
    url: "https://pubmed.ncbi.nlm.nih.gov/31922561/"
  };

  var OVERDOSE = {
    head: "The overdose picture right now",
    body: "An estimated 69,973 people died of drug overdose in the United States in 2025 — down about 14% from 81,313 in 2024, and the third consecutive annual decline. Opioid-involved deaths fell from roughly 55,296 to 44,564.",
    uneven: "The decline is not uniform, and the unevenness is the story. Rhode Island, New York, North Carolina, Alabama and Vermont each fell more than 25%. New Mexico, Arizona and Colorado each rose more than 10%.",
    caveat: "2025 figures are provisional and subject to revision. The 2024 final figure of 79,384 deaths — an age-adjusted rate of 23.1 per 100,000 — differs from the provisional 81,313 for exactly that reason. That final figure comes from NCHS Data Brief No. 549, published January 2026, not from the May 2026 provisional release the rest of this card cites.",
    src: "CDC NCHS — provisional 2025 release (May 13, 2026); final 2024 figures from NCHS Data Brief No. 549 (January 2026)",
    finalUrl: "https://www.cdc.gov/nchs/products/databriefs/db549.htm",
    url: "https://www.cdc.gov/nchs/pressroom/releases/20260513.html",
    stateUrl: "https://www.cdc.gov/nchs/state-stats/deaths/drug-overdose.html"
  };

  var SCORECARD_NOTE = "This scorecard combines four things a state government controls: whether it adopted Medicaid expansion, whether drug checking equipment is legal, whether syringe services programs are authorised by statute, and whether it has a public opioid settlement oversight body. Each is a policy choice on the record. None of them is a judgement about the people who live there.";

  var OVERSIGHT = {
    AZ: "https://www.azag.gov/issues/opioids/one-arizona-agreement/state",
    MN: "https://www.ag.state.mn.us/opioids/SettlementAllocation.asp",
    MS: "https://attorneygenerallynnfitch.com/opioid-settlement-fund-advisory-council/",
    NY: "https://ag.ny.gov/nys-opioid-settlement",
    RI: "https://eohhs.ri.gov/Opioid-Settlement-Advisory-Committee",
    VT: "https://www.healthvermont.gov/alcohol-drugs/public-meetings-comments/opioid-settlement-advisory-committee",
    WI: "https://www.dhs.wisconsin.gov/opioids/settlement-funds.htm"
  };
  var OVERSIGHT_NOTE = "Clapback lists only the state oversight bodies whose official pages it verified directly. Many more exist — this is not a complete roster, and the absence of a state here means Clapback did not verify one, not that none exists. Two catalogues that attempt completeness are linked below.";

  var ACT = {
    head: "If this bothers you, the useful thing to do is dull",
    steps: [
      { n: "Find out what your own state did with its share", t: "Start with your state attorney general's opioid settlement page and your state's oversight council if it has one. Most publish meeting minutes. Most meetings are open, and most are close to empty." },
      { n: "Read the roll call, not the press release", t: "The Clerk of the House and the Senate publish every recorded vote. A member's actual vote is frequently different from the position described in their own newsletter." },
      { n: "Write with the citation in it", t: "A letter that says “on July 3, 2025 you voted for H.R. 1, House roll call 190” is a different object from a letter that says you are disappointed. The first goes in a file. The second goes in a bin." },
      { n: "Show up to the settlement council meeting", t: "This is the single highest-leverage thing on this list and almost nobody does it. These bodies allocate real money, meet publicly, and often take public comment from whoever turns up." },
      { n: "Use the transparency you are owed", t: "If your state promised public reporting and you cannot find it, that is itself the story. State public records laws apply to settlement spending." }
    ],
    close: "None of that is satisfying in the way a good insult is satisfying. It is, however, the version that changes an appropriation."
  };

  return {
    UPDATED: UPDATED, CHARTER: CHARTER,
    SETTLEMENT: SETTLEMENT, FINDINGS: FINDINGS, TRANSPARENCY: TRANSPARENCY,
    VOTES: VOTES, MEMBER: MEMBER, LOOKUP: LOOKUP, MONEY: MONEY,
    NON_EXPANSION: NON_EXPANSION, EXPANSION_NOTE: EXPANSION_NOTE,
    EXPANSION_SRC: EXPANSION_SRC, EXPANSION_URL: EXPANSION_URL,
    EVIDENCE: EVIDENCE, OVERDOSE: OVERDOSE,
    SCORECARD_NOTE: SCORECARD_NOTE, OVERSIGHT: OVERSIGHT, OVERSIGHT_NOTE: OVERSIGHT_NOTE,
    ACT: ACT
  };
})();

# Clapback — v4.3.0

> **Installing:** unzip this archive into a folder, then in Chrome go to `chrome://extensions`, turn on **Developer mode** (top right), click **Load unpacked**, and select the folder you extracted into — the one that has `manifest.json` sitting directly inside it. If Chrome says "Manifest file is missing or unreadable," you have almost certainly selected a folder one level too high; go one level down, or up, until you see `manifest.json` in the folder you are picking.

*(Formerly “Lemmy,” before that “Extremely Professional,” originally “Personal Data Shield.” Same kit, same charter — new name and new logo. Old backups import fine.)*

A free Chrome extension: **your personal-data self-defense kit.** It takes the most capable parts of a data-broker toolkit and points them at *defending you* — finding and removing your own exposure, cleaning up your own social media, spotting scams that come at you, and responding safely if someone is harassing you.

It is built around one rule:

**It only ever works on *your* data, *your* accounts, and things that contacted *you*.** It does **not** look up, profile, or investigate other people from a name, phone number, or email, and it can never touch anyone else's account — that's the toolkit a stalker or scammer uses, and it's exactly what this is built to defend against. Everything runs locally on your own computer; the extension itself **makes no network requests**. The external checks and removals it suggests are ordinary links and buttons *you* choose to use.

---

## What's new in 2.0

- **📱 Social & footprint** — bulk-clean your *own* accounts across **9 platforms** (X, Facebook, Instagram, TikTok, Snapchat, Reddit, LinkedIn, YouTube, Google). A guided control-center for every platform, plus optional one-click cleanup that automates the account you're already signed into.
- **🔐 Harden & monitor** — a live **protection score**, a breach-response checklist, proactive account-security steps (passkeys, 2FA, SIM-lock), free monitoring set-up, and optional **recheck reminders** that notify you when broker opt-outs are due to be redone.
- **🧭 Guided help** — step-by-step **playbooks**: first-time lockdown, "I was just scammed," moving house, leaving a relationship, and "I got a breach notice." Each routes you to the right tool at each step.
- **🗂️ Far more data** — **110+** brokers and people-search sites (up from ~60), including risk/insurance & tenant-screening bureaus, ad-tech identity graphs, and international/EU brokers. Eight removal-letter templates now include **GDPR erasure**, a regulator **escalation** letter, a **credit-freeze** request, and an urgent **child-removal** letter.
- **♿ Full accessibility** — light / dark / high-contrast / system themes, adjustable text size, a dyslexia-friendly font option, reduced-motion, always-underline-links, a skip link, full keyboard navigation (arrow keys in the sidebar), visible focus states, ARIA labelling, and live regions.
- **🛰️ Smarter scam vetting** — brand-impersonation detection now catches digit/character swaps like `paypa1-secure.com` and `amaz0n-login.net`.

---

## What it does

Six tools, plus a profile and settings that tie them together.

### 🔎 Audit my exposure
Turns a map of **110+ data brokers and people-search sites** on *you*, so you can see where your home address, phone, email, relatives, and old resumes are published — and remove them.

- People-search sites first (Spokeo, BeenVerified, Whitepages, Radaris, FastPeopleSearch, FamilyTreeNow, and more) — the first place anyone looks when they have your name.
- Contact/profile databases that resell scraped cell numbers and emails (ZoomInfo, Apollo, Lusha, RocketReach…).
- Identity & income data holders (LexisNexis, Equifax's Work Number), **risk/insurance & tenant-screening bureaus** (C.L.U.E., Verisk, MIB, TeleCheck, tenant screening), specialty bureaus, **ad-tech identity graphs** (LiveRamp, plus the DAA/NAI one-click bulk opt-outs), marketing brokers, **international/EU brokers**, and old job-board resumes.
- Every entry has a direct removal link. Check items off — the kit **stamps the date** and flags them for a **recheck after 6 months**, because broker records commonly reappear.
- **Copy-ready removal letters** that fill in your name, state, and email: standard deletion/opt-out, an *urgent safety removal* version, FCRA correction and file-request letters, a **GDPR Article 17 erasure** letter, a **second-request/escalation** letter, a **credit-freeze** request, and an urgent **child-removal** letter.
- California residents get the state's one-request **DROP** platform, which forces every registered broker (500+) to delete your data.

### 📱 Social & footprint
Your own accounts are your biggest public footprint. This module helps you shrink it — on **your accounts only**.

- **Guided control-center** for all nine platforms: privacy-hardening deep links, each site's own bulk-management tools, data-export links, account-deletion links, and vetted third-party cleaners (Redact, TweetDelete, Power Delete Suite).
- **Optional one-click cleanup.** A browser extension can't (and this one won't) log into your accounts or ask for your passwords. When you click **Launch cleanup**, it opens the site *where you're already signed in* and adds a small on-page panel that clicks the site's own delete buttons for you — with a **Preview-first count**, a **limit you set**, human-like pacing, a **Stop** button, and a nudge to **download your data first** (deletions are permanent).
  - **X (Twitter):** delete your posts, undo reposts, remove your likes.
  - **Reddit:** delete your comments (with a pointer to overwrite-then-delete tools for archive resistance).
  - **Facebook / Instagram / TikTok:** an *assisted* mode that opens each platform's own multi-select bulk tool, which is safer and faster than scripted clicking.
- The panel lives in an isolated Shadow DOM, stays completely dormant until you launch it, and only ever acts on the account you're signed into.

### 🛰️ Vet a contact
Got a call, text, email, or link and something feels off? Paste it in. Entirely on your device, it checks it against known scam and spoofing patterns and tells you what to watch for.

- **Emails:** look-alike / typosquat domains (`paypa1.com`, `arnazon.com`), digit/character swaps (`micros0ft-support.com`), brand names bolted onto the wrong domain, a "bank" writing from Gmail, punycode tricks, risky TLDs.
- **Phone numbers:** "neighbor spoofing," your own number spoofed back at you, premium-rate and invalid numbers.
- **Links:** the `@`-in-the-URL disguise, raw-IP and punycode hosts, buried subdomains, shorteners, non-HTTPS login pages, brand look-alikes.
- **Messages:** the manipulation tactics scammers stack — urgency, gift-card/crypto/wire demands, requests for passwords or codes, prize bait, authority impersonation.
- Each result gives a plain-English risk read, the specific signals, what to do, and links to authoritative **free** checks (Have I Been Pwned, Google Safe Browsing, ICANN WHOIS) or reporting (FTC, FBI IC3, IdentityTheft.gov). It never tells you *who* is behind something.

### 🔐 Harden & monitor
Lock your accounts down so a leak can't cascade, and know what to do the moment something is breached.

- A live **protection score** (0–100) built from your broker removals, footprint lockdown, account-security steps, and profile setup.
- Free **monitoring** set-up: Have I Been Pwned notifications, Google "Results about you," Google Alerts on your name, credit freezes, and free weekly credit reports.
- **Recheck reminders** — turn them on and the extension notifies you (locally) when broker opt-outs you've completed are due to be redone.
- A **breach-response checklist** for the moment a company loses your data, and **proactive account-security** steps: password manager, passkeys, 2FA that survives SIM-swaps, carrier port-out PIN, and recovery-option hardening.

### 🛡️ Respond to harassment
A calm, five-step playbook for when someone is targeting you — built around getting you safe and supported, **not** confronting or unmasking the person yourself (which can escalate the danger): **Document** (a private, exportable incident log), **Report** (per-platform), **Lock down** (harden your footprint), **Escalate** (police, protective orders, IC3, StopNCII), and **Support** (the National Domestic Violence Hotline, SPARC, NNEDV Safety Net, CCRI).

### 🧭 Guided help
Not sure where to start, or something just happened? Pick a walkthrough — first-time lockdown, "I was just scammed," moving / new address, leaving a relationship (tech-safety reset), or "I got a breach notice." Each gives you a short, ordered checklist and sends you to exactly the right tool at each step.

### On-page helper (optional)
While you browse, the extension can quietly (a) offer a one-click removal link when you land on a known people-search site, and (b) warn you if a page is asking for a password while its address shows strong phishing signs. It only *reads* the page address locally — it never fills, submits, or sends anything, and you can switch it off in the toolbar or in Settings.

### ⚙️ Settings & accessibility
Color theme (light / dark / high-contrast / system), text size, dyslexia-friendly font, reduced motion, always-underline links, and the on-page-helper toggle. Everything is saved on this device.

---

## Install it (about 60 seconds)

This loads as an "unpacked" extension — normal for a tool shared directly rather than through the Web Store.

1. **Unzip** `lemmy.zip`. You'll get a folder called `lemmy` (it must contain `manifest.json`).
2. Open Chrome and go to **`chrome://extensions`** (copy-paste that into the address bar).
   - Microsoft Edge: `edge://extensions`. Brave: `brave://extensions`. Steps are identical.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the **`lemmy` folder**.
5. The shield icon appears in your toolbar — click the puzzle-piece icon and **pin** it.

The command center opens automatically the first time. Click the toolbar icon anytime to reopen it.

> Keep the folder somewhere permanent (not a temp/Downloads folder). If you move or delete it, Chrome disables the extension.

---

## Permissions — and why

The extension asks for the minimum it needs, and every permission is used locally:

- **storage** — saves your profile, checklists, and settings on your device.
- **alarms** — the daily local timer behind recheck reminders (off unless you enable it).
- **notifications** — shows the recheck reminder itself.
- **Access to social sites** (x.com, twitter.com, facebook.com, instagram.com, tiktok.com, reddit.com) — lets the optional cleanup panel appear *on your own account pages* when you launch it. The panel is dormant until then. There is **no** access to your passwords and **no** server — it clicks the same buttons you would.

The extension makes **no network requests of its own** on any of these sites. It never reads or transmits page contents; the social cleanup only clicks the site's own controls, at your instruction.

---

## Your privacy

Everything you enter — your profile, checklists, lockdown and breach progress, incident log, and display settings — is stored **only in your browser** using Chrome's local storage. The extension sends your data **nowhere**. The contact-vetting tool analyzes what you paste locally and does not save it. Use **Profile → Export** to back up or move your data to another computer, and **Erase everything** to wipe it.

---

## A few honest caveats

- **Not legal advice.** This is general information and a set of tools. Privacy and harassment laws vary by state and change; every screen links to an authoritative source, and for anything high-stakes talk to a qualified professional or a victim advocate.
- **Vetting is heuristic.** It flags *patterns*, not verdicts. A clean result is not proof something is safe, and a flag is not proof of fraud — it's a prompt to slow down and verify through a channel you already trust. It never identifies who owns a number, address, or domain.
- **Social automation clicks the site's current buttons.** Sites change their layout often, so always run **Preview** first; if an action finds nothing, that platform likely changed and the recipe needs updating — the platform's own bulk tools (linked on every card) always work. Some platforms discourage automation in their terms; use it on your own account, at a reasonable pace, at your discretion. Deletions are permanent, so download your data first.
- **Data current as of August 2026.** Opt-out and settings URLs were verified live; if one moves, search the site name plus "opt out" (or the setting name).
- **Opt-outs need repeating.** Broker records commonly reappear within 3–6 months — the kit tracks your dates and (optionally) reminds you. Paid services like DeleteMe, Incogni, EasyOptOuts, or Optery automate this if you'd rather hand it off — not required.

---

## If you're in danger

If you feel unsafe right now, contact local emergency services (**911** in the US). If someone is stalking or threatening you, the fastest way to identify an unknown person is a **police report** — law enforcement can compel that information legally, and it's the safe path. Free, confidential support is available any time: **National Domestic Violence Hotline 1-800-799-7233** (text START to 88788), and the **988 Suicide & Crisis Lifeline** (call or text 988) if the stress becomes overwhelming.

## What's new in 2.1.0

- **New "Job-application screening & hiring tech" category** in *Audit my exposure* — the FCRA background-check companies that run a file on you when you apply for a job (Checkr, Sterling, HireRight). Each links to the vendor's own candidate portal so you can request your report for free and dispute errors before a wrong record costs you an offer.
- **New "Starting a job search" guided walkthrough** — a proactive checklist for a job hunt: privatize old resumes, opt out of recruiter contact databases, check your background-check and Work Number files, use a masked email on applications, and lock down socials before recruiters look you up.
- **Expanded rights on automated hiring tools** — the walkthrough and the California state note now cover the growing right to access and opt out of AI hiring/assessment systems (HireVue, Eightfold, and similar), including California's anti-bias coverage (effective Oct 1, 2025) and access/opt-out rights phasing in through Jan 1, 2027.

Everything remains local and defender-oriented: it only ever works on *your* data and links out to authoritative sources you choose to open. No network requests, no third-party profiling.

## What's new in 2.2.0

- **New "📄 Résumé & applications" module.** Build an ATS-friendly résumé tuned to your target industry (12 industry profiles with standard section order, action verbs, and keyword sets), auto-draft a summary, then export as copy / .txt / print-to-PDF. All on-device.
  - **Readability grade** — Flesch–Kincaid grade level on *your own* résumé, with flags for long sentences, passive voice, and weak filler phrases, so you can pitch it clearly (target grade 8–11).
  - **Match a posting** — paste a job description *you're applying to* and see its most frequent skill terms, which already appear in your résumé, and its reading level so you can mirror its language. It analyzes the text you paste; it does **not** identify or profile the poster.
  - **ATS & recruiter standards** — a plain-English guide to what applicant-tracking systems and recruiters generally scan for (keyword match, parseable formatting, file type, reverse-chronological dating, impact-over-duties), in aggregate.

  Consistent with the rest of the kit: it only works on your résumé and text you choose to paste, stays entirely in your browser, adds no permissions, and makes no network requests. By design it does **not** look up, identify, or build demographic/reading-level profiles of recruiters or any other individuals — that's the profiling toolkit this app exists to defend against.

## What's new in 2.3.0

- **New "🏢 Staffing agencies" module — a US recruitment-agency directory built for self-defense.** ~25,000 staffing and recruiting firms operate in the US; this maps the **175 national firms and corporate families** that account for the bulk of candidate files and recruiter outreach — every major segment: general & franchise networks, industrial/logistics, IT, engineering & energy, healthcare travel/per-diem, locum tenens, finance & accounting, executive search, legal, creative, education, RPO/enterprise hiring, and on-demand gig apps. Researched and updated for the 2026 landscape (Aya + Cross Country, Vaco → Highspring, Kelly + Motion, Employbridge restructuring, Akkodis, Dexian, Actalent, Amergis, and more).
  - **Verify who really contacted you.** Every entry shows the agency's *real* domain (plus corporate-family badges, so "an Aston Carter recruiter about a Robert Half role" reads as odd immediately). Search by name, domain, or family; filter by 14 segments.
  - **Take your candidate file back.** Mark agencies you've used, open their site, and generate a personalized **deletion / file-request letter** (auto-filled from your profile, with a candidate-data P.S. covering résumés, submittals, assessments, and payroll/onboarding records). The date is stamped locally; backups now include this tracker.
  - **The vetting engine now knows all 175 agency domains** — plus Indeed, ZipRecruiter, Glassdoor, Monster, and Workday. Look-alikes, typosquats, homoglyph swaps (`r0berthalf.com`), token abuse (`aerotek-careers.net`), and "agency" mail sent from Gmail all flag automatically, in the popup, the dashboard, and on-page.
  - **New scam lexicon: "Fake recruiter / job-offer bait"** — Telegram/WhatsApp-only interviews, training and equipment fees, fake-check "buy equipment" schemes, task/commission bait, and shortlist flattery.
  - **Engine hardening for the bigger brand list:** the real-domain exemption is now checked against *all* brands first (so two legitimate look-alike neighbors like `shiftkey.com` / `shiftmed.com` can never cross-flag each other), and typosquat distance now scales with domain length (fixes false alarms like `usa.com` → UPS on short domains).
  - **"Agency not listed?"** guidance for the long tail: how to verify any firm (American Staffing Association directory, FTC job-scam patterns, FBI IC3) and send the same letter to any local or boutique agency.
  - The "Starting a job search" walkthrough gained a matching step.

  Same charter as everything else: **company-level only.** It shows which corporations hold your file and what their real domains are — it never identifies, looks up, or profiles an individual recruiter, and it still makes no network requests.

## What's new in 2.4.0 — second name, agencies go geographic

- **The app took its third name here.** Same defender-only charter, same local-only architecture. Existing data and old backup files carry over untouched.
- **The agency directory goes geographic.**
  - **Headquarters on every entry** — all 175 agencies now carry a researched HQ city and state (verified August 2026, including recent moves like Ingenovis Health's 2025 relocation to Blue Ash, OH), spanning 32 states.
  - **Filter by state** — an HQ-state dropdown with per-state counts, and a ★ shortcut to your own state when your profile has one. Useful for "who actually operates out of here" checks and for knowing which corporate address your deletion letter is headed to.
  - **Narrow to your ZIP code** — enter a ZIP and every agency row gains a **"Near you"** button that maps that firm's branch offices around you, plus one-click maps of *all* staffing, temp, and healthcare agencies near that ZIP — including local boutiques the directory can't list. National firms run hundreds of branches; the branch that holds your paper file is the one near you. Your ZIP is stored only on-device and appears nowhere except inside map links you choose to click.
  - **Address verification for scam defense** — a "recruiter" who names a local office can now be checked in two clicks: map the agency near your ZIP and see whether that office exists. Real branches have signage, photos, and history; a mail-drop suite is a caution sign.
- **State-by-state verification notes.** Filtering to a state surfaces what that state actually requires of staffing agencies — with specific, primary-source-verified entries for the states that license or register them (Massachusetts DLS licensing/registration + Temporary Workers Right to Know, New Jersey Division of Consumer Affairs registration + Temp Workers' Bill of Rights, Illinois IDOL day-labor registration, New York employment-agency licensing, California's bond/talent-agency rules), honest "most states don't license these — here's how to verify anyway" guidance everywhere else, a note on state healthcare-staffing registries, and the US DOL directory of state labor offices.
- Scope stays honest: roughly 25,000 staffing firms operate in the US. The directory covers the national firms and corporate families behind most candidate files; the ZIP maps and state notes are how you reach and vet **everyone else** — without this extension shipping a single unverifiable domain into its impersonation engine.

Still company-level only, still zero network requests of its own.

## What's new in 2.5.0

- **Social media verification on every agency — LinkedIn first.** Each of the 175 agencies now has a **LinkedIn** button (official company-page search) and a **Socials** expander with X, Facebook, Instagram, and the agency's own site footer. No hardcoded profile URLs anywhere: profile links rot and get squatted, so every button lands on the platform's own search, and the directory teaches the one check that can't be faked — **the company page's Website field must match the real domain listed here, character for character.**
- **New "Verify a recruiter on LinkedIn" guide** — the checklist for the platform where most recruiter impersonation actually happens: the Website-field rule, follower/employee sanity checks, matching the recruiter's profile to the real company page, then vetting the email address they actually write from, and the never-move-to-Telegram rule.
- **New tool: Ghosting letters — polite, but very direct.** Five candidate self-advocacy letters, generated with your profile and details filled in, each with one clean ask and a real 7-day deadline:
  - *Ghosted after an interview* — decision or timeline, or I withdraw.
  - *Ghosted after final round / verbal offer* — "is an offer coming, or not? Either answer is fine. No answer is the only unprofessional outcome."
  - *Ghosted after a take-home* — outcome and feedback for hours of unpaid work, and no further use of that work product after the deadline.
  - *Recruiter submitted me, then vanished* — status, exactly which companies received my data, and no further submissions without written approval per role.
  - *Final notice* — withdraw candidacy **and** demand deletion of the candidate file under your state's privacy law. You end it; they do the paperwork.
  Subject lines included, copy buttons for both, and honest framing: send at most two, keep it between you and the company, never a public post naming individuals.

Company-level, on-device, zero network requests — unchanged.

## What's new in 2.6.0 — third name, the Report tab

- **Third name landed here.** Same charter, zero data migration — everything carries over, and backups from any prior name still import.
- **New "🚩 Report it" tab — your state attorney general, one click away.**
  - **All 50 states + DC**, sourced from the official USA.gov attorney-general directory (fetched, not remembered). Pick your state — or let your profile pick it — and get the AG's official site plus a **File a consumer complaint** button.
  - **Direct, individually verified complaint-form links** for California, Texas, Florida, New York, and Pennsylvania (about a third of the US population), each marked *"direct link · verified Aug 2026."* Every other state gets an honest one-click **"find the current complaint form"** search scoped to that AG's own domain — it lands on the form today and still lands on it after the state redesigns its website. No guessed URLs anywhere: a broken link at the moment someone is reporting fraud is the one failure this tab is not allowed to have.
  - **Licensing leverage where it exists:** for the five states that register or license staffing agencies (MA, NJ, IL, NY, CA), the AG card also surfaces that state's registration regime — an unregistered agency is itself reportable.
  - **"Which harm goes where"** — a routing guide that treats people like adults: fee-charging and fake postings → AG + FTC; *ghost jobs* framed honestly (ghosting is rude, not illegal — but advertising roles that don't exist to harvest applications **is** deceptive advertising, reportable to the AG, the FTC, and the platform it ran on); identity exposure → IdentityTheft.gov then IC3; fake checks and wire demands → IC3 + your bank; unpaid wages by a staffing agency → your state labor department; hiring discrimination → EEOC, which covers staffing agencies too.
  - **Federal lanes card** (ReportFraud.ftc.gov, IC3, IdentityTheft.gov, EEOC, the FTC job-scams guide) and a **five-minute complaint builder** checklist, cross-linked to Vet a contact, the agency directory, and the evidence log.

Company-level, on-device, zero network requests of its own — every button on the new tab is an ordinary link to an official government intake.

## What's new in 2.7.0

- **The app got a face.** A circular badge on the deep-green field with a gold shooting star (since replaced by the Clapback mark in 3.3.0) became the extension icon at every size (16/48/128), the toolbar button, and the sidebar mark.
- **The whole app wears the badge's colors.** The theme is rebuilt from colors sampled directly out of the logo: deep green `#1F4936` (sidebar), field green `#276F49`, accent green `#1E6B45`, cream `#F7F2E4` background with warm card and line tones, and the gold `#E8B84B` reserved for the places it earns — the sidebar tagline, the active-tab marker, and focus accents in dark mode.
- **Accessibility held to the same bar as before:** every text/background pairing in both light and dark themes was contrast-checked (all body and accent text ≥ 4.5:1 WCAG AA; success labels darkened to `#187347` specifically to clear it). Dark mode is now green-tinted to match, with brighter accent greens so links stay readable. The high-contrast theme is deliberately untouched — black/cyan/yellow is an accessibility mode, not a branding surface.
- Popup, on-page vet panel, and the social-cleanup overlay all follow the new palette; no layout or behavior changes.

## What's new in 3.0.0 — the final form

- **New "🏛️ Represent" tab — the rules layer.** Reporting handles the scam in front of you; this handles why it's legal. Official lookups only, and you enter your ZIP on the government's own site, never in Clapback: the House's find-your-representative tool, the Senate directory, Congress.gov member search, Open States for all 50 state legislatures, and USA.gov's elected-officials directory. Plus the executive branch, framed honestly: **there is no dedicated "White House economic complaint form"** — Clapback links the official White House contact channel for describing economic harms like ghost-job proliferation, and pairs it with the CFPB complaint system, the federal intake that actually compels a company response. Three ready-to-send advocacy letters round it out, filled from your profile with a slot for your own story: truth-in-advertising for job postings, staffing-agency registration for your state (MA/NJ/IL already have it), and a national one-stop data-broker deletion modeled on California's DROP.
- **New "🗺️ Ghost map" tab — a national heatmap with an honest data source: you.** No agency publishes ghost-job reports by state or by company, and Clapback will not fabricate a national dataset. Instead: log every ghost posting, post-interview ghosting, scam, fee demand, or shady tactic you hit (state, kind, company with directory autocomplete, note), and a 51-jurisdiction US tile map shades itself from *your* log — your state ringed in gold, totals summarized, everything stored only on this device. **Your agency scale** ranks companies by your logged incidents and pairs every name with the public record: Glassdoor interview reviews and the BBB file, one click each. The whole log exports as CSV or JSON — an evidence pack ready to attach to AG and FTC complaints — and is included in Settings backup.
- **Glassdoor on all 175 agencies.** Every directory row now has a Glassdoor button (and BBB in the expander) using the same no-fabricated-URLs architecture as LinkedIn: platform search plus the domain cross-check, because a wrong "official profile" link in a verification tool is worse than none. Tip baked in: the *Interviews* section is where ghosting patterns show up first.
- **Résumé & applications is flagged 🚧 work-in-progress** — in the sidebar and in the section itself. It works, but it's under active development; expect rough edges there while everything else in 3.0.0 is final.

Fifty-one AG offices, 175 agencies, 113 brokers, five ghosting letters, three advocacy letters, one map — company-level only, on-device only, zero network requests of its own. That's the final form.

## What's new in 3.1.0 — the Ghost map goes real-data

- **The map now shades from documented public action, not personal logs.** Real things happened and the map shows them: the **Texas Attorney General opened a formal investigation into LinkedIn over ghost jobs** (Civil Investigative Demand, July 2026 — primary source linked), **New York's legislature passed the first US ghost-job bill** (S8877, both houses, June 2026 — awaiting the governor's signature as of this snapshot), and bills are moving in **Pennsylvania (HB2321), New Jersey (S2136/A1161), California (AB1251, held in committee), and Kentucky**. Four shading tiers — AG enforcement, passed legislature, bill introduced, none documented — and every colored state is clickable to filter the tracker to its items.
- **New: the Lawsuit & law tracker** — a reverse-chronological feed of eleven dated, statused, sourced items: the TX investigation, the NY bill, all four state bills, the reported federal Transparent Job Advertising Accountability Act, Ontario's first-in-the-world ghost-job law in force, the CRS analysis warning ghost jobs distort official jobs data, the ongoing private class-action investigation, and the Columbia Law Review Forum FTC Act §5(a) theory. Statuses are precise on purpose: an investigation is not a lawsuit, and a passed bill is not a signed law. Because Clapback makes zero network requests, the feed ships as a **researched snapshot (August 17, 2026)** — and a **Follow it live** row (Google News, the Texas AG newsroom, CourtListener docket search, Reddit, a community legislation tracker) keeps you current between Clapback releases.
- **New: "What the reports say"** — the social-media noise, measured: 8 in 10 recruiters admit posting ghost jobs (MyPerfectResume, 753 recruiters), 40% of hiring managers admit a fake listing in the past year (Resume Builder, 1,600+ managers), one-fifth to one-third of postings may be ghosts (studies cited by the Texas AG), 62% used ghost ads to make current staff feel replaceable. Every number names its survey and links its source.
- **Your evidence log stays** — private, on-device, exportable, feeding the agency scale — but it's now clearly separated: personal entries never touch the public map. The agency scale also gained a **Reddit** button per company alongside Glassdoor and BBB.

## What's new in 3.2.0

- **New "⚖️ Hiring rights" tab — the full US directory for reporting unethical hiring practices**, built from a compiled directory verified against official government sources (current as of August 18, 2026):
  - **Triage first:** fifteen expandable "what happened" rows — discrimination, citizens-only ads, union retaliation, ghost jobs, FCRA background-check abuse, ban-the-box violations, USERRA, federal-hiring nepotism, pay-transparency, polygraphs, unpaid working interviews, AI screening tools — each jumping straight to the right agency profile or the state finder.
  - **Nine federal agency profiles** (EEOC, DOJ IER, DOL WHD, NLRB, OFCCP, DOL VETS, OSC/MSPB, FTC, CFPB): what each handles, how to file with direct .gov links, the deadline highlighted (180/300 days, six months, 45 days for federal applicants…), and the hotline. The OFCCP profile preserves the directory's "verify before citing" status note on the agency's 2025–2026 restructuring.
  - **All 51 state fair-employment agencies**, searchable, with **your state pinned to the top** from your profile — including the honest rows for the four states with no private-sector FEPA (file with EEOC), the 2025 Tennessee and Iowa reorganizations, and CA/NY's three-year windows vs Texas's 180 days. Plus the canonical master directories (EEOC FEPA lists, DOL state labor offices, NAAG, USA.gov) and the mid-2026 pay-transparency enforcement map.
  - **23 city & county commissions** (both NYC agencies, Chicago, Cook County, LA, Seattle, Philadelphia…) with the 311/211 trick for finding yours, **seven vetted non-governmental resources** (Cornell LII, Workplace Fairness, NELA, Legal Aid at Work, A Better Balance's helpline, ABA Free Legal Answers, LawHelp), and the complete **methodology & sources** section — 24 primary .gov sources and 9 secondary analyses — as a collapsible.
  - Three governing rules up top (FEPA dual filing, short-and-varying deadlines, applicants-are-covered) and the directory's own disclaimer preserved. Report it's routing card now cross-links here for hiring-specific violations.

## What's new in 3.4.0 — the Legal campaigns tab

- **New "📣 Legal campaigns" tab — the legal war on the recruitment industry, tracked on every front, not just ghost jobs.** The Ghost map's lawsuit tracker proved the format; this tab widens the lens to all six fronts where courts, regulators, prosecutors, and legislatures are going after recruiting practices:
  - **AI screening** — *Mobley v. Workday*, the nationwide ADEA collective action covering applications rejected through the platform since 2020 (a pool courts have put at over a billion), with the vendor-as-"agent" liability ruling, the March 2026 age-claims ruling, and the June 2026 algorithm-discovery order; the first-ever settled AI-hiring case (*EEOC v. iTutorGroup*, $365K); and the state AI-hiring statutes now in force (IL HB 3773 and Texas TRAIGA live January 1, 2026, Colorado June 30, NYC and California already on).
  - **Ghost jobs & deceptive postings** — the Texas AG × LinkedIn investigation and New York's S8877 as headlines (the full state-by-state feed stays on the Ghost map tab), plus the template case: the FTC's $8.5M Care.com settlement over inflated job listings, refunds already mailed.
  - **Wage-fixing & no-poach** — the first criminal wage-fixing trial conviction (a home-health staffing executive: 40 months, $550K), and the FTC's standing Joint Labor Task Force, still active case-by-case in 2026.
  - **Temp-worker protections** — the Third Circuit upholding New Jersey's Temp Workers' Bill of Rights over the staffing industry's challenge, and Illinois' amended day-and-temp-labor act (equal pay on longer assignments, joint safety responsibility, private right of action).
  - **Pay transparency** — *Branson v. Washington Fine Wine & Spirits*: any applicant to a range-less posting can seek statutory damages, class actions proceeding (with the honest counterweight: July 2025 cure-period amendments); plus Virginia and Maine joining the posting-mandate states in 2026.
  - **Hiring-bias enforcement** — the EEOC's 2026 shift to treating demographic hiring preferences as Title VII violations, framed precisely: an enforcement-priority change, not a statute change.
  - **Same rules as the ghost tracker:** a researched snapshot (verified August 20, 2026) shipped with the release because Clapback makes no network requests; every item dated, statused precisely (an investigation is not a lawsuit, a passed bill is not a signed law, one conviction is not an industry-wide rule), and sourced — primary sources where they exist. Follow-it-live links (Google News, CourtListener, the EEOC newsroom, FTC press releases, DOJ Antitrust, Littler's legislation tracker) keep you current between releases. Filter the tracker by front, with per-front counts.
  - **"Turn a campaign into your next move"** closes the loop: each front maps to the tool it powers — AI-screening complaints route through Hiring rights, ghost postings through Report it and the Ghost map log, pay-range omissions to the state finder, temp-agency violations to your state labor department, and candidate-file deletion letters through Staffing agencies.
  - Read-only and on-charter: the tab stores nothing, profiles no one, and names companies only as they appear in public court and agency records. Zero network requests, as always.

## What's new in 3.3.0 — "Clapback"

- **The app is now Clapback** — fourth and current name — with a new logo to match: the clapping-hands badge, rendered to every icon size (16/48/128), the toolbar button, the popup header, and the sidebar mark. The old badge is gone across the board.
- **Zero theme churn, on purpose:** the new logo was drawn in the app's exact palette — deep green `#1F4936`, cream `#F7F2E4`, gold `#E8B84B` — verified pixel-for-pixel, so the whole UI already matches the mark. No color, layout, or behavior changes; backups from any prior name (and their old filenames) import unchanged.

## What's new in 4.0.0 — medical bills and credit

- **Seven new tabs, one charter.** The same rule that governs the rest of Clapback governs these: they work on **your** bills, **your** insurance, **your** credit file, and a lawsuit filed against **you**. Nothing profiles anyone. Everything runs on this device, and the extension still makes **zero network requests of its own** — every external check is an ordinary link you choose to open.

- **🧾 Medical bills.** A bill is a claim, not a verdict. Get the itemized version and your records with two ready-to-send letters, then run the highest-value check in the whole tab: compare your insurer's *patient responsibility* line against what the provider is billing. Anything over it is presumptively an improper balance bill, and that check needs no coding knowledge and no clinical judgment. Plus a fifteen-item error taxonomy (unit errors, unbundling, duplicate charges, room charges on your discharge day, observation-vs-inpatient status), the CO/PR group-code decoder that tells you which adjustments the provider absorbs, a $400 surprise-bill dispute calculator with its 120-day deadline, and honest price benchmarking — including a note that two tools everyone still recommends as free consumer price lookups no longer work that way.

- **🤝 Financial assistance.** The step that most often takes a hospital bill to zero, and the one almost nobody is told about. A poverty-level calculator built on the verified 2026 guidelines; the full section 501(r) engine — what a tax-exempt hospital owes you, the Amounts Generally Billed cap, and what counts as an "extraordinary collection action"; and a timeline calculator that turns one date (your first bill after discharge) into the three that govern everything: **120 days** before they may report or sue you, **240 days** to apply, and **30 days'** written notice before the first action. Then the part that matters most if you're already being sued: if you apply and qualify, the hospital must take all reasonably available measures to **reverse** what it did — vacate the judgment, lift the lien, remove the credit reporting. Verified state programs for WA, NY, IL, MD, CA, CO, NJ, MN, OR, ME, CT, NV and RI.

- **🏥 Insurance appeals.** Under 1% of denied claims are ever appealed; about a third of the appeals win. A deadline calculator for the 180-day internal appeal and the four-month external review, a denial-reason triage that separates what's worth appealing from what's a five-minute phone call, and the routing that no official source provides: **self-funded or fully insured?** The NAIC's own complaint guidance never mentions that a state insurance department cannot touch a self-funded employer plan — so someone following it files with the wrong regulator and burns weeks against a hard clock. Plus the Medicare five-level ladder, Medicare Advantage's automatic escalation, Medicaid's exhaustion trap, and honest coverage of plans with weak or no appeal rights.

- **💳 Your credit file.** Thirteen files on you, not three — the fourth national bureau, your prescription history, your insurance-application file, bank screening, employment and income — each with its free-report link and its freeze link, checkable. A quick medical-collection test against the bureaus' own published policies (paid, under $500, or under a year old means it shouldn't be there at all, no legal theory required). All fifteen verified state medical-debt reporting laws, with the miscounted ones called out — Nevada's bill was **vetoed**; North Carolina's is a Medicaid program condition, not a statute. And the dispute-sequencing trap that decides whether you can ever sue: **dispute through the bureau first**, because only a bureau-routed dispute triggers the furnisher duty that is privately enforceable.

  **What this tab will not tell you:** that medical debt is off your credit report by federal rule. That rule was **vacated on July 11, 2025** and never took effect for a single day. A great deal of 2025-vintage advice still says otherwise.

- **📞 Debt collectors.** A validation-deadline calculator that uses the five-business-day presumed-receipt rule (so your window is longer than you think), the 7-in-7 call rule explained as the rebuttable presumption it actually is — measured per person *and per debt*, which is why one hospital stay can lawfully produce 28 calls a week — a violation log that starts a **one-year countdown from the violation, not from when you noticed**, verified state licensing lookups, and the one reliable test for whether a collector is real. Not "they knew my Social Security number": legitimate medical collectors routinely do, and so do criminals.

- **🧑‍⚖️ Sued? The court kit.** Most consumer debt lawsuits end in a default judgment because nobody answers. Answer deadlines and statutes of limitation for all 51 jurisdictions — with the ones Clapback **could not verify from a primary source marked as unverified rather than guessed**, because a confident wrong number here is a default judgment. A defense builder across sixteen defenses (including the medical-specific ones: charity-care screening failure, surprise-billing violations, unreasonable charges), what the plaintiff actually has to prove and why debt buyers so often can't, the requests-for-admission move that can end a case outright, post-judgment exemptions, and verified free legal help.

- **📅 Deadlines.** Every calculator in these tabs has a *track this* button, and they all land here — sorted, banded by urgency, exportable, with a calendar file so a local-only tool can still actually remind you. Anything inside two weeks surfaces on the Overview.

- **Five new guided walkthroughs** — *I just got a huge medical bill*, *I'm being sued over a debt*, *A collector is calling*, *My insurance denied a claim*, and *Medical debt hit my credit report* — plus three new scam-lexicon categories in **Vet a contact**: fake debt collectors, medical billing and insurance bait, and debt relief / credit repair scams.

### On accuracy, because this half of the app is different

A wrong deadline in a lawsuit is a default judgment, so this release follows stricter rules than any before it. Every legal claim carries a primary source. Anything that could not be verified against one is **marked unverified in the interface**, out loud, rather than filled in with a plausible number — sixteen states' answer deadlines and eighteen states' limitations periods are shown that way, and the app tells you to read your summons and call the clerk instead. Withdrawn guidance and vacated rules are labeled as such: the CFPB withdrew its entire debt-collection guidance library on May 12, 2025 and some of it is still posted with no withdrawal banner. And the widely-quoted "80% of medical bills contain errors" appears nowhere here, because no study supports it — the figure traces to a trade association for paid billing advocates that has never published a methodology.

All 164 external links were fetch-verified. Two failed and were fixed: an Alaska summons link that pointed at an **eviction** form rather than a civil answer, and the FTC's fraud-reporting portal, which was still serving a stale government-shutdown notice with no working form — so Clapback routes you elsewhere and says why.

Verified August 22, 2026. Not legal, medical, or financial advice.

## What's new in 4.1.0 — student loans and bankruptcy

- **🎓 Student loans, federal and private.** Federal student loan rules changed more between July 2025 and July 2026 than in the decade before, and most explainers online are stale in ways that cost money. This tab starts by asking which kind of loan you have, because the strategies barely overlap — and says plainly that refinancing federal loans into a private consolidation is the one genuinely irreversible mistake. Then: a **Repayment Assistance Plan calculator** built from the statute's own bracket table, including the part almost nothing explains — the percentage applies to your **total** adjusted gross income, not the part inside the bracket, so every $10,000 boundary is a step rather than a slope. The calculator shows you your next cliff. Every plan is listed with its closure date and, more usefully, whether its payments actually count toward PSLF — which for Tiered Standard turns on whether your balance is under $25,000, a distinction that both the optimistic and the pessimistic summaries get wrong.

- **The auto-pay deadline.** The interest reduction went from 0.25% to a full 1%, enrollment closes **September 30, 2026**, and the benefit runs through June 2028. It's trackable from the tab.

- **Default, honestly.** The 270-day clock, what administrative wage garnishment can do without any lawsuit, the Treasury offset floor, and the choice that matters most: rehabilitation removes the default notation from your credit report and consolidation does not. Two facts on the page are flagged as **volatile by nature** rather than hardcoded — whether the Department is actually garnishing right now (collections were paused in January 2026 with no end date) and the current means-test figures. Being told your refund is safe when garnishment has restarted is the worst thing this tool could do to you, so it says it doesn't know.

- **State by state.** A verified student loan ombudsman or advocate lookup for the sixteen jurisdictions that have one, with the complaint link where it exists — and, for the rest, the honest note that a state office generally cannot compel the federal Department of Education anyway; its leverage is over servicers and private lenders.

- **⚖️ Bankruptcy & discharge.** A three-mode tile map: where student loan discharge lawsuits are actually **filed**, consumer bankruptcy filing rates, and Chapter 13 share — click any state for its detail. Plus the undue-hardship test by circuit, the 2022 Justice Department process that changed the odds, what filing actually involves (the $350 adversary fee that must not be charged when the debtor is the plaintiff; the three-address service requirement that defeats most self-represented filers), and what bankruptcy does and doesn't discharge — with the two exceptions where **Chapter 13 is broader than Chapter 7**, which is a real reason to compare rather than assume.

- **Three new guided walkthroughs** — *I can't pay my student loans*, *My loans are in default*, and *Can bankruptcy clear my student loans?* — and seven new letter templates covering servicer disputes, the CFPB complaint, disability discharge, private-loan validation, and the bankruptcy attestation.

### The answer to "where are student loan discharges happening?"

It is not where anyone expects, and the honest answer required correcting the question.

**Almost all student loan discharge is administrative, not judicial.** In fiscal 2024 the Department of Education discharged about **$28.7 billion** through six programs — Public Service Loan Forgiveness ($17.8B), Total and Permanent Disability ($4.9B), borrower defense ($4.7B), death ($1.0B), Teacher Loan Forgiveness ($147M) and closed school ($33M). In the same year, **692 people in the entire country** filed the bankruptcy lawsuit required to attempt a discharge. Clapback deliberately publishes **no ratio** between those two figures: the first is dollars and the second is lawsuits, and the Congressional Research Service says plainly that borrower counts for the administrative programs are not publicly available. The direction and the order of magnitude are not in doubt; a precise ratio would be invented.

**Within bankruptcy, the concentration is geographic and it does not track the law.** The only district-level dataset that exists was built by hand from PACER dockets by three law professors, covering November 2022 to October 2024. It counts **filings, not outcomes** — no dataset anywhere breaks down student loan discharge *outcomes* by geography, and Clapback says so rather than building a map out of numbers that don't exist. On that data the District of **Minnesota** leads the country by a wide margin, with a roughly thirtyfold increase after the 2022 guidance. The top fifteen districts account for about half of all filings nationally.

**And the counterintuitive part:** that concentration is not explained by which legal test the circuit applies. Minnesota sits in the Eighth Circuit, the one circuit using the more flexible "totality of the circumstances" standard rather than Brunner — but the empirical work finds no significant outcome difference between Brunner and totality circuits. What varies is local practice: which bankruptcy bar knows the 2022 process exists and uses it. The barrier is not that these cases lose. Most of the few that are brought win. The barrier is that almost nobody files one.

### On accuracy

Both new data files went through an adversarial fact-check against primary sources, and it found real errors that are now fixed. Among them: a 360-day involuntary-collections threshold that appears in no regulation and has been removed; a once-only limit wrongly transplanted onto the three-payment consolidation route; the 15% Social Security offset cap cited to the statute when it is Treasury's regulation; a spouse's Social Security number described as required for the disability-discharge tax exclusion when the statute asks only for the taxpayer's; the NCSLT settlement figure off by an order of magnitude; and a 120-day government answer period that is actually 35 days under Bankruptcy Rule 7012(a).

The state Chapter 13 completion column was rebuilt from scratch. The original figures could not be traced to a published source, so all 51 were replaced with values computed directly from the Administrative Office's **BAPCPA Report Table 6** — plans completed over cases terminated, districts summed to states — and the column now carries its source. The state filing table is checksummed: the 51 rows sum to the AO's national consumer total less the territories, and the population column sums to the Census national total exactly.

Where a claim could not be tied to a primary source it is now either softened or removed, and the app says which. That includes the SAVE end date (the Department's own release describes a court-approved settlement, not the date that circulates), the exact withdrawal date of a CFPB bulletin, and the vacatur of the PSLF employer-exclusion rule — a claim that tells you to disregard published regulatory text, so the app now names the case and docket, links the rule as published, and tells you exactly how thin the sourcing is.

Verified August 23, 2026. Not legal, tax, or financial advice.
## What's new in 4.2.0 — addiction resources, the public record, and CY2025 data

### 🫂 Find help

Substance use treatment and harm reduction, built around a constraint that shaped everything: **Clapback makes zero network requests, so it cannot ship a live directory of clinics.** A stale phone number in this context is not a minor bug — it is someone calling a dead line in the worst hour of their life. So the tab ships verified national entry points and a **launcher**: you type a ZIP on your device, and Clapback builds the correct query URL into findtreatment.gov and the HRSA health center finder. Nothing you type is sent anywhere. Every deep link carries a plain fallback beside it — the bare domain and a phone number — because a zero-network tool cannot detect at runtime that a query parameter has quietly stopped working.

- **Overdose response comes first, above everything else on the page.** The CDC signs, the naloxone sequence, the 2–3 minute repeat-dose interval, and the fentanyl-era detail that one dose is often not enough. Plus a xylazine card, because the failure mode there kills people: naloxone will not reverse xylazine, but you give it anyway since xylazine is nearly always mixed with fentanyl — and the person may stay unconscious even after it has worked correctly. Do not conclude it failed.
- **The number that would have been wrong.** The 988 Lifeline's specialised LGBTQI+ service — the "press 3" option — closed on July 17, 2025. Printed material still in circulation tells people to press 3. Clapback states the closure, gives the independent alternative, and flags that HHS has committed to relaunching something within 2026, so this is the item on the page most likely to change.
- **What the evidence actually shows.** Methadone and buprenorphine are associated with roughly half and a third lower mortality respectively, with the confidence intervals shown rather than hidden behind a point estimate. Naltrexone gets the harder, fairer treatment: buprenorphine won the head-to-head trial's primary endpoint, and the reason was induction failure rather than the drug failing.
- **The methadone rules changed permanently in 2024 and most guidance has not caught up** — the one-year history requirement is gone, take-homes can start immediately, counselling cannot be a precondition. With the caveat that matters: these are federal *ceilings*, not floors, and your clinic may legitimately be stricter.
- **Rights, with the qualifications intact.** 42 CFR Part 2 records cannot be used against you in a legal proceeding — and the 2024 rewrite cut both ways, which the page says. Insurance parity applies, but enforcement of the 2024 rules is paused pending litigation. Being on prescribed methadone is a protected disability under the ADA. FMLA covers treatment but not use, and an employer's uniformly applied policy still bites.
- **State harm reduction law** for all 51 jurisdictions — fentanyl test strip legality and syringe services authorisation — with the survey vintage disclosed rather than implied.

### 🏛️ The record

Public accountability built on one rule: **nothing appears unless it is an official act with a citation.** A recorded vote, an audited expenditure, a statute, a settlement term. No motives, no personal life, no contact details, no suggestions about what to do to any individual. That constraint is not squeamishness — it is what makes the page work. A sourced roll-call vote cannot be argued with; an unsourced accusation hands its subject an easy win.

- **Where the opioid settlement money went.** $58.58 billion across all settlements. Of $6.5 billion received in 2024, $2.7 billion was spent or committed — and about 20% was untrackable, with sixteen states leaving more than 30% of their spending with no public documentation at all.
- **Three documented findings, each with its status label showing**, because they are not the same weight. New Jersey's comptroller itemised $632,502.16 spent on two "awareness" concerts down to the cotton candy machines and the $12,648 luxury VIP trailers. Arizona's auditors found $50.9 million the corrections department could not document — which the department disputes, and where the related lawsuit was *voluntarily dropped*, not decided. KFF Health News catalogued $61 million of settlement money spent on law enforcement equipment, including rifle suppressors.
- **The votes**, linked to the Clerk of the House and the Senate. H.R. 1's Medicaid provisions (Senate 50–50 on the Vice President's tiebreak; House 218–214). The SUPPORT Act reauthorisation that passed 366–57 after an identical bill died in the Senate two years earlier. And the HALT Fentanyl Act, which is the one worth actually reading — House Democrats split 98 to 107, almost exactly down the middle.
- **A state scorecard** across Medicaid expansion, fentanyl test strip legality and syringe services authorisation, on the same tile map the rest of the app uses.
- **Where Clapback stops.** KFF found twelve states promised full settlement transparency and seven delivered. Clapback publishes the headline but *not* which seven, because that breakdown lives in a graphic and three attempts to read it produced conflicting assignments. Publishing a state in the wrong column is exactly the error this page exists to avoid.

### 📊 The bankruptcy data, rebuilt on CY2025

The uploaded 25-tab statistics workbook replaced the entire dataset and unlocked several series the app could not previously show: fourteen years of filings, Chapter 13 completion by year, student loan discharge attempts from 2011 to 2024, who files, what drives them there, and what it costs.

Three findings genuinely change the advice the app gives:

- **Chapter 13 completion has fallen every year since 2021** — 58% to 44.6%. Of CY2025's 101,709 dismissals, 51,333 were for failure to make plan payments.
- **The biggest predictor of getting a discharge is whether you had a lawyer.** Chapter 7: 97.7% with counsel against about 75% without. Chapter 13: 40% against 12%. That is the widest outcome gap in the entire dataset.
- **The fee explanation is now quantified rather than asserted.** Chapter 7 counsel must generally be paid up front, around $1,200–1,400; Chapter 13 fees come out of the plan. A 2017 study found people steered into Chapter 13 because they could not raise the Chapter 7 fee — and paying about $2,000 more overall for it. People are being sorted into the worse-completing chapter by their inability to pay in advance. The app now surfaces the Chapter 7 fee waiver, available below 150% of the federal poverty line, next to that finding.

### On accuracy — including a correction to 4.1.0

**The 4.1.0 "fix" was the regression.** An adversarial fact-check flagged the state Chapter 13 completion column as unsourceable, so it was replaced with CY2024 figures. The workbook and the Administrative Office's own BAPCPA Report Table 6 both confirm the original column was CY2025 data and correct all along. It has been restored and now carries its source. The lesson is recorded here rather than quietly reversed: "I could not find the source" is not the same as "the number is wrong," and treating the two as equivalent broke working data.

Both new data files went through the same adversarial pass, which found real errors now fixed. Two were potentially dangerous and are worth naming:

- **Texas and Iowa were coded as expressly authorising syringe services programs. Both prohibit them.** The tool would have told users in prohibition states that the activity was statutorily authorised. Corrected against the source's own state-by-state answers.
- **The overdose signs list omitted gurgling or snoring sounds from someone who cannot be woken** — the sign a lay bystander is most likely to recognise, and the one most often mistaken for ordinary sleep. Added.

Also corrected: rescue breaths were attributed to CDC when they come from SAMHSA and harm reduction training; the four-hour stay-with-them figure was cited to the wrong CDC page; the airway step now comes before the wait-and-redose rather than after it; the X:BOT trial's primary result was omitted in naltrexone's favour and now leads; two xylazine claims are NIDA's rather than CDC's and are labelled that way; the pharma lobbying "38% above second place" was a quarterly comparison attached to a half-year figure; and the settlement total is stated as pending final settlement rather than closed.

Where a figure could not be traced to a publishing source it was removed rather than softened — a widely repeated count of operating syringe services programs is gone entirely. And a circular citation was caught: a 2026 brief that appeared to corroborate the 2024 drug-checking survey turned out to be built on that same survey, so the app no longer claims independent confirmation it does not have.

All 80 new external links were fetch-verified: no dead links, two redirects updated, eight blocked by bot protection and labelled unverifiable rather than assumed broken. Every roll-call tally was read off the Clerk's and the Senate's own pages and matched.

Verified August 23, 2026. Not legal, medical, tax, or financial advice.

## What's new in 4.3.0 — Louisiana, and a named member's record

### ⚜️ Louisiana

Louisiana is the only civil-law state in the country. Its procedure descends from the Napoleonic Code, and every national 50-state debt table is built on common-law categories that do not exist here — which produces a specific, checkable, dangerous error on the most time-critical fact in a collection lawsuit.

- **Your answer deadline is probably not 21 days.** Twenty-one is the district court rule (art. 1001). In city courts, the three parish courts, and justice of the peace courts, it is **ten** — fifteen if you were served through the Secretary of State. That is art. 4903 for city and parish, art. 4920 for JP, and art. 4831 is the mechanism by which Book VIII displaces the general rule. Every page currently ranking for this reports only the twenty-one.

- **And the citation you were handed may print the wrong number.** This is the trap, and it is written into the Code: art. 1202(5) requires a citation to tell the defendant to appear "within the delay provided in Article 1001." A city court citation using the standard form language therefore points you at 21 days when your real deadline is 10. What *is* reliable is the court NAME, which art. 1202(4) also requires. Read the name, not the number.

- **"Does my parish have a city court" is the wrong question**, and it is the one most Louisiana guides pose. A city court's territorial jurisdiction stops at the city limits — live outside them and you are in district court regardless. The question that works is what court is named on your papers.

- **Prescription, correctly.** Open accounts including credit cards at 3 years (art. 3494(4)), notes at 5 (art. 3498), delictual actions at 2 since July 2024 (art. 3493.1). And the ten-year figure that gets miscited constantly: art. 3499 is titled "Personal action" and is a *residual* — it applies only when nothing else does, so an open account never reaches it. A national legal site currently presents it as the written-contracts rule, on a common-law distinction Louisiana does not draw.

- **Two defences national content describes backwards**, both stated with their limits intact. And the collector registration lookup, the Fifth Circuit fee-shifting trap that catches settling FDCPA plaintiffs, LUTPA's conditional fees, and both legal aid intake lines.

- **What this tab will not do:** tell you which pleading to file, calculate your deadline, or generate a document with your details in it. It hands you the rule, the quoted article, and the clerk's phone number. A tool that guesses wrong about your deadline does more damage than one that admits the limit.

### 🏛️ A named member's record, in The Record

The accountability tab gains a complete roll call for one member of Congress — nineteen consumer-finance votes, each linked to the Clerk of the House, each verified individually. All nineteen tallies and party splits matched the Clerk's own record exactly.

Three rules govern it, and the third is the one that matters:

1. Every vote is an official act with a citation.
2. No motive, no personal life, no family. Official acts and published constituent-service contact only.
3. **The counter-evidence ships with the votes, in the same tab, at the same weight** — the flood insurance bill, the CVS Health investigation, the PBM hearing quote, the data-broker vote. Publishing the votes alone is the failure this whole tab exists to prevent.

The page also refuses the easy argument. The FEC filings do not support "bought by corporate donors" — the entire identifiable consumer-finance donor footprint is about 1% of receipts, zero from payday lenders, and he has never sat on the committee with jurisdiction. The page says so, because a corruption story that falls apart on inspection is worse than no story. The sentence the record actually supports is narrower and much harder to rebut.

### On accuracy

**Six things in the Louisiana source material would have shipped wrong**, caught by verification against legis.la.gov and the published opinions:

- **Arts. 1702(D) and 4904(D) are discretionary.** The court *may* raise prescription at default; the plaintiff's prima facie burden attaches only after it does. An earlier draft described it as an unconditional bar, and the tab now says so.
- **R.S. 9:3534.1(E) is written for a collection agency suing on "the debt of a client or customer."** Whether it reaches a debt *buyer* suing on paper it owns is textually doubtful — and no reported Louisiana decision has ever applied the subsection. The original framing was built entirely around debt buyers.
- **R.S. 10:3-118 is not a flat five years** — unaccepted drafts run three.
- **Justia's text of art. 4843 is a year stale** and lacks the 2026 amendment, so the per-city jurisdiction table comes from legis.la.gov.
- **No parish-by-parish legal aid table is publishable.** Every third-party list contradicts the organisations' own counts — one names 31 parishes for an organisation claiming 42, another says "20" while listing 23, and one parish appears on both. Two phone numbers and an instruction to call is worse product design and better advice.
- **First National Bank of Commerce v. Band applied the open-account period to a credit card; it did not hold that credit cards are open accounts.** The tab says "generally" and explains the argument you may have to answer.

Verification also *added* things the source material missed — that JP courts carry the same ten-day rule, and the art. 1202(5) citation trap, which is now the single most useful warning on the page.

**In the member record, one claim was outright false**, and it was in the counter-evidence section, which is the worst place for one: the flood insurance bill was introduced by Rep. Frank Pallone with Higgins as an original cosponsor, not the other way round. It is corrected on the card, out loud, rather than quietly. Also corrected: four bills' official short titles, one vote that is party-line rather than a deviation, and one absence that should not be read as a statement.

Verified August 23, 2026. Legal information, not legal advice.

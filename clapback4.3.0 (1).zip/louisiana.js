/* Clapback — "Louisiana" module.
 * Legal information, not legal advice. No network requests.
 * Deliberately does NOT calculate deadlines or generate pleadings — see
 * CBLA.GUARDRAIL for why that line is drawn where it is.
 */
(function () {
  "use strict";
  var X = window.CBX, L = window.CBLA;
  var mounted = false;
  var prof = {};
  var courtPick = null;

  function mount() {
    var view = X.$("#view-louisiana");
    if (!view || mounted) { if (mounted) refresh(); return; }
    mounted = true;

    view.innerHTML =
      '<h1>Louisiana</h1>' +
      '<p class="lede">Louisiana is the one state where national debt-collection advice is not just thin but wrong, because Louisiana runs on civil law rather than common law. The most consequential difference is the answer deadline: every page that ranks for this reports 21 days, and in most Louisiana courts that hear consumer collection suits it is <strong>ten</strong>.</p>' +

      /* ---- served banner ---- */
      '<div class="card danger">' +
      '<h2>Served with a lawsuit?</h2>' +
      '<p id="ur-body"></p>' +
      '<div class="callout callout-warn" id="ur-urgent"></div>' +
      '<div class="btn-row"><button class="btn" data-goto="louisiana-deadline">Which deadline applies to me →</button>' +
      '<button class="btn btn-ghost" data-goto="court">The general court kit →</button></div>' +
      '</div>' +

      /* ---- why national advice fails ---- */
      '<div class="card">' +
      '<h2 id="in-head"></h2><p id="in-body"></p>' +
      '<div class="cmp-wrap"><table class="cmp"><thead><tr><th>What other guides say</th><th>What Louisiana calls it</th></tr></thead><tbody id="in-vocab"></tbody></table></div>' +
      '<div class="callout callout-warn" id="in-stakes"></div>' +
      '</div>' +

      /* ---- THE DEADLINE ---- */
      '<h2 id="ladl-head"></h2>' +
      '<div class="card danger" id="louisiana-deadline">' +
      '<h3 id="latrap-head"></h3>' +
      '<p id="latrap-body"></p><p id="latrap-what"></p>' +
      '<div class="callout callout-warn" id="latrap-do"></div>' +
      '</div>' +

      '<div class="card">' +
      '<p class="muted">Pick the court named at the top of your papers.</p>' +
      '<div class="chips" id="ct-pick">' +
      '<button class="chip" data-court="district">Judicial District Court</button>' +
      '<button class="chip" data-court="city">City Court</button>' +
      '<button class="chip" data-court="parish">Parish Court</button>' +
      '<button class="chip" data-court="jp">Justice of the Peace</button>' +
      '</div>' +
      '<div id="ct-out" style="margin-top:14px"></div>' +
      '<div class="callout callout-info" id="ladl-summary"></div>' +
      '<p class="muted" id="ladl-honest"></p>' +
      '</div>' +

      '<div class="card"><h3 id="wq-head"></h3><p id="wq-body"></p>' +
      '<div class="callout callout-info" id="wq-right"></div></div>' +

      '<div class="card"><h3>What each city court can hear</h3>' +
      '<div id="cl-list"></div>' +
      '<p class="muted" id="cl-note"></p>' +
      '<div class="callout callout-warn" id="cl-caveat"></div>' +
      '<div class="btn-row">' + X.a("Article 4843 ↗", L.CITY_LIMITS_URL, "btn btn-sm") + '</div></div>' +

      /* ---- PRESCRIPTION ---- */
      '<h2 id="lapr-head"></h2>' +
      '<div class="card">' +
      '<p class="lede" style="font-size:15px" id="lapr-lead"></p>' +
      '<div class="cmp-wrap"><table class="cmp"><thead><tr><th>Type of debt</th><th>Period</th><th>Article</th></tr></thead><tbody id="lapr-rows"></tbody></table></div>' +
      '<div id="lapr-notes" class="link-list"></div>' +
      '</div>' +
      '<div class="card danger"><h3 id="rt-head"></h3><p id="rt-body"></p>' +
      '<div class="callout callout-warn" id="rt-why"></div></div>' +
      '<div class="card"><h3 id="cc-head"></h3><p id="cc-body"></p>' +
      '<p class="muted" id="cc-detail"></p>' +
      '<div class="callout callout-info" id="cc-arg"></div></div>' +
      '<div class="card danger"><h3 id="it-head"></h3><p id="it-body"></p>' +
      '<div class="callout callout-warn" id="it-warn"></div>' +
      '<p class="muted" id="it-renounce"></p></div>' +

      /* ---- DEFENCES ---- */
      '<h2>Two defences national content describes wrong</h2>' +
      '<div id="df-list"></div>' +

      /* ---- COLLECTOR ---- */
      '<h2 id="rg-head"></h2>' +
      '<div class="card"><p id="rg-body"></p>' +
      '<div class="callout callout-warn" id="rg-guard"></div>' +
      '<p class="muted" id="rg-verify"></p>' +
      '<p id="rg-ag"></p>' +
      '<div class="btn-row">' + X.a("Secretary of State filing info ↗", L.REGISTRATION.sosUrl, "btn btn-sm") +
      X.a("OFI's own page ↗", L.REGISTRATION.ofiUrl) + X.a("Attorney General ↗", L.REGISTRATION.agUrl) + '</div></div>' +

      /* ---- FEES ---- */
      '<h2 id="fe-head"></h2>' +
      '<div class="card"><p id="fe-body"></p>' +
      '<h4 style="margin-top:14px" id="tj-head"></h4>' +
      '<p id="tj-body"></p><p class="muted" id="tj-status"></p>' +
      '<div class="callout callout-warn" id="fe-ask"></div>' +
      X.srcLine("Tejero v. Portfolio Recovery Assocs. (5th Cir. 2021)", L.FEES.tejero.url) +
      '</div>' +
      '<div class="card"><h3 id="lalutpa-head"></h3><p id="lalutpa-body"></p>' +
      '<p id="lalutpa-real"></p><p class="muted" id="lalutpa-limits"></p>' +
      '<div class="callout callout-info" id="lalutpa-unsettled"></div>' +
      '<div class="btn-row">' + X.a("R.S. 51:1409 ↗", L.FEES.lutpa.url, "btn btn-sm") + '</div></div>' +

      /* ---- HELP ---- */
      '<h2 id="lahp-head"></h2>' +
      '<div class="card"><p id="lahp-body"></p><div id="lahp-orgs"></div></div>' +
      '<div class="card danger"><h3 id="lalsnl-head"></h3><p id="lalsnl-body"></p>' +
      '<p class="muted" id="lalsnl-honest"></p></div>' +
      '<div class="card"><h3>Other routes</h3><div id="lahp-other" class="link-list"></div>' +
      '<p class="muted" id="lahp-bar"></p></div>' +
      '<div class="card"><h3 id="nt-head"></h3><p id="nt-body"></p>' +
      '<div class="callout callout-info" id="nt-why"></div></div>' +

      /* ---- COMPLAINTS ---- */
      '<div class="card"><h2 id="cp-head"></h2><p id="cp-body"></p>' +
      '<p id="cp-cfpb"></p><p class="muted" id="cp-state"></p>' +
      '<p id="cp-ftc"></p><p id="cp-ag"></p>' +
      '<div class="callout callout-info" id="cp-angle"></div>' +
      '<div class="btn-row">' + X.a("CFPB complaint ↗", L.COMPLAINTS.urls.cfpb, "btn btn-sm") +
      X.a("FTC ↗", L.COMPLAINTS.urls.ftc) + X.a("Louisiana AG ↗", L.COMPLAINTS.urls.ag) + '</div></div>' +

      /* ---- GUARDRAIL ---- */
      '<div class="card danger"><h2 id="gd-head2"></h2><p id="gd-body2"></p>' +
      '<div class="callout callout-warn" id="gd-not"></div>' +
      '<p class="muted" id="gd-why"></p>' +
      '<div class="callout callout-info" id="gd-urgent"></div></div>' +

      /* ---- delegation cross-link ---- */
      '<div class="card"><h3>Who represents Louisiana on this</h3>' +
      '<p>The federal agency that would supervise Louisiana’s larger collectors is the CFPB, and how Louisiana’s congressional delegation has voted on it is public record. The Record tab carries one member’s complete roll call, with the counter-evidence alongside it.</p>' +
      '<div class="btn-row"><button class="btn btn-sm" data-goto="account">Open the record →</button></div></div>' +

      /* ---- sources ---- */
      '<h2>Every source on this page</h2>' +
      '<div class="card"><p class="muted">Each claim above links to the article it came from. The full list, so you can check any of it without hunting.</p>' +
      '<div id="sr-list" class="link-list"></div></div>' +

      '<p class="disclaimer">Legal information, not legal advice. Clapback is not a law firm and no attorney-client relationship is formed by reading this. Louisiana law changes and this page may be out of date — every statute is linked so you can check the current text yourself. Deadlines are fact-specific and short. If you have been served, speak to a Louisiana attorney immediately. Verified ' + X.esc(L.UPDATED) + '.</p>';

    renderStatic();
    load();
  }

  function renderStatic() {
    var D = L.DEADLINE;
    X.$("#ur-body").textContent = "The clock started when you were served, and in Louisiana it is shorter than almost everything written about it. Before anything else, find out which court you are in — that single fact changes your deadline from 21 days to 10.";
    X.$("#ur-urgent").innerHTML = "<strong>Do not wait to find a lawyer before finding your deadline.</strong> Read the court name on your papers, then call that court's clerk and ask when your answer is due. That call is free, takes minutes, and clerks answer this question every day.";

    var I = L.INTRO;
    X.$("#in-head").textContent = I.head;
    X.$("#in-body").textContent = I.body;
    X.$("#in-vocab").innerHTML = I.vocab.map(function (v) {
      return "<tr><td>" + X.esc(v.them) + '</td><td class="num">' + X.esc(v.us) + "</td></tr>";
    }).join("");
    X.$("#in-stakes").innerHTML = "<strong>What that costs a real person.</strong> " + X.esc(I.stakes);

    X.$("#ladl-head").textContent = D.head;
    var T = D.trap;
    X.$("#latrap-head").textContent = T.head;
    X.$("#latrap-body").textContent = T.body;
    X.$("#latrap-what").textContent = T.what;
    X.$("#latrap-do").innerHTML = "<strong>What to do about it.</strong> " + X.esc(T.do) +
      " <span class='muted'>(" + X.esc(T.cite) + ")</span> " + X.a("The article ↗", T.url);

    X.$("#ladl-summary").innerHTML = "<strong>" + X.esc(D.summary) + "</strong>";
    X.$("#ladl-honest").textContent = D.honest;

    var W = D.wrongQuestion;
    X.$("#wq-head").textContent = W.head;
    X.$("#wq-body").textContent = W.body;
    X.$("#wq-right").innerHTML = "<strong>The question that works instead.</strong> " + X.esc(W.right);

    X.$("#ct-pick").addEventListener("click", function (e) {
      var c = e.target.closest(".chip"); if (!c) return;
      X.$$("#ct-pick .chip").forEach(function (x) { x.classList.toggle("active", x === c); });
      courtPick = c.dataset.court;
      renderCourt();
    });
    renderCourt();

    /* city court limits */
    X.$("#cl-list").innerHTML = L.CITY_LIMITS.map(function (t) {
      return '<div class="law-card"><div class="law-head"><div class="law-name">Up to ' + X.esc(t.amt) + '</div></div>' +
        '<p>' + t.cities.map(function (c) { return '<span class="tag tag-plain">' + X.esc(c) + "</span>"; }).join(" ") + "</p></div>";
    }).join("");
    X.$("#cl-note").textContent = L.CITY_LIMITS_NOTE;
    X.$("#cl-caveat").innerHTML = "<strong>One thing Clapback is not certain about.</strong> " + X.esc(L.CITY_LIMITS_CAVEAT);

    /* prescription */
    var P = L.PRESCRIPTION;
    X.$("#lapr-head").textContent = P.head;
    X.$("#lapr-lead").textContent = P.lead;
    X.$("#lapr-rows").innerHTML = P.rows.map(function (r) {
      return "<tr><td>" + X.esc(r.t) + (r.flag ? ' <span class="status-pill pill-amber">read the note</span>' : "") +
        '</td><td class="num">' + X.esc(r.y) + "</td><td>" + X.a(X.esc(r.c), r.u) + "</td></tr>";
    }).join("");
    var pn = X.$("#lapr-notes"); pn.innerHTML = "";
    P.rows.filter(function (r) { return r.n; }).forEach(function (r) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", r.t));
      l.appendChild(X.el("div", "li-note", r.n));
      row.appendChild(l);
      pn.appendChild(row);
    });

    var R = P.residualTrap;
    X.$("#rt-head").textContent = R.head;
    X.$("#rt-body").textContent = R.body;
    X.$("#rt-why").innerHTML = "<strong>Why it matters to you.</strong> " + X.esc(R.why);

    var C = P.cardCaution;
    X.$("#cc-head").textContent = C.head;
    X.$("#cc-body").textContent = C.body;
    X.$("#cc-detail").textContent = C.detail;
    X.$("#cc-arg").innerHTML = "<strong>The argument you may have to answer.</strong> " + X.esc(C.argument);

    var IT = P.interruption;
    X.$("#it-head").textContent = IT.head;
    X.$("#it-body").textContent = IT.body;
    X.$("#it-warn").innerHTML = "<strong>The $20 mistake.</strong> " + X.esc(IT.warn);
    X.$("#it-renounce").textContent = IT.renounce;

    /* defences */
    var dl = X.$("#df-list"); dl.innerHTML = "";
    L.DEFENCES.forEach(function (d) {
      var card = X.el("div", "card");
      card.appendChild(X.el("h3", null, d.n));
      card.appendChild(X.el("div", "law-eff", d.cite));
      card.appendChild(X.el("p", null, d.body));
      if (d.cutoff) {
        var cu = X.el("div", "callout callout-warn");
        cu.innerHTML = "<strong>The timing is the whole point.</strong> " + X.esc(d.cutoff);
        card.appendChild(cu);
      }
      if (d.exception) {
        card.appendChild(X.el("h4", null, d.exception.head));
        card.appendChild(X.el("p", null, d.exception.body));
        var pr = X.el("div", "callout callout-info");
        pr.innerHTML = "<strong>Stated precisely.</strong> " + X.esc(d.exception.precise);
        card.appendChild(pr);
      }
      if (d.honest) {
        card.appendChild(X.el("h4", null, d.honest.head));
        var ho = X.el("div", "callout callout-warn");
        ho.innerHTML = "<strong>Scope.</strong> " + X.esc(d.honest.scope) +
          "<br><br><strong>And it is untested.</strong> " + X.esc(d.honest.untested);
        card.appendChild(ho);
      }
      if (d.why) card.appendChild(X.el("p", "muted", d.why));
      if (d.practical) {
        var p2 = X.el("div", "callout callout-info");
        p2.innerHTML = "<strong>What that means in practice.</strong> " + X.esc(d.practical);
        card.appendChild(p2);
      }
      var row = X.el("div", "btn-row");
      row.innerHTML = X.a("The statute ↗", d.url, "btn btn-sm");
      card.appendChild(row);
      dl.appendChild(card);
    });

    /* registration */
    var RG = L.REGISTRATION;
    X.$("#rg-head").textContent = RG.head;
    X.$("#rg-body").innerHTML = X.esc(RG.body) + " <span class='muted'>(" + X.esc(RG.cite) + ")</span> Secretary of State: <strong>" + X.esc(RG.sosPhone) + "</strong>";
    X.$("#rg-guard").innerHTML = "<strong>" + X.esc(RG.guardrail.head) + ".</strong> " + X.esc(RG.guardrail.body) + " " + X.esc(RG.guardrail.use);
    X.$("#rg-verify").textContent = RG.verify;
    X.$("#rg-ag").textContent = RG.ag;

    /* fees */
    var F = L.FEES;
    X.$("#fe-head").textContent = F.head;
    X.$("#fe-body").textContent = F.body;
    X.$("#tj-head").textContent = F.tejero.head;
    X.$("#tj-body").textContent = F.tejero.body;
    X.$("#tj-status").textContent = F.tejero.status + " " + F.tejero.cite;
    X.$("#fe-ask").innerHTML = "<strong>Ask this, in these words.</strong> " + X.esc(F.ask);

    var LU = F.lutpa;
    X.$("#lalutpa-head").textContent = LU.head;
    X.$("#lalutpa-body").textContent = LU.body;
    X.$("#lalutpa-real").innerHTML = "<strong>What it is actually good for.</strong> " + X.esc(LU.real);
    X.$("#lalutpa-limits").textContent = LU.limits;
    X.$("#lalutpa-unsettled").innerHTML = "<strong>An unsettled point, flagged rather than smoothed over.</strong> " + X.esc(LU.unsettled);

    /* help */
    var H = L.HELP;
    X.$("#lahp-head").textContent = H.head;
    X.$("#lahp-body").textContent = H.body;
    X.$("#lahp-orgs").innerHTML = H.orgs.map(function (o) {
      return '<div class="law-card"><div class="law-head"><div class="law-name">' + X.esc(o.n) + '</div>' +
        '<span class="status-pill pill-ban">' + X.esc(o.cov) + '</span></div>' +
        '<div style="font-size:19px;font-weight:800;margin:6px 0">' + X.esc(o.phone) + '</div>' +
        (o.hours ? '<p class="muted">' + X.esc(o.hours) + "</p>" : "") +
        "<p>" + o.offices.map(function (x) { return '<span class="tag tag-plain">' + X.esc(x) + "</span>"; }).join(" ") + "</p>" +
        '<div class="law-eff">' + X.esc(o.elig) + "</div>" +
        '<div class="btn-row">' + X.a("Their site ↗", o.u, "btn btn-sm") + "</div></div>";
    }).join("");

    X.$("#lalsnl-head").textContent = H.lsnl.head;
    X.$("#lalsnl-body").textContent = H.lsnl.body;
    X.$("#lalsnl-honest").textContent = H.lsnl.honest;

    var ho2 = X.$("#lahp-other"); ho2.innerHTML = "";
    H.other.forEach(function (o) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", o.n));
      l.appendChild(X.el("div", "li-note", o.t));
      row.appendChild(l);
      var a = X.el("div"); a.innerHTML = X.a("Open ↗", o.u, "btn btn-sm");
      row.appendChild(a);
      ho2.appendChild(row);
    });
    X.$("#lahp-bar").textContent = H.bar;

    X.$("#nt-head").textContent = H.noTable.head;
    X.$("#nt-body").textContent = H.noTable.body;
    X.$("#nt-why").innerHTML = "<strong>Why that is the right call.</strong> " + X.esc(H.noTable.why);

    /* complaints */
    var CP = L.COMPLAINTS;
    X.$("#cp-head").textContent = CP.head;
    X.$("#cp-body").textContent = CP.body;
    X.$("#cp-cfpb").textContent = CP.cfpb;
    X.$("#cp-state").textContent = CP.cfpbState;
    X.$("#cp-ftc").textContent = CP.ftc;
    X.$("#cp-ag").textContent = CP.ag;
    X.$("#cp-angle").innerHTML = "<strong>" + X.esc(CP.angle) + "</strong>";

    /* guardrail */
    var G = L.GUARDRAIL;
    X.$("#gd-head2").textContent = G.head;
    X.$("#gd-body2").textContent = G.body;
    X.$("#gd-not").innerHTML = "<strong>What it will not do.</strong> " + X.esc(G.not);
    X.$("#gd-why").textContent = G.why;
    X.$("#gd-urgent").innerHTML = "<strong>If you have been served.</strong> " + X.esc(G.urgent);

    /* sources */
    var sl = X.$("#sr-list"); sl.innerHTML = "";
    L.SOURCES.forEach(function (s) {
      var row = X.el("div", "link-item");
      var l = X.el("div");
      l.appendChild(X.el("div", "li-main", s.n));
      row.appendChild(l);
      var a = X.el("div"); a.innerHTML = X.a("Read it ↗", s.u, "btn btn-sm");
      row.appendChild(a);
      sl.appendChild(row);
    });
  }

  function renderCourt() {
    var out = X.$("#ct-out"); if (!out) return;
    if (!courtPick) {
      out.innerHTML = '<p class="muted">Pick a court above and Clapback will show the article that governs your answer deadline there, and what that court can hear.</p>';
      return;
    }
    var c = L.DEADLINE.courts.filter(function (x) { return x.id === courtPick; })[0];
    if (!c) { out.innerHTML = ""; return; }
    var band = c.days <= 10 ? "risk-high" : "risk-caution";
    out.innerHTML =
      '<div class="risk-banner ' + band + '"><div class="risk-ic">' + c.days + '</div><div>' +
      '<div class="risk-label">' + X.esc(c.n) + ' — ' + c.days + ' days to answer.</div>' +
      '<div class="risk-sub">' + X.esc(c.rule) + '</div>' +
      '</div></div>' +
      (c.quote ? '<div class="callout callout-info" style="margin-top:12px"><em>&ldquo;' + X.esc(c.quote) + '&rdquo;</em> <span class="muted">— ' + X.esc(c.cite) + '</span></div>' : "") +
      '<p><strong>Who is in this court:</strong> ' + X.esc(c.who) + '</p>' +
      (c.extra ? '<p class="muted">' + X.esc(c.extra) + "</p>" : "") +
      '<div class="btn-row">' + X.a("Read " + X.esc(c.cite) + " ↗", c.url, "btn btn-sm") + '</div>' +
      '<div class="callout callout-warn" style="margin-top:12px"><strong>Confirm it with the clerk anyway.</strong> ' +
      'Clapback is showing you which article governs, not counting your days. Service method, holidays and the exact date of service all move the real deadline, and the citation you were handed may print a different number. One phone call to the clerk of the court named on your papers settles it.</div>';
  }

  function load() {
    X.profile().then(function (p) { prof = p; showBanner(); });
  }
  function refresh() { load(); }

  /* If the user's profile says Louisiana, say so. If it doesn't, this tab is
     still readable — it just says who it is for. */
  function showBanner() {
    var b = X.$("#ur-body"); if (!b) return;
    if (prof.state && prof.state !== "LA") {
      var note = X.$("#in-stakes");
      if (note && !X.$("#la-notyours")) {
        var d = X.el("div", "callout callout-info");
        d.id = "la-notyours";
        d.innerHTML = "<strong>Your profile says " + X.esc(X.stateName(prof.state)) + ", not Louisiana.</strong> " +
          "This tab is Louisiana-specific and most of it does not transfer — the vocabulary, the deadlines and the prescription periods are all different where you are. The Court kit tab covers your state. Read on if you are helping someone in Louisiana.";
        note.parentNode.insertBefore(d, note.nextSibling);
      }
    }
  }

  X.bootstrap("louisiana", mount);
})();

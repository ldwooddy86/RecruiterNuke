/*
 * Clapback — Louisiana debt defense dataset  (window.CBLA)
 *
 * Louisiana is the one state where national debt-collection advice is not
 * merely incomplete but actively wrong, because Louisiana is a civil-law
 * jurisdiction and every 50-state table is built on common-law categories.
 * "Statute of limitations" is prescription. "County" is parish. "Motion to
 * dismiss" is a peremptory exception. And the answer deadline that every
 * ranking page reports — 21 days — is the DISTRICT court deadline. In a city,
 * parish, or justice of the peace court it is TEN.
 *
 * Everything here was verified against legis.la.gov or the published opinion
 * on August 23, 2026. Where a claim could not be verified it says so on the
 * card rather than being quietly dropped or quietly asserted.
 *
 * Six things a first draft of this file would have got wrong, corrected
 * against primary sources and recorded here so they are not reintroduced:
 *   1. C.C.P. arts. 1702(D) and 4904(D) are DISCRETIONARY — the court MAY
 *      raise prescription. The plaintiff's prima facie burden attaches only
 *      after the court raises it, not automatically.
 *   2. R.S. 9:3534.1(E) is written for a collection agency suing on "the debt
 *      of a client or customer." Whether it reaches a debt BUYER suing on
 *      paper it owns is textually doubtful and entirely untested.
 *   3. R.S. 10:3-118 is not a flat five years — unaccepted drafts run three.
 *   4. Justia's text of art. 4843 is stale; it lacks Acts 2026 No. 50.
 *   5. No publishable parish-by-parish legal aid table exists. Every
 *      third-party list contradicts the organizations' own counts.
 *   6. First Nat'l Bank of Commerce v. Band APPLIED the open-account period
 *      to a credit card. It did not hold that credit cards are open accounts.
 *
 * This tab explains what the rules are and when they apply. It does not tell
 * anyone which pleading to file, in what order, or what to put in it. That
 * line is deliberate.
 *
 * Verified August 23, 2026. Legal information, not legal advice.
 */
window.CBLA = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  var INTRO = {
    head: "Why national advice gets Louisiana wrong",
    body: "Louisiana is the only civil-law state in the country. Its procedure descends from the Napoleonic Code rather than English common law, and almost every national debt-collection guide is built on common-law categories that simply do not exist here. That is not a stylistic difference. It produces a specific, checkable error on the single most time-critical fact in a collection lawsuit.",
    vocab: [
      { them: "Statute of limitations", us: "Prescription" },
      { them: "County", us: "Parish" },
      { them: "Motion to dismiss", us: "Peremptory exception" },
      { them: "Written vs. oral contract split", us: "No such split — the category is the type of claim" }
    ],
    stakes: "Every top-ranking page for Louisiana debt questions reports a 21-day answer deadline. That is correct for district court and wrong for every court of limited jurisdiction in the state, where the deadline is ten days. Two of those pages also contradict each other on how long a medical debt lasts."
  };

  /* ================================================================== */
  /* THE DEADLINE — the highest-stakes fact on the page                  */
  /* ================================================================== */
  var DEADLINE = {
    head: "Your answer deadline depends on which court, and it is probably not 21 days",
    courts: [
      {
        id: "district",
        n: "District Court",
        days: 21,
        rule: "21 days after service of citation — 30 days if the plaintiff filed and served a discovery request along with the petition.",
        cite: "La. C.C.P. art. 1001",
        url: "https://www.legis.la.gov/legis/law.aspx?d=111105",
        quote: "A defendant shall file his answer within twenty-one days after service of citation upon him, except as otherwise provided by law.",
        who: "Louisiana's 42 judicial districts. This is the default court — it has original jurisdiction over all civil matters, so if no court of limited jurisdiction covers your case, you are here.",
        extra: "If an exception is filed before answer and is overruled or referred to the merits, the answer is then due 15 days after that ruling. The court may also grant additional time."
      },
      {
        id: "city",
        n: "City Court",
        days: 10,
        rule: "10 days after service of citation — 15 days if you were served through the Secretary of State.",
        cite: "La. C.C.P. art. 4903",
        url: "https://www.legis.la.gov/legis/Law.aspx?d=112112",
        quote: "The defendant shall answer within ten days of the service of citation, except that when the citation is served through the secretary of state, the delay, as to all defendants, shall be fifteen days after service.",
        who: "Roughly 46 to 50 city courts statewide. Civil jurisdiction runs from $15,000 to $50,000 depending on the city, which covers most consumer collection suits.",
        extra: "Article 4903 sits in Book VIII of the Code of Civil Procedure. Article 4831 provides that Book VIII governs trial courts of limited jurisdiction and that the rest of the Code applies only where Book VIII does not otherwise provide. It does otherwise provide. That is the mechanism by which 10 displaces 21."
      },
      {
        id: "parish",
        n: "Parish Court",
        days: 10,
        rule: "10 days after service of citation — 15 days if served through the Secretary of State. Same article as city court.",
        cite: "La. C.C.P. art. 4903",
        url: "https://www.legis.la.gov/legis/Law.aspx?d=112112",
        who: "There are only three parish courts in the entire state: the First and Second Parish Courts of Jefferson Parish, and the Parish Court of Ascension Parish. Civil jurisdiction up to $20,000 (art. 4842).",
        extra: "If you are not in Jefferson or Ascension, you do not have a parish court. This is the smallest category and the one most often confused with district court because of the word “parish.”"
      },
      {
        id: "jp",
        n: "Justice of the Peace Court",
        days: 10,
        rule: "10 days after service of citation — 15 days if served through the Secretary of State.",
        cite: "La. C.C.P. art. 4920",
        url: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4920/",
        who: "Civil jurisdiction up to $5,000, exclusive of interest, court costs, attorney fees and penalties (art. 4911).",
        extra: "Most Louisiana guides omit JP courts entirely. The ten-day rule reaches them too — so it covers every court of limited jurisdiction in the state, not just city courts."
      }
    ],
    summary: "Ten days is the rule in every Louisiana court of limited jurisdiction. Twenty-one is the district court rule. National content reports only the twenty-one.",
    /* The single most useful warning on this page. */
    trap: {
      head: "Do not trust the deadline printed on your citation",
      body: "This is the trap, and it is written into the Code. La. C.C.P. art. 1202(5) requires a citation to state that the defendant must appear “within the delay provided in Article 1001” — the twenty-one-day article. A city court citation that uses the standard form language therefore points you at 21 days when your actual deadline is 10.",
      what: "So the number printed on the paper can be wrong for your own case. What is reliable is the court NAME, which art. 1202(4) also requires the citation to carry.",
      do: "Read the name of the court at the top of the citation and the petition. If it says City Court, Parish Court, or Justice of the Peace Court, work from ten days and call the clerk of that court to confirm. If it says Judicial District Court, work from twenty-one. When the printed delay and the court name disagree, the court name is the one that tells you which rule applies.",
      cite: "La. C.C.P. art. 1202",
      url: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-1202/"
    },
    /* Correcting the widely repeated framing. */
    wrongQuestion: {
      head: "“Does my parish have a city court?” is the wrong question",
      body: "It is the question most Louisiana guides pose, and it produces wrong answers. A city court's territorial jurisdiction is limited to its municipality or ward. If you live in a parish that HAS a city court but you live outside that city's limits, you are sued in district court anyway. And most parishes have no city court at all, so district court applies there.",
      right: "The question that actually works is: what court is named on the papers you were served? That is a fact you can read, not a rule you have to look up."
    },
    honest: "Clapback will not calculate your deadline for you, because doing that requires knowing your service date, your service method, and your court — and being wrong by a day here is a default judgment. What it will do is tell you which rule governs which court, and quote the article so you can check it. Then call the clerk of the court named on your papers. That call is free and clerks answer this question routinely."
  };

  /* Per-city jurisdictional tiers, La. C.C.P. art. 4843, current through
     Acts 2026 No. 50. Source: legis.la.gov. Justia's copy is stale. */
  var CITY_LIMITS = [
    { amt: "$50,000", cities: ["Alexandria", "Bogalusa", "East St. Tammany", "Hammond", "Lake Charles", "Pineville", "Ruston", "Sulphur", "Third Ward City Court of Franklin"] },
    { amt: "$35,000", cities: ["Abbeville", "Baker", "Baton Rouge", "Crowley", "Kaplan", "Lafayette", "Leesville", "Minden", "Plaquemine", "Rayne", "Shreveport", "Springhill", "Zachary"] },
    { amt: "$30,000", cities: ["Breaux Bridge", "Houma", "Jeanerette", "Jennings", "Monroe", "New Iberia", "Oakdale", "Winnfield"] },
    { amt: "$25,000", cities: ["Bastrop", "Bunkie", "Eunice", "Marksville", "Natchitoches", "New Orleans", "Opelousas", "Port Allen", "Ville Platte", "Winnsboro"] },
    { amt: "$15,000", cities: ["Bossier City", "All other city courts — the general rule, and cities under 50,000 population"] }
  ];
  var CITY_LIMITS_NOTE = "La. C.C.P. art. 4843, current through Acts 2026 No. 50, which moved Bogalusa up to $50,000 in June 2026. The tiers are written into the article by name, city by city. Clapback took this from legis.la.gov because Justia's copy of this article is a year behind and does not have the 2026 change.";
  var CITY_LIMITS_URL = "https://www.legis.la.gov/legis/Law.aspx?d=112087";
  var CITY_LIMITS_CAVEAT = "One residual uncertainty Clapback will state rather than hide: in the current legislative text, Bogalusa appears to be listed in both the $25,000 and the $50,000 subsections, which is likely an artifact of how the 2026 amendment was engrossed. If you are in Bogalusa City Court, confirm the limit with the clerk.";

  /* ================================================================== */
  /* PRESCRIPTION — Louisiana's statute of limitations                   */
  /* ================================================================== */
  var PRESCRIPTION = {
    head: "How long a Louisiana debt lasts",
    lead: "Louisiana calls this prescription, and the periods are shorter than most national tables report. Two of the pages currently ranking for this question contradict each other, and at least one applies a written-versus-oral contract split that does not exist in Louisiana law.",
    rows: [
      { t: "Open account — including credit cards", y: "3 years", c: "La. Civ. Code art. 3494(4)", u: "https://law.justia.com/codes/louisiana/civil-code/article-3494/", flag: true,
        n: "This is the category most consumer debt falls into. See the caution below on credit cards specifically." },
      { t: "Money lent", y: "3 years", c: "La. Civ. Code art. 3494(3)", u: "https://law.justia.com/codes/louisiana/civil-code/article-3494/" },
      { t: "Compensation for services rendered", y: "3 years", c: "La. Civ. Code art. 3494(1)", u: "https://law.justia.com/codes/louisiana/civil-code/article-3494/" },
      { t: "Arrearages of rent", y: "3 years", c: "La. Civ. Code art. 3494(2)", u: "https://law.justia.com/codes/louisiana/civil-code/article-3494/" },
      { t: "Promissory notes and other instruments, negotiable or not", y: "5 years", c: "La. Civ. Code art. 3498", u: "https://law.justia.com/codes/louisiana/civil-code/article-3498/",
        n: "Runs from the day payment is exigible." },
      { t: "Notes under Louisiana's UCC enactment", y: "3 to 5 years", c: "La. R.S. 10:3-118", u: "https://www.legis.la.gov/legis/Law.aspx?d=74142", flag: true,
        n: "Five years for a note payable at a definite time, and for a demand note. But an unaccepted draft is three years after dishonour OR five years after the date of the draft, whichever expires first. Not a flat five, and not the six years the generic UCC table would give you." },
      { t: "Everything else — the residual rule", y: "10 years", c: "La. Civ. Code art. 3499", u: "https://law.justia.com/codes/louisiana/civil-code/article-3499/", flag: true,
        n: "READ THE CAUTION. This is a default, not a contracts rule." },
      { t: "Delictual actions (tort)", y: "2 years", c: "La. Civ. Code art. 3493.1", u: "https://www.legis.la.gov/Legis/Law.aspx?d=1386443", flag: true,
        n: "Changed from one year to two by Acts 2024 No. 423, effective July 1, 2024. Reported as prospective only, so a claim that arose before that date probably keeps the one-year period — Clapback could not confirm the prospectivity language against the act text itself." }
    ],
    residualTrap: {
      head: "The ten-year figure is the most commonly miscited number in Louisiana debt law",
      body: "Article 3499 is titled “Personal action” and reads, in full: “Unless otherwise provided by legislation, a personal action is subject to a liberative prescription of ten years.” It is a residual — it applies only when nothing else does. Articles 3494 and 3498 ARE legislation otherwise providing, so an open account or a promissory note never reaches article 3499.",
      why: "A national legal site currently ranking for this query presents article 3499 as the rule for written contracts, on the common-law assumption that written and oral contracts get different periods. Louisiana draws no such distinction. A collector who tells you your credit card debt has ten years is relying on that error."
    },
    cardCaution: {
      head: "On credit cards specifically, state it as “generally” and know why",
      body: "Credit card debt is generally treated as an open account, which makes it three years. That is settled practice rather than a squarely decided question, and the distinction matters if a collector fights you on it.",
      detail: "First National Bank of Commerce v. Band (La. App. 4 Cir. 1998) APPLIED the three-year open-account period to a credit card debt and found the suit prescribed. But it assumed the classification rather than analysing it. A 2026 Third Circuit decision, Capital One v. Danzy, likewise describes a credit card suit as one on open account without controversy. Good evidence of how courts actually treat it — not a holding on the point.",
      argument: "The counter-argument collectors make is that a signed cardholder agreement turns the debt into a written contract carrying ten years under article 3499. The residual-rule point above is the answer to that, but be aware it is an argument you may have to make rather than a matter nobody disputes."
    },
    interruption: {
      head: "What restarts the clock — and why a small payment is dangerous",
      body: "Prescription is interrupted when you acknowledge the right of the person prescribing against you (art. 3464). And interruption does not pause the clock — it resets it. Article 3466: “If prescription is interrupted, the time that has run is not counted. Prescription commences to run anew from the last day of interruption.”",
      warn: "That is why a $20 “good faith” payment on an old debt is one of the most expensive things a person can do. It may restart a three-year period from zero on a debt that was weeks from being unenforceable. Partial payment as tacit acknowledgment is jurisprudential rather than spelled out in the article, so say it MAY restart the clock — but treat the risk as real.",
      renounce: "Separately, prescription can be renounced, but only after it has already accrued (art. 3449). And a prescribed debt becomes a natural obligation (art. 1762(1)) — it still exists, it just cannot be enforced by suit. Voluntarily paying one is not recoverable."
    },
    src: "La. Civil Code arts. 3449, 3464, 3466, 3493.1, 3494, 3498, 3499; La. R.S. 10:3-118"
  };

  /* ================================================================== */
  /* THE TWO DEFENCES NATIONAL CONTENT DESCRIBES WRONG                   */
  /* ================================================================== */
  var DEFENCES = [
    {
      n: "Prescription must be pleaded — the court will not do it for you",
      cite: "La. C.C.P. art. 927(B); La. Civ. Code art. 3452",
      url: "https://legis.la.gov/legis/Law.aspx?d=112296",
      body: "In a contested Louisiana case the judge may not notice prescription on its own. Article 927(B) reads: “Except as otherwise provided by Articles 1702(D), 4904(D), and 4921(C), the court shall not supply the objection of prescription, which shall be specially pleaded.” If nobody raises it, a claim that is plainly too old still produces a judgment.",
      exception: {
        head: "The 2021 exception, stated accurately",
        body: "Acts 2021 No. 259 added those three cross-references. Each of them — art. 1702(D) for district court, art. 4904(D) for city and parish court, art. 4921(C) for justice of the peace court — is word-for-word identical, so the rule is uniform across every trial court in the state. Where a default judgment is sought on a claim acquired BY ASSIGNMENT in an open account, promissory note or other negotiable instrument, the court MAY raise prescription on its own before entering the default. If it does, the plaintiff must then present prima facie proof the claim is not barred.",
        precise: "State this precisely. The court's power is discretionary, and it applies only if the grounds appear from the pleadings or from the plaintiff's own evidence. It is not a rule that the plaintiff must always prove non-prescription at default, and Clapback said exactly that in an earlier draft, which was wrong. What the amendment gives you is a court that CAN act — not one that must."
      },
      why: "The practical upshot: this is a defence that exists only if someone raises it, in every contested case."
    },
    {
      n: "The assignment objection has a cutoff — and it may not apply to debt buyers at all",
      cite: "La. R.S. 9:3534.1(E)",
      url: "https://legis.la.gov/Legis/Law.aspx?d=408390",
      body: "The statute reads: “In any suit brought by a collection agency or debt collection to collect the debt of a client or customer, the formal assignment of the debt to such collector shall be presumed valid if a copy of the assignment is filed in court with the petition. If the defendant fails to object to the validity of the assignment prior to the filing of an answer, then the assignment shall be conclusively presumed valid.”",
      cutoff: "The timing is the point. The objection must come BEFORE an answer is filed. Standard national advice — “whatever else you do, file your answer” — can therefore forfeit it, because chain of title is the defence that most often defeats a debt buyer nationally.",
      honest: {
        head: "Two limits Clapback will not paper over",
        scope: "The statute by its terms governs a suit by a collection agency collecting “the debt of a client or customer” — an agency collecting for a creditor it works for. A debt BUYER like Midland, Portfolio Recovery or LVNV sues in its own name on paper it owns outright; there is no client whose debt it is collecting. Whether subsection (E) reaches debt buyers at all is textually doubtful. Clapback's first draft asserted that it did, and that was not supportable.",
        untested: "No reported Louisiana decision applies subsection (E). Not one, across every database searched. “Conclusively presumed valid” is the statute's plain text, not a holding — and the presumption by its own terms attaches only if the assignment was actually filed with the petition."
      },
      practical: "What this means in practice: raising a chain-of-title objection early costs nothing and protects you either way, whether or not (E) turns out to reach your particular plaintiff. Waiting costs you the argument if it does."
    }
  ];

  /* ================================================================== */
  /* THE COLLECTOR                                                       */
  /* ================================================================== */
  var REGISTRATION = {
    head: "Is this collector registered in Louisiana?",
    body: "Collection agencies and debt collectors operating in Louisiana must register with the SECRETARY OF STATE. Not the Office of Financial Institutions — and this trips people up because OFI's own website lists collection agencies while stating plainly, in its own words, “OFI does not regulate Collection Agencies.” People follow that listing and end up at the wrong agency.",
    cite: "La. R.S. 9:3534.1(B)",
    url: "https://legis.la.gov/Legis/Law.aspx?d=408390",
    sosUrl: "https://www.sos.la.gov/BusinessServices/HTMLPages/CollectionAgencyFilingInstructions.htm",
    ofiUrl: "https://ofi.la.gov/non-depository/collection-agencies/",
    sosPhone: "(225) 925-4704",
    guardrail: {
      head: "What a missing registration is, and what it is not",
      body: "The statute specifies NO penalty for failing to register — no fine, no sanction, no bar on suing. And no case makes non-registration a defence to the collection itself.",
      use: "So treat it as evidence and as leverage, never as an automatic win. A collector operating unregistered in Louisiana is a fact worth raising with your own lawyer, with the Attorney General, and in any settlement conversation. It is not a reason to ignore a lawsuit."
    },
    ag: "The Attorney General's Consumer Protection Division takes complaints about collectors: (225) 326-6465 or (800) 351-4889.",
    agUrl: "https://ag.state.la.us/PublicProtection",
    verify: "One caveat on the lookup itself: Clapback has not confirmed that collection agency registrations actually surface in the Secretary of State's public commercial search, as opposed to being filed but not indexed publicly. If a search comes back empty, that may mean unregistered or it may mean not searchable. Call the number above before drawing a conclusion."
  };

  /* ================================================================== */
  /* THE FEE QUESTION                                                    */
  /* ================================================================== */
  var FEES = {
    head: "The fee question Louisiana readers need to ask, and nobody tells them to",
    body: "National content says the collector pays your lawyer if you win an FDCPA claim. In the Fifth Circuit — which is Louisiana, Mississippi and Texas — that is conditional in a way that matters, because most of these cases settle.",
    tejero: {
      head: "Tejero v. Portfolio Recovery Associates",
      body: "The Fifth Circuit held in 2021 that a private settlement is not a “successful action to enforce the foregoing liability” under 15 U.S.C. § 1692k(a)(3), and so does not trigger the statute's fee-shifting. The court defined a successful action as “a lawsuit that generates a favorable end result compelling accountability and legal compliance with a formal command or decree.” Tejero “won no such relief because he settled before his lawsuit reached any end result.”",
      status: "Still good law as of August 2026 — no reversal, no rehearing en banc, no contrary Fifth Circuit authority. It binds federal courts in Louisiana.",
      cite: "Tejero v. Portfolio Recovery Assocs., No. 20-50543 (5th Cir. Apr. 7, 2021)",
      url: "https://www.ca5.uscourts.gov/opinions/pub/20/20-50543-CV0.pdf"
    },
    ask: "One question to put to any lawyer you consult, in these words: if this settles rather than going to judgment, who pays your fee, and does it come out of my recovery? You are entitled to a straight answer before you sign anything.",
    lutpa: {
      head: "LUTPA is an alternative, not an escape hatch",
      body: "The Louisiana Unfair Trade Practices Act makes attorney fees mandatory — but only conditionally. R.S. 51:1409 says fees are awarded “in the event that damages are awarded under this Section.” A private settlement produces no awarded damages, so LUTPA carries the same structural gap as Tejero rather than curing it.",
      real: "Its genuine advantages are different: treble damages where the defendant continued the conduct after Attorney General notice, and reach into conduct the FDCPA does not cover.",
      limits: "Three limits to know. It bars class actions — the statute permits suit “individually but not in a representative capacity.” R.S. 51:1406(1) exempts federally insured financial institutions and OFI licensees, so LUTPA generally reaches an unregulated third-party collector or debt buyer but not a bank collecting its own paper. And the fee provision runs both ways: a court may award fees against you if it finds the action groundless and brought in bad faith or for harassment.",
      unsettled: "Its limitation period is one year. Whether that period is prescriptive (can be interrupted or suspended) or peremptive (cannot) is a live split the Louisiana Supreme Court has not resolved. Treat one year as a hard deadline.",
      url: "https://legis.la.gov/Legis/Law.aspx?d=104033"
    }
  };

  /* ================================================================== */
  /* HELP                                                                */
  /* ================================================================== */
  var HELP = {
    head: "Free and low-cost legal help",
    body: "Two organisations cover all 64 parishes between them. Clapback deliberately does NOT publish a parish-by-parish lookup — see the note below — so the reliable move is to call the intake line for whichever covers your part of the state, and if you get the wrong one they will redirect you.",
    orgs: [
      {
        n: "Acadiana Legal Service Corporation",
        cov: "42 parishes — north, central and southwest Louisiana",
        phone: "1-866-ASK-ALSC · 1-866-275-2572",
        hours: "Intake Monday, Tuesday, Wednesday 9am–12pm; Thursday 1pm–3pm",
        offices: [
          "Lafayette — 1020 Surrey Street",
          "Lake Charles — 2911 Ryan Street",
          "Shreveport — 720 Travis Street",
          "Monroe — 3016 Cameron Street",
          "Alexandria — 1808 Jackson Street",
          "Natchitoches — 134 St. Denis Street",
          "Franklin — 1407 Barrow Street, Suite H-1"
        ],
        u: "https://www.la-law.org/",
        elig: "Generally 125% of federal poverty guidelines, some cases to 200%, and age 60 and over to 400%."
      },
      {
        n: "Southeast Louisiana Legal Services",
        cov: "22 parishes — southeast Louisiana",
        phone: "(877) 521-6242",
        offices: [
          "New Orleans — 1340 Poydras Street, Suite 600 · (504) 529-1000",
          "Baton Rouge", "Covington", "Gretna", "Hahnville", "Hammond", "Houma"
        ],
        u: "https://slls.org/en/",
        elig: "Generally 125% of federal poverty guidelines."
      }
    ],
    lsnl: {
      head: "If you were given a number for Legal Services of North Louisiana",
      body: "Acadiana Legal Service Corporation now serves north Louisiana and runs the Shreveport office at 720 Travis Street — the address LSNL used. Several directories, including Yelp and some legal referral sites, still list LSNL as a live separate organisation, which means people are making dead calls.",
      honest: "Clapback found no primary source documenting a formal merger or dissolution, so it describes this as ALSC now serving the territory rather than asserting LSNL no longer exists. Either way, the number to call is ALSC's."
    },
    other: [
      { n: "LSBA Modest Means", t: "Screens up to 400% of federal poverty guidelines — far more generous than legal aid's usual ceiling, and badly underused.", u: "https://www.lsba.org/Public/FindLegalHelp/ModestMeans.aspx" },
      { n: "Louisiana Free Legal Answers", t: "Post a civil legal question online and a volunteer Louisiana lawyer answers it. Free.", u: "https://louisiana.freelegalanswers.org/" },
      { n: "Baton Rouge Bar referral", t: "$50 for a 30-minute consultation.", u: "https://www.brba.org/" },
      { n: "New Orleans Bar referral", t: "$75 for an hour.", u: "https://www.neworleansbar.org/" },
      { n: "NACA — consumer attorneys", t: "National directory of consumer-side lawyers. Filter for Louisiana.", u: "https://www.consumeradvocates.org/findanattorney/" },
      { n: "LouisianaLawHelp.org", t: "The state's legal aid portal. Useful, though parts of it have not been updated since 2023.", u: "https://louisianalawhelp.org/find-legal-help" }
    ],
    noTable: {
      head: "Why there is no parish lookup here",
      body: "Clapback tried to build one and could not do it honestly. Neither organisation publishes an enumerated parish list. The third-party lists that do exist contradict both the organisations' own counts and each other — one names 31 parishes for an organisation that says it covers 42, another says “20 parishes” while listing 23, and at least one parish appears on both lists.",
      why: "A wrong parish assignment sends someone to the wrong intake line during a ten-day deadline, and most people do not call twice. Two phone numbers and an instruction to call is worse product design and better advice."
    },
    bar: "One more correction worth carrying: the Louisiana State Bar Association runs no statewide referral service, and its Find an Attorney page points only to the Lafayette Bar. Do not conclude that is your only option — the Baton Rouge and New Orleans bars both run their own."
  };

  /* ================================================================== */
  /* COMPLAINTS                                                          */
  /* ================================================================== */
  var COMPLAINTS = {
    head: "Filing a complaint: what actually happens",
    body: "Every other site tells you to file a complaint and implies something will come of it. Here is the honest version, which is more useful.",
    cfpb: "The CFPB portal works, takes about ten minutes, and creates a dated federal record. That record is genuinely useful later as evidence of what you reported and when. What it is unlikely to do is resolve your case: of roughly 5.4 million complaints closed in 2025, under 1% produced monetary relief and 53% closed with an explanation and nothing else.",
    cfpbState: "The Bureau's own enforcement posture has narrowed considerably, and in August 2026 it announced it will stop discretionary publication of complaint narratives and visualisations. The database itself remains; prior narratives move to the FOIA reading room.",
    ftc: "The FTC is currently the more active federal enforcer on debt collection.",
    ag: "The Louisiana Attorney General forwards complaints and states outright that it cannot act as your attorney. Describe that as mediation, not enforcement.",
    angle: "File it — but file it as evidence, not as a remedy. That is the opposite of what most sites say and it is the accurate version.",
    urls: {
      cfpb: "https://www.consumerfinance.gov/complaint/",
      ftc: "https://reportfraud.ftc.gov/",
      ag: "https://ag.state.la.us/PublicProtection"
    }
  };

  var GUARDRAIL = {
    head: "What this tab does and does not do",
    body: "It explains what the Louisiana rules are, which court each applies in, and what each pleading is. It quotes the article so you can check it.",
    not: "It does not tell you which pleading to file, in what order, or what to write in it. It does not calculate your deadline, screen your case, or generate a document with your details merged into it. Applying law to one person's specific facts is what a lawyer does, and in Louisiana it is also what the unauthorised-practice statute reaches.",
    why: "That boundary is not caution for its own sake. A tool that guesses wrong about your deadline or your defence does more damage than one that hands you the rule and the clerk's phone number.",
    urgent: "If you have been served, the useful sequence is: read the court name on your papers, call that court's clerk to confirm your deadline, and call legal aid the same day. Ten days is not long."
  };

  var SOURCES = [
    { n: "La. C.C.P. art. 1001 — answer, district court", u: "https://www.legis.la.gov/legis/law.aspx?d=111105" },
    { n: "La. C.C.P. art. 4903 — answer, city and parish court", u: "https://www.legis.la.gov/legis/Law.aspx?d=112112" },
    { n: "La. C.C.P. art. 4920 — answer, justice of the peace court", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4920/" },
    { n: "La. C.C.P. art. 4831 — scope of Book VIII", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4831/" },
    { n: "La. C.C.P. art. 1202 — form of citation", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-1202/" },
    { n: "La. C.C.P. art. 4843 — city court jurisdiction", u: "https://www.legis.la.gov/legis/Law.aspx?d=112087" },
    { n: "La. C.C.P. art. 4842 — parish court jurisdiction", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4842/" },
    { n: "La. C.C.P. art. 4911 — justice of the peace jurisdiction", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4911/" },
    { n: "La. C.C.P. art. 927 — peremptory exceptions", u: "https://legis.la.gov/legis/Law.aspx?d=112296" },
    { n: "La. C.C.P. art. 1702 — default judgment, district", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-1702/" },
    { n: "La. C.C.P. art. 4904 — default, city and parish", u: "https://www.legis.la.gov/legis/law.aspx?d=112113" },
    { n: "La. C.C.P. art. 4921 — default, justice of the peace", u: "https://law.justia.com/codes/louisiana/code-of-civil-procedure/article-4921/" },
    { n: "La. Civ. Code art. 3452 — prescription must be pleaded", u: "https://law.justia.com/codes/louisiana/civil-code/article-3452/" },
    { n: "La. Civ. Code art. 3494 — three-year prescription", u: "https://law.justia.com/codes/louisiana/civil-code/article-3494/" },
    { n: "La. Civ. Code art. 3498 — instruments, five years", u: "https://law.justia.com/codes/louisiana/civil-code/article-3498/" },
    { n: "La. Civ. Code art. 3499 — residual ten years", u: "https://law.justia.com/codes/louisiana/civil-code/article-3499/" },
    { n: "La. Civ. Code art. 3493.1 — delictual, two years", u: "https://www.legis.la.gov/Legis/Law.aspx?d=1386443" },
    { n: "La. Civ. Code art. 3464 — interruption", u: "https://law.justia.com/codes/louisiana/civil-code/article-3464/" },
    { n: "La. Civ. Code art. 3466 — effect of interruption", u: "https://law.justia.com/codes/louisiana/civil-code/article-3466/" },
    { n: "La. Civ. Code art. 3449 — renunciation", u: "https://law.justia.com/codes/louisiana/civil-code/article-3449/" },
    { n: "La. Civ. Code art. 1762 — natural obligations", u: "https://law.justia.com/codes/louisiana/civil-code/article-1762/" },
    { n: "La. R.S. 9:3534.1 — collection agency registration", u: "https://legis.la.gov/Legis/Law.aspx?d=408390" },
    { n: "La. R.S. 10:3-118 — instruments", u: "https://www.legis.la.gov/legis/Law.aspx?d=74142" },
    { n: "La. R.S. 51:1409 — LUTPA private action", u: "https://legis.la.gov/Legis/Law.aspx?d=104033" },
    { n: "La. R.S. 51:1406 — LUTPA exemptions", u: "https://www.legis.la.gov/legis/Law.aspx?d=104030" },
    { n: "Tejero v. Portfolio Recovery Assocs. (5th Cir. 2021)", u: "https://www.ca5.uscourts.gov/opinions/pub/20/20-50543-CV0.pdf" },
    { n: "First Nat'l Bank of Commerce v. Band (La. App. 4 Cir. 1998)", u: "https://caselaw.findlaw.com/court/la-court-of-appeal/1045008.html" },
    { n: "Louisiana court structure — LSBA", u: "https://www.lsba.org/Public/CourtStructure.aspx" }
  ];

  return {
    UPDATED: UPDATED, INTRO: INTRO, DEADLINE: DEADLINE,
    CITY_LIMITS: CITY_LIMITS, CITY_LIMITS_NOTE: CITY_LIMITS_NOTE,
    CITY_LIMITS_URL: CITY_LIMITS_URL, CITY_LIMITS_CAVEAT: CITY_LIMITS_CAVEAT,
    PRESCRIPTION: PRESCRIPTION, DEFENCES: DEFENCES, REGISTRATION: REGISTRATION,
    FEES: FEES, HELP: HELP, COMPLAINTS: COMPLAINTS, GUARDRAIL: GUARDRAIL,
    SOURCES: SOURCES
  };
})();

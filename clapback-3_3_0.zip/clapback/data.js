/*
 * Clapback — shared dataset
 * Exposed as window.PDS for dashboard.html, popup.html and the content script.
 *
 * MISSION: personal-data self-defense. Everything here helps you (1) find and
 * remove YOUR OWN exposure, (2) judge whether something that contacted YOU is a
 * scam or spoof, and (3) respond safely to harassment. It never profiles a third
 * party, and it makes no network requests — external checks are links you choose
 * to open. The staffing-agency directory is company-level only (real domains +
 * where your candidate file lives) — it never identifies individual recruiters.
 *
 * NOTE ON ACCURACY: privacy laws and opt-out URLs change. Every entry is
 * guidance, not legal advice, and each screen links to an authoritative source.
 * Last researched and URL-verified: August 2026.
 */
window.PDS = (function () {
  "use strict";

  // Re-run opt-outs after this many days — broker records commonly reappear.
  const RECHECK_DAYS = 180;

  const STATES = [
    ["AL", "Alabama"], ["AK", "Alaska"], ["AZ", "Arizona"], ["AR", "Arkansas"],
    ["CA", "California"], ["CO", "Colorado"], ["CT", "Connecticut"], ["DE", "Delaware"],
    ["DC", "District of Columbia"], ["FL", "Florida"], ["GA", "Georgia"], ["HI", "Hawaii"],
    ["ID", "Idaho"], ["IL", "Illinois"], ["IN", "Indiana"], ["IA", "Iowa"],
    ["KS", "Kansas"], ["KY", "Kentucky"], ["LA", "Louisiana"], ["ME", "Maine"],
    ["MD", "Maryland"], ["MA", "Massachusetts"], ["MI", "Michigan"], ["MN", "Minnesota"],
    ["MS", "Mississippi"], ["MO", "Missouri"], ["MT", "Montana"], ["NE", "Nebraska"],
    ["NV", "Nevada"], ["NH", "New Hampshire"], ["NJ", "New Jersey"], ["NM", "New Mexico"],
    ["NY", "New York"], ["NC", "North Carolina"], ["ND", "North Dakota"], ["OH", "Ohio"],
    ["OK", "Oklahoma"], ["OR", "Oregon"], ["PA", "Pennsylvania"], ["PR", "Puerto Rico"],
    ["RI", "Rhode Island"], ["SC", "South Carolina"], ["SD", "South Dakota"], ["TN", "Tennessee"],
    ["TX", "Texas"], ["UT", "Utah"], ["VT", "Vermont"], ["VA", "Virginia"],
    ["WA", "Washington"], ["WV", "West Virginia"], ["WI", "Wisconsin"], ["WY", "Wyoming"]
  ];

  // State consumer-privacy laws giving deletion + opt-out rights.
  // deletion: 'yes' | 'limited' | 'no'   broker: has an active data-broker registry
  const PRIVACY_LAWS = {
    CA: { law: "CCPA / CPRA", deletion: "yes", optout: true, broker: true, note: "Strongest rights in the US, plus the DROP one-stop broker deletion platform. Also leads on hiring AI — anti-bias rules now cover automated hiring tools (since Oct 1, 2025), and access / opt-out rights over automated decisions phase in through Jan 1, 2027." },
    VA: { law: "VCDPA", deletion: "yes", optout: true, broker: false },
    CO: { law: "Colorado Privacy Act", deletion: "yes", optout: true, broker: false, note: "Must honor the Global Privacy Control browser signal." },
    CT: { law: "CTDPA", deletion: "yes", optout: true, broker: false, note: "A CT data-broker registry law starts Jan 1, 2027, with its own one-stop deletion mechanism due by mid-2028." },
    UT: { law: "Utah Consumer Privacy Act", deletion: "limited", optout: true, broker: false },
    TX: { law: "TDPSA", deletion: "yes", optout: true, broker: true, note: "Texas also has a data-broker registration law." },
    OR: { law: "Oregon Consumer Privacy Act", deletion: "yes", optout: true, broker: true, note: "Oregon requires data brokers to register." },
    MT: { law: "Montana Consumer Data Privacy Act", deletion: "yes", optout: true, broker: false },
    IA: { law: "Iowa Consumer Data Protection Act", deletion: "limited", optout: true, broker: false },
    DE: { law: "Delaware Personal Data Privacy Act", deletion: "yes", optout: true, broker: false },
    NE: { law: "Nebraska Data Privacy Act", deletion: "yes", optout: true, broker: false },
    NH: { law: "New Hampshire Privacy Act", deletion: "yes", optout: true, broker: false },
    NJ: { law: "New Jersey Data Privacy Act", deletion: "yes", optout: true, broker: false, note: "A NJ data-broker registry is enacted but doesn't begin until 2027." },
    IN: { law: "Indiana Consumer Data Protection Act", deletion: "yes", optout: true, broker: false, note: "In effect since Jan 1, 2026." },
    KY: { law: "Kentucky Consumer Data Protection Act", deletion: "yes", optout: true, broker: false, note: "In effect since Jan 1, 2026." },
    TN: { law: "Tennessee Information Protection Act", deletion: "yes", optout: true, broker: false },
    MN: { law: "Minnesota Consumer Data Privacy Act", deletion: "yes", optout: true, broker: false },
    MD: { law: "Maryland Online Data Privacy Act", deletion: "yes", optout: true, broker: false },
    RI: { law: "Rhode Island Data Transparency & Privacy Protection Act", deletion: "yes", optout: true, broker: false, note: "In effect since Jan 1, 2026." },
    FL: { law: "Florida Digital Bill of Rights", deletion: "limited", optout: true, broker: false, note: "Narrow — it mainly binds very large ($1B+) companies, but you still get deletion rights against those." },
    VT: { law: "Vermont Data Broker Law", deletion: "no", optout: false, broker: true, note: "Registry-only today; Vermont's full comprehensive privacy law arrives Jan 1, 2028." }
  };

  const PRIVACY_COMING = [
    { state: "LA", law: "Louisiana comprehensive privacy law (SB 386)", effective: "Jan 1, 2027" },
    { state: "OK", law: "Oklahoma comprehensive privacy law (SB 546)", effective: "Jan 1, 2027" },
    { state: "AL", law: "Alabama comprehensive privacy law (HB 351)", effective: "May 1, 2027" },
    { state: "VT", law: "Vermont comprehensive privacy law (S.71)", effective: "Jan 1, 2028" }
  ];

  /* ------------------------------------------------------------------ */
  /* Exposure-source categories (display order matters)                  */
  /* Re-framed for self-defense: "where a stranger could find YOU."      */
  /* ------------------------------------------------------------------ */
  const CATEGORIES = [
    { key: "peoplesearch", name: "People-search sites", blurb: "The #1 self-defense priority. These are the sites that publish your home address, phone, relatives, and past addresses to anyone who types your name — the first place a stalker, harasser, or scammer looks. Remove your profile from each, then monitor.", danger: true },
    { key: "recruiterdb", name: "Contact & profile databases", blurb: "Tools that resell scraped personal cell numbers and emails pulled from your social profiles. Opting out shrinks how easily someone links your name to a phone or inbox." },
    { key: "verify", name: "Identity & income data holders", blurb: "Large brokers that hold sensitive financial and identity data about you. Freezing or suppressing these closes quiet channels others can pull from." },
    { key: "jobboards", name: "Old resumes & job-board profiles", blurb: "Old resumes are exposure time capsules — full name, phone, email, address, and work history, searchable by anyone with a database login. Some sites even auto-create public profiles. Privatize or delete the ones where you've had an account." },
    { key: "hiring", name: "Job-application screening & hiring tech", blurb: "When you apply for a job, these vendors run a file on you. Background-check companies are FCRA consumer-reporting agencies — you have a legal right to see your report for free and to dispute errors, and a wrong record can quietly cost you the offer. Check your file before it's used against you." },
    { key: "specialty", name: "Specialty data bureaus", blurb: "Lesser-known bureaus whose files feed people-search and screening results. Most can be frozen for free — a quiet way to cut another data channel." },
    { key: "riskbureau", name: "Risk, insurance & check-screening bureaus", blurb: "Bureaus that score you for insurers, landlords, lenders, and retailers (claims history, check-writing, tenant history). Freezing or requesting your file stops quiet pulls and lets you catch errors that can cost you a policy, an apartment, or a loan." },
    { key: "marketing", name: "Marketing data brokers", blurb: "General consumer-data brokers whose feeds keep the people-search profiles fresh. Opting out slows how fast your removed profiles come back." },
    { key: "adtech", name: "Ad-tech & identity-graph brokers", blurb: "Companies that stitch your devices, emails, and browsing into a single advertising identity sold in real time. Opting out shrinks the profile that follows you across sites and apps." },
    { key: "international", name: "International & EU/UK brokers", blurb: "Directories and brokers outside the US. If you have ties to the EU or UK, GDPR/UK-GDPR give you a strong right to erasure — the letters tab includes a GDPR Article 17 version." }
  ];

  /*
   * Curated, prioritized opt-out / removal targets.
   * priority: critical | high | medium    action: link | email
   * `host` (where present) lets the on-page helper recognize the site and
   * surface its removal link when you land on it.
   * All URLs verified live or corroborated August 2026.
   */
  const BROKERS = [
    /* ---------------- People-search (highest self-defense priority) ---------------- */
    {
      id: "google-results", name: "Google 'Results about you'", cat: "peoplesearch",
      priority: "critical", action: "link", url: "https://myactivity.google.com/results-about-you",
      note: "Set this up first — it monitors Google for pages exposing your home address, phone, or email and lets you request removal from search results. Then work the sites below."
    },
    { id: "spokeo", name: "Spokeo", cat: "peoplesearch", priority: "critical", action: "link", url: "https://www.spokeo.com/optout", host: "spokeo.com", note: "Search your name first, copy the profile URL, then paste it into the opt-out form and confirm by email." },
    { id: "beenverified", name: "BeenVerified", cat: "peoplesearch", priority: "critical", action: "link", url: "https://www.beenverified.com/app/optout/search", host: "beenverified.com", note: "Find your record, then request removal and confirm the email link." },
    { id: "whitepages", name: "Whitepages", cat: "peoplesearch", priority: "critical", action: "link", url: "https://www.whitepages.com/suppression_requests", host: "whitepages.com", note: "Publishes phone + address. Locate your listing, submit a suppression request, verify by phone call." },
    { id: "intelius", name: "Intelius", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.intelius.com/opt-out/", host: "intelius.com", note: "Covers the PeopleConnect family (also Truthfinder, Instant Checkmate, US Search)." },
    { id: "truthfinder", name: "TruthFinder", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.truthfinder.com/opt-out/", host: "truthfinder.com" },
    { id: "instantcheckmate", name: "Instant Checkmate", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.instantcheckmate.com/opt-out/", host: "instantcheckmate.com" },
    { id: "radaris", name: "Radaris", cat: "peoplesearch", priority: "high", action: "link", url: "https://radaris.com/control/privacy", host: "radaris.com" },
    { id: "mylife", name: "MyLife", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.mylife.com/ccpa/index.pubview", host: "mylife.com" },
    { id: "fastpeoplesearch", name: "FastPeopleSearch", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.fastpeoplesearch.com/removal", host: "fastpeoplesearch.com", note: "Free and heavily indexed by Google — a common first hit on your name. Remove promptly." },
    { id: "truepeoplesearch", name: "TruePeopleSearch", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.truepeoplesearch.com/removal", host: "truepeoplesearch.com" },
    { id: "peoplefinders", name: "PeopleFinders", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.peoplefinders.com/opt-out", host: "peoplefinders.com" },
    { id: "usphonebook", name: "USPhoneBook", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.usphonebook.com/opt-out", host: "usphonebook.com", note: "Reverse-phone lookups — remove so your number can't be tied back to your name and address." },
    { id: "nuwber", name: "Nuwber", cat: "peoplesearch", priority: "high", action: "link", url: "https://nuwber.com/removal/link", host: "nuwber.com" },
    { id: "peekyou", name: "PeekYou", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.peekyou.com/about/contact/optout/", host: "peekyou.com" },
    { id: "thatsthem", name: "ThatsThem", cat: "peoplesearch", priority: "high", action: "link", url: "https://thatsthem.com/optout", host: "thatsthem.com" },
    { id: "clustrmaps", name: "ClustrMaps", cat: "peoplesearch", priority: "high", action: "link", url: "https://clustrmaps.com/bl/opt-out", host: "clustrmaps.com" },
    { id: "searchpeoplefree", name: "SearchPeopleFree", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.searchpeoplefree.com/opt-out", host: "searchpeoplefree.com" },
    { id: "cyberbackground", name: "CyberBackgroundChecks", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.cyberbackgroundchecks.com/removal", host: "cyberbackgroundchecks.com", note: "Free and heavily Google-indexed. Find your record, then submit the removal form." },
    { id: "advancedbg", name: "Advanced Background Checks", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.advancedbackgroundchecks.com/removal", host: "advancedbackgroundchecks.com" },
    { id: "checkpeople", name: "CheckPeople", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.checkpeople.com/opt-out", host: "checkpeople.com" },
    { id: "peoplelooker", name: "PeopleLooker", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.peoplelooker.com/f/optout/search", host: "peoplelooker.com", note: "Part of the BeenVerified family — a separate opt-out is still required." },
    { id: "neighborwho", name: "NeighborWho", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.neighborwho.com/optout-search", host: "neighborwho.com" },
    { id: "ownerly", name: "Ownerly", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.ownerly.com/optout-search", host: "ownerly.com", note: "Property + owner data broker in the BeenVerified family." },
    { id: "familytreenow", name: "FamilyTreeNow", cat: "peoplesearch", priority: "high", action: "link", url: "https://www.familytreenow.com/optout", host: "familytreenow.com", note: "Exposes relatives and associates for free — a common tool for tracing family. Remove promptly." },
    { id: "zabasearch", name: "ZabaSearch", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.zabasearch.com/block_records/", host: "zabasearch.com" },
    { id: "anywho", name: "AnyWho", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.anywho.com/optout", host: "anywho.com" },
    { id: "usapeoplesearch", name: "USA People Search", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.usa-people-search.com/manage/", host: "usa-people-search.com" },
    { id: "publicrecordsnow", name: "PublicRecordsNow", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.publicrecordsnow.com/optout/", host: "publicrecordsnow.com" },
    { id: "spyfly", name: "SpyFly", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.spyfly.com/help-center/remove-my-info", host: "spyfly.com" },
    { id: "infotracer", name: "InfoTracer", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.infotracer.com/optout/", host: "infotracer.com" },
    { id: "golookup", name: "GoLookUp", cat: "peoplesearch", priority: "medium", action: "link", url: "https://golookup.com/optout", host: "golookup.com" },
    { id: "idtrue", name: "IDTrue", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.idtrue.com/optout/", host: "idtrue.com" },
    { id: "smartbackground", name: "SmartBackgroundChecks", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.smartbackgroundchecks.com/optout", host: "smartbackgroundchecks.com" },
    { id: "backgroundalert", name: "BackgroundAlert", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.backgroundalert.com/optout", host: "backgroundalert.com" },
    { id: "clubset", name: "Clubset / SearchQuarry", cat: "peoplesearch", priority: "medium", action: "link", url: "https://www.searchquarry.com/optout/", host: "searchquarry.com" },
    { id: "arivify", name: "Arivify", cat: "peoplesearch", priority: "medium", action: "link", url: "https://arivify.com/contact", host: "arivify.com", note: "Property-focused people search; email the site to demand removal." },
    { id: "propertyshark", name: "Rehold / AddressReport", cat: "peoplesearch", priority: "medium", action: "link", url: "https://rehold.com/optout", host: "rehold.com", note: "Publishes who lives at an address; remove your address record." },

    /* ---------------- Contact & profile databases ---------------- */
    {
      id: "zoominfo", name: "ZoomInfo", cat: "recruiterdb",
      priority: "high", action: "link", url: "https://www.zoominfo.com/update/remove",
      note: "Holds direct-dial cell numbers and personal emails. Submit an email-verified removal in its Privacy Center."
    },
    { id: "apollo", name: "Apollo.io", cat: "recruiterdb", priority: "high", action: "link", url: "https://www.apollo.io/privacy-policy/remove", note: "200M+ scraped profiles. Enter your email and click the verification link to remove and suppress your profile." },
    { id: "lusha", name: "Lusha", cat: "recruiterdb", priority: "high", action: "link", url: "https://www.lusha.com/privacy-center/request-removal/", note: "Pulls phones/emails from social profiles. Submit the Privacy Center removal form." },
    { id: "rocketreach", name: "RocketReach", cat: "recruiterdb", priority: "high", action: "link", url: "https://rocketreach.co/remove-profile/", note: "Has public profile pages that surface on Google. Enter your email and confirm — no account needed." },
    { id: "contactout", name: "ContactOut", cat: "recruiterdb", priority: "high", action: "link", url: "https://contactout.com/optout", note: "Exposes personal emails/phones. Verify your email on the opt-out page; deletion in ~24 hours." },
    { id: "signalhire", name: "SignalHire", cat: "recruiterdb", priority: "high", action: "link", url: "https://www.signalhire.com/opt-out", note: "Reveals emails and phone numbers. Submit your email and profile URL on the opt-out form." },
    { id: "seamless", name: "Seamless.AI", cat: "recruiterdb", priority: "high", action: "link", url: "https://preferences.seamless.ai/", note: "Holds scraped contact records. Use the personal-information request form to delete (or 855-953-3265)." },
    { id: "pdl", name: "People Data Labs", cat: "recruiterdb", priority: "high", action: "link", url: "https://www.peopledatalabs.com/do-not-sell-or-share", note: "Wholesale person-data API feeding dozens of apps — removing yourself here cuts data upstream. Full deletion via privacy.peopledatalabs.com." },
    { id: "seekout", name: "SeekOut", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.seekout.com/privacy/choices", note: "Aggregated public profiles. Submit a deletion request via the Privacy Choices Portal (permanent)." },
    { id: "wiza", name: "Wiza", cat: "recruiterdb", priority: "medium", action: "link", url: "https://wiza.co/optout-contact-info", note: "Email/phone scraper. Also submit the directory form at wiza.co/optout-directory." },
    { id: "swordfish", name: "Swordfish AI", cat: "recruiterdb", priority: "medium", action: "link", url: "https://swordfish.ai/Optout", note: "Cell-phone and personal-email finder; removal within 30 days." },
    { id: "uplead", name: "UpLead", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.uplead.com/opt-out-request/", note: "Choose 'Delete my Information' and your jurisdiction on the form." },
    { id: "hunter", name: "Hunter.io", cat: "recruiterdb", priority: "medium", action: "link", url: "https://hunter.io/claim", note: "Claim your email and Hunter deletes all data and sources tied to it immediately." },
    { id: "snov", name: "Snov.io", cat: "recruiterdb", priority: "medium", action: "link", url: "https://snov.io/do-not-sell-my-personal-information", note: "Complete the form, then enter the emailed verification code." },
    { id: "clearbit", name: "Clearbit (HubSpot)", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.clearbit.com/ccpa-opt-out", note: "Use the privacy-request form; for HubSpot-held data use preferences.hubspot.com." },
    { id: "fullcontact", name: "FullContact", cat: "recruiterdb", priority: "medium", action: "link", url: "https://platform.fullcontact.com/your-privacy-choices", note: "Identity-resolution broker; it suppresses your record so it can't re-enter." },
    { id: "leadiq", name: "LeadIQ", cat: "recruiterdb", priority: "medium", action: "link", url: "https://leadiq.com/request-removal", note: "Captures contact data from social profiles." },
    { id: "nymeria", name: "Nymeria", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.nymeria.io/do-not-sell", note: "Contact-discovery tool; submit the Do Not Sell / Data Request form." },
    { id: "lead411", name: "Lead411", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.lead411.com/privacy-policy/", note: "B2B contact broker. Email its privacy contact requesting deletion and suppression." },
    { id: "adapt", name: "Adapt.io", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.adapt.io/opt-out", note: "Scraped business contacts; use the opt-out form to remove your email/phone." },
    { id: "datanyze", name: "Datanyze", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.datanyze.com/data-privacy", note: "Contact/technographic broker (ZoomInfo-owned); submit a data-privacy request." },
    { id: "kaspr", name: "Kaspr", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.kaspr.io/data-request", note: "LinkedIn contact extractor; submit a data-subject request to delete your record." },
    { id: "cufinder", name: "CUFinder", cat: "recruiterdb", priority: "medium", action: "link", url: "https://cufinder.io/opt-out", note: "Contact-enrichment scraper; opt out to have your record removed." },
    { id: "getprospect", name: "GetProspect", cat: "recruiterdb", priority: "medium", action: "link", url: "https://getprospect.com/opt-out", note: "Email-finder database; request removal of your email and profile." },
    { id: "voila", name: "VoilaNorbert", cat: "recruiterdb", priority: "medium", action: "link", url: "https://www.voilanorbert.com/privacy-policy/", note: "Email-finding tool; email the privacy contact to delete your data." },

    /* ---------------- Identity & income data holders ---------------- */
    {
      id: "lexisnexis", name: "LexisNexis Risk Solutions", cat: "verify",
      priority: "critical", action: "link", url: "https://optout.lexisnexis.com/",
      note: "One of the biggest identity-data brokers; feeds many background and people-search results. Request suppression here (eligibility rules apply), and pull your free Full File Disclosure at consumer.risk.lexisnexis.com/request."
    },
    {
      id: "theworknumber", name: "The Work Number (Equifax) — freeze", cat: "verify",
      priority: "high", action: "link", url: "https://employees.theworknumber.com/employee-data-freeze",
      note: "Equifax's payroll/income database. Place a free security freeze so no one can pull your income record without you unfreezing it."
    },
    { id: "equifax-privacy", name: "Equifax privacy portal", cat: "verify", priority: "medium", action: "link", url: "https://myprivacy.equifax.com/opt-in-opt-out/personal-info", note: "Submit 'Right to Limit the Use' and 'Right to Opt-Out' requests." },
    { id: "corelogic", name: "CoreLogic", cat: "verify", priority: "medium", action: "link", url: "https://www.corelogic.com/privacy-center/", note: "Holds property and rental-history data tied to your address." },
    { id: "optoutprescreen", name: "OptOutPrescreen", cat: "verify", priority: "medium", action: "link", url: "https://www.optoutprescreen.com/", note: "Stops pre-screened credit/insurance offers (the paper mail that confirms your address). Also 1-888-567-8688." },

    /* ---------------- Old resumes & job-board profiles ---------------- */
    { id: "lensa", name: "Lensa", cat: "jobboards", priority: "medium", action: "link", url: "https://career.lensa.com/request_removal", note: "Auto-creates profiles from aggregated resume data — even for people who never signed up. Enter your email to trigger deletion." },
    { id: "jobcase", name: "Jobcase", cat: "jobboards", priority: "medium", action: "link", url: "https://privacyportal.onetrust.com/webform/d6c0258c-bfbe-4326-8414-aaa9dea289be/e2889c95-f940-4fbb-a2ee-e6c21fbf8832?website=jobcase.com", note: "Auto-creates PUBLIC member profiles from resume and public-source data. Use the privacy form to demand deletion." },
    { id: "indeed", name: "Indeed", cat: "jobboards", priority: "medium", action: "link", url: "https://support.indeed.com/hc/en-us/articles/204524164-How-do-I-change-visibility-settings-for-my-Indeed-resume-", note: "Set your resume to Private or delete it; the Personal Data Request form also covers SimplyHired and Resume.com." },
    { id: "linkedin", name: "LinkedIn visibility", cat: "jobboards", priority: "medium", action: "link", url: "https://www.linkedin.com/public-profile/settings", note: "Hide your public profile from search engines and tighten who can see your connections and contact info." },
    { id: "monster", name: "Monster", cat: "jobboards", priority: "medium", action: "link", url: "https://www.monster.com/inside/privacy-notice/privacy-rights", note: "Delete your Job Seeker Profile via 'Delete My Personal Information' (or 833-971-0574)." },
    { id: "ziprecruiter", name: "ZipRecruiter", cat: "jobboards", priority: "medium", action: "link", url: "https://support.ziprecruiter.com/candidate/s/article/How-to-Delete-Your-ZipRecruiter-Account", note: "Delete under Account Settings, or email dsars@ziprecruiter.com." },
    { id: "postjobfree", name: "PostJobFree", cat: "jobboards", priority: "medium", action: "link", url: "https://www.postjobfree.com/how-to-delete-resume-from-postjobfree", note: "Resumes here are public and Google-indexed — delete yours and purge the cached copy." },
    /* ---------------- Job-application screening & hiring tech ---------------- */
    { id: "checkr", name: "Checkr — request & dispute your report", cat: "hiring", priority: "high", action: "link", url: "https://candidate.checkr.com/", note: "One of the largest background-check providers (common in gig and hourly hiring). Log into the Candidate Portal to see your report and file a dispute for free. You can also request your file by emailing legal@checkr.com, and opt out of forced arbitration within 30 days via arbitration@checkr.com." },
    { id: "sterling", name: "Sterling — request & dispute your report", cat: "hiring", priority: "high", action: "link", url: "https://mybackgroundcheck.sterlingcheck.com/", note: "Major pre-hire screener. Request a copy or dispute inaccurate items — call 1-888-889-5248 or email dispute.resolution@sterlingcheck.com. Under the FCRA a screener must investigate your dispute within 30 days, free of charge." },
    { id: "hireright", name: "HireRight — request & dispute your report", cat: "hiring", priority: "high", action: "link", url: "https://support.hireright.com/", note: "Large employment-screening company. Use the Candidate Support Site to request a copy of your report or dispute errors. If you applied through Applicant Center, your report link may be in your original candidate invitation." },

    /* ---------------- Specialty data bureaus ---------------- */
    { id: "chexsystems", name: "ChexSystems", cat: "specialty", priority: "medium", action: "link", url: "https://www.chexsystems.com/security-freeze/place-freeze", note: "Banking-history bureau. Free security freeze; free report at chexsystems.com." },
    { id: "innovis", name: "Innovis", cat: "specialty", priority: "medium", action: "link", url: "https://www.innovis.com/personal/securityFreeze", note: "The 'fourth credit bureau.' Free security freeze and report, self-serve." },
    { id: "nctue", name: "NCTUE", cat: "specialty", priority: "medium", action: "link", url: "https://www.nctue.com/consumers", note: "Telecom & utility payment exchange run by Equifax. Freeze: 866-349-5355." },
    { id: "sagestream", name: "SageStream / Clarity (Experian)", cat: "specialty", priority: "medium", action: "link", url: "https://www.clarityservices.com/support/security-freeze/", note: "Alternative-data bureau owned by Experian; freeze it free." },
    { id: "datax", name: "DataX (Equifax)", cat: "specialty", priority: "medium", action: "link", url: "https://consumers.dataxltd.com/consumerOptOut", note: "Equifax-owned specialty bureau with separate flows for opt-out, freeze, and disputes." },

    /* ---------------- Marketing brokers & lists ---------------- */
    { id: "acxiom", name: "Acxiom", cat: "marketing", priority: "medium", action: "link", url: "https://www.acxiom.com/optout/", note: "One of the largest consumer-data brokers." },
    { id: "epsilon", name: "Epsilon", cat: "marketing", priority: "medium", action: "email", url: "optout@epsilon.com", note: "Email optout@epsilon.com with your name and address to opt out." },
    { id: "oracle", name: "Oracle Data Cloud", cat: "marketing", priority: "medium", action: "link", url: "https://www.oracle.com/legal/privacy/marketing-cloud-data-cloud-privacy-policy.html", note: "Large ad-data broker; use the opt-out choices linked in its privacy policy." },
    { id: "dmachoice", name: "DMAchoice", cat: "marketing", priority: "medium", action: "link", url: "https://www.dmachoice.org/", note: "Reduces direct-marketing mail tied to broker profiles." },
    { id: "dataaxle", name: "Data Axle (Infogroup)", cat: "marketing", priority: "medium", action: "link", url: "https://www.data-axle.com/privacy-policy/opt-out-request/", note: "Big consumer + business list compiler; submit the opt-out request form." },
    { id: "experianmkt", name: "Experian Marketing (opt-out)", cat: "marketing", priority: "medium", action: "link", url: "https://www.experian.com/privacy/opting_out", note: "Separate from your credit file — this stops Experian's marketing-list sale of your data." },
    { id: "spokeodata", name: "Versium", cat: "marketing", priority: "medium", action: "link", url: "https://versium.com/opt-out", note: "Identity/marketing data broker; submit the consumer opt-out." },
    { id: "truthset", name: "Adstra", cat: "marketing", priority: "medium", action: "link", url: "https://adstradata.com/privacy-policy/", note: "Consumer marketing database; email the privacy contact to opt out and delete." },

    /* ---------------- Risk, insurance & check-screening bureaus ---------------- */
    { id: "clue", name: "LexisNexis C.L.U.E. report", cat: "riskbureau", priority: "high", action: "link", url: "https://consumer.risk.lexisnexis.com/request", note: "Your home + auto insurance claims history. Pull your free report yearly — errors here quietly raise premiums or get you denied. Request via the LexisNexis consumer portal." },
    { id: "verisk", name: "Verisk / ISO ClaimSearch", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.verisk.com/units/verisk-consumer-request/", note: "Insurance industry claims database. Submit a consumer file-access request." },
    { id: "mib", name: "MIB (medical/insurance)", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.mib.com/request_your_record.html", note: "Used by life/health/disability insurers. One free disclosure per year; check it for errors." },
    { id: "milliman", name: "Milliman IntelliScript (Rx history)", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.rxhistories.com/", note: "Your prescription history as seen by insurers. Request your free report and dispute errors." },
    { id: "telecheck", name: "TeleCheck (First Data)", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.firstdata.com/telecheck/telecheck-consumer.htm", note: "Check-acceptance bureau; retailers use it to approve/decline your checks. Request your file or dispute a decline." },
    { id: "certegy", name: "Certegy", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.askcertegy.com/", note: "Another check-verification service; request your file and opt out of its marketing use." },
    { id: "teletrack", name: "Teletrack (Equifax)", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.equifax.com/personal/products/credit/teletrack/", note: "Subprime/payday-loan reporting bureau; you can freeze it and request your report." },
    { id: "lci", name: "LexisNexis C.L.U.E. tenant / Resident History", cat: "riskbureau", priority: "medium", action: "link", url: "https://consumer.risk.lexisnexis.com/request", note: "Rental/tenant screening history landlords pull. Request your file so a bad entry doesn't cost you an apartment." },
    { id: "corelogic-rental", name: "CoreLogic Rental Property Solutions", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.corelogic.com/privacy-center/", note: "Tenant-screening reports; request your consumer file and dispute inaccuracies." },
    { id: "transunion-smartmove", name: "TransUnion rental screening", cat: "riskbureau", priority: "medium", action: "link", url: "https://www.transunion.com/consumer-support", note: "Tenant screening + SmartMove reports used by landlords." },

    /* ---------------- Ad-tech & identity-graph brokers ---------------- */
    { id: "liveramp", name: "LiveRamp", cat: "adtech", priority: "high", action: "link", url: "https://liveramp.com/opt_out/", note: "A core identity graph linking your email(s) to advertising IDs across the web. Opting out here cuts a major cross-site tracking channel." },
    { id: "tapad", name: "Tapad (cross-device)", cat: "adtech", priority: "medium", action: "link", url: "https://www.tapad.com/privacy-policy", note: "Cross-device graph that links your phone, laptop, and TV. Use the opt-out in its privacy policy." },
    { id: "neustar", name: "TransUnion/Neustar (TruAudience)", cat: "adtech", priority: "medium", action: "link", url: "https://www.transunion.com/client-support/marketing-opt-out", note: "Marketing identity data; submit the marketing opt-out." },
    { id: "nielsen", name: "Nielsen", cat: "adtech", priority: "medium", action: "link", url: "https://www.nielsen.com/legal/privacy-principles/nielsen-marketing-cloud-opt-out/", note: "Audience-measurement + marketing data; opt out of the Nielsen Marketing Cloud." },
    { id: "aboutads", name: "DAA WebChoices (all ad networks at once)", cat: "adtech", priority: "high", action: "link", url: "https://optout.aboutads.info/", note: "One page that opts you out of interest-based ads from dozens of ad-tech companies. Run it, then re-run after clearing cookies." },
    { id: "nai", name: "NAI opt-out (ad networks)", cat: "adtech", priority: "medium", action: "link", url: "https://optout.networkadvertising.org/", note: "Network Advertising Initiative's bulk opt-out from member ad networks." },
    { id: "yahoo-adtech", name: "Yahoo/AOL ad opt-out", cat: "adtech", priority: "medium", action: "link", url: "https://legal.yahoo.com/us/en/yahoo/privacy/adinfo/index.html", note: "Opt out of Yahoo's interest-based advertising and data sharing." },

    /* ---------------- International & EU/UK brokers ---------------- */
    { id: "192com", name: "192.com (UK)", cat: "international", priority: "medium", action: "link", url: "https://www.192.com/help/faqs/remove-my-details/", note: "UK people-finder built on the electoral roll. Ask to be removed and register for the 'open register' opt-out with your council." },
    { id: "infobel", name: "Infobel", cat: "international", priority: "medium", action: "link", url: "https://www.infobel.com/en/world/contact", note: "International phone/address directory; contact them to remove your listing (cite GDPR if in the EU/UK)." },
    { id: "yasni", name: "Yasni", cat: "international", priority: "medium", action: "link", url: "https://www.yasni.com/", note: "Person search aggregator; use its contact/removal form. GDPR erasure applies for EU residents." },
    { id: "acxiom-eu", name: "Acxiom EU (data access)", cat: "international", priority: "medium", action: "link", url: "https://www.acxiom.co.uk/about-us/privacy/", note: "Acxiom's EU/UK data-subject access and deletion route under GDPR." },
    { id: "webmii", name: "WebMii", cat: "international", priority: "medium", action: "link", url: "https://webmii.com/", note: "Aggregates public web mentions of your name; request removal via its contact form." }
  ];

  /* ================================================================== */
  /* STAFFING & RECRUITING AGENCIES — your candidate file (US)           */
  /* Company-level directory only. Purpose: (1) recognize whether a      */
  /* recruiter who contacted YOU is using an agency's real domain, and   */
  /* (2) request/delete YOUR candidate file at agencies you've used.     */
  /* Never identifies or profiles an individual recruiter.               */
  /* ~25,000 staffing firms operate in the US; this directory covers the */
  /* national firms and corporate families that account for the bulk of  */
  /* candidate files and recruiter outreach (SIA-scale firms + major     */
  /* specialty brands). Any agency not listed: use the letter + the      */
  /* verification links in the Agencies tab.                             */
  /* Researched: August 2026.                                            */
  /* Fields: seg = segment key; fam = corporate family; alt = other real */
  /* domains; tok = distinctive impersonation tokens (omitted for names  */
  /* that are common words/places/surnames, to avoid false alarms).      */
  /* ================================================================== */

  const AGENCY_SEGMENTS = [
    { key: "general",    label: "General & franchise" },
    { key: "industrial", label: "Industrial, logistics & drivers" },
    { key: "office",     label: "Office, admin & HR" },
    { key: "it",         label: "IT & tech" },
    { key: "eng",        label: "Engineering, energy & science" },
    { key: "health",     label: "Healthcare — nursing & allied" },
    { key: "locum",      label: "Physicians & locum tenens" },
    { key: "finance",    label: "Finance & accounting" },
    { key: "exec",       label: "Executive search" },
    { key: "legal",      label: "Legal" },
    { key: "creative",   label: "Creative & marketing" },
    { key: "edu",        label: "Education & schools" },
    { key: "rpo",        label: "RPO / enterprise hiring" },
    { key: "ondemand",   label: "On-demand & gig apps" }
  ];

  const AGENCIES = [
    /* ---- Allegis Group (largest US staffing group) ---- */
    { id: "aerotek", st: "MD", hq: "Hanover, MD", name: "Aerotek", domain: "aerotek.com", seg: "industrial", fam: "Allegis Group", tok: ["aerotek"], note: "Skilled trades & industrial arm of Allegis, the #1 US staffing group." },
    { id: "actalent", st: "MD", hq: "Hanover, MD", name: "Actalent", domain: "actalentservices.com", seg: "eng", fam: "Allegis Group", tok: ["actalent"], note: "Engineering & sciences — split out of Aerotek in 2022; legacy Aerotek E&S files moved here." },
    { id: "teksystems", st: "MD", hq: "Hanover, MD", name: "TEKsystems", domain: "teksystems.com", seg: "it", fam: "Allegis Group", tok: ["teksystems"], note: "Largest US IT staffing brand." },
    { id: "astoncarter", st: "MD", hq: "Hanover, MD", name: "Aston Carter", domain: "astoncarter.com", seg: "finance", fam: "Allegis Group", tok: ["astoncarter"], note: "Corporate & professional staffing (accounting, ops, admin)." },
    { id: "mlaglobal", st: "MD", hq: "Hanover, MD", name: "Major, Lindsey & Africa", domain: "mlaglobal.com", seg: "legal", fam: "Allegis Group", tok: ["mlaglobal"], note: "Largest legal search firm." },

    /* ---- Global majors & general staffing ---- */
    { id: "randstad", st: "GA", hq: "Atlanta, GA", name: "Randstad", domain: "randstadusa.com", alt: ["randstad.com"], seg: "general", fam: "Randstad", tok: ["randstad"], note: "Largest global staffing firm; also operates Randstad Digital and Randstad Enterprise in the US." },
    { id: "adecco", st: "FL", hq: "Jacksonville, FL", name: "Adecco", domain: "adeccousa.com", alt: ["adecco.com", "adeccogroup.com"], seg: "general", fam: "Adecco Group", tok: ["adecco"], note: "Global #2; US family also includes Akkodis, LHH, and Entegee." },
    { id: "manpower", st: "WI", hq: "Milwaukee, WI", name: "Manpower / ManpowerGroup", domain: "manpower.com", alt: ["manpowergroup.com"], seg: "general", fam: "ManpowerGroup", tok: ["manpower"], note: "Global major; US family includes Experis (IT) and Talent Solutions (RPO)." },
    { id: "kelly", st: "MI", hq: "Troy, MI", name: "Kelly Services", domain: "kellyservices.com", seg: "general", fam: "Kelly", tok: ["kellyservices"], note: "Also runs Kelly Education and Kelly Science/Engineering/Technology; owns Motion Recruitment and Sevenstep (2024)." },
    { id: "expresspros", st: "OK", hq: "Oklahoma City, OK", name: "Express Employment Professionals", domain: "expresspros.com", seg: "general", tok: ["expresspros"], note: "800+ franchise offices across the US." },
    { id: "roberthalf", st: "CA", hq: "San Ramon, CA", name: "Robert Half", domain: "roberthalf.com", seg: "finance", tok: ["roberthalf"], note: "Largest specialized talent firm: finance & accounting, technology, legal, marketing/creative, and administrative lines. A top target for recruiter impersonation." },
    { id: "spherion", st: "GA", hq: "Atlanta, GA", name: "Spherion", domain: "spherion.com", seg: "general", fam: "Randstad", tok: ["spherion"], note: "Franchise staffing network owned by Randstad." },
    { id: "staffmark", st: "OH", hq: "Cincinnati, OH", name: "Staffmark", domain: "staffmark.com", seg: "general", fam: "RGF Staffing (Recruit Holdings)", tok: ["staffmark"], note: "Owned by Japan's Recruit Holdings — the same parent as Indeed and Glassdoor." },
    { id: "advantageresourcing", st: "OH", hq: "Cincinnati, OH", name: "Advantage Resourcing", domain: "advantageresourcing.com", seg: "general", fam: "RGF Staffing (Recruit Holdings)", tok: ["advantageresourcing"] },
    { id: "pridestaff", st: "CA", hq: "Fresno, CA", name: "PrideStaff", domain: "pridestaff.com", seg: "general", tok: ["pridestaff"], note: "National franchise staffing organization." },
    { id: "atwork", st: "TN", hq: "Knoxville, TN", name: "AtWork Group", domain: "atwork.com", seg: "general", note: "Franchise staffing network." },
    { id: "nextaff", st: "KS", hq: "Overland Park, KS", name: "NEXTAFF", domain: "nextaff.com", seg: "general", tok: ["nextaff"], note: "Franchise staffing network." },
    { id: "talentlaunch", st: "OH", hq: "Independence, OH", name: "TalentLaunch", domain: "mytalentlaunch.com", seg: "general", tok: ["talentlaunch"], note: "Network of independent staffing brands (Alliance Solutions Group and others)." },
    { id: "nescoresource", st: "OH", hq: "Mayfield Heights, OH", name: "Nesco Resource", domain: "nescoresource.com", seg: "general", tok: ["nescoresource"] },
    { id: "surgestaffing", st: "OH", hq: "Columbus, OH", name: "Surge Staffing", domain: "surgestaffing.com", seg: "general", tok: ["surgestaffing"] },
    { id: "malonesolutions", st: "KY", hq: "Louisville, KY", name: "Malone Workforce Solutions", domain: "malonesolutions.com", seg: "general", tok: ["malonesolutions"] },
    { id: "snelling", st: "SC", hq: "Goose Creek, SC", name: "Snelling", domain: "snelling.com", seg: "general", fam: "HireQuest", tok: ["snelling"] },
    { id: "mrinetwork", st: "SC", hq: "Goose Creek, SC", name: "MRINetwork", domain: "mrinetwork.com", seg: "exec", fam: "HireQuest", tok: ["mrinetwork"], note: "Franchise recruiting network (Management Recruiters International)." },

    /* ---- Industrial, logistics & drivers ---- */
    { id: "employbridge", st: "GA", hq: "Atlanta, GA", name: "Employbridge", domain: "employbridge.com", seg: "industrial", fam: "Employbridge", tok: ["employbridge"], note: "Largest US industrial staffing group (brands below). Restructured under new ownership in 2025 — candidate records persist across its brands." },
    { id: "resourcemfg", st: "GA", hq: "Atlanta, GA", name: "ResourceMFG", domain: "resourcemfg.com", seg: "industrial", fam: "Employbridge", tok: ["resourcemfg"], note: "Manufacturing." },
    { id: "prologistix", st: "GA", hq: "Atlanta, GA", name: "ProLogistix", domain: "prologistix.com", seg: "industrial", fam: "Employbridge", tok: ["prologistix"], note: "Warehouse & logistics." },
    { id: "prodrivers", st: "GA", hq: "Atlanta, GA", name: "ProDrivers", domain: "prodrivers.com", seg: "industrial", fam: "Employbridge", tok: ["prodrivers"], note: "CDL drivers." },
    { id: "selectstaffing", st: "GA", hq: "Atlanta, GA", name: "Select Staffing", domain: "selectstaffing.com", seg: "industrial", fam: "Employbridge", tok: ["selectstaffing"] },
    { id: "remedystaffing", st: "GA", hq: "Atlanta, GA", name: "Remedy Intelligent Staffing", domain: "remedystaffing.com", seg: "industrial", fam: "Employbridge", tok: ["remedystaffing"] },
    { id: "remx", st: "GA", hq: "Atlanta, GA", name: "RemX", domain: "remx.com", seg: "office", fam: "Employbridge", tok: ["remx"], note: "Professional/office arm of Employbridge." },
    { id: "westaff", st: "GA", hq: "Atlanta, GA", name: "Westaff", domain: "westaff.com", seg: "general", fam: "Employbridge", tok: ["westaff"] },
    { id: "hiredynamics", st: "GA", hq: "Atlanta, GA", name: "Hire Dynamics", domain: "hiredynamics.com", seg: "industrial", fam: "Employbridge", tok: ["hiredynamics"] },
    { id: "peopleready", st: "WA", hq: "Tacoma, WA", name: "PeopleReady", domain: "peopleready.com", seg: "industrial", fam: "TrueBlue", tok: ["peopleready"], note: "On-demand labor; the JobStack app holds your worker profile." },
    { id: "staffmanagement", st: "WA", hq: "Tacoma, WA", name: "Staff Management | SMX", domain: "staffmanagement.com", seg: "industrial", fam: "TrueBlue", note: "On-site contingent workforce programs." },
    { id: "centerlinedrivers", st: "WA", hq: "Tacoma, WA", name: "Centerline Drivers", domain: "centerlinedrivers.com", seg: "industrial", fam: "TrueBlue", tok: ["centerlinedrivers"] },
    { id: "integritystaffing", st: "DE", hq: "Newark, DE", name: "Integrity Staffing Solutions", domain: "integritystaffing.com", seg: "industrial", tok: ["integritystaffing"], note: "Known for very large e-commerce warehouse programs." },
    { id: "elwoodstaffing", st: "IN", hq: "Columbus, IN", name: "Elwood Staffing", domain: "elwoodstaffing.com", seg: "industrial", tok: ["elwoodstaffing"] },
    { id: "oninstaffing", st: "AL", hq: "Birmingham, AL", name: "Onin Staffing", domain: "oninstaffing.com", alt: ["oningroup.com"], seg: "industrial", fam: "The Ōnin Group" },
    { id: "penmac", st: "MO", hq: "Springfield, MO", name: "Penmac Staffing", domain: "penmac.com", seg: "industrial", tok: ["penmac"], note: "Employee-owned." },
    { id: "peoplelink", st: "IN", hq: "South Bend, IN", name: "Peoplelink Group", domain: "peoplelinkstaffing.com", seg: "industrial", tok: ["peoplelinkstaffing"] },
    { id: "laborfinders", st: "FL", hq: "Palm Beach Gardens, FL", name: "Labor Finders", domain: "laborfinders.com", seg: "industrial", tok: ["laborfinders"], note: "Day-labor franchise." },
    { id: "labormax", st: "MO", hq: "Kansas City, MO", name: "LaborMax Staffing", domain: "labormax.net", seg: "industrial", tok: ["labormax"] },
    { id: "hirequest", st: "SC", hq: "Goose Creek, SC", name: "HireQuest Direct", domain: "hirequest.com", seg: "industrial", fam: "HireQuest", tok: ["hirequest"], note: "Franchise parent that also owns Snelling and MRINetwork." },

    /* ---- IT & tech ---- */
    { id: "insightglobal", st: "GA", hq: "Atlanta, GA", name: "Insight Global", domain: "insightglobal.com", seg: "it", tok: ["insightglobal"], note: "Top-3 US staffing firm, IT-led. Very high outbound recruiter volume — verify the sender domain." },
    { id: "apexsystems", st: "VA", hq: "Glen Allen, VA", name: "Apex Systems", domain: "apexsystems.com", seg: "it", fam: "ASGN", tok: ["apexsystems"] },
    { id: "cybercoders", st: "CA", hq: "Irvine, CA", name: "CyberCoders", domain: "cybercoders.com", seg: "it", fam: "ASGN", tok: ["cybercoders"], note: "High-volume job-match emails; a common name in fake-recruiter spoofs." },
    { id: "oxfordcorp", st: "MA", hq: "Beverly, MA", name: "Oxford Global Resources", domain: "oxfordcorp.com", seg: "it", fam: "ASGN", note: "Specialty IT/engineering consulting & staffing." },
    { id: "akkodis", st: "FL", hq: "Jacksonville, FL", name: "Akkodis", domain: "akkodis.com", seg: "it", fam: "Adecco Group", tok: ["akkodis"], note: "Formed from Modis + AKKA (2022) — former Modis candidates' files live here." },
    { id: "experis", st: "WI", hq: "Milwaukee, WI", name: "Experis", domain: "experis.com", seg: "it", fam: "ManpowerGroup", tok: ["experis"], note: "Absorbed ettain group's candidate base (2021)." },
    { id: "dexian", st: "VA", hq: "McLean, VA", name: "Dexian", domain: "dexian.com", seg: "it", tok: ["dexian"], note: "Formed from DISYS + Signature Consultants (2023); holds legacy records from both." },
    { id: "kforce", st: "FL", hq: "Tampa, FL", name: "Kforce", domain: "kforce.com", seg: "it", tok: ["kforce"], note: "Technology plus finance & accounting." },
    { id: "collabera", st: "NJ", hq: "Basking Ridge, NJ", name: "Collabera", domain: "collabera.com", seg: "it", tok: ["collabera"] },
    { id: "mastechdigital", st: "PA", hq: "Pittsburgh, PA", name: "Mastech Digital", domain: "mastechdigital.com", seg: "it", tok: ["mastechdigital"] },
    { id: "motionrecruitment", st: "MA", hq: "Boston, MA", name: "Motion Recruitment", domain: "motionrecruitment.com", seg: "it", fam: "Kelly", tok: ["motionrecruitment"], note: "Acquired by Kelly in 2024." },
    { id: "judgegroup", st: "PA", hq: "Wayne, PA", name: "The Judge Group", domain: "judge.com", seg: "it", note: "IT, healthcare, and learning divisions." },
    { id: "systemone", st: "PA", hq: "Pittsburgh, PA", name: "System One", domain: "systemone.com", seg: "eng", note: "Engineering, IT, scientific & clinical." },
    { id: "eliassen", st: "MA", hq: "Reading, MA", name: "Eliassen Group", domain: "eliassen.com", seg: "it", tok: ["eliassen"] },
    { id: "yoh", st: "PA", hq: "Philadelphia, PA", name: "Yoh", domain: "yoh.com", seg: "it", fam: "Day & Zimmermann" },
    { id: "jobot", st: "CA", hq: "Newport Beach, CA", name: "Jobot", domain: "jobot.com", seg: "it", tok: ["jobot"], note: "AI-assisted recruiting across tech, accounting, legal and more." },
    { id: "harveynash", st: "NY", hq: "New York, NY", name: "Harvey Nash", domain: "harveynash.com", seg: "it", fam: "Nash Squared", tok: ["harveynash"] },
    { id: "brooksource", st: "IN", hq: "Indianapolis, IN", name: "Brooksource", domain: "brooksource.com", seg: "it", fam: "Eight Eleven Group", tok: ["brooksource"], note: "Sister company to Medasource." },
    { id: "swoon", st: "IL", hq: "Chicago, IL", name: "Swoon", domain: "swoonstaffing.com", seg: "it", tok: ["swoonstaffing"] },
    { id: "optomi", st: "GA", hq: "Atlanta, GA", name: "Optomi", domain: "optomi.com", seg: "it", tok: ["optomi"] },
    { id: "pyramidci", st: "GA", hq: "Alpharetta, GA", name: "Pyramid Consulting", domain: "pyramidci.com", seg: "it", tok: ["pyramidci"] },
    { id: "artech", st: "NJ", hq: "Cedar Knolls, NJ", name: "Artech", domain: "artech.com", seg: "it", note: "One of the largest women-owned IT staffing firms." },
    { id: "roseint", st: "MO", hq: "Chesterfield, MO", name: "Rose International", domain: "roseint.com", seg: "it" },
    { id: "ustech", st: "NJ", hq: "Jersey City, NJ", name: "US Tech Solutions", domain: "ustechsolutions.com", seg: "it", tok: ["ustechsolutions"] },
    { id: "innovasolutions", st: "GA", hq: "Duluth, GA", name: "Innova Solutions", domain: "innovasolutions.com", seg: "it", tok: ["innovasolutions"], note: "Holds legacy Volt Workforce Solutions candidate records (acquired 2022)." },
    { id: "inspyr", st: "FL", hq: "Fort Lauderdale, FL", name: "INSPYR Solutions", domain: "inspyrsolutions.com", seg: "it", tok: ["inspyrsolutions"], note: "Formed from TekPartners + Genuent." },
    { id: "toptal", st: "", hq: "Fully remote", name: "Toptal", domain: "toptal.com", seg: "it", tok: ["toptal"], note: "Screened freelance network — your profile and screening results stay on file." },

    /* ---- Engineering, energy & science ---- */
    { id: "nesfircroft", st: "TX", hq: "Houston, TX", name: "NES Fircroft", domain: "nesfircroft.com", seg: "eng", tok: ["nesfircroft"], note: "Energy & engineering." },
    { id: "airswift", st: "TX", hq: "Houston, TX", name: "Airswift", domain: "airswift.com", seg: "eng", tok: ["airswift"], note: "Energy, process & infrastructure." },
    { id: "brunel", st: "TX", hq: "Houston, TX", name: "Brunel", domain: "brunel.net", seg: "eng", note: "Global engineering & energy staffing." },
    { id: "entegee", st: "MA", hq: "Burlington, MA", name: "Entegee", domain: "entegee.com", seg: "eng", fam: "Adecco Group", tok: ["entegee"], note: "Engineering & technical." },
    { id: "belcan", st: "OH", hq: "Cincinnati, OH", name: "Belcan", domain: "belcan.com", seg: "eng", fam: "Cognizant", tok: ["belcan"], note: "Engineering services & staffing; acquired by Cognizant in 2024." },
    { id: "epitec", st: "MI", hq: "Southfield, MI", name: "Epitec", domain: "epitec.com", seg: "it", tok: ["epitec"] },

    /* ---- Office, admin, HR & multi-specialty professional ---- */
    { id: "beaconhillstaffing", st: "MA", hq: "Boston, MA", name: "Beacon Hill Staffing Group", domain: "beaconhillstaffing.com", seg: "office", tok: ["beaconhillstaffing"], note: "Multi-specialty: associate/admin, tech, legal, financial, life sciences." },
    { id: "addisongroup", st: "IL", hq: "Chicago, IL", name: "Addison Group", domain: "addisongroup.com", seg: "office", fam: "Addison Group", tok: ["addisongroup"], note: "Also owns Mondo." },
    { id: "mondo", st: "NY", hq: "New York, NY", name: "Mondo", domain: "mondo.com", seg: "it", fam: "Addison Group", note: "Tech & creative staffing." },
    { id: "hays", st: "FL", hq: "Tampa, FL", name: "Hays", domain: "hays.com", seg: "office", note: "Global recruiter with US technology and professional lines." },
    { id: "michaelpage", st: "NY", hq: "New York, NY", name: "Michael Page", domain: "michaelpage.com", seg: "office", fam: "PageGroup", tok: ["michaelpage"] },
    { id: "robertwalters", st: "NY", hq: "New York, NY", name: "Robert Walters", domain: "robertwalters.com", seg: "office", tok: ["robertwalters"] },
    { id: "lhh", st: "FL", hq: "Jacksonville, FL", name: "LHH", domain: "lhh.com", seg: "office", fam: "Adecco Group", note: "Recruitment + career transition; absorbed Special Counsel, Ajilon, and Parker+Lynch — files from those brands live here." },
    { id: "rothstaffing", st: "CA", hq: "Orange, CA", name: "Roth Staffing", domain: "rothstaffing.com", seg: "office", fam: "Roth Staffing", tok: ["rothstaffing"], note: "Parent of Ultimate Staffing, Ledgent, and Adams & Martin Group." },
    { id: "ultimatestaffing", st: "CA", hq: "Orange, CA", name: "Ultimate Staffing", domain: "ultimatestaffing.com", seg: "office", fam: "Roth Staffing", tok: ["ultimatestaffing"] },
    { id: "bgsf", st: "TX", hq: "Plano, TX", name: "BGSF", domain: "bgsf.com", seg: "office", tok: ["bgsf"], note: "Property management & professional staffing." },

    /* ---- Finance & accounting ---- */
    { id: "vaco", st: "TN", hq: "Brentwood, TN", name: "Vaco", domain: "vaco.com", seg: "finance", fam: "Highspring", note: "Talent arm of Highspring (Vaco Holdings rebranded in 2025)." },
    { id: "ledgent", st: "CA", hq: "Orange, CA", name: "Ledgent", domain: "ledgent.com", seg: "finance", fam: "Roth Staffing", tok: ["ledgent"], note: "Finance & accounting." },
    { id: "cfstaffing", st: "MA", hq: "Boston, MA", name: "Creative Financial Staffing (CFS)", domain: "cfstaffing.com", seg: "finance", tok: ["cfstaffing"] },
    { id: "centurygroup", st: "CA", hq: "El Segundo, CA", name: "Century Group", domain: "century-group.com", seg: "finance" },
    { id: "brilliantfs", st: "IL", hq: "Chicago, IL", name: "Brilliant", domain: "brilliantfs.com", seg: "finance", note: "Finance, accounting & technology search." },
    { id: "jacobson", st: "IL", hq: "Chicago, IL", name: "The Jacobson Group", domain: "jacobsononline.com", seg: "finance", note: "Insurance-industry staffing & search." },
    { id: "phaidoninternational", st: "NY", hq: "New York, NY", name: "Phaidon International", domain: "phaidoninternational.com", seg: "finance", fam: "Phaidon International", tok: ["phaidoninternational"], note: "Parent of Selby Jennings, Glocomms, EPM Scientific, and DSJ Global." },
    { id: "selbyjennings", st: "NY", hq: "New York, NY", name: "Selby Jennings", domain: "selbyjennings.com", seg: "finance", fam: "Phaidon International", tok: ["selbyjennings"], note: "Banking & financial services search." },

    /* ---- Healthcare — nursing, allied & per-diem ---- */
    { id: "amnhealthcare", st: "TX", hq: "Dallas, TX", name: "AMN Healthcare", domain: "amnhealthcare.com", seg: "health", fam: "AMN Healthcare", tok: ["amnhealthcare"], note: "Largest US healthcare talent company; brands include American Mobile and Staff Care." },
    { id: "ayahealthcare", st: "CA", hq: "San Diego, CA", name: "Aya Healthcare", domain: "ayahealthcare.com", seg: "health", fam: "Aya Healthcare", tok: ["ayahealthcare"], note: "Now the #2 US staffing firm overall; acquired Cross Country Healthcare in 2025." },
    { id: "crosscountry", st: "FL", hq: "Boca Raton, FL", name: "Cross Country Healthcare", domain: "crosscountry.com", alt: ["crosscountryhealthcare.com"], seg: "health", fam: "Aya Healthcare", note: "Part of Aya since 2025 — records may sit with either brand." },
    { id: "medicalsolutions", st: "NE", hq: "Omaha, NE", name: "Medical Solutions", domain: "medicalsolutions.com", seg: "health", note: "Major travel-nurse agency." },
    { id: "ingenovis", st: "OH", hq: "Blue Ash (Cincinnati), OH", name: "Ingenovis Health", domain: "ingenovishealth.com", seg: "health", fam: "Ingenovis Health", tok: ["ingenovis"], note: "Parent of Fastaff, Trustaff, and HealthCare Support." },
    { id: "fastaff", st: "CO", hq: "Greenwood Village, CO", name: "Fastaff", domain: "fastaff.com", seg: "health", fam: "Ingenovis Health", tok: ["fastaff"], note: "Rapid-response travel nursing." },
    { id: "trustaff", st: "OH", hq: "Cincinnati, OH", name: "Trustaff", domain: "trustaff.com", seg: "health", fam: "Ingenovis Health", tok: ["trustaff"] },
    { id: "healthcaresupport", st: "FL", hq: "Maitland, FL", name: "HealthCare Support", domain: "healthcaresupport.com", seg: "health", fam: "Ingenovis Health" },
    { id: "amergis", st: "MD", hq: "Columbia, MD", name: "Amergis", domain: "amergis.com", seg: "health", tok: ["amergis"], note: "Formerly Maxim Healthcare Staffing — old Maxim staffing files live here." },
    { id: "shccares", st: "UT", hq: "Park City, UT", name: "Supplemental Health Care", domain: "shccares.com", seg: "health" },
    { id: "hosthealthcare", st: "CA", hq: "San Diego, CA", name: "Host Healthcare", domain: "hosthealthcare.com", seg: "health", tok: ["hosthealthcare"] },
    { id: "totalmed", st: "WI", hq: "Appleton, WI", name: "TotalMed", domain: "totalmed.com", seg: "health" },
    { id: "fusionmedstaff", st: "NE", hq: "Omaha, NE", name: "Fusion Medical Staffing", domain: "fusionmedstaff.com", seg: "health", tok: ["fusionmedstaff"] },
    { id: "triagestaff", st: "NE", hq: "Omaha, NE", name: "Triage Staffing", domain: "triagestaff.com", seg: "health", tok: ["triagestaff"] },
    { id: "lrshealthcare", st: "NE", hq: "Omaha, NE", name: "LRS Healthcare", domain: "lrshealthcare.com", seg: "health", tok: ["lrshealthcare"] },
    { id: "ghrhealthcare", st: "PA", hq: "Blue Bell, PA", name: "GHR Healthcare", domain: "ghrhealthcare.com", seg: "health", tok: ["ghrhealthcare"] },
    { id: "healthcarousel", st: "OH", hq: "Cincinnati, OH", name: "Health Carousel", domain: "healthcarousel.com", seg: "health", tok: ["healthcarousel"] },
    { id: "prolink", st: "OH", hq: "Cincinnati, OH", name: "Prolink", domain: "prolinkworks.com", seg: "health", note: "Healthcare-led, multi-specialty." },
    { id: "advantismed", st: "TX", hq: "Dallas, TX", name: "Advantis Medical", domain: "advantismed.com", seg: "health", tok: ["advantismed"] },
    { id: "nomadhealth", st: "NY", hq: "New York, NY", name: "Nomad Health", domain: "nomadhealth.com", seg: "health", tok: ["nomadhealth"], note: "Direct-booking travel-nurse marketplace." },
    { id: "trustedhealth", st: "CA", hq: "San Francisco, CA", name: "Trusted Health", domain: "trustedhealth.com", seg: "health", note: "Travel-nurse marketplace." },
    { id: "vivian", st: "NY", hq: "New York, NY", name: "Vivian Health", domain: "vivian.com", seg: "health", note: "Job marketplace — one profile here is visible to many agencies at once; deactivate it when you stop searching." },
    { id: "gale", st: "FL", hq: "Tampa, FL", name: "Gale Healthcare Solutions", domain: "galehealthcare.com", seg: "health", tok: ["galehealthcare"], note: "Per-diem nursing app." },
    { id: "favoritestaffing", st: "KS", hq: "Overland Park, KS", name: "Favorite Healthcare Staffing", domain: "favoritestaffing.com", seg: "health", fam: "Acacium Group", tok: ["favoritestaffing"] },
    { id: "interimhealthcare", st: "FL", hq: "Sunrise, FL", name: "Interim HealthCare", domain: "interimhealthcare.com", seg: "health", tok: ["interimhealthcare"], note: "Franchise network (staffing + home care)." },
    { id: "giftedhealthcare", st: "LA", hq: "New Orleans, LA", name: "Gifted Healthcare", domain: "giftedhealthcare.com", seg: "health", tok: ["giftedhealthcare"] },
    { id: "cynethealth", st: "VA", hq: "Sterling, VA", name: "Cynet Health", domain: "cynethealth.com", seg: "health", fam: "Cynet Group", tok: ["cynethealth"] },
    { id: "epictravelstaffing", st: "CA", hq: "El Segundo, CA", name: "Epic Travel Staffing", domain: "epictravelstaffing.com", seg: "health", tok: ["epictravelstaffing"] },
    { id: "medasource", st: "IN", hq: "Indianapolis, IN", name: "Medasource", domain: "medasource.com", seg: "health", fam: "Eight Eleven Group", tok: ["medasource"], note: "Healthcare IT & clinical." },

    /* ---- Physicians & locum tenens ---- */
    { id: "chghealthcare", st: "UT", hq: "Midvale, UT", name: "CHG Healthcare", domain: "chghealthcare.com", seg: "locum", fam: "CHG Healthcare", tok: ["chghealthcare"], note: "Parent of CompHealth, Weatherby, and RNnetwork." },
    { id: "comphealth", st: "UT", hq: "Midvale, UT", name: "CompHealth", domain: "comphealth.com", seg: "locum", fam: "CHG Healthcare", tok: ["comphealth"], note: "Largest locum tenens agency." },
    { id: "weatherby", st: "FL", hq: "Fort Lauderdale, FL", name: "Weatherby Healthcare", domain: "weatherbyhealthcare.com", seg: "locum", fam: "CHG Healthcare", tok: ["weatherbyhealthcare"] },
    { id: "rnnetwork", st: "FL", hq: "Boca Raton, FL", name: "RNnetwork", domain: "rnnetwork.com", seg: "health", fam: "CHG Healthcare", tok: ["rnnetwork"], note: "Travel nursing arm of CHG." },
    { id: "jacksonhealthcare", st: "GA", hq: "Alpharetta, GA", name: "Jackson Healthcare", domain: "jacksonhealthcare.com", seg: "locum", fam: "Jackson Healthcare", tok: ["jacksonhealthcare"], note: "Family includes LocumTenens.com and Jackson Physician Search." },
    { id: "locumtenens", st: "GA", hq: "Alpharetta, GA", name: "LocumTenens.com", domain: "locumtenens.com", seg: "locum", fam: "Jackson Healthcare" },
    { id: "jacksonphysiciansearch", st: "GA", hq: "Alpharetta, GA", name: "Jackson Physician Search", domain: "jacksonphysiciansearch.com", seg: "locum", fam: "Jackson Healthcare", tok: ["jacksonphysiciansearch"] },
    { id: "staffcare", st: "TX", hq: "Dallas, TX", name: "Staff Care", domain: "staffcare.com", seg: "locum", fam: "AMN Healthcare", note: "AMN's locum tenens brand." },
    { id: "bartonassociates", st: "MA", hq: "Peabody, MA", name: "Barton Associates", domain: "bartonassociates.com", seg: "locum", tok: ["bartonassociates"] },
    { id: "medicushcs", st: "NH", hq: "Windham, NH", name: "Medicus Healthcare Solutions", domain: "medicushcs.com", seg: "locum" },
    { id: "hayeslocums", st: "FL", hq: "Fort Lauderdale, FL", name: "Hayes Locums", domain: "hayeslocums.com", seg: "locum", tok: ["hayeslocums"] },

    /* ---- Executive search ---- */
    { id: "kornferry", st: "CA", hq: "Los Angeles, CA", name: "Korn Ferry", domain: "kornferry.com", seg: "exec", tok: ["kornferry"], note: "Largest executive search + RPO firm. If a headhunter approached you, a profile likely exists here." },
    { id: "heidrick", st: "IL", hq: "Chicago, IL", name: "Heidrick & Struggles", domain: "heidrick.com", seg: "exec", tok: ["heidrick"] },
    { id: "spencerstuart", st: "IL", hq: "Chicago, IL", name: "Spencer Stuart", domain: "spencerstuart.com", seg: "exec", tok: ["spencerstuart"] },
    { id: "russellreynolds", st: "NY", hq: "New York, NY", name: "Russell Reynolds Associates", domain: "russellreynolds.com", seg: "exec", tok: ["russellreynolds"] },
    { id: "egonzehnder", st: "NY", hq: "New York, NY", name: "Egon Zehnder", domain: "egonzehnder.com", seg: "exec", tok: ["egonzehnder"] },
    { id: "boyden", st: "NY", hq: "Purchase, NY", name: "Boyden", domain: "boyden.com", seg: "exec", tok: ["boyden"] },
    { id: "dhrglobal", st: "IL", hq: "Chicago, IL", name: "DHR Global", domain: "dhrglobal.com", seg: "exec", tok: ["dhrglobal"] },
    { id: "divsearch", st: "PA", hq: "Philadelphia, PA", name: "Diversified Search Group", domain: "divsearch.com", seg: "exec" },
    { id: "wittkieffer", st: "IL", hq: "Oak Brook, IL", name: "WittKieffer", domain: "wittkieffer.com", seg: "exec", tok: ["wittkieffer"], note: "Healthcare, education & nonprofit leadership." },
    { id: "zrgpartners", st: "NJ", hq: "Rochelle Park, NJ", name: "ZRG Partners", domain: "zrgpartners.com", seg: "exec", tok: ["zrgpartners"] },
    { id: "stantonchase", st: "MD", hq: "Baltimore, MD", name: "Stanton Chase", domain: "stantonchase.com", seg: "exec", tok: ["stantonchase"] },

    /* ---- Legal ---- */
    { id: "adamsmartingroup", st: "CA", hq: "Orange, CA", name: "Adams & Martin Group", domain: "adamsmartingroup.com", seg: "legal", fam: "Roth Staffing", note: "Legal staffing." },
    { id: "laterallink", st: "CA", hq: "Los Angeles, CA", name: "Lateral Link", domain: "laterallink.com", seg: "legal", tok: ["laterallink"], note: "Attorney placement." },

    /* ---- Creative & marketing ---- */
    { id: "creativecircle", st: "CA", hq: "Los Angeles, CA", name: "Creative Circle", domain: "creativecircle.com", seg: "creative", fam: "ASGN", note: "Creative, marketing & digital talent." },
    { id: "aquent", st: "MA", hq: "Boston, MA", name: "Aquent", domain: "aquent.com", seg: "creative", tok: ["aquent"], note: "Creative & marketing staffing (includes the former Vitamin T)." },
    { id: "24seventalent", st: "NY", hq: "New York, NY", name: "24 Seven Talent", domain: "24seventalent.com", seg: "creative", note: "Fashion, beauty, retail & creative." },
    { id: "onwardsearch", st: "CT", hq: "Norwalk, CT", name: "Onward Search", domain: "onwardsearch.com", seg: "creative", tok: ["onwardsearch"] },
    { id: "solomonpage", st: "NY", hq: "New York, NY", name: "Solomon Page", domain: "solomonpage.com", seg: "creative", tok: ["solomonpage"], note: "Creative, fashion, healthcare & financial divisions." },
    { id: "artisantalent", st: "IL", hq: "Chicago, IL", name: "Artisan Talent", domain: "artisantalent.com", seg: "creative", tok: ["artisantalent"] },

    /* ---- Education & schools ---- */
    { id: "ess", st: "NJ", hq: "Cherry Hill, NJ", name: "ESS", domain: "ess.com", seg: "edu", note: "Largest K-12 substitute-teacher and support-staff provider." },
    { id: "swingeducation", st: "CA", hq: "San Mateo, CA", name: "Swing Education", domain: "swingeducation.com", seg: "edu", tok: ["swingeducation"], note: "Substitute-teacher platform." },
    { id: "scoot", st: "CA", hq: "Los Angeles, CA", name: "Scoot Education", domain: "scoot.education", seg: "edu" },
    { id: "zeneducate", st: "MN", hq: "Minneapolis, MN", name: "Zen Educate", domain: "zeneducate.com", seg: "edu", tok: ["zeneducate"] },
    { id: "soliant", st: "GA", hq: "Peachtree Corners, GA", name: "Soliant", domain: "soliant.com", seg: "edu", tok: ["soliant"], note: "School-based therapy, special education & healthcare." },
    { id: "sunbeltstaffing", st: "FL", hq: "Oldsmar, FL", name: "Sunbelt Staffing", domain: "sunbeltstaffing.com", seg: "edu", tok: ["sunbeltstaffing"], note: "School and healthcare professionals." },
    { id: "steppingstones", st: "MA", hq: "Boston, MA", name: "The Stepping Stones Group", domain: "thesteppingstonesgroup.com", seg: "edu", note: "School-based therapeutic & behavioral staffing." },

    /* ---- RPO / enterprise hiring (they run hiring for big employers) ---- */
    { id: "cielotalent", st: "WI", hq: "Brookfield, WI", name: "Cielo", domain: "cielotalent.com", seg: "rpo", tok: ["cielotalent"], note: "If you applied to a large employer, an RPO like Cielo may have run the process — your application file can live here, not just at the employer." },
    { id: "wilsonhcg", st: "FL", hq: "Tampa, FL", name: "WilsonHCG", domain: "wilsonhcg.com", seg: "rpo", tok: ["wilsonhcg"] },
    { id: "sevenstep", st: "MA", hq: "Boston, MA", name: "Sevenstep", domain: "sevensteprpo.com", seg: "rpo", fam: "Kelly" },
    { id: "peoplescout", st: "IL", hq: "Chicago, IL", name: "PeopleScout", domain: "peoplescout.com", seg: "rpo", fam: "TrueBlue", tok: ["peoplescout"] },
    { id: "ams", st: "NY", hq: "New York, NY", name: "AMS (Alexander Mann Solutions)", domain: "weareams.com", seg: "rpo", note: "Global RPO; runs hiring for major employers." },

    /* ---- On-demand & gig work apps (hold worker profiles + IDs) ---- */
    { id: "instawork", st: "CA", hq: "San Francisco, CA", name: "Instawork", domain: "instawork.com", seg: "ondemand", tok: ["instawork"], note: "Hospitality & warehouse shifts." },
    { id: "wonolo", st: "CA", hq: "San Francisco, CA", name: "Wonolo", domain: "wonolo.com", seg: "ondemand", tok: ["wonolo"] },
    { id: "veryable", st: "TX", hq: "Dallas, TX", name: "Veryable", domain: "veryable.us", seg: "ondemand", note: "Manufacturing & logistics gigs." },
    { id: "qwick", st: "AZ", hq: "Phoenix, AZ", name: "Qwick", domain: "qwick.com", seg: "ondemand", tok: ["qwick"], note: "Hospitality shifts." },
    { id: "medely", st: "CA", hq: "Santa Monica, CA", name: "Medely", domain: "medely.com", seg: "ondemand", tok: ["medely"], note: "Per-diem clinical shifts — holds licenses and credentials." },
    { id: "shiftkey", st: "TX", hq: "Dallas, TX", name: "ShiftKey", domain: "shiftkey.com", seg: "ondemand", tok: ["shiftkey"], note: "Per-diem nursing shifts." },
    { id: "shiftmed", st: "VA", hq: "McLean, VA", name: "ShiftMed", domain: "shiftmed.com", seg: "ondemand", tok: ["shiftmed"] },
    { id: "intelycare", st: "MA", hq: "Quincy, MA", name: "IntelyCare", domain: "intelycare.com", seg: "ondemand", tok: ["intelycare"] },
    { id: "clipboardhealth", st: "CA", hq: "San Francisco, CA", name: "Clipboard Health", domain: "clipboardhealth.com", seg: "ondemand", tok: ["clipboardhealth"] },
    { id: "connectrn", st: "MA", hq: "Waltham, MA", name: "connectRN", domain: "connectrn.com", seg: "ondemand", tok: ["connectrn"] }
  ];

  // Feed the agency directory into the impersonation engine so the vetting
  // module can flag look-alike recruiter domains and confirm the real ones.
  // Tokens are only set on distinctive coined names — never on common words,
  // places, or surnames — so legitimate unrelated domains aren't flagged.
  const AGENCY_BRANDS = AGENCIES.map(function (a) {
    return { name: a.name, domains: [a.domain].concat(a.alt || []), tokens: a.tok || [] };
  });





  /* Representatives & policymaker channels \u2014 official lookups only. Every
   * link is the government\u2019s own finder: the user enters their ZIP/address on
   * the official site, never in Clapback. */
  const REP_LINKS = {
    fed: [
      { name: "Find your House representative", url: "https://www.house.gov/representatives/find-your-representative", why: "The House\u2019s official ZIP lookup \u2014 you enter your ZIP on house.gov itself; Clapback never sees it." },
      { name: "Your two senators", url: "https://www.senate.gov/senators/", why: "Official Senate directory \u2014 every senator\u2019s site and contact form." },
      { name: "Congress.gov member search", url: "https://www.congress.gov/members/find-your-member", why: "The Library of Congress member finder \u2014 committees, sponsored bills, contact." }
    ],
    state: [
      { name: "Open States \u2014 find your state legislators", url: "https://openstates.org/find_your_legislator/", why: "The standard nonprofit lookup for all 50 state legislatures \u2014 your state rep and state senator with contact links." },
      { name: "USA.gov \u2014 elected officials", url: "https://www.usa.gov/elected-officials", why: "Federal directory of every level: federal, state, and local officials." }
    ],
    exec: [
      { name: "White House contact form", url: "https://www.whitehouse.gov/contact/", why: "There is no dedicated \u201ceconomic complaint form\u201d \u2014 this is the official White House contact channel. Use it to describe economic harms you\u2019re seeing, like ghost-job proliferation or data-broker abuse." },
      { name: "CFPB consumer complaint", url: "https://www.consumerfinance.gov/complaint/", why: "The federal intake that actually forces a company response \u2014 for financial products: job-related loans, payroll cards, credit-report errors from background checks, debt collectors." }
    ]
  };

  /* Advocacy letters \u2014 the user\u2019s own voice to their own representatives.
   * One clean ask each; {{story}} is optional and dropped when empty. */
  const ADVOCACY_LETTERS = {
    congressGhostJobs: {
      label: "To Congress: make job postings honest",
      hint: "Truth-in-advertising for job listings \u2014 real, open, time-stamped roles.",
      subject: "Constituent request: truth-in-advertising for job postings",
      body: "Dear Representative,\n\nI\u2019m a constituent in {{city}}, {{state}}. I\u2019m writing about \u201cghost jobs\u201d \u2014 postings for roles that aren\u2019t real or open, left up for months to harvest applications and personal data.{{storypara}}\n\nJob ads are advertising. I\u2019m asking you to support requiring that posted roles be genuine and open, that listings carry a posting date and be removed when filled, and that the FTC apply its deceptive-advertising authority to job listings the way it does to every other ad.\n\nApplicants spend real hours and hand over real personal data. Honesty about whether a job exists is a modest ask.\n\nRespectfully,\n{{name}}\n{{city}}, {{state}}\n{{today}}"
    },
    stateStaffing: {
      label: "To my state legislature: register staffing agencies",
      hint: "MA, NJ, and IL already do it \u2014 ask your state to catch up.",
      subject: "Constituent request: staffing-agency registration in {{state}}",
      body: "Dear Legislator,\n\nI\u2019m a constituent in {{city}}, {{state}}. Staffing and recruiting agencies hold job seekers\u2019 most sensitive data \u2014 r\u00e9sum\u00e9s, SSNs, ID documents, background checks \u2014 yet in most states no one registers who they are.{{storypara}}\n\nMassachusetts licenses and registers these agencies, New Jersey registers them with its Division of Consumer Affairs, and Illinois registers day-labor agencies and publishes the list. I\u2019m asking you to support the same for {{state}}: registration, so workers can verify an agency is real, and basic duties for how candidate data is stored and deleted.\n\nRespectfully,\n{{name}}\n{{city}}, {{state}}\n{{today}}"
    },
    databroker: {
      label: "To Congress: one-stop data-broker deletion",
      hint: "A single federal delete-my-data mechanism, like California\u2019s DROP.",
      subject: "Constituent request: a federal one-stop data-broker deletion mechanism",
      body: "Dear Representative,\n\nI\u2019m a constituent in {{city}}, {{state}}. Removing yourself from data brokers today means finding and petitioning more than a hundred companies, one by one, forever \u2014 I know because I do it.{{storypara}}\n\nCalifornia\u2019s Delete Act created DROP: one request, every registered broker must honor it. I\u2019m asking you to support the same nationally \u2014 a single federal registry and one-stop deletion request that every data broker must honor.\n\nPeople shouldn\u2019t need a part-time job to exercise a basic privacy right.\n\nRespectfully,\n{{name}}\n{{city}}, {{state}}\n{{today}}"
    }
  };


  /* Ghost-jobs enforcement & legislation tracker \u2014 a researched snapshot,
   * shipped with the extension because Clapback makes no network requests.
   * Every item is real, dated, and sourced (primary sources preferred).
   * Snapshot researched and verified: August 17, 2026. */
  const GHOST_FEED_UPDATED = "August 17, 2026";
  const GHOST_FEED = [
    { date: "2026-07-14", st: "TX", kind: "enforcement", status: "Investigation opened \u2014 CID issued",
      title: "Texas AG investigates LinkedIn over ghost jobs",
      sum: "Attorney General Ken Paxton opened a formal investigation into LinkedIn for advertising and profiting from \u201cghost jobs,\u201d issuing a Civil Investigative Demand for documents, data, and internal communications about advertising, verification practices, and Premium subscriptions. The office cites studies estimating one-fifth to one-third of online postings may be ghost jobs, and is probing violations of the Texas Deceptive Trade Practices Act. As of this snapshot: investigation stage \u2014 no lawsuit or formal charges filed yet.",
      src: [{ n: "Texas AG press release (primary)", u: "https://www.texasattorneygeneral.gov/news/releases/attorney-general-ken-paxton-investigates-linkedin-advertising-fake-and-misleading-job-opportunities" },
            { n: "KXAN coverage", u: "https://www.kxan.com/news/texas-ag-investigates-linkedin-over-alleged-ghost-job-listings/" }] },
    { date: "2026-06-02", st: "NY", kind: "legislation", status: "Passed both houses \u2014 awaiting governor\u2019s signature",
      title: "New York passes the first US ghost-job bill (S8877)",
      sum: "Both houses of the New York Legislature passed S8877: employers with 100+ employees and job platforms must disclose whether a posting is a real, current vacancy \u2014 fill within 90 days, longer, or r\u00e9sum\u00e9-collection only \u2014 and remove listings within two weeks of filling. Penalties reported at $1,000\u2013$5,000 per violation, up to $25,000 per applicant for data mining or selling. As of this snapshot it awaits Governor Hochul\u2019s signature and would take effect immediately if signed.",
      src: [{ n: "SHRM analysis", u: "https://www.shrm.org/topics-tools/news/talent-acquisition/new-york-law-ghost-job-postings" },
            { n: "Staffing Industry Analysts", u: "https://www.staffingindustry.com/editorial/cws-30-contingent-workforce-strategies/lawmakers-target-ghost-jobs-in-next-hiring-fight" }] },
    { date: "2026-03-15", st: "PA", kind: "legislation", status: "Bill introduced",
      title: "Pennsylvania introduces the Ghost Job Postings Prevention Act (HB2321)",
      sum: "The most comprehensive bill under review: bans posting jobs that don\u2019t exist, requires stating whether a posting is an existing or anticipated vacancy plus a hiring timeline, requires disclosing how many times the role was posted in the past year, and mandates removal within two weeks of filling. Sponsors explicitly cite employers\u2019 harvesting of applicant data as a motive for ghost postings.",
      src: [{ n: "Forbes (state roundup)", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" }] },
    { date: "2026-05-01", st: "NJ", kind: "legislation", status: "Bill active in committee",
      title: "New Jersey advances vacancy-disclosure bill (S2136 / A1161)",
      sum: "Employers and third-party job platforms would have to specify whether a posting is for an existing vacancy, remove filled postings within two weeks (or 30 days of posting), notify interviewed applicants of their status, and face civil penalties \u2014 with each month a violating ad stays up counting as a separate violation.",
      src: [{ n: "Congress.gov CRS In Focus IF12977", u: "https://www.congress.gov/crs-product/IF12977" },
            { n: "Forbes (state roundup)", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" }] },
    { date: "2025-08-01", st: "CA", kind: "legislation", status: "Passed Assembly \u2014 held in Senate Appropriations",
      title: "California\u2019s AB1251 stalls after passing the Assembly",
      sum: "AB1251 would amend the Labor Code so every publicly advertised job posting must disclose whether it\u2019s for an actual vacancy. It passed the Assembly and reached the Senate in June 2025 \u2014 and has been held in the Senate Appropriations Committee since August 2025. Stalled, not dead.",
      src: [{ n: "Staffing Industry Analysts", u: "https://www.staffingindustry.com/editorial/cws-30-contingent-workforce-strategies/lawmakers-target-ghost-jobs-in-next-hiring-fight" }] },
    { date: "2026-02-01", st: "KY", kind: "legislation", status: "Bill introduced",
      title: "Kentucky introduces a ghost-job ban (HB 324; some coverage cites HB 342)",
      sum: "Kentucky\u2019s bill would prohibit postings for \u201cghost jobs,\u201d defined as postings not intended to be filled within a set window \u2014 part of a five-state wave of 2026 legislation alongside NY, PA, NJ, and CA.",
      src: [{ n: "Littler 2026 legislative landscape", u: "https://www.littler.com/news-analysis/asap/ones-watch-legislation-landscape-2026" },
            { n: "Forbes (state roundup)", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" }] },
    { date: "2026-04-01", st: "", kind: "legislation", status: "Federal bill introduced (reported)",
      title: "Transparent Job Advertising Accountability Act reported in Congress",
      sum: "A federal ghost-job transparency bill has been reported as introduced in Congress. Early stage; committee action not yet documented in this snapshot.",
      src: [{ n: "SoviaJobs legislation tracker", u: "https://www.soviajobs.com/ghost-job-laws" }] },
    { date: "2026-01-01", st: "", kind: "context", status: "Law in force (Ontario, Canada)",
      title: "Ontario enacts the first anti-ghost-job law",
      sum: "Ontario\u2019s Working for Workers legislation (Bill 190) took effect: employers must disclose in postings whether a position is actually vacant. The first jurisdiction anywhere with an anti-ghost-job law in force \u2014 the template US bills are chasing.",
      src: [{ n: "SoviaJobs legislation tracker", u: "https://www.soviajobs.com/ghost-job-laws" }] },
    { date: "2025-04-25", st: "", kind: "context", status: "Congressional research published",
      title: "CRS: ghost jobs may distort official job-openings data",
      sum: "The Congressional Research Service\u2019s In Focus brief documents why ghost postings appear, warns they may contaminate official measures of job openings, and maps existing law and legislative proposals \u2014 the neutral, citable foundation for every bill above.",
      src: [{ n: "Congress.gov CRS IF12977 (primary)", u: "https://www.congress.gov/crs-product/IF12977" }] },
    { date: "2024-11-01", st: "", kind: "courts", status: "Class-action investigation ongoing",
      title: "Private class-action investigation into ghost postings",
      sum: "Plaintiffs\u2019 firm Audet & Partners is running an active class-action investigation into ghost jobs on fraud, negligent-misrepresentation, and unfair-business-practice theories \u2014 the private-litigation lane running parallel to AG enforcement.",
      src: [{ n: "Audet & Partners case page", u: "https://audetlaw.com/lawsuit-updates/ghost-jobs-lawsuit-update/" }] },
    { date: "2025-06-01", st: "", kind: "data", status: "Legal scholarship",
      title: "Columbia Law Review Forum: the FTC can act now",
      sum: "Analysis by Daniel J. Grimm argues ghost-job ads may already violate Section 5(a) of the FTC Act as deceptive commercial practices \u2014 no new legislation required. The theory the Texas investigation echoes at state level.",
      src: [{ n: "Forbes summary of the Forum piece", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" }] }
  ];

  /* Sourced numbers only \u2014 each stat names its survey and source. */
  const GHOST_STATS = [
    { stat: "8 in 10 recruiters admit their company posts jobs that are filled or don\u2019t exist", src: "MyPerfectResume survey of 753 US recruiters (2024), via Forbes", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" },
    { stat: "40% of hiring managers admitted posting a fake listing in the past year", src: "Resume Builder survey of 1,600+ hiring managers (2024), via Bloomberg Law", u: "https://news.bloomberglaw.com/daily-labor-report/state-job-ad-bills-shift-from-pay-ranges-to-ghost-jobs-ai-use" },
    { stat: "One-fifth to one-third of online job postings may be ghost jobs", src: "Independent studies cited by the Texas Attorney General (2026)", u: "https://www.texasattorneygeneral.gov/news/releases/attorney-general-ken-paxton-investigates-linkedin-advertising-fake-and-misleading-job-opportunities" },
    { stat: "62% of hiring managers said they used ghost ads to make current employees feel replaceable", src: "MyPerfectResume survey (2024), via Forbes", u: "https://www.forbes.com/sites/michelletravis/2026/05/26/ghost-job-ads-are-latest-employer-tactic-targeted-by-state-lawmakers/" }
  ];

  /* Live follow links \u2014 the feed above is a shipped snapshot; these are how
   * you watch it move between Clapback updates. */
  const GHOST_FOLLOW = [
    { n: "Google News: \u201cghost jobs\u201d", u: "https://news.google.com/search?q=%22ghost%20jobs%22" },
    { n: "Texas AG newsroom", u: "https://www.texasattorneygeneral.gov/news" },
    { n: "CourtListener docket search: ghost jobs", u: "https://www.courtlistener.com/?q=%22ghost+jobs%22" },
    { n: "Reddit: r/recruitinghell & search", u: "https://www.reddit.com/search/?q=%22ghost%20job%22" },
    { n: "SoviaJobs state-law tracker", u: "https://www.soviajobs.com/ghost-job-laws" }
  ];

  /* Ghost-job incident log \u2014 kinds + US tile-grid layout (col,row) for the
   * local heatmap. Grid is the standard square-per-state cartogram: roughly
   * geographic, every jurisdiction exactly once, no path data to get wrong. */
  const GHOST_KINDS = [
    { k: "ghostjob", label: "Ghost job posting (role doesn\u2019t exist / never closes)" },
    { k: "ghosted", label: "Ghosted after interview or offer" },
    { k: "scam", label: "Scam or impersonation" },
    { k: "fees", label: "Fee demand / pay-to-work" },
    { k: "unethical", label: "Other unethical recruiting" }
  ];
  const TILE_GRID = {
    AK:[0,0], ME:[10,0],
    WA:[0,1], MT:[2,1], ND:[3,1], MN:[4,1], WI:[5,1], MI:[7,1], NY:[8,1], VT:[9,1], NH:[10,1],
    OR:[0,2], ID:[1,2], WY:[2,2], SD:[3,2], IA:[4,2], IL:[5,2], IN:[6,2], OH:[7,2], PA:[8,2], NJ:[9,2], MA:[10,2], RI:[11,2],
    CA:[0,3], NV:[1,3], UT:[2,3], CO:[3,3], NE:[4,3], MO:[5,3], KY:[6,3], WV:[7,3], VA:[8,3], MD:[9,3], DE:[10,3], CT:[11,3],
    AZ:[1,4], NM:[2,4], KS:[3,4], AR:[4,4], TN:[5,4], NC:[6,4], SC:[7,4], DC:[8,4],
    OK:[3,5], LA:[4,5], MS:[5,5], AL:[6,5], GA:[7,5],
    HI:[0,6], TX:[3,6], FL:[8,6]
  };

  /* State attorney general offices \u2014 official sites for all 50 states + DC,
   * sourced from the USA.gov state-attorney-general directory (fetched Aug 2026).
   * `form` = consumer-complaint intake verified individually against the state
   * site (Aug 2026). Where absent, the UI builds a site-scoped search that lands
   * on the current form and survives state-site redesigns. */
  const AG_OFFICES = {
    AL: { site: "https://www.alabamaag.gov/" },
    AK: { site: "https://law.alaska.gov/" },
    AZ: { site: "https://www.azag.gov/" },
    AR: { site: "https://arkansasag.gov/" },
    CA: { site: "https://www.oag.ca.gov/", form: "https://oag.ca.gov/contact/consumer-complaint-against-business-or-company" },
    CO: { site: "https://coag.gov/" },
    CT: { site: "https://portal.ct.gov/ag" },
    DE: { site: "https://attorneygeneral.delaware.gov/" },
    DC: { site: "https://oag.dc.gov/" },
    FL: { site: "https://www.myfloridalegal.com/", form: "https://www.myfloridalegal.com/consumer-protection/consumer-complaint-form" },
    GA: { site: "https://law.georgia.gov/" },
    HI: { site: "https://ag.hawaii.gov/" },
    ID: { site: "https://www.ag.idaho.gov/" },
    IL: { site: "https://www.illinoisattorneygeneral.gov/" },
    IN: { site: "https://www.in.gov/attorneygeneral/" },
    IA: { site: "https://www.iowaattorneygeneral.gov/" },
    KS: { site: "https://www.ag.ks.gov/" },
    KY: { site: "https://www.ag.ky.gov/" },
    LA: { site: "https://www.ag.state.la.us/" },
    ME: { site: "https://www.maine.gov/ag/" },
    MD: { site: "https://www.marylandattorneygeneral.gov/" },
    MA: { site: "https://www.mass.gov/orgs/office-of-the-attorney-general" },
    MI: { site: "https://www.michigan.gov/ag/" },
    MN: { site: "https://www.ag.state.mn.us/" },
    MS: { site: "https://attorneygenerallynnfitch.com/" },
    MO: { site: "https://ago.mo.gov/" },
    MT: { site: "https://dojmt.gov/attorney-generals-office/" },
    NE: { site: "https://ago.nebraska.gov/" },
    NV: { site: "https://ag.nv.gov/" },
    NH: { site: "https://www.doj.nh.gov/" },
    NJ: { site: "https://www.njoag.gov/" },
    NM: { site: "https://nmdoj.gov/" },
    NY: { site: "https://ag.ny.gov/", form: "https://ag.ny.gov/file-complaint/consumer" },
    NC: { site: "https://ncdoj.gov/" },
    ND: { site: "https://attorneygeneral.nd.gov/" },
    OH: { site: "https://www.ohioattorneygeneral.gov/" },
    OK: { site: "https://oklahoma.gov/oag.html" },
    OR: { site: "https://www.doj.state.or.us/" },
    PA: { site: "https://www.attorneygeneral.gov/", form: "https://www.attorneygeneral.gov/submit-a-complaint/consumer-complaint/" },
    RI: { site: "https://riag.ri.gov/" },
    SC: { site: "https://www.scag.gov/" },
    SD: { site: "https://atg.sd.gov/" },
    TN: { site: "https://www.tn.gov/attorneygeneral.html" },
    TX: { site: "https://www.texasattorneygeneral.gov/", form: "https://www.texasattorneygeneral.gov/consumer-protection/file-consumer-complaint" },
    UT: { site: "https://attorneygeneral.utah.gov/" },
    VT: { site: "https://ago.vermont.gov/" },
    VA: { site: "https://www.oag.state.va.us/" },
    WA: { site: "https://www.atg.wa.gov/" },
    WV: { site: "https://ago.wv.gov/" },
    WI: { site: "https://www.doj.state.wi.us/" },
    WY: { site: "https://ag.wyo.gov/" }
  };

  /* Federal reporting lanes \u2014 stable .gov intakes. */
  const REPORT_FED = [
    { name: "FTC \u2014 ReportFraud.ftc.gov", url: "https://reportfraud.ftc.gov/", why: "The main federal intake for scams, fake job postings, and deceptive business practices. Shared with 3,000+ law-enforcement agencies." },
    { name: "FBI IC3", url: "https://www.ic3.gov/", why: "Internet-enabled fraud \u2014 fake-check schemes, wire transfers, crypto payment demands, account takeovers." },
    { name: "IdentityTheft.gov", url: "https://www.identitytheft.gov/", why: "If you gave a fake recruiter your SSN, ID documents, or bank details \u2014 this builds your official recovery plan." },
    { name: "EEOC", url: "https://www.eeoc.gov/", why: "Discrimination in hiring \u2014 including by staffing agencies, which are covered employers." },
    { name: "FTC \u2014 job scams guide", url: "https://consumer.ftc.gov/articles/job-scams", why: "Current fake-recruiter and fake-job patterns, kept up to date." }
  ];

  /* Ghosting letters \u2014 candidate self-advocacy. Polite, but very direct.
   * Written for the user\u2019s OWN applications: each letter answers a counterparty
   * who engaged the user first (interview, assessment, submission) and then went
   * silent. One clean ask, a real deadline, zero groveling, zero threats. */
  const GHOST_LETTERS = {
    ghostInterview: {
      label: "Ghosted after an interview",
      hint: "You interviewed, they promised next steps, then silence.",
      subject: "Following up on my {{role}} interview \u2014 decision or timeline?",
      body: "Hi {{recipient}},\n\nI interviewed for the {{role}} position with {{org}} on {{lastdate}} and haven\u2019t heard back since. Hiring timelines shift \u2014 I understand that \u2014 so I\u2019m asking directly: am I still under consideration?\n\nIf no decision has been made yet, a realistic date for one is all I need. If I\u2019m no longer in the running, a two-line note saying so is genuinely welcome; it lets us both close the loop professionally.\n\nIf I don\u2019t hear back by {{deadline}}, I\u2019ll take that as my answer and withdraw my candidacy so we can each move on.\n\nThank you \u2014 I did appreciate the conversation.\n\n{{name}}\n{{today}}"
    },
    ghostFinal: {
      label: "Ghosted after final round / verbal offer",
      hint: "Final interviews done, an offer was discussed, then nothing.",
      subject: "{{role}} \u2014 I need a definitive answer",
      body: "Hi {{recipient}},\n\nAfter my final-round interview for {{role}} with {{org}} on {{lastdate}}, I was told to expect next steps shortly. Since then, I\u2019ve heard nothing.\n\nI\u2019ve invested significant time in this process \u2014 multiple interviews, preparation, and in some cases my references\u2019 time as well \u2014 so I\u2019m asking plainly: is an offer coming, or not? Either answer is fine. No answer is the only unprofessional outcome.\n\nPlease reply by {{deadline}} with a decision or a firm date for one. Absent that, I\u2019ll withdraw my candidacy on that date and commit fully to my other options.\n\nRespectfully,\n{{name}}\n{{today}}"
    },
    ghostAssessment: {
      label: "Ghosted after a take-home / assessment",
      hint: "You delivered hours of unpaid work, then silence.",
      subject: "{{role}} assessment \u2014 outcome requested",
      body: "Hi {{recipient}},\n\nOn {{lastdate}} I submitted the assessment for the {{role}} position with {{org}} \u2014 several hours of focused, unpaid work, delivered on time. I haven\u2019t received any response since.\n\nI\u2019m asking for two things, directly: the outcome of my assessment, and whatever feedback you can share. Work product deserves at least an acknowledgment.\n\nPlease reply by {{deadline}}. After that date I\u2019ll consider this process closed, and I don\u2019t authorize any further use of the work I submitted.\n\nThank you,\n{{name}}\n{{today}}"
    },
    ghostRecruiter: {
      label: "Recruiter submitted me, then vanished",
      hint: "A staffing recruiter pitched you, sent your info out, went quiet.",
      subject: "My {{role}} submission \u2014 status and where my information went",
      body: "Hi {{recipient}},\n\nYou contacted me about the {{role}} opportunity, submitted my information, and I haven\u2019t heard from you since {{lastdate}}. Because my personal data is now in motion, I need three specific answers:\n\n1. The current status of my submission.\n2. Exactly which companies have received my r\u00e9sum\u00e9 and details through {{org}}.\n3. Whether {{org}} intends to keep marketing my profile.\n\nUntil I say otherwise in writing, please do not submit me to any further roles. I remain interested in real opportunities \u2014 with communication to match.\n\nPlease reply by {{deadline}}.\n\n{{name}}\n{{today}}"
    },
    ghostCloseFile: {
      label: "Final notice: withdraw + delete my file",
      hint: "You\u2019ve already followed up. Time to end it on your terms.",
      subject: "{{role}} \u2014 withdrawal of candidacy and data-deletion request",
      body: "Hello {{recipient}},\n\nI\u2019ve followed up about the {{role}} process with {{org}} without response, so I\u2019m resolving it myself.\n\nEffective today, I withdraw my candidacy and revoke any consent to market, submit, or shop my profile.\n\nAdditionally, I request deletion of my candidate data \u2014 r\u00e9sum\u00e9, contact details, submittal records, assessments, and interview notes \u2014 under applicable privacy law ({{state}} resident), with written confirmation of the deletion within the statutory response window.\n\nNo further response about the role is needed. The deletion confirmation is.\n\n{{name}}\n{{today}}"
    }
  };

  /* State-level verification notes for staffing & recruiting agencies.
   * Only states with a verified, agency-specific registration/licensing regime
   * get a specific entry (checked against primary sources, Aug 2026); everyone
   * else gets DEFAULT. HEALTH applies on top for medical staffing anywhere. */
  const STATE_NOTES = {
    MA: "Massachusetts licenses employment agencies and registers staffing/placement agencies with the Department of Labor Standards (Employment, Placement, and Staffing Agencies Program on mass.gov), and the Temporary Workers Right to Know Law entitles you to written job details before accepting an assignment. Any agency placing Massachusetts workers should hold one of these credentials \u2014 ask for the license or registration number.",
    NJ: "New Jersey requires staffing and employment agencies to register with the Division of Consumer Affairs, and the Temporary Workers\u2019 Bill of Rights adds pay-transparency and disclosure protections. Ask an unfamiliar NJ agency for its Consumer Affairs registration before handing over documents.",
    IL: "Illinois registers day & temporary labor service agencies with the Illinois Department of Labor under the Day and Temporary Labor Services Act, and IDOL publishes the registered-agency list. An unregistered day-labor agency in Illinois is a serious red flag.",
    NY: "New York requires employment agencies to be licensed \u2014 in New York City by the Department of Consumer and Worker Protection. Ask for the license number and verify it with the licensing office before paying anyone anything.",
    CA: "California has no general staffing-agency license, but employment agencies must file a surety bond with the Secretary of State, and talent agencies must be licensed by the Labor Commissioner. Be especially wary of \u201ctalent agencies\u201d charging up-front fees \u2014 that is the classic California scam pattern.",
    DEFAULT: "Most states don\u2019t license general staffing agencies. To verify a local firm: check your state labor department (the US DOL keeps a directory of every state labor office), search your state attorney general\u2019s consumer-complaint records, and look for the agency in the American Staffing Association directory.",
    HEALTH: "Medical staffing is different: many states separately register healthcare staffing agencies (\u201cnurse pools\u201d) with the state health department or board of nursing. For a healthcare agency you don\u2019t recognize, check that registry too."
  };

  const DROP = {
    name: "California DROP (Delete Request & Opt-out Platform)",
    url: "https://privacy.ca.gov/drop/",
    app: "https://consumer.drop.privacy.ca.gov/",
    blurb: "If you live in California, this is your shortcut. Under the DELETE Act, one verified request through the state's DROP platform forces every registered data broker (500+) to delete your data and stop selling it. As of August 1, 2026, brokers must check DROP every 45 days and process all pending deletion requests."
  };

  const MASKED_EMAIL = [
    { name: "Apple Hide My Email", url: "https://support.apple.com/en-us/105078", note: "Built into iCloud+; generates unique aliases that forward to you." },
    { name: "Firefox Relay", url: "https://relay.firefox.com/", note: "Free tier; email (and phone) masks." },
    { name: "DuckDuckGo Email Protection", url: "https://duckduckgo.com/email/", note: "Free; also strips trackers from forwarded mail." },
    { name: "SimpleLogin", url: "https://simplelogin.io/", note: "Open source; unlimited aliases." },
    { name: "addy.io", url: "https://addy.io/", note: "Open source alias service." }
  ];

  // Letter templates. Placeholders: {{name}} {{state}} {{city}} {{email}} {{today}}
  const LETTERS = {
    deletion:
      "Subject: Consumer Privacy Request — Deletion and Opt-Out\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}} and I am a resident of {{state}}. I am exercising my rights under applicable consumer-privacy law (including, where applicable, the California Consumer Privacy Act and my state's consumer privacy law) and under your posted privacy policy.\n\n" +
      "I request that you:\n" +
      "1. Delete all personal information you have collected about me;\n" +
      "2. Stop selling and sharing my personal information; and\n" +
      "3. Confirm in writing what you have done and what categories of data you held.\n\n" +
      "To locate my record, I am providing only the minimum information necessary: my full name ({{name}}) and state of residence ({{state}}). If you require additional verification, please contact me at {{email}} and tell me specifically what is needed before disclosing or processing anything further.\n\n" +
      "Please complete this request within the timeframe required by law (generally 45 days) and send confirmation to {{email}}.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    urgentRemoval:
      "Subject: Urgent Safety-Related Removal Request\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}}, a resident of {{state}}. I am requesting the immediate removal and suppression of any listing, profile, or record you publish or sell about me, including my name, home address, phone number(s), email address(es), and any information about my relatives or associates.\n\n" +
      "This request is made for personal-safety reasons. Continued publication of my home address and contact information creates a risk of physical harm to me. I am exercising my rights under applicable consumer-privacy law and your posted privacy policy, and I ask that you also flag my record for permanent suppression so it does not reappear.\n\n" +
      "Please confirm completion to {{email}}. If you require verification, tell me exactly what is needed before publishing or processing anything further; do not post this request or my supporting details publicly.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    fcra:
      "Subject: FCRA Dispute — Request to Correct Inaccurate Information\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}} and I am disputing inaccurate information in the consumer report or file you maintain about me, under the Fair Credit Reporting Act (15 U.S.C. § 1681i).\n\n" +
      "The following information is inaccurate:\n" +
      "  - [Describe the error]\n\n" +
      "The accurate information is:\n" +
      "  - [State the correct details]\n\n" +
      "Under the FCRA, please investigate this dispute, correct or delete the inaccurate information, and send me a corrected copy of my file, generally within 30 days.\n\n" +
      "You can reach me at {{email}}.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    fileRequest:
      "Subject: FCRA File Disclosure Request (15 U.S.C. § 1681g)\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}}, a resident of {{state}}. Under section 609 of the Fair Credit Reporting Act (15 U.S.C. § 1681g), I request a complete copy of my consumer file, including all information in my file, the sources of that information, and a record of all inquiries.\n\n" +
      "If you are a nationwide specialty consumer reporting agency, I am entitled to one free file disclosure in any 12-month period. If any fee applies, tell me before processing.\n\n" +
      "Please tell me exactly what identity verification you require, and contact me at {{email}} before disclosing anything further.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    gdpr:
      "Subject: GDPR Article 17 — Request for Erasure of Personal Data\n\n" +
      "To the Data Protection Officer,\n\n" +
      "My name is {{name}}. Under Article 17 of the General Data Protection Regulation (and the UK GDPR where applicable), I request the erasure of all personal data you hold about me, and under Article 21 I object to the processing of my data for direct marketing and profiling.\n\n" +
      "Please also, under Article 15, tell me what personal data you hold, its source, and every third party you have shared it with. If you rely on legitimate interests, explain that basis; I contest it.\n\n" +
      "Please confirm completion within one month (Article 12(3)) to {{email}}. If you need to verify my identity, tell me exactly what is required before processing.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    escalate:
      "Subject: Second Request — Unanswered Privacy Request (Escalation)\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}}, a resident of {{state}}. On [date of first request] I asked you to delete my personal information and stop selling it. That legal deadline has passed with no adequate response.\n\n" +
      "This is my formal second request. If I do not receive written confirmation of deletion within 10 business days, I will file a complaint with my state Attorney General and, where applicable, the California Privacy Protection Agency or the FTC, and document your non-compliance.\n\n" +
      "Confirm completion to {{email}}.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    creditFreeze:
      "Subject: Request to Place a Security Freeze\n\n" +
      "To Whom It May Concern,\n\n" +
      "My name is {{name}}, a resident of {{state}}. I request that you place a security freeze on my consumer file so that it cannot be accessed for new credit or accounts without my authorization. A freeze is free under federal law.\n\n" +
      "Please confirm the freeze and send me the PIN or credentials I need to lift it later, to {{email}}. Tell me what identity verification you require before proceeding.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}",
    childRemoval:
      "Subject: Urgent Removal — Information About a Minor\n\n" +
      "To Whom It May Concern,\n\n" +
      "I am {{name}}, the parent/legal guardian of a minor child whose information appears in a listing, profile, or record you publish or sell. I request the immediate and permanent removal and suppression of ALL information relating to my child, including name, age, address, school, photos, and any linkage to me or other family members.\n\n" +
      "Publishing a child's information creates a safety risk. I am exercising rights under applicable privacy law (including COPPA and state privacy laws) and your posted policy. Do not post this request or my child's details publicly. If you require verification of guardianship, tell me exactly what is needed and contact me only at {{email}}.\n\n" +
      "Sincerely,\n{{name}}\n{{today}}"
  };

  /* ================================================================== */
  /* MODULE 2 — VETTING (assess an inbound contact for scam/spoof risk)  */
  /* All matching is local. Nothing here identifies who owns anything.   */
  /* ================================================================== */

  // Free consumer mailbox providers. A message *claiming* to be a bank or
  // company but sent from one of these is a red flag.
  const FREEMAIL = [
    "gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "outlook.com", "hotmail.com",
    "live.com", "msn.com", "aol.com", "icloud.com", "me.com", "mac.com", "proton.me",
    "protonmail.com", "gmx.com", "mail.com", "zoho.com", "yandex.com", "hushmail.com"
  ];

  // TLDs heavily overrepresented in phishing/abuse (many have legit uses too).
  const RISKY_TLDS = [
    "zip", "mov", "top", "xyz", "click", "country", "kim", "work", "party", "gq", "cf",
    "ml", "ga", "tk", "rest", "fit", "cam", "loan", "men", "date", "stream", "download",
    "racing", "review", "science", "win", "bid", "trade", "webcam", "cricket", "accountant",
    "support", "help", "live", "buzz", "monster", "sbs", "cfd", "lol", "quest"
  ];

  const URL_SHORTENERS = [
    "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "buff.ly", "is.gd", "rebrand.ly",
    "cutt.ly", "shorturl.at", "rb.gy", "t.ly", "tiny.cc", "bl.ink", "lnkd.in", "snip.ly",
    "shorte.st", "adf.ly", "bit.do", "soo.gd", "clck.ru", "v.gd"
  ];

  // Commonly impersonated brands: name, legit registrable domains, and tokens
  // that, when they appear in an *unofficial* domain, signal impersonation.
  const IMPERSONATED_BRANDS = [
    { name: "PayPal", domains: ["paypal.com"], tokens: ["paypal"] },
    { name: "Apple / iCloud", domains: ["apple.com", "icloud.com"], tokens: ["apple", "icloud", "appleid"] },
    { name: "Amazon", domains: ["amazon.com"], tokens: ["amazon"] },
    { name: "Microsoft", domains: ["microsoft.com", "live.com", "office.com", "office365.com"], tokens: ["microsoft", "office365", "outlook"] },
    { name: "Google", domains: ["google.com", "gmail.com"], tokens: ["google", "gmail"] },
    { name: "Netflix", domains: ["netflix.com"], tokens: ["netflix"] },
    { name: "Meta / Facebook", domains: ["facebook.com", "meta.com"], tokens: ["facebook", "faceb00k"] },
    { name: "Instagram", domains: ["instagram.com"], tokens: ["instagram"] },
    { name: "USPS", domains: ["usps.com"], tokens: ["usps"] },
    { name: "UPS", domains: ["ups.com"], tokens: ["ups-", "-ups"] },
    { name: "FedEx", domains: ["fedex.com"], tokens: ["fedex"] },
    { name: "DHL", domains: ["dhl.com"], tokens: ["dhl-", "-dhl"] },
    { name: "IRS", domains: ["irs.gov"], tokens: ["irs-", "irsgov"] },
    { name: "Social Security (SSA)", domains: ["ssa.gov"], tokens: ["ssa-", "socialsecurity"] },
    { name: "Chase", domains: ["chase.com"], tokens: ["chase"] },
    { name: "Bank of America", domains: ["bankofamerica.com", "bofa.com"], tokens: ["bankofamerica", "bofa"] },
    { name: "Wells Fargo", domains: ["wellsfargo.com"], tokens: ["wellsfargo"] },
    { name: "Citi", domains: ["citi.com", "citibank.com"], tokens: ["citibank"] },
    { name: "Capital One", domains: ["capitalone.com"], tokens: ["capitalone"] },
    { name: "American Express", domains: ["americanexpress.com", "aexp.com"], tokens: ["americanexpress", "amex"] },
    { name: "Coinbase", domains: ["coinbase.com"], tokens: ["coinbase"] },
    { name: "Venmo", domains: ["venmo.com"], tokens: ["venmo"] },
    { name: "Zelle", domains: ["zellepay.com"], tokens: ["zelle"] },
    { name: "Cash App", domains: ["cash.app", "square.com"], tokens: ["cashapp"] },
    { name: "Binance", domains: ["binance.com", "binance.us"], tokens: ["binance"] },
    { name: "Walmart", domains: ["walmart.com"], tokens: ["walmart"] },
    { name: "Best Buy / Geek Squad", domains: ["bestbuy.com"], tokens: ["geeksquad", "bestbuy"] },
    { name: "Norton / McAfee", domains: ["norton.com", "mcafee.com"], tokens: ["norton", "mcafee"] },
    { name: "LinkedIn", domains: ["linkedin.com"], tokens: ["linkedin"] },
    { name: "DocuSign", domains: ["docusign.com", "docusign.net"], tokens: ["docusign"] },
    { name: "AT&T", domains: ["att.com"], tokens: ["att-", "attmail"] },
    { name: "Verizon", domains: ["verizon.com"], tokens: ["verizon"] },
    { name: "T-Mobile", domains: ["t-mobile.com", "tmobile.com"], tokens: ["tmobile"] },
    { name: "Xfinity / Comcast", domains: ["xfinity.com", "comcast.net"], tokens: ["xfinity", "comcast"] },
    /* Job platforms — heavily impersonated in fake-recruiter scams */
    { name: "Indeed", domains: ["indeed.com"], tokens: ["indeed"] },
    { name: "ZipRecruiter", domains: ["ziprecruiter.com"], tokens: ["ziprecruiter"] },
    { name: "Glassdoor", domains: ["glassdoor.com"], tokens: ["glassdoor"] },
    { name: "Monster", domains: ["monster.com"], tokens: [] },
    { name: "Workday", domains: ["workday.com", "myworkday.com"], tokens: ["myworkday"] }
  ];

  // Scam-language lexicon, grouped by manipulation tactic. Lowercased substrings.
  const SCAM_PHRASES = {
    "Manufactured urgency / threats": [
      "urgent", "act now", "immediately", "within 24 hours", "within 48 hours", "final notice",
      "last warning", "account has been suspended", "account suspended", "account is locked",
      "account will be closed", "will be deactivated", "your access will", "expire", "expires today",
      "failure to respond", "legal action", "lawsuit", "arrest warrant", "warrant for your arrest",
      "you will be arrested", "police", "suspended immediately", "avoid suspension", "verify now or"
    ],
    "Unusual payment demands": [
      "gift card", "google play card", "apple gift card", "itunes card", "steam card", "prepaid card",
      "wire transfer", "western union", "moneygram", "bitcoin", "cryptocurrency", "crypto wallet",
      "zelle", "venmo", "cash app", "pay with", "send payment", "processing fee", "release fee",
      "unlock fee", "pay a fee", "bank transfer to", "convert to crypto"
    ],
    "Requests for credentials / codes": [
      "verify your account", "confirm your password", "enter your password", "one-time code",
      "one time password", "otp", "verification code", "security code", "2fa code", "read me the code",
      "social security number", "your ssn", "confirm your identity", "update your payment",
      "re-enter your", "log in to verify", "click the link to verify", "confirm your card",
      "card number", "cvv", "pin number", "online banking login"
    ],
    "Prize / lottery bait": [
      "you have won", "you've won", "congratulations you", "claim your prize", "you are a winner",
      "selected as a winner", "lottery", "sweepstakes", "free gift", "reward is waiting",
      "you qualify for", "government grant", "you are entitled to"
    ],
    "Impersonation of authority": [
      "this is the irs", "internal revenue service", "social security administration",
      "your bank's security", "amazon security", "microsoft support", "apple support", "tech support",
      "refund department", "fraud department", "medicare", "your utility", "final disconnection",
      "warranty department", "we detected a virus", "your computer is infected"
    ],
    "Secrecy / isolation pressure": [
      "do not tell anyone", "keep this confidential", "don't hang up", "stay on the line",
      "this is not a scam", "you can trust me", "between us", "do not contact", "don't tell your bank",
      "go to the store now", "withdraw cash"
    ],
    "Too-good / relationship bait": [
      "guaranteed return", "double your money", "risk-free investment", "investment opportunity",
      "i love you", "we have never met", "stuck abroad", "need your help", "send me money",
      "hospital bill", "customs fee", "i can't call right now", "buy me a gift card"
    ],
    "Fake recruiter / job-offer bait": [
      "interview via telegram", "interview via whatsapp", "telegram interview", "whatsapp interview",
      "google chat interview", "text-based interview", "no interview needed", "hired without an interview",
      "you have been shortlisted", "your resume impressed us", "pay for training", "training fee",
      "equipment fee", "purchase equipment", "send you a check", "deposit the check",
      "keep the difference", "refund the remainder", "onboarding fee", "registration fee",
      "daily commission", "commission per task", "complete simple tasks", "earn per task",
      "flexible hours no experience", "$300 a day", "$500 a day", "weekly salary in advance"
    ]
  };

  // External, authoritative checks — links the user chooses to open (no auto-fetch).
  const VERIFY_LINKS = {
    email: [
      { name: "Have I Been Pwned", url: "https://haveibeenpwned.com/", note: "See if this email address appears in known data breaches." },
      { name: "Google 'Results about you'", url: "https://myactivity.google.com/results-about-you", note: "Check what's already public about this email/you." }
    ],
    domain: [
      { name: "Google Safe Browsing status", url: "https://transparencyreport.google.com/safe-browsing/search", note: "Paste the domain to see if Google flags it as unsafe." },
      { name: "ICANN WHOIS lookup", url: "https://lookup.icann.org/", note: "See when the domain was registered — brand-new domains impersonating known brands are a red flag." },
      { name: "VirusTotal URL scan", url: "https://www.virustotal.com/gui/home/url", note: "Scans a URL/domain against many security vendors." }
    ],
    phone: [
      { name: "FTC — how phone scams work", url: "https://consumer.ftc.gov/articles/phone-scams", note: "Signs of a spoofed or scam call, and what to do." },
      { name: "FCC — stop unwanted calls", url: "https://www.fcc.gov/consumers/guides/stop-unwanted-calls-texts-and-faxes", note: "Blocking and reporting spoofed calls." }
    ],
    report: [
      { name: "FTC — Report Fraud", url: "https://reportfraud.ftc.gov/", note: "Report scams and phishing to the FTC." },
      { name: "FBI IC3", url: "https://www.ic3.gov/", note: "Report internet crime, including phishing and online fraud." },
      { name: "IdentityTheft.gov", url: "https://www.identitytheft.gov/", note: "If you shared info, build a recovery plan here." }
    ]
  };

  /* ================================================================== */
  /* MODULE 3 — HARASSMENT RESPONSE                                      */
  /* ================================================================== */

  // Fields for the local, exportable incident log.
  const EVIDENCE_FIELDS = [
    { key: "when", label: "Date & time", placeholder: "e.g. Aug 3, 2026, 9:14 PM", type: "text" },
    { key: "where", label: "Where it happened", placeholder: "Instagram DM / text / email / in person", type: "text" },
    { key: "who", label: "Who (username / number / email)", placeholder: "@handle, phone, or address used", type: "text" },
    { key: "what", label: "What happened", placeholder: "Describe it in your own words — quote exact wording if you can", type: "area" },
    { key: "evidence", label: "Evidence saved", placeholder: "Screenshot filename, URL, or where you stored it", type: "text" },
    { key: "witness", label: "Witnesses", placeholder: "Anyone who saw it", type: "text" },
    { key: "reported", label: "Reported to", placeholder: "Platform / police report # / advocate", type: "text" }
  ];

  const PLATFORM_REPORTS = [
    { name: "Instagram", url: "https://help.instagram.com/", how: "Tap ⋯ on the profile, post, or DM → Report → choose Bullying or harassment. Then open the profile → Block. You can block and report without them being notified." },
    { name: "Facebook", url: "https://www.facebook.com/help/", how: "Click ⋯ on the profile, post, or message → Report / Find support → Harassment. Then ⋯ → Block." },
    { name: "X (Twitter)", url: "https://help.x.com/en/safety-and-security", how: "Click ⋯ on the post or profile → Report → Abuse & harassment. Then ⋯ → Block." },
    { name: "TikTok", url: "https://support.tiktok.com/en/safety-hc", how: "Press and hold the video, or tap ⋯/Share → Report; on a profile tap ⋯ → Report. Then Block." },
    { name: "Snapchat", url: "https://help.snapchat.com/", how: "Press and hold the Snap or message, or tap ⋮ on a profile → Report. Then Block." },
    { name: "YouTube", url: "https://support.google.com/youtube/answer/2802027", how: "Click ⋯ under the video, or the Report link on the channel's About page → Harassment." },
    { name: "Reddit", url: "https://support.reddithelp.com/", how: "Use Report under the post/comment, or file at reddit.com/report for targeted harassment; then block the account." },
    { name: "LinkedIn", url: "https://www.linkedin.com/help/linkedin", how: "Click ⋯ on the profile or message → Report/Block." },
    { name: "WhatsApp", url: "https://faq.whatsapp.com/", how: "Open the chat → tap the contact's name → Report contact, then Block. Reporting forwards the last messages to WhatsApp." },
    { name: "Discord", url: "https://support.discord.com/", how: "Turn on Developer Mode, right-click the message → Report; block the user. For threats, file at dis.gd/request." }
  ];

  const ESCALATION = [
    { name: "In immediate danger? Call 911", url: "", note: "If you feel physically unsafe right now, contact local emergency services. Trust that instinct." },
    { name: "File a police report (non-emergency)", url: "", note: "Bring your evidence log. A report number creates an official record and is often required before a court will issue a protective order. Ask whether an officer or victim advocate can help." },
    { name: "Protective / restraining order — WomensLaw.org", url: "https://www.womenslaw.org/", note: "Plain-language, state-by-state guide to restraining and stalking protective orders, including how to file and what evidence helps. Not just for women." },
    { name: "Report cyberstalking to the FBI (IC3)", url: "https://www.ic3.gov/", note: "For online stalking, threats, extortion, or fraud that crosses state lines." },
    { name: "Report identity theft / fraud (FTC)", url: "https://reportfraud.ftc.gov/", note: "If the harasser is impersonating you or misusing your information." },
    { name: "Intimate images shared without consent — StopNCII", url: "https://stopncii.org/", note: "Creates a digital fingerprint of the image (the image never leaves your device) so participating platforms block it. See also cybercivilrights.org." }
  ];

  const SUPPORT_RESOURCES = [
    { name: "National Domestic Violence Hotline", url: "https://www.thehotline.org/", contact: "Call 1-800-799-7233 · text START to 88788 · 24/7", note: "Confidential help and safety planning, including for stalking and tech-enabled abuse." },
    { name: "SPARC — Stalking Prevention, Awareness & Resource Center", url: "https://www.stalkingawareness.org/", contact: "stalkingawareness.org", note: "How to document stalking, a stalking incident log, and safety-planning guidance." },
    { name: "NNEDV Safety Net — tech safety", url: "https://www.techsafety.org/", contact: "techsafety.org", note: "Guidance on tech-facilitated stalking: spyware/stalkerware, location tracking, and account security." },
    { name: "Cyber Civil Rights Initiative — Safety Center", url: "https://cybercivilrights.org/ccri-safety-center/", contact: "Crisis helpline 1-844-878-2274", note: "Help with online abuse and non-consensual intimate images." },
    { name: "988 Suicide & Crisis Lifeline", url: "https://988lifeline.org/", contact: "Call or text 988", note: "If the stress becomes overwhelming, free confidential support is available any time." }
  ];

  // Footprint-lockdown checklist (harden yourself so you're harder to find/reach).
  const LOCKDOWN_STEPS = [
    { id: "2fa", text: "Turn on two-factor authentication (an authenticator app, not SMS if you can) on your email first, then your socials. This is the single biggest thing that stops account takeover.", url: "https://www.cisa.gov/secure-our-world" },
    { id: "passwords", text: "Change passwords on any account the harasser might know or have accessed; use a password manager so each one is unique.", url: "" },
    { id: "removeself", text: "Remove yourself from people-search sites so your home address and phone aren't one search away — use the 'Audit My Exposure' tab in this tool.", url: "" },
    { id: "resultsabout", text: "Set up Google 'Results about you' to monitor for and remove pages exposing your contact info.", url: "https://myactivity.google.com/results-about-you" },
    { id: "location", text: "Turn off location sharing everywhere: phone Find-My sharing, Snapchat's Snap Map (Ghost Mode), shared albums, and check-ins. Review which apps have location permission.", url: "" },
    { id: "socialprivacy", text: "Lock down social privacy: set accounts to private, review and prune followers/friends, and remove posts that reveal your home, workplace, routine, or car.", url: "" },
    { id: "stalkerware", text: "If someone had physical access to your phone, check for stalkerware/spyware and review installed apps and account sessions.", url: "https://stopstalkerware.org/information-for-survivors/" },
    { id: "masked", text: "Use a masked email and a secondary phone number (e.g. Google Voice) for new signups so your real contacts are harder to link to you.", url: "https://voice.google.com/" },
    { id: "gpc", text: "Turn on Global Privacy Control (GPC) so brokers in several states must honor deletion/opt-out automatically.", url: "https://globalprivacycontrol.org/" },
    { id: "address", text: "Keep your home address off the record: opt out of pre-screened offers, ask your state about an Address Confidentiality Program, and consider a P.O. box or private mailbox for mail.", url: "https://www.optoutprescreen.com/" }
  ];

  /* ================================================================== */
  /* MODULE 4 — SOCIAL MEDIA & DIGITAL FOOTPRINT                         */
  /* Everything here is about YOUR OWN accounts: hardening privacy,      */
  /* bulk-cleaning old posts/likes, downloading your data, and deleting  */
  /* accounts. The optional automation only ever acts on the account you */
  /* are already logged into, in your own browser. No third-party server.*/
  /* ================================================================== */

  // kind: privacy | bulk | download | delete | thirdparty | ad
  // actions: on-page automation recipes (implemented in social.js). Each is
  //   destructive unless noted, and requires you to already be on `where`.
  const SOCIAL_PLATFORMS = [
    {
      id: "x", name: "X (Twitter)", icon: "𝕏", color: "#0f1419",
      hosts: ["x.com", "twitter.com"],
      summary: "Bulk-delete your old posts, reposts, and likes, lock your account, and hide your activity. X is one of the most automatable platforms.",
      automatable: true,
      actions: [
        { id: "x-delete-posts", label: "Delete my posts", desc: "Works through your profile page, deleting your own tweets newest-first.", where: "https://x.com/", whereHint: "Open your own profile (your posts tab) before starting.", destructive: true, gate: true },
        { id: "x-unretweet", label: "Undo my reposts", desc: "Removes your reposts (retweets) from your profile timeline.", where: "https://x.com/", whereHint: "Open your profile → Posts tab.", destructive: true },
        { id: "x-unlike", label: "Remove my likes", desc: "Unlikes posts from your Likes tab so your likes aren't public history.", where: "https://x.com/", whereHint: "Open your profile → Likes tab.", destructive: true }
      ],
      links: [
        { kind: "privacy", label: "Privacy & safety settings", url: "https://x.com/settings/privacy_and_safety", note: "Protect your posts, control tagging, discoverability by email/phone, and location." },
        { kind: "privacy", label: "Audience & tagging (protect posts)", url: "https://x.com/settings/audience_and_tagging", note: "Flip 'Protect your posts' so only approved followers see them." },
        { kind: "bulk", label: "Your Twitter data / activity", url: "https://x.com/settings/your_twitter_data", note: "Review what X has on you." },
        { kind: "download", label: "Download an archive of your data", url: "https://x.com/settings/download_your_data", note: "Do this BEFORE bulk-deleting — it's your permanent backup." },
        { kind: "thirdparty", label: "Redact (multi-platform cleaner)", url: "https://redact.dev/", note: "Free/paid tool that bulk-deletes across X, Reddit, Facebook, Discord and more." },
        { kind: "thirdparty", label: "TweetDelete", url: "https://www.tweetdelete.net/", note: "Bulk-delete tweets by age; can auto-delete going forward." },
        { kind: "delete", label: "Deactivate / delete account", url: "https://x.com/settings/deactivate", note: "30-day grace period before permanent deletion." }
      ]
    },
    {
      id: "facebook", name: "Facebook", icon: "📘", color: "#1877f2",
      hosts: ["facebook.com", "m.facebook.com"],
      summary: "Facebook has powerful built-in bulk tools — use Manage Activity to archive or bin thousands of old posts at once, then run Privacy Checkup.",
      automatable: true,
      actions: [
        { id: "fb-assist-activity", label: "Open Manage Activity (assisted)", desc: "Opens Facebook's own bulk tool and walks you through selecting and binning old posts — safer than scripted deletion here.", where: "https://www.facebook.com/me/allactivity", whereHint: "We'll open your Activity Log.", destructive: false, assist: true }
      ],
      links: [
        { kind: "privacy", label: "Privacy Checkup", url: "https://www.facebook.com/privacy/checkup/", note: "Guided pass over who can see your stuff, how people find you, and your data settings." },
        { kind: "bulk", label: "Manage Activity (bulk archive/bin posts)", url: "https://www.facebook.com/manage_activity", note: "Native bulk tool — filter by date/person and archive or move to trash in one go." },
        { kind: "bulk", label: "Activity Log", url: "https://www.facebook.com/me/allactivity", note: "Every post, like, comment, and tag — filter and remove." },
        { kind: "privacy", label: "Off-Facebook Activity", url: "https://www.facebook.com/off_facebook_activity/", note: "See and clear the browsing/purchase data other apps sent to Facebook." },
        { kind: "privacy", label: "Limit past posts to Friends", url: "https://www.facebook.com/settings?tab=privacy", note: "One click makes all past public posts friends-only." },
        { kind: "download", label: "Download your information", url: "https://www.facebook.com/dyi", note: "Back up before you delete." },
        { kind: "delete", label: "Delete account", url: "https://www.facebook.com/help/delete_account", note: "Permanent after a grace period." }
      ]
    },
    {
      id: "instagram", name: "Instagram", icon: "📷", color: "#e1306c",
      hosts: ["instagram.com"],
      summary: "Use 'Your Activity' to bulk-delete likes, comments, and old posts, go private, and cut who can see or tag you.",
      automatable: true,
      actions: [
        { id: "ig-assist-activity", label: "Open Your Activity (assisted)", desc: "Opens Instagram's native bulk tool where you can multi-select likes, comments and posts and delete them together.", where: "https://www.instagram.com/your_activity/interactions/", whereHint: "We'll open Your Activity → Interactions.", destructive: false, assist: true }
      ],
      links: [
        { kind: "privacy", label: "Go private + privacy settings", url: "https://www.instagram.com/accounts/privacy_and_security/", note: "Set the account private and review tagging/mentions." },
        { kind: "bulk", label: "Your Activity (bulk delete)", url: "https://www.instagram.com/your_activity/interactions/", note: "Multi-select and delete likes, comments, and posts at once." },
        { kind: "download", label: "Download your data", url: "https://www.instagram.com/download/request/", note: "Request a full export before cleaning." },
        { kind: "delete", label: "Delete account", url: "https://www.instagram.com/accounts/remove/request/permanent/delete/", note: "Permanent deletion request." }
      ]
    },
    {
      id: "tiktok", name: "TikTok", icon: "🎵", color: "#010101",
      hosts: ["tiktok.com"],
      summary: "Make your account private, bulk-delete or hide old videos, clear your comment history, and lock down who can duet/message you.",
      automatable: true,
      actions: [
        { id: "tk-assist-videos", label: "Bulk-manage my videos (assisted)", desc: "Walks you through TikTok's video manager to set old videos private or delete them; TikTok has no one-click bulk delete, so we assist item-by-item.", where: "https://www.tiktok.com/", whereHint: "Open your own profile.", destructive: false, assist: true }
      ],
      links: [
        { kind: "privacy", label: "Privacy settings", url: "https://www.tiktok.com/setting/account-privacy", note: "Private account, who can comment/duet/DM, and 'suggest your account'." },
        { kind: "download", label: "Download your data", url: "https://www.tiktok.com/setting/download-your-data", note: "Request an export of your TikTok data." },
        { kind: "privacy", label: "Personalized ads / data", url: "https://www.tiktok.com/setting/ads", note: "Turn off ad personalization and data sharing." },
        { kind: "delete", label: "Delete account", url: "https://www.tiktok.com/setting/deactivate-or-delete-account", note: "Deactivate or permanently delete." }
      ]
    },
    {
      id: "snapchat", name: "Snapchat", icon: "👻", color: "#0b93f6",
      hosts: ["snapchat.com", "accounts.snapchat.com"],
      summary: "Snaps auto-delete, so the exposure is your profile, Memories, location on Snap Map, and who can contact you. Lock those down.",
      automatable: false,
      links: [
        { kind: "privacy", label: "Ghost Mode + privacy (in-app)", url: "https://help.snapchat.com/hc/en-us/articles/7012304746132-How-do-I-change-my-privacy-settings-on-Snapchat", note: "Turn on Ghost Mode (hide location) and restrict who can contact/view you." },
        { kind: "download", label: "Download my data", url: "https://accounts.snapchat.com/accounts/downloadmydata", note: "Export your account data and Memories." },
        { kind: "delete", label: "Delete account", url: "https://accounts.snapchat.com/accounts/delete_account", note: "Deactivates for 30 days, then permanent." }
      ]
    },
    {
      id: "reddit", name: "Reddit", icon: "👽", color: "#ff4500",
      hosts: ["reddit.com"],
      summary: "Reddit posts are pseudonymous but permanent and searchable. Bulk-edit-then-delete comments so the original text isn't kept, and tighten profile visibility.",
      automatable: true,
      actions: [
        { id: "rd-delete-comments", label: "Delete my comments", desc: "Deletes your comments newest-first from your profile's comments tab. Tip: services that overwrite before deleting are safest against archives.", where: "https://www.reddit.com/user/me/comments/", whereHint: "Open your profile → Comments.", destructive: true, gate: true }
      ],
      links: [
        { kind: "privacy", label: "Privacy settings", url: "https://www.reddit.com/settings/privacy", note: "Hide your profile from search, control who can DM you, and personalization." },
        { kind: "thirdparty", label: "Power Delete Suite", url: "https://github.com/j0be/PowerDeleteSuite", note: "Community tool that overwrites then deletes your comments/posts — beats plain deletion against archives." },
        { kind: "thirdparty", label: "Redact", url: "https://redact.dev/", note: "Also cleans Reddit with edit-before-delete." },
        { kind: "download", label: "Request your data", url: "https://www.reddit.com/settings/data-request", note: "Export before you wipe." },
        { kind: "delete", label: "Deactivate account", url: "https://www.reddit.com/settings/account", note: "Deactivation removes your profile; content may persist unless deleted first." }
      ]
    },
    {
      id: "linkedin", name: "LinkedIn", icon: "💼", color: "#0a66c2",
      hosts: ["linkedin.com"],
      summary: "LinkedIn leaks your full work history to recruiters and scrapers. Hide your public profile, turn off 'open to' broadcasts, and stop data brokers from exporting you.",
      automatable: false,
      links: [
        { kind: "privacy", label: "Public profile visibility", url: "https://www.linkedin.com/public-profile/settings", note: "Hide your profile from search engines and limit what's shown publicly." },
        { kind: "privacy", label: "Data privacy controls", url: "https://www.linkedin.com/mypreferences/d/categories/privacy", note: "Who sees your connections, email, last name, and whether you feed 3rd-party data exports." },
        { kind: "privacy", label: "Turn off profile-discovery by email/phone", url: "https://www.linkedin.com/mypreferences/d/categories/account", note: "Stop people linking your inbox/number to your profile." },
        { kind: "download", label: "Get a copy of your data", url: "https://www.linkedin.com/mypreferences/d/download-my-data", note: "Export before changing anything major." },
        { kind: "delete", label: "Close account", url: "https://www.linkedin.com/psettings/account-management/close-submit", note: "Permanent after closing." }
      ]
    },
    {
      id: "youtube", name: "YouTube", icon: "▶️", color: "#ff0000",
      hosts: ["youtube.com", "studio.youtube.com"],
      summary: "Your comments, likes, and any uploads are tied to your real Google identity. Clean your comment/watch history and set videos private.",
      automatable: false,
      links: [
        { kind: "privacy", label: "YouTube privacy settings", url: "https://www.youtube.com/account_privacy", note: "Keep saved playlists and subscriptions private." },
        { kind: "bulk", label: "Your comment history", url: "https://myactivity.google.com/page?hl=en&page=youtube_comments", note: "Review and delete comments you've left." },
        { kind: "bulk", label: "Manage your videos (Studio)", url: "https://studio.youtube.com/", note: "Set old uploads to Private or delete them." },
        { kind: "privacy", label: "Auto-delete YouTube history", url: "https://myactivity.google.com/activitycontrols/youtube", note: "Turn on auto-delete (3 months) for watch/search history." }
      ]
    },
    {
      id: "google", name: "Google", icon: "🔎", color: "#4285f4",
      hosts: ["google.com", "myaccount.google.com", "myactivity.google.com"],
      summary: "The big one. Remove pages exposing your contact info from Search, auto-delete your activity, cut ad personalization, and download or delete Google data.",
      automatable: false,
      links: [
        { kind: "privacy", label: "Results about you (remove from Search)", url: "https://myactivity.google.com/results-about-you", note: "Monitors Google for your home address/phone/email and requests removal from results." },
        { kind: "bulk", label: "My Activity + auto-delete", url: "https://myactivity.google.com/activitycontrols", note: "Turn on auto-delete for Web & App, Location, and YouTube history." },
        { kind: "privacy", label: "Ad personalization / My Ad Center", url: "https://myadcenter.google.com/", note: "Turn off personalized ads and sensitive-category targeting." },
        { kind: "privacy", label: "Location History / Timeline", url: "https://myactivity.google.com/activitycontrols/location", note: "Pause and delete your location history." },
        { kind: "download", label: "Google Takeout (download everything)", url: "https://takeout.google.com/", note: "Full export of your Google data before any cleanup." },
        { kind: "delete", label: "Delete a service or your account", url: "https://myaccount.google.com/delete-services-or-account", note: "Remove individual services or the whole account." }
      ]
    }
  ];

  // Shared safety copy the automation panel shows before any destructive run.
  const SOCIAL_SAFETY = {
    ownOnly: "This only ever acts on the account you are already logged into in this browser. It cannot and will not touch anyone else's account.",
    permanent: "Deletions are permanent and cannot be undone. Download your data first (button above) so you keep a copy.",
    brittle: "Automation clicks the site's own buttons for you. Sites change their layout often — always run Preview first to see a count, and if it finds 0 items the recipe may need updating.",
    rateLimited: "Runs are paced with human-like pauses so you don't trip the platform's limits. You can press Stop at any time.",
    tos: "Some platforms discourage automation in their terms. Use this on your own account, at a reasonable pace, at your own discretion."
  };

  /* ================================================================== */
  /* MODULE 5 — HARDEN & MONITOR (breach response + ongoing safety)      */
  /* ================================================================== */

  // Immediate checklist after a breach notice or suspected account compromise.
  const BREACH_STEPS = [
    { id: "br-confirm", text: "Confirm what leaked. Check the breach notice or Have I Been Pwned to see whether it was a password, card, SSN, or just an email — that decides how urgent this is.", url: "https://haveibeenpwned.com/" },
    { id: "br-password", text: "Change the password on the breached account AND anywhere you reused it. Reuse is how one breach becomes ten. Use a unique password per site.", url: "" },
    { id: "br-2fa", text: "Turn on two-factor authentication (authenticator app or passkey, not SMS if you can) on that account and your email.", url: "https://www.cisa.gov/secure-our-world" },
    { id: "br-email", text: "Secure the email tied to the account first — it's the reset key to everything else. New password + 2FA + check forwarding rules and recovery info for tampering.", url: "" },
    { id: "br-financial", text: "If payment or SSN data leaked: freeze your credit at all three bureaus (free), watch statements, and set fraud alerts.", url: "https://www.equifax.com/personal/credit-report-services/credit-freeze/" },
    { id: "br-monitor", text: "Expect targeted phishing next — attackers pair leaked details with fake 'security' alerts. Vet anything that contacts you (use the Vet a contact tab).", url: "" },
    { id: "br-report", text: "If someone actually misused your identity, start a recovery plan and get an affidavit at IdentityTheft.gov.", url: "https://www.identitytheft.gov/" }
  ];

  // Proactive account-security hardening (distinct from footprint lockdown).
  const SECURITY_TIPS = [
    { id: "sec-manager", title: "Use a password manager", text: "A manager generates and stores a unique strong password for every site, so one breach can't cascade. Bitwarden and Apple/Google Passwords are free.", url: "https://bitwarden.com/" },
    { id: "sec-passkeys", title: "Switch to passkeys where offered", text: "Passkeys replace passwords with a device-bound key that can't be phished or leaked in a breach. Google, Apple, Microsoft, and many banks support them.", url: "https://fidoalliance.org/passkeys/" },
    { id: "sec-2fa", title: "Two-factor everything important", text: "Prefer an authenticator app or passkey over SMS (SIM-swap risk). Save backup codes offline.", url: "https://www.cisa.gov/secure-our-world" },
    { id: "sec-updates", title: "Keep devices and browsers updated", text: "Most real-world hacks exploit known bugs that an update already fixed. Turn on automatic updates.", url: "" },
    { id: "sec-sim", title: "Lock your phone carrier account", text: "Add a port-out PIN with your carrier so an attacker can't hijack your number to defeat SMS codes.", url: "https://www.fcc.gov/consumers/guides/protect-yourself-against-sim-swapping" },
    { id: "sec-recovery", title: "Harden account recovery", text: "Review the recovery email/phone and security questions on your main accounts — attackers pivot through these. Remove stale ones.", url: "" }
  ];

  // Ongoing monitoring surfaces (mostly free) the tool points you to.
  const MONITORING = [
    { id: "mon-hibp", name: "Have I Been Pwned + notify", url: "https://haveibeenpwned.com/NotifyMe", note: "Register your email to be alerted the moment it shows up in a future breach.", free: true },
    { id: "mon-google", name: "Google 'Results about you'", url: "https://myactivity.google.com/results-about-you", note: "Ongoing monitoring + removal of pages exposing your contact info in Search.", free: true },
    { id: "mon-alerts", name: "Google Alerts on your name", url: "https://www.google.com/alerts", note: "Get emailed when your name (or name + city) newly appears online.", free: true },
    { id: "mon-freeze", name: "Credit freeze (all three bureaus)", url: "https://www.usa.gov/credit-freeze", note: "The single best defense against new-account identity theft — and it's free.", free: true },
    { id: "mon-annual", name: "Free annual credit reports", url: "https://www.annualcreditreport.com/", note: "Now free weekly from all three bureaus — check for accounts you didn't open.", free: true }
  ];

  /* ================================================================== */
  /* MODULE 6 — GUIDED WIZARDS (scenario playbooks that route to tools)  */
  /* ================================================================== */
  // step: { title, body, goto?: view id, url?: external link, label?: link text }
  const WIZARDS = [
    {
      id: "firsttime", icon: "🚀", title: "First-time lockdown", tagline: "New here? Do these in order.",
      intro: "A guided first pass that gets you most of the protection in about an hour. Work top to bottom.",
      steps: [
        { title: "Set up your profile", body: "Add your name, state, and phone once. It personalizes your removal letters and improves spoof detection.", goto: "profile" },
        { title: "Turn on your monitors", body: "Set up Google 'Results about you' and register your email with Have I Been Pwned so you're alerted to future exposure.", goto: "harden" },
        { title: "Clear the top people-search sites", body: "Start with the 'Do first' critical brokers — these publish your home address to anyone who types your name.", goto: "audit" },
        { title: "Lock down your accounts", body: "Password manager, two-factor on your email first, and passkeys where offered.", goto: "harden" },
        { title: "Clean and privatize social media", body: "Go private, bulk-delete old posts and likes, and download your data first.", goto: "social" },
        { title: "Set a recheck reminder", body: "Broker records reappear in 3–6 months. Keep the checklist — items resurface here when they're due.", goto: "audit" }
      ]
    },
    {
      id: "scammed", icon: "🆘", title: "I was just scammed", tagline: "Shared info or sent money? Act now.",
      intro: "Move fast and in this order. The first hour matters most.",
      steps: [
        { title: "If you sent money", body: "Contact your bank or the payment app immediately and report fraud — some transfers can still be stopped or reversed. For gift cards, call the card company's fraud line right away.", url: "https://reportfraud.ftc.gov/", label: "Report to FTC" },
        { title: "If you shared a password", body: "Change it now, and change it anywhere you reused it. Turn on two-factor authentication. Secure your email first — it resets everything else.", goto: "harden" },
        { title: "If you shared card or bank details", body: "Call your bank to freeze/replace the card, watch statements, and freeze your credit at all three bureaus (free).", goto: "harden" },
        { title: "If you shared your SSN", body: "Freeze your credit, set fraud alerts, and build a recovery plan at IdentityTheft.gov.", url: "https://www.identitytheft.gov/", label: "IdentityTheft.gov" },
        { title: "Expect a follow-up scam", body: "Scammers resell victims and return posing as 'recovery' help. Vet anyone who contacts you about it.", goto: "vet" },
        { title: "Document it", body: "Save every message, number, and receipt. If it becomes harassment or ongoing, keep an incident log.", goto: "harass" }
      ]
    },
    {
      id: "moving", icon: "🏠", title: "Moving / new address", tagline: "Keep your new home address off the record.",
      intro: "A new address is a fresh chance to keep it private. Do this around your move.",
      steps: [
        { title: "Opt out of pre-screened offers", body: "Those 'you're pre-approved' letters confirm your address to brokers. Opt out for 5 years or permanently.", url: "https://www.optoutprescreen.com/", label: "OptOutPrescreen" },
        { title: "Consider a mailbox for the record", body: "Using a private mailbox (CMRA) or PO box for accounts and deliveries keeps your real home address out of databases." },
        { title: "Re-run the people-search removals", body: "Removals are tied to your address — a move can resurface old listings under the new one. Recheck the critical sites.", goto: "audit" },
        { title: "Ask about an Address Confidentiality Program", body: "Many states offer an ACP (a legal substitute address) for survivors of stalking or abuse. Your Secretary of State's office can tell you." },
        { title: "Update masked contacts, not the real ones", body: "Where you can, give new services a masked email and a secondary number so the new address isn't linked to your primary identity.", goto: "harden" }
      ]
    },
    {
      id: "jobhunt", icon: "💼", title: "Starting a job search", tagline: "Job-hunting scatters your data — get ahead of it.",
      intro: "Applying for jobs spreads your name, number, resume, and history across job boards, recruiter databases, and screening vendors — and puts you in front of automated systems that score you. Do these to control what a stranger, or an algorithm, can pull about you.",
      steps: [
        { title: "Privatize old resumes and job-board profiles", body: "Old resumes are exposure time capsules — full name, phone, email, address, and work history, visible to anyone with a database login. Delete or privatize the accounts you no longer use.", goto: "audit" },
        { title: "Opt out of recruiter contact databases", body: "Tools like ZoomInfo, Apollo, and RocketReach resell scraped cell numbers and personal emails pulled from your profiles. Opting out shrinks how easily someone links your name to a phone or inbox. Work the 'Contact & profile databases' list.", goto: "audit" },
        { title: "Pull your candidate file from staffing agencies", body: "Every staffing or recruiting agency you've ever registered with still holds your résumé, ID, and pay records — and agencies get breached too. The Agencies tab maps the major US firms and families: request deletion where you're no longer active, and check any recruiter who contacts you against the real domain.", goto: "agencies" },
        { title: "Check your background-check file before it's used", body: "Employers order reports from FCRA screeners like Checkr, Sterling, and HireRight. You have the right to see your file for free and dispute errors — a wrong record can quietly sink an offer. Request yours from the 'Job-application screening & hiring tech' list.", goto: "audit" },
        { title: "Freeze your employment & income file", body: "The Work Number (Equifax) holds detailed salary and employment history that lenders and employers can pull. Place a free freeze so no one sees it without you unfreezing it first.", url: "https://employees.theworknumber.com/employee-data-freeze", label: "The Work Number" },
        { title: "Know your rights on AI hiring tools", body: "Video-interview and resume-scoring AI (HireVue, Eightfold, and others) profile you when you apply. Rights are growing: California extends anti-bias rules to automated hiring tools (since Oct 1, 2025) and phases in access and opt-out rights over automated decisions through Jan 1, 2027. Ask employers what tools they use and how to request human review.", url: "https://cppa.ca.gov/regulations/ccpa_updates.html", label: "CA ADMT rules" },
        { title: "Use a masked email and secondary number on applications", body: "Give job boards and applications a masked email and a secondary number, so a fresh wave of recruiter spam — or a breach of a job site — doesn't reach your primary identity.", goto: "harden" },
        { title: "Lock down before recruiters look you up", body: "Recruiters and hiring managers search your name and socials. Go private where you want to, and remove posts that reveal where you live, work, or spend time.", goto: "social" }
      ]
    },
    {
      id: "breakup", icon: "💔", title: "Leaving a relationship", tagline: "Regain control of your accounts and location.",
      intro: "When someone had access to your devices or accounts, assume they may still. This is a tech-safety reset. If you're in danger, the harassment tab has hotlines.",
      warn: true,
      steps: [
        { title: "Safety first", body: "If changing settings could tip off someone dangerous, plan around that. The support tab lists advisors experienced with exactly this.", goto: "harass" },
        { title: "Change passwords from a safe device", body: "Reset your email password first, then socials and banking. Use a device they haven't had access to if possible.", goto: "harden" },
        { title: "Check for tracking", body: "Turn off location sharing (Find My, Snap Map), review AirTags/trackers, and check for stalkerware and unfamiliar logged-in sessions.", url: "https://stopstalkerware.org/information-for-survivors/", label: "Stalkerware help" },
        { title: "Audit account recovery", body: "Remove their email/phone from your recovery options and security questions — a common back door.", goto: "harden" },
        { title: "Lock down and clean social", body: "Go private, review followers, and remove posts that reveal where you live, work, or spend time.", goto: "social" },
        { title: "Document anything concerning", body: "If there's harassment or boundary-crossing, start an incident log now — before you block.", goto: "harass" }
      ]
    },
    {
      id: "breachnotice", icon: "📩", title: "I got a breach notice", tagline: "A company lost my data — now what?",
      intro: "Work the checklist. The right moves depend on what actually leaked.",
      steps: [
        { title: "See exactly what leaked", body: "Read the notice and check Have I Been Pwned. A leaked password is urgent; a leaked email alone means brace for phishing.", goto: "harden" },
        { title: "Kill password reuse", body: "Change it on the breached site and everywhere you reused it, then turn on two-factor.", goto: "harden" },
        { title: "Watch for tailored phishing", body: "Breached details get paired with fake alerts. Vet anything claiming to be that company.", goto: "vet" },
        { title: "Protect your finances if needed", body: "If payment or SSN data was in it, freeze your credit and set fraud alerts.", goto: "harden" }
      ]
    }
  ];

  // Short reference of major non-US privacy laws (for the letters + audit notes).
  const INTL_LAWS = [
    { region: "EU", law: "GDPR", right: "Right to erasure (Art. 17), access (Art. 15), and objection to marketing (Art. 21). Companies must respond within one month.", url: "https://gdpr.eu/right-to-be-forgotten/" },
    { region: "UK", law: "UK GDPR / Data Protection Act 2018", right: "Same core rights as the EU; complain to the ICO if ignored.", url: "https://ico.org.uk/for-the-public/" },
    { region: "Canada", law: "PIPEDA", right: "Access and correction rights; withdraw consent to use of your data.", url: "https://www.priv.gc.ca/en/" },
    { region: "Brazil", law: "LGPD", right: "Access, deletion, and portability, similar to GDPR.", url: "https://www.gov.br/anpd/pt-br" },
    { region: "Australia", law: "Privacy Act (APPs)", right: "Access and correction of personal information held about you.", url: "https://www.oaic.gov.au/" }
  ];

  // Hostname → removal target, for the on-page helper (derived from BROKERS with a host).
  const PEOPLE_SEARCH_SITES = BROKERS
    .filter(function (b) { return b.host; })
    .map(function (b) { return { host: b.host, name: b.name, url: b.url }; });

  return {
    RECHECK_DAYS: RECHECK_DAYS,
    STATES: STATES,
    PRIVACY_LAWS: PRIVACY_LAWS,
    PRIVACY_COMING: PRIVACY_COMING,
    CATEGORIES: CATEGORIES,
    BROKERS: BROKERS,
    DROP: DROP,
    MASKED_EMAIL: MASKED_EMAIL,
    LETTERS: LETTERS,
    FREEMAIL: FREEMAIL,
    RISKY_TLDS: RISKY_TLDS,
    URL_SHORTENERS: URL_SHORTENERS,
    IMPERSONATED_BRANDS: IMPERSONATED_BRANDS.concat(AGENCY_BRANDS),
    AGENCIES: AGENCIES,
    STATE_NOTES: STATE_NOTES,
    GHOST_LETTERS: GHOST_LETTERS,
    REP_LINKS: REP_LINKS,
    ADVOCACY_LETTERS: ADVOCACY_LETTERS,
    GHOST_FEED: GHOST_FEED,
    GHOST_FEED_UPDATED: GHOST_FEED_UPDATED,
    GHOST_STATS: GHOST_STATS,
    GHOST_FOLLOW: GHOST_FOLLOW,
    GHOST_KINDS: GHOST_KINDS,
    TILE_GRID: TILE_GRID,
    AG_OFFICES: AG_OFFICES,
    REPORT_FED: REPORT_FED,
    AGENCY_SEGMENTS: AGENCY_SEGMENTS,
    SCAM_PHRASES: SCAM_PHRASES,
    VERIFY_LINKS: VERIFY_LINKS,
    EVIDENCE_FIELDS: EVIDENCE_FIELDS,
    PLATFORM_REPORTS: PLATFORM_REPORTS,
    ESCALATION: ESCALATION,
    SUPPORT_RESOURCES: SUPPORT_RESOURCES,
    LOCKDOWN_STEPS: LOCKDOWN_STEPS,
    PEOPLE_SEARCH_SITES: PEOPLE_SEARCH_SITES,
    SOCIAL_PLATFORMS: SOCIAL_PLATFORMS,
    SOCIAL_SAFETY: SOCIAL_SAFETY,
    BREACH_STEPS: BREACH_STEPS,
    SECURITY_TIPS: SECURITY_TIPS,
    MONITORING: MONITORING,
    WIZARDS: WIZARDS,
    INTL_LAWS: INTL_LAWS
  };
})();

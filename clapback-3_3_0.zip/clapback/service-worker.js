/*
 * Clapback — background service worker (MV3)
 * Makes NO network requests and transmits no data anywhere.
 * Jobs:
 *   1. Open the command center on first install; seed default settings.
 *   2. Open the command center (optionally at a specific view) on request.
 *   3. Launch a social cleanup: flag the platform, then open its tab so the
 *      on-page panel (social.js) knows to appear on the account you're in.
 *   4. Recheck reminders: a daily local alarm that notifies you when broker
 *      opt-outs you've completed are due to be redone (records reappear).
 */

const DEFAULT_SETTINGS = {
  detectorEnabled: true,   // on-page phishing caution + people-search removal helper
  remindersEnabled: false, // recheck reminders (local notifications)
  onboarded: false,
  theme: "system", textsize: "m", dyslexia: false, motion: false, underline: false
};

const VALID_VIEWS = ["overview", "guide", "audit", "social", "vet", "harden", "harass", "profile", "settings"];
const RECHECK_DAYS = 180;
const ALARM = "pdsRecheck";

function openDashboard(view) {
  const hash = VALID_VIEWS.indexOf(view) >= 0 ? "#" + view : "";
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") + hash });
}

async function ensureAlarm() {
  try {
    const existing = await chrome.alarms.get(ALARM);
    if (!existing) chrome.alarms.create(ALARM, { periodInMinutes: 1440, delayInMinutes: 60 });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    const stored = await chrome.storage.local.get(["settings"]);
    const settings = Object.assign({}, DEFAULT_SETTINGS, stored.settings || {});
    await chrome.storage.local.set({ settings });
    ensureAlarm();
    if (details.reason === "install") {
      chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
    }
  } catch (e) {
    console.warn("Clapback init warning:", e);
  }
});

if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(ensureAlarm);

/* ---- Recheck reminders ---- */
async function countStaleBrokers() {
  try {
    const d = await chrome.storage.local.get(["brokerProgress"]);
    const map = d.brokerProgress || {};
    const cutoff = Date.now() - RECHECK_DAYS * 24 * 60 * 60 * 1000;
    let n = 0;
    Object.keys(map).forEach((k) => {
      const v = map[k];
      if (v && typeof v === "object" && v.done && typeof v.at === "number" && v.at < cutoff) n++;
    });
    return n;
  } catch (e) { return 0; }
}

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== ALARM) return;
    try {
      const d = await chrome.storage.local.get(["settings"]);
      if (!d.settings || !d.settings.remindersEnabled) return;
      const stale = await countStaleBrokers();
      if (stale <= 0) return;
      if (chrome.notifications) {
        chrome.notifications.create("pdsRecheck-" + Date.now(), {
          type: "basic",
          iconUrl: chrome.runtime.getURL("icons/icon128.png"),
          title: "Clapback — time to recheck",
          message: stale + " data-broker opt-out" + (stale > 1 ? "s are" : " is") + " due to be redone. Broker records commonly reappear — open your exposure audit to re-clear them.",
          priority: 1
        });
      }
    } catch (e) {}
  });
}

if (chrome.notifications) {
  chrome.notifications.onClicked.addListener((id) => {
    if (id && id.indexOf("pdsRecheck") === 0) openDashboard("audit");
  });
}

/* ---- Messages from dashboard / popup ---- */
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return false;

  if (msg.type === "OPEN_DASHBOARD") {
    openDashboard(msg.view);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "OPEN_SOCIAL" && msg.platform && msg.url) {
    // Flag the platform so social.js activates when the tab loads, then open it.
    chrome.storage.local.set({ socialActivate: { platform: msg.platform, ts: Date.now() } }, () => {
      chrome.tabs.create({ url: msg.url });
      sendResponse({ ok: true });
    });
    return true; // async response
  }

  if (msg.type === "SCHEDULE_REMINDERS") {
    ensureAlarm();
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

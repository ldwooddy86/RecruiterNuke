/* Clapback — dashboard logic (MV3-safe, no inline scripts) */
(function () {
  "use strict";
  const D = window.PDS;
  const V = window.PDSVet;
  const STALE_MS = D.RECHECK_DAYS * 24 * 60 * 60 * 1000;

  /* ---------- storage (chrome.storage.local, with localStorage fallback) ---------- */
  const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  const store = {
    get(keys) {
      if (hasChrome) return chrome.storage.local.get(keys);
      return Promise.resolve((Array.isArray(keys) ? keys : [keys]).reduce((o, k) => {
        try { const v = localStorage.getItem("pds_" + k); if (v != null) o[k] = JSON.parse(v); } catch (e) {}
        return o;
      }, {}));
    },
    set(obj) {
      if (hasChrome) return chrome.storage.local.set(obj);
      Object.keys(obj).forEach(k => localStorage.setItem("pds_" + k, JSON.stringify(obj[k])));
      return Promise.resolve();
    },
    clear() {
      if (hasChrome) return chrome.storage.local.clear();
      Object.keys(localStorage).filter(k => k.indexOf("pds_") === 0).forEach(k => localStorage.removeItem(k));
      return Promise.resolve();
    }
  };

  /* ---------- app state ---------- */
  const DEFAULT_SETTINGS = {
    detectorEnabled: true, remindersEnabled: false, onboarded: true,
    theme: "system", textsize: "m", dyslexia: false, motion: false, underline: false
  };
  const state = {
    profile: { name: "", email: "", phone: "", city: "", state: "", notes: "" },
    brokerProgress: {},
    lockdownProgress: {},
    breachProgress: {},
    evidenceLog: [],
    settings: Object.assign({}, DEFAULT_SETTINGS),
    brokerFilter: "all",
    brokerSearch: "",
    vetType: "auto"
  };

  function normProgress(raw) {
    const out = {};
    Object.keys(raw || {}).forEach(k => {
      const v = raw[k];
      if (v === true) out[k] = { done: true, at: Date.now() };
      else if (v && typeof v === "object" && v.done) out[k] = { done: true, at: typeof v.at === "number" ? v.at : Date.now() };
    });
    return out;
  }
  function isDone(map, id) { return !!(map[id] && map[id].done); }
  function isStale(map, id) { return isDone(map, id) && map[id].at && (Date.now() - map[id].at > STALE_MS); }
  function doneCount(map, items) { return items.filter(it => isDone(map, it.id)).length; }
  function staleCount(map, items) { return items.filter(it => isStale(map, it.id)).length; }

  /* ---------- helpers ---------- */
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.prototype.slice.call(document.querySelectorAll(sel));
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function fmtDate(ts) { try { return new Date(ts).toLocaleDateString("en-US", { month: "short", year: "numeric" }); } catch (e) { return ""; } }
  let toastTimer;
  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.classList.remove("hidden");
    requestAnimationFrame(() => t.classList.add("show"));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.classList.remove("show"); setTimeout(() => t.classList.add("hidden"), 220); }, 1900);
  }
  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => toast("Copied to clipboard"), () => toast("Copy failed — select and copy manually"));
    } else { toast("Copy not available — select the text manually"); }
  }
  function stateName(abbr) { const s = D.STATES.find(x => x[0] === abbr); return s ? s[1] : abbr; }
  function linkBtn(label, url, cls) {
    const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.rel = "noopener";
    a.className = cls; a.textContent = label; a.style.display = "inline-block"; a.style.textDecoration = "none";
    return a;
  }
  function linkItem(main, note, url, label) {
    const item = el("div", "link-item");
    const left = el("div");
    left.appendChild(el("div", "li-main", main));
    if (note) left.appendChild(el("div", "li-note", note));
    item.appendChild(left);
    if (url) item.appendChild(linkBtn(label || "Open ↗", url, "btn btn-ghost btn-sm"));
    return item;
  }

  /* ---------- state selects ---------- */
  function fillStateSelects() {
    const s = $("#p-state"); if (!s) return;
    s.innerHTML = ""; s.appendChild(new Option("Select a state…", ""));
    D.STATES.forEach(([abbr, name]) => s.appendChild(new Option(name, abbr)));
  }

  /* ---------- OVERVIEW ---------- */
  function renderOverview() {
    const wrap = $("#overview-stats"); wrap.innerHTML = "";
    const total = D.BROKERS.length;
    const done = doneCount(state.brokerProgress, D.BROKERS);
    const stale = staleCount(state.brokerProgress, D.BROKERS);
    wrap.appendChild(stat(done + " / " + total, "Exposure sources cleared"));
    wrap.appendChild(stat(stale > 0 ? String(stale) : "0", "Due for recheck"));
    wrap.appendChild(stat(String(state.evidenceLog.length), "Incidents logged"));
    const dlBox = stat("—", "Deadlines running");
    wrap.appendChild(dlBox);
    const p = state.profile;
    wrap.appendChild(stat(p.name && p.state ? "Set" : "—", p.name && p.state ? "Profile ready" : "Set up your profile", true));

    /* Deadlines are the highest-stakes thing in the app: a missed answer date
       is a default judgment. Surface anything urgent at the top of Overview. */
    store.get(["medDeadlines"]).then(d => {
      const list = Array.isArray(d.medDeadlines) ? d.medDeadlines : [];
      const num = dlBox.querySelector(".stat-num");
      if (num) num.textContent = String(list.length);
      const host = $("#overview-urgent");
      if (!host) return;
      const soon = list.map(x => {
        const parts = String(x.due || "").split("-");
        if (parts.length !== 3) return null;
        const dt = new Date(+parts[0], +parts[1] - 1, +parts[2]);
        const t = new Date(); t.setHours(0, 0, 0, 0); dt.setHours(0, 0, 0, 0);
        return { x, n: Math.round((dt - t) / 86400000) };
      }).filter(Boolean).filter(r => r.n <= 14).sort((a, b) => a.n - b.n);
      if (!soon.length) { host.innerHTML = ""; host.classList.add("hidden"); return; }
      host.classList.remove("hidden");
      host.innerHTML = "";
      const c = el("div", "callout callout-warn");
      const lines = soon.slice(0, 4).map(r =>
        "<li><strong>" + r.x.label.replace(/[<>&]/g, "") + "</strong> — " +
        (r.n < 0 ? "passed " + Math.abs(r.n) + " day" + (Math.abs(r.n) === 1 ? "" : "s") + " ago"
          : r.n === 0 ? "TODAY" : "in " + r.n + " day" + (r.n === 1 ? "" : "s")) + "</li>"
      ).join("");
      c.innerHTML = "<strong>⏱ Deadlines coming up.</strong><ul class='tidy'>" + lines + "</ul>" +
        (soon.length > 4 ? "<p class='muted'>and " + (soon.length - 4) + " more</p>" : "") +
        "<button class='btn btn-sm' data-goto='deadlines'>Open the deadline tracker →</button>";
      host.appendChild(c);
    });
    function stat(num, lbl, small) {
      const box = el("div", "stat");
      const n = el("div", "stat-num", num); if (small) n.style.fontSize = "17px";
      box.appendChild(n); box.appendChild(el("div", "stat-lbl", lbl));
      return box;
    }
  }

  /* ---------- AUDIT: DROP + privacy + brokers + letters ---------- */
  function renderAuditNudge() {
    const n = $("#audit-profile-nudge");
    if (state.profile.name && state.profile.state) n.classList.add("hidden");
    else n.classList.remove("hidden");
  }

  function renderDropCard() {
    const wrap = $("#drop-card"); wrap.innerHTML = "";
    const isCA = state.profile.state === "CA";
    const card = el("div", "drop-card");
    card.appendChild(el("h3", null, (isCA ? "★ Your shortcut: " : "") + D.DROP.name));
    card.appendChild(el("p", null, D.DROP.blurb + (isCA ? " You're in California — start here before doing the sites one by one." : " (California residents only.)")));
    const row = el("div", "btn-row");
    row.appendChild(linkBtn("Submit a DROP request", D.DROP.app, "btn btn-ghost btn-sm"));
    row.appendChild(linkBtn("About DROP (official)", D.DROP.url, "btn btn-ghost btn-sm"));
    card.appendChild(row);
    wrap.appendChild(card);
  }

  function renderPrivacyLawCard() {
    const wrap = $("#privacy-law-card"); if (!wrap) return;
    wrap.innerHTML = "";
    const abbr = state.profile.state;
    if (!abbr) return;
    const pl = D.PRIVACY_LAWS[abbr];
    const coming = D.PRIVACY_COMING.find(c => c.state === abbr);
    const card = el("div", "card");
    card.appendChild(el("h3", null, "Your data-privacy rights in " + stateName(abbr)));
    if (pl) {
      let txt = "You're covered by the " + pl.law + " — you can demand deletion of your personal data" +
        (pl.deletion === "limited" ? " (with some limits)" : "") +
        (pl.optout ? " and opt out of its sale" : "") + ".";
      if (pl.broker) txt += " Your state also runs a data-broker registry.";
      card.appendChild(el("p", "muted", txt));
      if (pl.note) card.appendChild(el("p", "muted", pl.note));
      card.appendChild(el("p", "muted", "The deletion letter below cites this law for you automatically."));
    } else if (coming) {
      card.appendChild(el("p", "muted", "No comprehensive privacy law in effect yet — but the " + coming.law + " takes effect " + coming.effective + ". Many brokers honor deletion requests from any state anyway, so send them regardless."));
    } else {
      card.appendChild(el("p", "muted", "No comprehensive state privacy law yet. You can still use every opt-out here — most brokers process requests from all states."));
    }
    wrap.appendChild(card);
  }

  function matchesFilter(b) {
    const f = state.brokerFilter;
    if (f === "critical" && b.priority !== "critical") return false;
    if (f === "todo" && isDone(state.brokerProgress, b.id)) return false;
    if (f === "stale" && !isStale(state.brokerProgress, b.id)) return false;
    const q = state.brokerSearch.trim().toLowerCase();
    if (q) {
      const cat = D.CATEGORIES.find(c => c.key === b.cat);
      const hay = (b.name + " " + (b.note || "") + " " + (cat ? cat.name + " " + cat.blurb : "")).toLowerCase();
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  }

  function renderBrokers() {
    const list = $("#brokers-list"); list.innerHTML = "";
    const order = { critical: 0, high: 1, medium: 2 };
    let shown = 0;
    D.CATEGORIES.forEach(cat => {
      const items = D.BROKERS.filter(b => b.cat === cat.key)
        .sort((a, b) => order[a.priority] - order[b.priority]).filter(matchesFilter);
      if (!items.length) return;
      shown += items.length;
      const allInCat = D.BROKERS.filter(b => b.cat === cat.key);
      const catDone = doneCount(state.brokerProgress, allInCat);
      const group = el("div", "broker-group");
      const head = el("div", "cat-head");
      const h = el("h3", null, cat.name);
      if (cat.danger) h.appendChild(el("span", "tag tag-critical", "priority"));
      head.appendChild(h);
      head.appendChild(el("span", "cat-count", catDone + "/" + allInCat.length));
      group.appendChild(head);
      group.appendChild(el("p", "cat-blurb", cat.blurb));
      items.forEach(b => group.appendChild(brokerRow(b)));
      list.appendChild(group);
    });
    if (!shown) {
      const empty = el("div", "callout callout-info");
      empty.textContent = state.brokerFilter === "stale"
        ? "Nothing due for recheck — items reappear here 6 months after you mark them done."
        : "No sources match. Clear the search or switch the filter back to All.";
      list.appendChild(empty);
    }
    updateAuditProgress();
  }

  function brokerRow(b) {
    const row = el("div", "broker" + (b.priority === "critical" ? " critical" : ""));
    const cb = document.createElement("input");
    cb.type = "checkbox"; cb.className = "broker-check"; cb.checked = isDone(state.brokerProgress, b.id);
    cb.setAttribute("aria-label", "Mark " + b.name + " done");
    cb.addEventListener("change", () => {
      if (cb.checked) state.brokerProgress[b.id] = { done: true, at: Date.now() };
      else delete state.brokerProgress[b.id];
      store.set({ brokerProgress: state.brokerProgress });
      renderBrokers(); renderOverview();
    });
    const body = el("div", "broker-body");
    const nameEl = el("div", "broker-name" + (isDone(state.brokerProgress, b.id) ? " done" : ""));
    nameEl.appendChild(document.createTextNode(b.name));
    if (b.priority === "critical") nameEl.appendChild(el("span", "tag tag-critical", "do first"));
    if (isStale(state.brokerProgress, b.id)) nameEl.appendChild(el("span", "tag tag-stale", "recheck"));
    else if (isDone(state.brokerProgress, b.id) && state.brokerProgress[b.id].at) nameEl.appendChild(el("span", "done-date", "done " + fmtDate(state.brokerProgress[b.id].at)));
    body.appendChild(nameEl);
    if (b.note) body.appendChild(el("div", "broker-note", b.note));
    const act = el("div", "broker-act");
    if (b.action === "email") {
      const btn = el("button", "btn btn-sm btn-ghost", "Copy email");
      btn.addEventListener("click", () => copy(b.url));
      act.appendChild(btn);
    } else {
      act.appendChild(linkBtn("Remove ↗", b.url, "btn btn-sm"));
    }
    row.appendChild(cb); row.appendChild(body); row.appendChild(act);
    return row;
  }

  function updateAuditProgress() {
    const total = D.BROKERS.length;
    const done = doneCount(state.brokerProgress, D.BROKERS);
    const stale = staleCount(state.brokerProgress, D.BROKERS);
    $("#audit-progress-text").textContent = done + " of " + total + " done";
    $("#audit-stale-text").textContent = stale ? (" · " + stale + " due for recheck") : "";
    $("#audit-progress-fill").style.width = (total ? (done / total * 100) : 0) + "%";
  }

  function generateLetter(kind) {
    const p = state.profile;
    const today = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    const map = {
      "{{name}}": p.name || "[your full name]",
      "{{state}}": p.state ? stateName(p.state) : "[your state]",
      "{{city}}": p.city || "[your city]",
      "{{email}}": p.email || "[your email]",
      "{{today}}": today
    };
    let text = D.LETTERS[kind] || "";
    Object.keys(map).forEach(k => { text = text.split(k).join(map[k]); });
    $("#letter-text").value = text;
    const out = $("#letter-output"); out.classList.remove("hidden");
    out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  /* ---------- VET A CONTACT ---------- */
  const SEV_UI = {
    high: { cls: "sev-high", ic: "⛔" }, caution: { cls: "sev-caution", ic: "⚠️" },
    info: { cls: "sev-info", ic: "ℹ️" }, ok: { cls: "sev-ok", ic: "✓" }
  };
  const LEVEL_UI = {
    high: { cls: "risk-high", label: "High risk — treat as a scam until proven otherwise", ic: "⛔" },
    caution: { cls: "risk-caution", label: "Caution — several warning signs", ic: "⚠️" },
    low: { cls: "risk-low", label: "No strong scam signals — but stay skeptical", ic: "🔎" }
  };
  const TYPE_LABEL = { email: "Email address", phone: "Phone number", url: "Link / domain", message: "Message text" };

  function runVet() {
    const raw = $("#vet-input").value.trim();
    const box = $("#vet-result"); box.innerHTML = "";
    if (!raw) { toast("Paste something to check first"); return; }
    let res;
    try {
      if (state.vetType === "auto") res = V.run(raw, { ownNumber: state.profile.phone });
      else if (state.vetType === "email") res = V.email(raw);
      else if (state.vetType === "phone") res = V.phone(raw, { ownNumber: state.profile.phone });
      else if (state.vetType === "url") res = V.url(raw);
      else res = V.message(raw);
    } catch (e) { toast("Could not analyze that input"); return; }
    box.appendChild(renderVetResult(res));
    box.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function renderVetResult(res) {
    const lvl = LEVEL_UI[res.level] || LEVEL_UI.low;
    const card = el("div", "vet-result-card");
    const banner = el("div", "risk-banner " + lvl.cls);
    banner.appendChild(el("span", "risk-ic", lvl.ic));
    const bt = el("div");
    bt.appendChild(el("div", "risk-label", lvl.label));
    bt.appendChild(el("div", "risk-sub", "Checked as: " + (TYPE_LABEL[res.type] || res.type) + (state.vetType === "auto" ? " (auto-detected)" : "")));
    banner.appendChild(bt);
    card.appendChild(banner);

    const sigWrap = el("div", "sig-list");
    res.signals.forEach(s => {
      const ui = SEV_UI[s.sev] || SEV_UI.info;
      const row = el("div", "sig " + ui.cls);
      row.appendChild(el("span", "sig-ic", ui.ic));
      row.appendChild(el("span", "sig-text", s.text));
      sigWrap.appendChild(row);
    });
    card.appendChild(sigWrap);

    if (res.foundLinks && res.foundLinks.length) {
      const lw = el("div", "vet-links-found");
      lw.appendChild(el("div", "vet-sub", "Links found in this message — check each before tapping:"));
      res.foundLinks.forEach(u => {
        const b = el("button", "btn btn-ghost btn-sm", "Check " + (u.length > 34 ? u.slice(0, 34) + "…" : u));
        b.addEventListener("click", () => { $("#vet-input").value = u; setVetType("url"); runVet(); });
        lw.appendChild(b);
      });
      card.appendChild(lw);
    }

    if (res.recommend && res.recommend.length) {
      const rc = el("div", "card vet-reco");
      rc.appendChild(el("h3", null, "What to do"));
      const ul = el("ul", "tidy");
      res.recommend.forEach(r => ul.appendChild(el("li", null, r)));
      rc.appendChild(ul);
      card.appendChild(rc);
    }

    if (res.verify && res.verify.length) {
      const vr = el("div", "card");
      vr.appendChild(el("h3", null, "Verify or report (opens the official site in a new tab)"));
      res.verify.forEach(v => vr.appendChild(linkItem(v.name, v.note, v.url, "Open ↗")));
      card.appendChild(vr);
    }
    card.appendChild(el("p", "fineprint", "Heuristic check, run locally. A clean result isn't proof it's safe; a flag isn't proof of fraud. When unsure, verify through a channel you already trust."));
    return card;
  }

  function setVetType(t) {
    state.vetType = t;
    $$("#vet-type .chip").forEach(c => c.classList.toggle("active", c.dataset.type === t));
  }

  /* ---------- HARASSMENT: document / report / lockdown / escalate / support ---------- */
  function renderEvidenceForm() {
    const wrap = $("#evidence-form"); wrap.innerHTML = "";
    D.EVIDENCE_FIELDS.forEach(f => {
      const field = el("div", "ev-field" + (f.type === "area" ? " ev-field-wide" : ""));
      field.appendChild(el("label", null, f.label));
      const input = f.type === "area" ? document.createElement("textarea") : document.createElement("input");
      if (f.type === "area") input.rows = 2;
      input.className = "input"; input.id = "ev-" + f.key; input.placeholder = f.placeholder || "";
      field.appendChild(input);
      wrap.appendChild(field);
    });
  }

  function addEvidence() {
    const entry = { id: "e" + Date.now() };
    let any = false;
    D.EVIDENCE_FIELDS.forEach(f => { const v = ($("#ev-" + f.key).value || "").trim(); entry[f.key] = v; if (v) any = true; });
    if (!any) { toast("Fill in at least one field"); return; }
    entry.added = Date.now();
    state.evidenceLog.unshift(entry);
    store.set({ evidenceLog: state.evidenceLog });
    D.EVIDENCE_FIELDS.forEach(f => { $("#ev-" + f.key).value = ""; });
    renderEvidenceLog(); renderOverview();
    toast("Added to your log");
  }

  function renderEvidenceLog() {
    $("#ev-count").textContent = String(state.evidenceLog.length);
    const list = $("#evidence-log"); list.innerHTML = "";
    const exportRow = $("#ev-export-row"); exportRow.innerHTML = "";
    if (state.evidenceLog.length) {
      const t = el("button", "btn btn-ghost btn-sm", "Export as text"); t.addEventListener("click", () => exportEvidence("txt"));
      const c = el("button", "btn btn-ghost btn-sm", "Export as CSV"); c.addEventListener("click", () => exportEvidence("csv"));
      exportRow.appendChild(t); exportRow.appendChild(c);
    }
    if (!state.evidenceLog.length) { list.appendChild(el("p", "muted", "No incidents logged yet. Add the first one above — even a short note with the date helps.")); return; }
    state.evidenceLog.forEach(entry => {
      const card = el("div", "ev-entry");
      const head = el("div", "ev-entry-head");
      head.appendChild(el("span", "ev-when", (entry.when || fmtDate(entry.added)) + (entry.where ? " · " + entry.where : "")));
      const del = el("button", "ev-del", "Remove");
      del.addEventListener("click", () => {
        state.evidenceLog = state.evidenceLog.filter(x => x.id !== entry.id);
        store.set({ evidenceLog: state.evidenceLog }); renderEvidenceLog(); renderOverview();
      });
      head.appendChild(del);
      card.appendChild(head);
      D.EVIDENCE_FIELDS.forEach(f => {
        if (f.key === "when" || f.key === "where") return;
        if (!entry[f.key]) return;
        const line = el("div", "ev-line");
        line.appendChild(el("span", "ev-k", f.label + ": "));
        line.appendChild(document.createTextNode(entry[f.key]));
        card.appendChild(line);
      });
      list.appendChild(card);
    });
  }

  function exportEvidence(fmt) {
    let content, name, mime;
    if (fmt === "csv") {
      const cols = D.EVIDENCE_FIELDS.map(f => f.key);
      const esc = v => '"' + String(v || "").replace(/"/g, '""') + '"';
      const rows = [["logged"].concat(D.EVIDENCE_FIELDS.map(f => f.label)).map(esc).join(",")];
      state.evidenceLog.forEach(e => {
        rows.push([new Date(e.added).toISOString()].concat(cols.map(k => e[k])).map(esc).join(","));
      });
      content = rows.join("\r\n"); name = "incident-log.csv"; mime = "text/csv";
    } else {
      const lines = ["PERSONAL DATA SHIELD — INCIDENT LOG", "Generated " + new Date().toLocaleString(), "Entries: " + state.evidenceLog.length, ""];
      state.evidenceLog.forEach((e, i) => {
        lines.push("── Incident " + (state.evidenceLog.length - i) + " ──");
        D.EVIDENCE_FIELDS.forEach(f => { if (e[f.key]) lines.push(f.label + ": " + e[f.key]); });
        lines.push("Logged: " + new Date(e.added).toLocaleString(), "");
      });
      content = lines.join("\n"); name = "incident-log.txt"; mime = "text/plain";
    }
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    toast("Log exported");
  }

  function renderPlatforms() {
    const list = $("#platform-list"); list.innerHTML = "";
    D.PLATFORM_REPORTS.forEach(p => {
      const card = el("div", "res-card");
      const head = el("div", "res-head");
      head.appendChild(el("div", "res-name", p.name));
      head.appendChild(linkBtn("Help center ↗", p.url, "btn btn-ghost btn-sm"));
      card.appendChild(head);
      card.appendChild(el("div", "res-note", p.how));
      list.appendChild(card);
    });
  }

  function renderLockdown() {
    const steps = $("#lockdown-steps"); steps.innerHTML = "";
    D.LOCKDOWN_STEPS.forEach(s => {
      const item = el("div", "checkitem");
      const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!state.lockdownProgress[s.id];
      cb.setAttribute("aria-label", s.text.slice(0, 60));
      const body = el("div"); body.style.flex = "1";
      const txt = el("span", "ci-text" + (state.lockdownProgress[s.id] ? " done" : ""), s.text);
      body.appendChild(txt);
      if (s.id === "removeself") { body.appendChild(document.createTextNode(" ")); const a = el("a", null, "Go to Audit →"); a.href = "#"; a.dataset.goto = "audit"; body.appendChild(a); }
      else if (s.url) { body.appendChild(document.createTextNode(" ")); const a = document.createElement("a"); a.href = s.url; a.target = "_blank"; a.rel = "noopener"; a.textContent = "Open ↗"; body.appendChild(a); }
      cb.addEventListener("change", () => { state.lockdownProgress[s.id] = cb.checked; store.set({ lockdownProgress: state.lockdownProgress }); txt.classList.toggle("done", cb.checked); });
      item.appendChild(cb); item.appendChild(body);
      steps.appendChild(item);
    });
    const me = $("#masked-email"); me.innerHTML = "";
    D.MASKED_EMAIL.forEach(m => me.appendChild(linkItem(m.name, m.note, m.url, "Open ↗")));
  }

  function renderEscalate() {
    const list = $("#escalate-list"); list.innerHTML = "";
    D.ESCALATION.forEach(e => {
      const card = el("div", "res-card");
      const head = el("div", "res-head");
      head.appendChild(el("div", "res-name", e.name));
      if (e.url) head.appendChild(linkBtn("Open ↗", e.url, "btn btn-ghost btn-sm"));
      card.appendChild(head);
      card.appendChild(el("div", "res-note", e.note));
      list.appendChild(card);
    });
  }

  function renderSupport() {
    const list = $("#support-list"); list.innerHTML = "";
    D.SUPPORT_RESOURCES.forEach(r => {
      const card = el("div", "res-card");
      const head = el("div", "res-head");
      head.appendChild(el("div", "res-name", r.name));
      if (r.url) head.appendChild(linkBtn("Open ↗", r.url, "btn btn-ghost btn-sm"));
      card.appendChild(head);
      if (r.contact) card.appendChild(el("div", "res-contact", r.contact));
      card.appendChild(el("div", "res-note", r.note));
      list.appendChild(card);
    });
  }

  function gotoHStep(step) {
    $$(".stepchip").forEach(b => b.classList.toggle("active", b.dataset.hstep === step));
    $$(".hstep").forEach(v => v.classList.toggle("active", v.id === "hstep-" + step));
  }

  /* ---------- PROFILE ---------- */
  function renderProfile() {
    const p = state.profile;
    $("#p-name").value = p.name || "";
    $("#p-email").value = p.email || "";
    $("#p-phone").value = p.phone || "";
    $("#p-city").value = p.city || "";
    $("#p-state").value = p.state || "";
    $("#p-notes").value = p.notes || "";
    /* Address, ZIP, household and income live in a separate key so an older
       backup that predates the medical modules still imports cleanly. */
    store.get(["medProfile"]).then(d => {
      const x = d.medProfile || {};
      const set = (sel, v) => { const e = $(sel); if (e) e.value = v || ""; };
      set("#p-addr", x.addr); set("#p-zip", x.zip);
      set("#p-household", x.household); set("#p-income", x.income);
    });
  }
  function saveProfile() {
    state.profile = {
      name: $("#p-name").value.trim(), email: $("#p-email").value.trim(), phone: $("#p-phone").value.trim(),
      city: $("#p-city").value.trim(), state: $("#p-state").value, notes: $("#p-notes").value
    };
    const val = sel => { const e = $(sel); return e ? e.value.trim() : ""; };
    const medProfile = { addr: val("#p-addr"), zip: val("#p-zip"), household: val("#p-household"), income: val("#p-income") };
    store.set({ profile: state.profile, medProfile }).then(() => {
      const s = $("#save-status"); s.textContent = "Saved ✓"; setTimeout(() => { s.textContent = ""; }, 1800);
      renderDropCard(); renderPrivacyLawCard(); renderAuditNudge(); renderOverview();
    });
  }

  /* ---------- export / import / wipe ---------- */
  function exportData() {
    store.get(["agencyProgress", "ghostLog", "medProfile", "medBills", "medDeadlines", "medViolations", "medCraProgress"]).then(extra => {
      const payload = { app: "clapback", version: 2, exportedAt: new Date().toISOString(),
        profile: state.profile, brokerProgress: state.brokerProgress, lockdownProgress: state.lockdownProgress, evidenceLog: state.evidenceLog,
        agencyProgress: (extra && extra.agencyProgress) || {},
        ghostLog: (extra && extra.ghostLog) || [],
        medProfile: (extra && extra.medProfile) || {},
        medBills: (extra && extra.medBills) || [],
        medDeadlines: (extra && extra.medDeadlines) || [],
        medViolations: (extra && extra.medViolations) || [],
        medCraProgress: (extra && extra.medCraProgress) || {} };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = "clapback-backup.json";
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      toast("Backup downloaded");
    });
  }
  function importData(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const d = JSON.parse(reader.result);
        if (d.profile) { state.profile = Object.assign(state.profile, d.profile); if (state.profile.state && !D.PRIVACY_LAWS[state.profile.state] && !D.STATES.some(s => s[0] === state.profile.state)) state.profile.state = ""; }
        if (d.brokerProgress) state.brokerProgress = normProgress(d.brokerProgress);
        if (d.lockdownProgress) state.lockdownProgress = d.lockdownProgress || {};
        if (Array.isArray(d.evidenceLog)) state.evidenceLog = d.evidenceLog;
        const extra = {};
        if (d.agencyProgress && typeof d.agencyProgress === "object") extra.agencyProgress = d.agencyProgress;
        if (Array.isArray(d.ghostLog)) extra.ghostLog = d.ghostLog;
        if (d.medProfile && typeof d.medProfile === "object") extra.medProfile = d.medProfile;
        if (Array.isArray(d.medBills)) extra.medBills = d.medBills;
        if (Array.isArray(d.medDeadlines)) extra.medDeadlines = d.medDeadlines;
        if (Array.isArray(d.medViolations)) extra.medViolations = d.medViolations;
        if (d.medCraProgress && typeof d.medCraProgress === "object") extra.medCraProgress = d.medCraProgress;
        store.set(Object.assign({ profile: state.profile, brokerProgress: state.brokerProgress, lockdownProgress: state.lockdownProgress, evidenceLog: state.evidenceLog }, extra))
          .then(() => { renderAll(); toast("Data imported"); });
      } catch (e) { toast("That file couldn't be read"); }
    };
    reader.readAsText(file);
  }
  function wipeData() {
    if (!window.confirm("Erase everything Clapback saved on this device? This can't be undone.")) return;
    store.clear().then(() => {
      state.profile = { name: "", email: "", phone: "", city: "", state: "", notes: "" };
      state.brokerProgress = {}; state.lockdownProgress = {}; state.evidenceLog = [];
      renderAll(); toast("All data erased");
    });
  }

  /* ================================================================== */
  /* SETTINGS & ACCESSIBILITY                                            */
  /* ================================================================== */
  function applySettings() {
    const s = state.settings || {};
    const root = document.documentElement;
    let theme = s.theme || "system";
    if (theme === "system") {
      theme = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
    }
    root.setAttribute("data-theme", theme);
    root.setAttribute("data-textsize", s.textsize || "m");
    root.setAttribute("data-dyslexia", s.dyslexia ? "on" : "off");
    root.setAttribute("data-underline", s.underline ? "on" : "off");
    const reduce = s.motion || (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    root.setAttribute("data-motion", reduce ? "reduce" : "no");
  }
  function saveSettings() {
    store.set({ settings: state.settings });
    applySettings();
  }
  function renderSettings() {
    const s = state.settings;
    const set = (id, val) => { const e = $(id); if (e) { if (e.type === "checkbox") e.checked = !!val; else e.value = val; } };
    set("#set-theme", s.theme || "system");
    set("#set-textsize", s.textsize || "m");
    set("#set-dyslexia", s.dyslexia);
    set("#set-motion", s.motion);
    set("#set-underline", s.underline);
    set("#set-detector", s.detectorEnabled !== false);
    set("#reminder-toggle", !!s.remindersEnabled);
  }

  // React to OS theme changes when on "system"
  function watchSystemTheme() {
    if (!window.matchMedia) return;
    try {
      window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => { if ((state.settings.theme || "system") === "system") applySettings(); });
      window.matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", () => { if (!state.settings.motion) applySettings(); });
    } catch (e) {}
  }

  /* ================================================================== */
  /* EXPOSURE SCORE (Harden view)                                        */
  /* ================================================================== */
  function computeScore() {
    const p = state.profile;
    // Weighted mix of the protective actions the tool tracks.
    const brokersTotal = D.BROKERS.length;
    const brokersDone = doneCount(state.brokerProgress, D.BROKERS);
    const brokersStale = staleCount(state.brokerProgress, D.BROKERS);
    const lockTotal = D.LOCKDOWN_STEPS.length;
    const lockDone = D.LOCKDOWN_STEPS.filter(x => state.lockdownProgress[x.id]).length;
    const secTotal = D.SECURITY_TIPS.length;
    const secDone = D.SECURITY_TIPS.filter(x => state.breachProgress["sec_" + x.id]).length;

    const brokerPct = brokersTotal ? (brokersDone - brokersStale * 0.5) / brokersTotal : 0;
    const lockPct = lockTotal ? lockDone / lockTotal : 0;
    const secPct = secTotal ? secDone / secTotal : 0;
    const profilePct = (p.name && p.state) ? 1 : 0;

    const score = Math.max(0, Math.min(100, Math.round(
      brokerPct * 55 + lockPct * 25 + secPct * 15 + profilePct * 5
    )));
    return {
      score,
      parts: [
        { label: "Broker removals", pct: Math.round(Math.max(0, brokerPct) * 100), detail: brokersDone + "/" + brokersTotal + (brokersStale ? " · " + brokersStale + " stale" : "") },
        { label: "Footprint lockdown", pct: Math.round(lockPct * 100), detail: lockDone + "/" + lockTotal },
        { label: "Account security", pct: Math.round(secPct * 100), detail: secDone + "/" + secTotal },
        { label: "Profile set up", pct: Math.round(profilePct * 100), detail: profilePct ? "Yes" : "No" }
      ]
    };
  }
  function scoreGrade(n) {
    if (n >= 80) return { t: "Strong — keep it up", c: "var(--green)" };
    if (n >= 55) return { t: "Solid, with gaps to close", c: "var(--teal)" };
    if (n >= 30) return { t: "Getting there — keep going", c: "var(--amber)" };
    return { t: "Exposed — start with the basics", c: "var(--red)" };
  }
  function renderScore() {
    const wrap = $("#exposure-score"); if (!wrap) return;
    wrap.innerHTML = "";
    const r = computeScore();
    const g = scoreGrade(r.score);
    const ring = el("div", "score-ring"); ring.style.setProperty("--p", r.score);
    const inner = el("div", "inner");
    const num = el("div", "num", String(r.score)); num.style.color = g.c;
    inner.appendChild(num); inner.appendChild(el("div", "of", "/ 100"));
    ring.appendChild(inner);
    ring.setAttribute("role", "img");
    ring.setAttribute("aria-label", "Protection score " + r.score + " out of 100: " + g.t);
    const body = el("div", "score-body");
    body.appendChild(el("h3", null, "Your protection score"));
    const grade = el("div", "score-grade", g.t); grade.style.color = g.c; body.appendChild(grade);
    const bars = el("div", "score-bars");
    r.parts.forEach(part => {
      const row = el("div", "score-bar");
      row.appendChild(el("span", null, part.label));
      const track = el("div", "track"); const fill = el("div", "fillb"); fill.style.width = part.pct + "%"; track.appendChild(fill);
      row.appendChild(track);
      row.appendChild(el("span", null, part.detail));
      bars.appendChild(row);
    });
    body.appendChild(bars);
    wrap.appendChild(ring); wrap.appendChild(body);
  }

  /* ================================================================== */
  /* HARDEN & MONITOR: monitoring, breach checklist, security tips       */
  /* ================================================================== */
  function renderMonitoring() {
    const list = $("#monitoring-list"); if (!list) return; list.innerHTML = "";
    D.MONITORING.forEach(m => {
      const card = el("div", "res-card");
      const head = el("div", "res-head");
      const name = el("div", "res-name");
      name.appendChild(document.createTextNode(m.name));
      if (m.free) name.appendChild(el("span", "free-tag", "free"));
      head.appendChild(name);
      if (m.url) head.appendChild(linkBtn("Set up ↗", m.url, "btn btn-ghost btn-sm"));
      card.appendChild(head);
      card.appendChild(el("div", "res-note", m.note));
      list.appendChild(card);
    });
  }
  function renderBreach() {
    const list = $("#breach-steps"); if (!list) return; list.innerHTML = "";
    D.BREACH_STEPS.forEach(s => {
      const item = el("div", "checkitem");
      const cb = document.createElement("input"); cb.type = "checkbox";
      const key = "br_" + s.id;
      cb.checked = !!state.breachProgress[key];
      cb.setAttribute("aria-label", s.text.slice(0, 60));
      const body = el("div"); body.style.flex = "1";
      const txt = el("span", "ci-text" + (cb.checked ? " done" : ""), s.text);
      body.appendChild(txt);
      if (s.url) { body.appendChild(document.createTextNode(" ")); const a = document.createElement("a"); a.href = s.url; a.target = "_blank"; a.rel = "noopener"; a.textContent = "Open ↗"; body.appendChild(a); }
      cb.addEventListener("change", () => { state.breachProgress[key] = cb.checked; store.set({ breachProgress: state.breachProgress }); txt.classList.toggle("done", cb.checked); });
      item.appendChild(cb); item.appendChild(body);
      list.appendChild(item);
    });
  }
  function renderSecurity() {
    const list = $("#security-tips"); if (!list) return; list.innerHTML = "";
    D.SECURITY_TIPS.forEach(s => {
      const item = el("div", "checkitem");
      const cb = document.createElement("input"); cb.type = "checkbox";
      const key = "sec_" + s.id;
      cb.checked = !!state.breachProgress[key];
      cb.setAttribute("aria-label", s.title);
      const body = el("div"); body.style.flex = "1";
      const t = el("span", "ci-text" + (cb.checked ? " done" : ""));
      t.appendChild(el("strong", null, s.title + " — "));
      t.appendChild(document.createTextNode(s.text));
      body.appendChild(t);
      if (s.url) { body.appendChild(document.createTextNode(" ")); const a = document.createElement("a"); a.href = s.url; a.target = "_blank"; a.rel = "noopener"; a.textContent = "Open ↗"; body.appendChild(a); }
      cb.addEventListener("change", () => { state.breachProgress[key] = cb.checked; store.set({ breachProgress: state.breachProgress }); t.classList.toggle("done", cb.checked); renderScore(); });
      item.appendChild(cb); item.appendChild(body);
      list.appendChild(item);
    });
  }

  /* ================================================================== */
  /* SOCIAL & FOOTPRINT control-center                                   */
  /* ================================================================== */
  function renderSocial() {
    const list = $("#social-list"); if (!list) return; list.innerHTML = "";
    D.SOCIAL_PLATFORMS.forEach(p => {
      const card = el("div", "social-card");
      const head = el("div", "social-head"); head.style.setProperty("--sc", p.color || "#64748b");
      head.appendChild(el("span", "social-ic", p.icon));
      head.appendChild(el("span", "social-name", p.name));
      if (p.automatable) head.appendChild(el("span", "social-auto", "1-click cleanup"));
      card.appendChild(head);

      const body = el("div", "social-body");
      body.appendChild(el("p", "social-summary", p.summary));

      // Launch automation button (only for automatable platforms with engine actions)
      const engineActions = (p.actions || []).filter(a => !a.assist);
      const assistActions = (p.actions || []).filter(a => a.assist);
      if (p.automatable && (p.actions || []).length) {
        const launchRow = el("div", "btn-row");
        const launch = el("button", "btn btn-sm", "🚀 Launch cleanup on " + p.name);
        launch.addEventListener("click", () => launchSocial(p));
        launchRow.appendChild(launch);
        const dl = (p.links || []).find(l => l.kind === "download");
        if (dl) launchRow.appendChild(linkBtn("⬇ Download data first", dl.url, "btn btn-ghost btn-sm"));
        body.appendChild(launchRow);

        const actWrap = el("div", "social-actions"); actWrap.style.marginTop = "10px";
        (p.actions || []).forEach(a => {
          const row = el("div", "social-action");
          const left = el("div");
          left.appendChild(el("div", "sa-t", (a.assist ? "🧭 " : "🧹 ") + a.label));
          left.appendChild(el("div", "sa-d", a.desc));
          row.appendChild(left);
          actWrap.appendChild(row);
        });
        body.appendChild(actWrap);
      }

      // Links, grouped
      const links = el("div", "social-links");
      const kindLabel = { privacy: "privacy", bulk: "bulk tool", download: "download", delete: "delete", thirdparty: "3rd-party", ad: "ads" };
      (p.links || []).forEach(l => {
        const item = el("div", "link-item");
        const left = el("div");
        const main = el("div", "li-main");
        const tag = el("span", "link-tag lt-" + l.kind, kindLabel[l.kind] || l.kind);
        main.appendChild(tag); main.appendChild(document.createTextNode(l.label));
        left.appendChild(main);
        if (l.note) left.appendChild(el("div", "li-note", l.note));
        item.appendChild(left);
        item.appendChild(linkBtn("Open ↗", l.url, "btn btn-ghost btn-sm"));
        links.appendChild(item);
      });
      body.appendChild(links);
      card.appendChild(body);
      list.appendChild(card);
    });
  }

  function launchSocial(p) {
    const url = (p.actions && p.actions[0] && p.actions[0].where) || ("https://" + p.hosts[0] + "/");
    if (hasChrome && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: "OPEN_SOCIAL", platform: p.id, url: url }, () => {
        if (chrome.runtime.lastError) { window.open(url, "_blank", "noopener"); }
        toast("Opening " + p.name + " — the cleanup panel appears there.");
      });
    } else {
      window.open(url, "_blank", "noopener");
      toast("Open " + p.name + " while signed in; the panel appears there.");
    }
  }

  /* ================================================================== */
  /* GUIDED WIZARDS                                                      */
  /* ================================================================== */
  function renderWizards() {
    const list = $("#wizard-list"); if (!list) return; list.innerHTML = "";
    $("#wizard-detail").classList.add("hidden");
    D.WIZARDS.forEach(w => {
      const card = el("button", "wizard-card" + (w.warn ? " warn" : ""));
      card.setAttribute("aria-label", "Open walkthrough: " + w.title);
      card.appendChild(el("div", "wizard-ic", w.icon));
      card.appendChild(el("div", "wizard-h", w.title));
      card.appendChild(el("div", "wizard-tag", w.tagline));
      card.addEventListener("click", () => openWizard(w));
      list.appendChild(card);
    });
  }
  function openWizard(w) {
    const list = $("#wizard-list"); const detail = $("#wizard-detail");
    list.classList.add("hidden");
    detail.classList.remove("hidden"); detail.innerHTML = "";
    const box = el("div", "wizard-detail");
    const back = el("button", "wd-back", "← All walkthroughs");
    back.addEventListener("click", () => { detail.classList.add("hidden"); list.classList.remove("hidden"); list.focus && list.focus(); });
    box.appendChild(back);
    const head = el("div"); head.style.display = "flex"; head.style.alignItems = "center"; head.style.gap = "10px";
    head.appendChild(el("span", null, w.icon)); head.querySelector("span").style.fontSize = "24px";
    head.appendChild(el("h2", null, w.title)); head.querySelector("h2").style.margin = "0";
    box.appendChild(head);
    if (w.warn) { const c = el("div", "callout callout-warn"); c.style.marginTop = "12px"; c.textContent = "If you're in immediate danger, contact emergency services (911 in the US). Change settings only when it's safe to do so."; box.appendChild(c); }
    box.appendChild(el("p", "muted", w.intro));
    w.steps.forEach((s, i) => {
      const step = el("div", "wstep");
      step.appendChild(el("div", "wstep-n", String(i + 1)));
      const b = el("div", "wstep-b");
      b.appendChild(el("h4", null, s.title));
      b.appendChild(el("p", null, s.body));
      const row = el("div", "btn-row");
      if (s.goto) { const btn = el("button", "btn btn-sm", "Go to this tool →"); btn.addEventListener("click", () => goto(s.goto)); row.appendChild(btn); }
      if (s.url) row.appendChild(linkBtn(s.label || "Open ↗", s.url, "btn btn-ghost btn-sm"));
      if (row.childNodes.length) b.appendChild(row);
      step.appendChild(b);
      box.appendChild(step);
    });
    detail.appendChild(box);
    detail.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ---------- navigation ---------- */
  function goto(view) {
    $$(".nav-btn").forEach(b => {
      const on = b.dataset.view === view;
      b.classList.toggle("active", on);
      if (on) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current");
    });
    $$(".view").forEach(v => v.classList.toggle("active", v.id === "view-" + view));
    if (location.hash.replace("#", "") !== view) { try { history.replaceState(null, "", "#" + view); } catch (e) {} }
    const main = $("#main"); if (main && main.focus) { try { main.focus({ preventScroll: true }); } catch (e) { } }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderAll() {
    renderOverview(); renderAuditNudge(); renderDropCard(); renderPrivacyLawCard(); renderBrokers();
    renderEvidenceForm(); renderEvidenceLog(); renderPlatforms(); renderLockdown(); renderEscalate(); renderSupport();
    renderProfile();
    renderSocial(); renderWizards(); renderScore(); renderMonitoring(); renderBreach(); renderSecurity(); renderSettings();
  }

  /* ---------- keyboard: roving arrow nav in the sidebar ---------- */
  function navKeydown(e) {
    if (["ArrowDown", "ArrowUp", "Home", "End"].indexOf(e.key) < 0) return;
    const btns = $$(".nav-btn"); const i = btns.indexOf(document.activeElement);
    if (i < 0) return; e.preventDefault();
    let n = i;
    if (e.key === "ArrowDown") n = (i + 1) % btns.length;
    else if (e.key === "ArrowUp") n = (i - 1 + btns.length) % btns.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = btns.length - 1;
    btns[n].focus();
  }

  /* ---------- wire ---------- */
  function wire() {
    $("#nav").addEventListener("click", e => { const b = e.target.closest(".nav-btn"); if (b) goto(b.dataset.view); });
    $("#nav").addEventListener("keydown", navKeydown);
    document.addEventListener("click", e => {
      const s = e.target.closest("[data-goto]"); if (s) { e.preventDefault(); goto(s.dataset.goto); }
      const l = e.target.closest("[data-letter]"); if (l) generateLetter(l.dataset.letter);
    });
    // audit
    $("#copy-letter").addEventListener("click", () => copy($("#letter-text").value));
    $("#close-letter").addEventListener("click", () => $("#letter-output").classList.add("hidden"));
    $("#broker-search").addEventListener("input", e => { state.brokerSearch = e.target.value; renderBrokers(); });
    $("#broker-chips").addEventListener("click", e => {
      const c = e.target.closest(".chip"); if (!c) return;
      state.brokerFilter = c.dataset.filter;
      $$("#broker-chips .chip").forEach(x => x.classList.toggle("active", x === c));
      renderBrokers();
    });
    // vet
    $("#vet-type").addEventListener("click", e => { const c = e.target.closest(".chip"); if (c) setVetType(c.dataset.type); });
    $("#vet-run").addEventListener("click", runVet);
    $("#vet-clear").addEventListener("click", () => { $("#vet-input").value = ""; $("#vet-result").innerHTML = ""; });
    $("#vet-input").addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") runVet(); });
    // harass
    $("#harass-steps").addEventListener("click", e => { const b = e.target.closest(".stepchip"); if (b) gotoHStep(b.dataset.hstep); });
    $("#ev-add").addEventListener("click", addEvidence);
    // profile + data
    $("#save-profile").addEventListener("click", saveProfile);
    $("#export-data").addEventListener("click", exportData);
    $("#import-data").addEventListener("click", () => $("#import-file").click());
    $("#import-file").addEventListener("change", e => { if (e.target.files[0]) importData(e.target.files[0]); e.target.value = ""; });
    $("#wipe-data").addEventListener("click", wipeData);
    // harden: recheck reminders
    const rt = $("#reminder-toggle");
    if (rt) rt.addEventListener("change", () => {
      state.settings.remindersEnabled = rt.checked;
      saveSettings();
      if (rt.checked && hasChrome && chrome.runtime) { try { chrome.runtime.sendMessage({ type: "SCHEDULE_REMINDERS" }); } catch (e) {} }
      toast(rt.checked ? "Recheck reminders on" : "Recheck reminders off");
    });
    // settings: accessibility
    const bindSel = (id, key) => { const e = $(id); if (e) e.addEventListener("change", () => { state.settings[key] = e.value; saveSettings(); }); };
    const bindChk = (id, key, extra) => { const e = $(id); if (e) e.addEventListener("change", () => { state.settings[key] = e.checked; saveSettings(); if (extra) extra(e.checked); }); };
    bindSel("#set-theme", "theme");
    bindSel("#set-textsize", "textsize");
    bindChk("#set-dyslexia", "dyslexia");
    bindChk("#set-motion", "motion");
    bindChk("#set-underline", "underline");
    bindChk("#set-detector", "detectorEnabled", (v) => toast(v ? "On-page helper on" : "On-page helper off"));
  }

  /* ---------- init ---------- */
  function init() {
    fillStateSelects();
    store.get(["profile", "brokerProgress", "lockdownProgress", "breachProgress", "evidenceLog", "settings"]).then(d => {
      if (d.profile) state.profile = Object.assign(state.profile, d.profile);
      state.brokerProgress = normProgress(d.brokerProgress);
      state.lockdownProgress = d.lockdownProgress || {};
      state.breachProgress = d.breachProgress || {};
      state.evidenceLog = Array.isArray(d.evidenceLog) ? d.evidenceLog : [];
      state.settings = Object.assign({}, DEFAULT_SETTINGS, d.settings || {});
      applySettings(); watchSystemTheme();
      store.set({ brokerProgress: state.brokerProgress, settings: state.settings });
      wire(); renderAll();
      const valid = ["overview", "guide", "audit", "social", "vet", "harden", "harass", "resume", "agencies",
        "report", "represent", "ghostmap", "hiring", "legal",
        "bills", "assist", "appeals", "credit", "collect", "court", "deadlines", "loans", "bankrupt",
  "recovery", "account",
        "profile", "settings"];
      const initial = (location.hash || "").replace("#", "");
      if (valid.indexOf(initial) >= 0) goto(initial);
      window.addEventListener("hashchange", () => { const v = (location.hash || "").replace("#", ""); if (valid.indexOf(v) >= 0) goto(v); });
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();

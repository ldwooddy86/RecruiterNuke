/*
 * Clapback — public accountability dataset  (window.CBA)
 *
 * THE RULE THIS FILE IS BUILT ON, and it is not decoration:
 * Nothing appears here unless it is an OFFICIAL ACT with a citation. A recorded
 * vote. An audited expenditure. A statute on the books. A settlement term.
 * No characterisations of anyone's motives, no personal life, no contact
 * details, no calls to action directed at an individual.
 *
 * That constraint is not squeamishness — it is what makes the thing work. A
 * sourced roll-call vote cannot be argued with. A joke can be waved away, and
 * an unsourced accusation hands the subject an easy win. So: every row below
 * carries the government URL it came from, journalism is labelled as
 * journalism, and where a widely repeated figure could not be traced to a
 * primary source it is marked rather than printed.
 *
 * Where a finding is disputed, the dispute is shown. The Arizona audit below
 * is a documentation finding that the audited agency contests, and the related
 * lawsuit was voluntarily dropped rather than decided — both facts are on the
 * card, because leaving either off would be the kind of thing this file exists
 * to avoid. An earlier draft said "dismissed"; that was wrong and the
 * correction is stated on the card rather than quietly made.
 *
 * Verified August 23, 2026.
 */
window.CBA = (function () {
  "use strict";

  var UPDATED = "August 23, 2026";

  var CHARTER = {
    head: "What this page is, and what it refuses to be",
    body: "Every claim on this page is an official act — a recorded vote, an audited expenditure, a statute, a settlement term — and carries a link to the government record it came from. Where the source is journalism rather than government, it says so.",
    refuse: "What you will not find here: anyone's home, family, staff or personal life; characterisations of motive; unsourced accusations; or any suggestion about what to do to a particular person. Those things are not merely off-limits, they are counterproductive. A voting record is unanswerable. An insult is a gift to the person receiving it.",
    use: "The intended use is the boring one. Look up what your own representatives actually did, check whether your state spent the settlement money on treatment, and if the answer bothers you, say so at a public meeting or in a letter that cites the record."
  };

  /* ================================================================== */
  /* THE MONEY                                                           */
  /* ================================================================== */
  var SETTLEMENT = {
    head: "The opioid settlement money",
    body: "Litigation against opioid manufacturers, distributors and pharmacies produced settlements paying out to states and localities over roughly eighteen years. The distributors and Johnson & Johnson agreement is the largest single piece; the Purdue and Sackler settlement of $7.4 billion took effect on May 1, 2026, front-loaded into its first three years and requiring the public release of more than thirty million documents.",
    total: "$58.58 billion",
    totalNote: "Global total across all defendants as of April 2026 — and stated by its own compiler as a figure that WILL be $58.58 billion once one remaining settlement is finalised, so read it as near-final rather than closed. Compiled by OpioidSettlementTracker.com — an independent project run by attorney Christine Minhee, not a government source. The official per-state allocation figures are published by the settlement administrator, linked below.",
    totalUrl: "https://www.opioidsettlementtracker.com/globalsettlementtracker",
    officialUrl: "https://www.nationalopioidofficialsettlement.com/Home/StateAllocationAmounts",
    purdueUrl: "https://www.michigan.gov/ag/news/press-releases/2026/05/01/purdue-sackler-opioid-settlement-goes-into-effect",
    spend: {
      head: "Where it has actually gone",
      rows: [
        { k: "Received by states and localities in 2024", v: "$6.5B+" },
        { k: "Spent or committed", v: "$2.7B — about 41%" },
        { k: "Went to treatment", v: "$615M (23%)" },
        { k: "Went to harm reduction", v: "$491M (18%)" },
        { k: "Went to recovery services", v: "$450M (17%)" },
        { k: "Untrackable — no public documentation", v: "About 20%" }
      ],
      note: "In sixteen states, more than 30% of settlement spending had no public documentation at all. Roughly 9% of tracked spending went to prevention activities the researchers characterised as having questionable evidence behind them — community concerts, school speakers, mixed martial arts demonstrations.",
      src: "Johns Hopkins Bloomberg School of Public Health, National Settlement Fund Tracking Project (2024) — academic, not government",
      url: "https://opioidprinciples.jhsph.edu/2024-national-settlement-fund-tracking-project-what-we-learned/",
      earlier: "An earlier joint database covering 2022–2023 — KFF Health News with Johns Hopkins and Shatterproof — catalogued more than 7,000 individual expenditures against the $6 billion received in that period, found roughly a third of it had no public accounting, and identified more than $240 million spent on purposes outside the settlements' remediation terms.",
      earlierUrl: "https://kffhealthnews.org/public-health/opioid-settlement-funds-detailed-database-state-county-city-spending/"
    }
  };

  /* Documented findings. `status` distinguishes what has actually been
     established from what is contested — do not flatten these. */
  var FINDINGS = [
    {
      st: "AZ", where: "Arizona", amount: "$50.9 million",
      head: "State auditors could not verify a corrections-department spend",
      status: "contested",
      body: "The Arizona Auditor General's Single Audit Report, released May 13, 2026, found that the Department of Corrections, Rehabilitation and Reentry “spent $50.9 million of opioid settlement monies but lacks records supporting they were spent for approved purposes.” That the spending went to hepatitis C treatment for incarcerated people comes from the Attorney General's own settlement page, not from the audit — the audit does not use the term.",
      quote: "When Agreement monies are not spent as intended, less monies are available for uses that benefit the State and its residents, such as for approved opioid abatement strategies outlined in the Agreement.",
      quoteWho: "Arizona Auditor General",
      dispute: "State this precisely or not at all. The finding is a DOCUMENTATION deficiency, not an adjudicated finding of illegality. The department agreed to a corrective action plan by September 30, 2026 while maintaining the expenditure was appropriate — and its substantive defence belongs here too: it estimates at least 95% of the inmates treated contracted hepatitis C through intravenous opioid use. Separately, the Attorney General's 2024 suit over a larger legislative transfer did not fail on the merits. After a judge dissolved the order blocking the transfer, the Attorney General VOLUNTARILY DROPPED the case in June 2024, and the judge's stated reasoning went to whether an Attorney General can bind how the state spends money through a litigation settlement — not to the evidence. Anyone describing that as a court rejecting the claim is overstating it. So was Clapback, until this was corrected.",
      context: "Arizona received $1.14 billion in national settlements. Reporting by KJZZ, Arizona's public radio station, describes roughly $150 million redirected by the Legislature and Governor to the prison system, with a further $40 million proposed.",
      src: "The $50.9M finding: Arizona Auditor General, Single Audit Report (May 13, 2026) — official. The hepatitis C characterisation: Arizona Attorney General's One Arizona page — official. The legislative transfers and the dropped lawsuit: KJZZ — journalism, not government.",
      url: "https://npr.brightspotcdn.com/19/a2/9720c5c14c6db3a36a60fad4a869/single-audit-report-state-of-arizona-20260513.pdf",
      url2: "https://www.azag.gov/issues/opioids/one-arizona-agreement/state",
      url3: "https://www.kjzz.org/news/2024-06-28/mayes-drops-lawsuit-over-opioid-settlement-funds-in-arizona-budget"
    },
    {
      st: "NJ", where: "Irvington Township, New Jersey", amount: "$632,502.16",
      head: "A state comptroller itemised two “awareness” concerts",
      status: "established",
      body: "The New Jersey Office of the State Comptroller found in July 2025 that Irvington Township spent $632,502.16 in opioid settlement funds on two Opioid Awareness Day concerts. The itemisation is the part worth reading: $368,500 on entertainment and musical performances, $115,398 on billboard advertising, $53,525 on additional promotional materials, a separate $16,000 on mobile billboards featuring the Mayor, $34,445 on t-shirts, $29,161 on food vending equipment including popcorn and cotton candy machines, $12,648 on luxury VIP trailers for performers, and $11,000 on generators.",
      dispute: "The Comptroller also found the spending decisions were made in a single directors' meeting with no health experts consulted, and identified a conflict of interest: businesses owned by or connected to a township employee were hired through a non-public, non-competitive process that the same employee controlled, while he drew roughly $180,000 in salary across 2021–24.",
      src: "New Jersey Office of the State Comptroller (July 8, 2025) — official",
      url: "https://www.nj.gov/comptroller/reports/2025/approved/20250708.shtml"
    },
    {
      st: null, where: "Multiple states and towns", amount: "$61 million+",
      head: "Settlement money spent on law enforcement equipment",
      status: "journalism",
      body: "Reporting by KFF Health News, published November 2025, identified more than $61 million of 2024 settlement spending going to law-enforcement purposes. Among the itemised examples: about $12,000 in Alexandria, Indiana for rifle suppressors; about $21,000 in Mooresville, Indiana for Tasers; about $49,000 in Hardy County, West Virginia for body cameras and Tasers; about $70,000 in Lewisburg, West Virginia for a drug task force officer, guns, vehicles and car window tinting; more than $67,000 in Oak Hill, West Virginia for a drone and surveillance cameras; and about $15,000 in Clarkdale, Arizona for drones.",
      dispute: "Whether these purchases fall inside the settlements' abatement terms is genuinely arguable in some cases and plainly not in others — and the settlements themselves permit some law-enforcement-adjacent spending. Colorado, Indiana, California, Kansas and Virginia have issued guidance restricting equipment purchases with these funds.",
      src: "KFF Health News (November 3, 2025) — journalism, not government",
      url: "https://kffhealthnews.org/news/article/opioid-settlements-law-enforcement-spending-states-towns-guns-narcan/"
    }
  ];

  var TRANSPARENCY = {
    head: "Twelve states promised full transparency. Seven delivered.",
    body: "An analysis by KFF Health News with OpioidSettlementTracker.com tested twelve states that had made written commitments to report 100% of their settlement spending publicly. The test had three parts: are specific dollar amounts stated, can a member of the public actually find the report by searching for it, and are vendors and uses described. Seven of the twelve passed.",
    states: ["Arizona", "Colorado", "Delaware", "Idaho", "Massachusetts", "Minnesota", "Missouri", "New Hampshire", "New Jersey", "Oregon", "South Carolina", "Utah"],
    honest: "Clapback shows the twelve states that made the promise but NOT which seven passed. The breakdown is published inside a graphic rather than in text, and three separate attempts to read it produced conflicting assignments. Publishing a state in the wrong column would be exactly the sort of error this page exists to avoid, so the headline stands and the individual assignments do not. Read the article's graphic yourself if you need them.",
    src: "KFF Health News and OpioidSettlementTracker.com (November 2024) — journalism",
    url: "https://kffhealthnews.org/news/article/state-opioid-settlement-funds-transparency-update/",
    everything: "https://www.opioidsettlementtracker.com/everything",
    nashp: "https://nashp.org/state-tracker/state-opioid-settlement-spending-decisions/"
  };

  /* ================================================================== */
  /* THE VOTES — official roll calls only                                */
  /* ================================================================== */
  var VOTES = [
    {
      bill: "H.R. 1 (2025)", n: "The 2025 reconciliation law — Medicaid provisions",
      what: "A budget reconciliation package containing substantial changes to Medicaid, the largest single payer for substance use disorder treatment in the United States.",
      rows: [
        { ch: "Senate", date: "July 1, 2025", tally: "50–50, Vice President breaking the tie", u: "https://www.senate.gov/legislative/LIS/roll_call_votes/vote1191/vote_119_1_00372.htm" },
        { ch: "House", date: "July 3, 2025", tally: "218–214 (R 218–2, D 0–212)", u: "https://clerk.house.gov/Votes/2025190" }
      ],
      honest: "One vote, many subjects. This was an omnibus reconciliation bill and a member's vote cannot honestly be described as a vote specifically about addiction treatment. What it is: a recorded position on a package whose Medicaid provisions affect who can pay for that treatment.",
      billUrl: "https://www.congress.gov/bill/119th-congress/house-bill/1/actions"
    },
    {
      bill: "H.R. 2483", n: "SUPPORT for Patients and Communities Reauthorization Act of 2025",
      what: "Reauthorised the main federal addiction-response statute. Enables first responders to access and administer naloxone, expands treatment for pregnant and postpartum women, strengthens state prescription drug monitoring, and continues funding for Comprehensive Opioid Recovery Centers. Signed into law.",
      rows: [
        { ch: "House", date: "June 4, 2025", tally: "366–57 (R 188–27, D 178–30)", u: "https://clerk.house.gov/Votes/2025151" },
        { ch: "Senate", date: "September 18, 2025", tally: "Passed — no roll call recorded", u: "https://www.congress.gov/bill/119th-congress/house-bill/2483/all-actions" }
      ],
      honest: "The interesting thing here is not the passage — it is the delay. A near-identical reauthorisation passed the House 386–37 in December 2023 and then died in the Senate, leaving the underlying authorities lapsed for the better part of two years before this vehicle carried them through.",
      prior: "https://clerk.house.gov/Votes/2023715",
      billUrl: "https://www.congress.gov/bill/119th-congress/house-bill/2483/all-actions"
    },
    {
      bill: "H.R. 27 / S. 331", n: "HALT Fentanyl Act",
      what: "Made class-wide scheduling of fentanyl-related substances permanent.",
      rows: [
        { ch: "House", date: "February 6, 2025", tally: "312–108 (R 214–1, D 98–107)", u: "https://clerk.house.gov/Votes/202533" },
        { ch: "Senate", date: "March 14, 2025", tally: "84–16", u: "https://www.senate.gov/legislative/LIS/roll_call_votes/vote1191/vote_119_1_00127.htm" }
      ],
      honest: "This is the roll call worth actually reading, because it is the one where the party lines break. House Democrats split almost exactly down the middle, 98 to 107. Both sides of that split were arguing about the same evidence — whether class-wide scheduling reduces overdose deaths or mainly increases sentences. If you want to know what your own representative thinks about drug policy, this vote tells you more than any of the others.",
      billUrl: "https://www.congress.gov/bill/119th-congress/senate-bill/331"
    }
  ];

  var LOOKUP = {
    head: "Look up your own representatives",
    body: "The point of the votes above is not the national tally. It is finding out what the person who represents you did. These are the official government tools — Clapback links them and never queries them.",
    links: [
      { n: "Find your Representative", t: "Official House lookup by ZIP code, with a link to the member's own site.", u: "https://www.house.gov/representatives/find-your-representative" },
      { n: "Your Senators", t: "Official Senate contact directory, by state.", u: "https://www.senate.gov/senators/senators-contact.htm" },
      { n: "Find your member on Congress.gov", t: "Sponsored and cosponsored legislation, committee assignments, full profile.", u: "https://www.congress.gov/members/find-your-member" },
      { n: "House roll call votes by year", t: "Every recorded House vote, official Clerk of the House.", u: "https://clerk.house.gov/evs/2025/index.asp" },
      { n: "Senate roll call votes", t: "Every recorded Senate vote, official.", u: "https://www.senate.gov/legislative/votes_new.htm" }
    ],
    honest: "One genuine limitation. Congress.gov organises member pages around legislation they sponsored, not around every vote they cast — there is no official “here is this member's complete voting record” page. To reconstruct one you need the roll-call lists above, or a non-governmental aggregator such as GovTrack. Clapback flags that rather than pretending the official tools do something they do not."
  };

  var MONEY = {
    head: "Industry money is public. Here is where it actually lives.",
    body: "Campaign contributions are filed with the Federal Election Commission and lobbying spending is filed with the Senate under the Lobbying Disclosure Act. Both are searchable by anyone, for free, and both are the actual system of record — aggregator sites are compiled FROM these filings.",
    links: [
      { n: "FEC — individual contributions", t: "Searchable by contributor employer and occupation, which is how contributions get attributed to an industry. The primary source.", u: "https://www.fec.gov/data/receipts/individual-contributions/" },
      { n: "FEC — browse all data", t: "Candidates, committees, spending.", u: "https://www.fec.gov/data/browse-data/" },
      { n: "Senate Lobbying Disclosure Act database", t: "Every registered lobbying filing. The statutory source for all lobbying totals you see quoted anywhere.", u: "https://lda.gov/system/public/" },
      { n: "OpenSecrets — pharmaceuticals & health products", t: "A non-governmental aggregator that compiles FEC and LDA filings into an industry view. Useful, but a secondary source.", u: "https://www.opensecrets.org/industries/summary?ind=H04" }
    ],
    figures: "Pharmaceutical and health products lobbying ran $121.4 million in the first quarter of 2025 and $105.4 million in the second — $226.8 million across the half year, about $22 million more than the same period in 2024, In the second quarter alone it outspent the next largest sector, electronics, by roughly 38%. That 38% is a quarterly comparison, not a half-year one; Clapback had it attached to the wrong figure until this was corrected.",
    figuresSrc: "OpenSecrets analysis of Senate Lobbying Disclosure Act filings — aggregator, not government",
    caution: "A methodological warning that matters if you are about to quote a number at someone. OpenSecrets' “Pharmaceuticals/Health Products” category is broad: it includes health insurers and device makers alongside drug manufacturers. If you say “pharma gave Senator X this much,” the figure probably includes UnitedHealth and AHIP. Either use the category's full name, or drill into specific manufacturer PACs in the FEC data — where the attribution is exact and nobody can argue with it."
  };

  /* ================================================================== */
  /* STATE POLICY SCORECARD — statute and status, not opinion            */
  /* ================================================================== */
  var NON_EXPANSION = ["AL", "FL", "GA", "KS", "MS", "SC", "TN", "TX", "WI", "WY"];
  var EXPANSION_NOTE = "Ten states have not adopted the Affordable Care Act's Medicaid expansion as of August 2026. Wisconsin is a genuine edge case and is flagged separately wherever it appears: it has not adopted the expansion, but it covers adults to 100% of the federal poverty level through a waiver, so it has no coverage gap. Treating it identically to the other nine would be misleading.";
  var EXPANSION_SRC = "KFF, Status of State Medicaid Expansion Decisions (updated August 21, 2026)";
  var EXPANSION_URL = "https://www.kff.org/medicaid/status-of-state-medicaid-expansion-decisions/";

  var EVIDENCE = {
    head: "Does Medicaid expansion change overdose deaths? Carefully.",
    body: "A study in JAMA Network Open examined 3,109 counties across 49 states and DC from 2001 to 2017. It found Medicaid expansion associated with 6% lower total opioid overdose mortality, 11% lower heroin deaths, and 10% lower deaths involving synthetic opioids other than methadone.",
    against: "And the finding that runs the other way, which Clapback includes because omitting it would be exactly the cherry-picking this page is supposed to avoid: the same study found methadone-related deaths 11% HIGHER in expansion states.",
    limits: "Three limits worth stating before anyone quotes this at a hearing. It establishes association, not causation — the authors' own title says so. The data ends in 2017, before the worst of the illicitly-manufactured fentanyl wave, so it cannot tell you what expansion does under current conditions. And the intervals are Bayesian credible intervals rather than confidence intervals.",
    src: "Kravitz-Wirtz, Davis, Ponicki, Rivera-Aguirre, Marshall, Martins & Cerdá, JAMA Network Open (2020)",
    url: "https://pubmed.ncbi.nlm.nih.gov/31922561/"
  };

  var OVERDOSE = {
    head: "The overdose picture right now",
    body: "An estimated 69,973 people died of drug overdose in the United States in 2025 — down about 14% from 81,313 in 2024, and the third consecutive annual decline. Opioid-involved deaths fell from roughly 55,296 to 44,564.",
    uneven: "The decline is not uniform, and the unevenness is the story. Rhode Island, New York, North Carolina, Alabama and Vermont each fell more than 25%. New Mexico, Arizona and Colorado each rose more than 10%.",
    caveat: "2025 figures are provisional and subject to revision. The 2024 final figure of 79,384 deaths — an age-adjusted rate of 23.1 per 100,000 — differs from the provisional 81,313 for exactly that reason. That final figure comes from NCHS Data Brief No. 549, published January 2026, not from the May 2026 provisional release the rest of this card cites.",
    src: "CDC NCHS — provisional 2025 release (May 13, 2026); final 2024 figures from NCHS Data Brief No. 549 (January 2026)",
    finalUrl: "https://www.cdc.gov/nchs/products/databriefs/db549.htm",
    url: "https://www.cdc.gov/nchs/pressroom/releases/20260513.html",
    stateUrl: "https://www.cdc.gov/nchs/state-stats/deaths/drug-overdose.html"
  };

  var SCORECARD_NOTE = "This scorecard combines four things a state government controls: whether it adopted Medicaid expansion, whether drug checking equipment is legal, whether syringe services programs are authorised by statute, and whether it has a public opioid settlement oversight body. Each is a policy choice on the record. None of them is a judgement about the people who live there.";

  var OVERSIGHT = {
    AZ: "https://www.azag.gov/issues/opioids/one-arizona-agreement/state",
    MN: "https://www.ag.state.mn.us/opioids/SettlementAllocation.asp",
    MS: "https://attorneygenerallynnfitch.com/opioid-settlement-fund-advisory-council/",
    NY: "https://ag.ny.gov/nys-opioid-settlement",
    RI: "https://eohhs.ri.gov/Opioid-Settlement-Advisory-Committee",
    VT: "https://www.healthvermont.gov/alcohol-drugs/public-meetings-comments/opioid-settlement-advisory-committee",
    WI: "https://www.dhs.wisconsin.gov/opioids/settlement-funds.htm"
  };
  var OVERSIGHT_NOTE = "Clapback lists only the state oversight bodies whose official pages it verified directly. Many more exist — this is not a complete roster, and the absence of a state here means Clapback did not verify one, not that none exists. Two catalogues that attempt completeness are linked below.";

  var ACT = {
    head: "If this bothers you, the useful thing to do is dull",
    steps: [
      { n: "Find out what your own state did with its share", t: "Start with your state attorney general's opioid settlement page and your state's oversight council if it has one. Most publish meeting minutes. Most meetings are open, and most are close to empty." },
      { n: "Read the roll call, not the press release", t: "The Clerk of the House and the Senate publish every recorded vote. A member's actual vote is frequently different from the position described in their own newsletter." },
      { n: "Write with the citation in it", t: "A letter that says “on July 3, 2025 you voted for H.R. 1, House roll call 190” is a different object from a letter that says you are disappointed. The first goes in a file. The second goes in a bin." },
      { n: "Show up to the settlement council meeting", t: "This is the single highest-leverage thing on this list and almost nobody does it. These bodies allocate real money, meet publicly, and often take public comment from whoever turns up." },
      { n: "Use the transparency you are owed", t: "If your state promised public reporting and you cannot find it, that is itself the story. State public records laws apply to settlement spending." }
    ],
    close: "None of that is satisfying in the way a good insult is satisfying. It is, however, the version that changes an appropriation."
  };

  return {
    UPDATED: UPDATED, CHARTER: CHARTER,
    SETTLEMENT: SETTLEMENT, FINDINGS: FINDINGS, TRANSPARENCY: TRANSPARENCY,
    VOTES: VOTES, LOOKUP: LOOKUP, MONEY: MONEY,
    NON_EXPANSION: NON_EXPANSION, EXPANSION_NOTE: EXPANSION_NOTE,
    EXPANSION_SRC: EXPANSION_SRC, EXPANSION_URL: EXPANSION_URL,
    EVIDENCE: EVIDENCE, OVERDOSE: OVERDOSE,
    SCORECARD_NOTE: SCORECARD_NOTE, OVERSIGHT: OVERSIGHT, OVERSIGHT_NOTE: OVERSIGHT_NOTE,
    ACT: ACT
  };
})();
